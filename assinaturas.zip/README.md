# Gerador de Assinaturas

### Instalando a aplicação

* git clone
* composer update
* php artisan migrate
* php artisan db:seed
