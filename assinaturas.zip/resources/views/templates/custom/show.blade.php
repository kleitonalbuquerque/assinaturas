
    <!-- ass css -->
    <link rel="stylesheet" href="{{URL::asset('assets/css/ass.css')}}">
    <link rel="stylesheet" href="{{URL::asset('assets/css/show.css')}}">