<!-- header area start -->
            <div class="header-area">
                <div class="row align-items-center">
                    <!-- nav and search button -->
                    <div class="col-md-6 col-sm-8 clearfix">
                        <div class="nav-btn pull-left">
                            <span></span>
                            <span></span>
                            <span></span>
                        </div>
                    </div>                      
                    <div class="col-sm-6 clearfix">
                        <div class="user-profile pull-right">
                            <!-- <img class="avatar user-thumb" src="<?php echo e(URL::asset('assets/images/author/avatar.png')); ?>" alt="avatar"> -->
                            <h4 class="user-name dropdown-toggle" data-toggle="dropdown"><?php echo e(Auth::user()->name); ?> <i class="fa fa-angle-down"></i></h4>
                            <div class="dropdown-menu">
                                <!-- <a class="dropdown-item" href="">Message</a> -->
                                <!-- <a class="dropdown-item" href="">Settings</a> -->
                                <a class="dropdown-item" href="<?php echo e(route('logout')); ?>"
                                   onclick="event.preventDefault();
                                    document.getElementById('logout-form').submit();">
                                    <?php echo e(__('Logout')); ?>                 
                                </a>
                                <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" style="display: none;">
                                    <?php echo csrf_field(); ?>
                                </form>
                            </div>
                        </div>
                        <!-- profile info & task notification -->
                        <div class="col-sm-2 pull-right">
                            <ul class="notification-area pull-left">
                                <!-- <li id="full-view"><i class="ti-fullscreen"></i></li> -->
                                <!-- <li id="full-view-exit"><i class="ti-zoom-out"></i></li> -->
                                <li class="dropdown">
                                    <i class="ti-bell dropdown-toggle" data-toggle="dropdown">
                                        <?php $notifications = app('App\Http\Controllers\DashController'); ?>

                                        <span><?php echo e($notifications->notifications()); ?></span>
                                    </i>
                                    <div class="dropdown-menu bell-notify-box notify-box">
                                        <span class="notify-title">Você tem <?php echo e($notifications->notifications()); ?> novos pedidos <a href="<?php echo e(route('dashbord.index')); ?>">Ver todas</a></span>
                                        <div class="nofity-list">
                                        <?php $pedidos = app('App\Http\Controllers\DashController'); ?>  
                                        <?php if(count($pedidos->pedidos()) > 0): ?>
                                            <?php $__currentLoopData = $pedidos->pedidos(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pedido): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <a href="<?php echo e(route('employees.show', $pedido->id)); ?>" class="notify-item">
                                                    <div class="notify-thumb"><i class="ti-comments-smiley btn-info"></i></div>
                                                    <div class="notify-text">
                                                        <p><?php echo e($pedido->name); ?></p>
                                                        <span><?php echo e($pedido->created_at); ?>/span>
                                                    </div>
                                                </a>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        <?php else: ?>
                                            <div class="container"><div class="col-md-12"><p class="">Não há novas solicitações</p></div></div>
                                        <?php endif; ?>
                                        </div>
                                    </div>
                                </li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
            <!-- header area end --><?php /**PATH /home/kleiton/Projetos/assinaturas/resources/views/templates/srtdash/inc/headarea.blade.php ENDPATH**/ ?>