<!-- page title area start -->
            <div class="page-title-area">
                <div class="row align-items-center">
                    <div class="col-sm-6">
                        <div class="breadcrumbs-area clearfix">
                            <h4 class="page-title pull-left"><?php echo e($title); ?></h4>
                            <ul class="breadcrumbs pull-left">
                                <li><a href="<?php echo e(route('home')); ?>">Home</a></li>
                                <li><a href="<?php echo e(route($active.'.index')); ?>"><?php echo e($title); ?></a></li>
                                <li><span><?php echo e($activeList); ?></span></li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div><?php /**PATH /home/kleiton/Projetos/assinaturas/resources/views/templates/srtdash/inc/pagearea.blade.php ENDPATH**/ ?>