        <!-- sidebar menu area start -->
        <div class="sidebar-menu">
            <div class="sidebar-header">
                <div class="logo">
                    <a href="index.html"><img src="<?php echo e(URL::asset('assets/images/icon/logo.png')); ?>" alt="logo"></a>
                </div>
            </div>
            <div class="main-menu">
                <div class="menu-inner">
                    <nav>
                        <ul class="metismenu" id="menu">
                        <?php if($active == 'dashbord'): ?>
                            <li class="active">
                        <?php else: ?>
                            <li>
                        <?php endif; ?>
                                <a href="<?php echo e(route('dashbord.index')); ?>"><i class="ti-dashboard"></i><span>Pedidos</span></a>
                            </li>
                        <?php if($active == 'companies'): ?>
                            <li class="active">
                        <?php else: ?>
                            <li>
                        <?php endif; ?>
                                <a href="javascript:void(0)" aria-expanded="true"><i class="ti-user"></i><span>Empresas</span></a>
                                <ul class="collapse">
                                <?php if($active == 'companies' && $activeList == 'Listagem'): ?>
                                    <li class="active">
                                <?php else: ?>
                                    <li>
                                <?php endif; ?>
                                        <a href="<?php echo e(route('companies.index')); ?>">Listagem</a></li>
                                <?php if($active == 'companies' && $activeList == 'Cadastro'): ?>
                                    <li class="active">
                                <?php else: ?>
                                    <li>
                                <?php endif; ?>
                                        <a href="<?php echo e(route('companies.create')); ?>">Cadastro</a></li>
                                </ul>
                            </li>
                        <?php if($active == 'employees'): ?>
                            <li class="active">
                        <?php else: ?>
                            <li>
                        <?php endif; ?>
                                <a href="javascript:void(0)" aria-expanded="true"><i class="ti-user"></i><span>Cooperadores</span></a>
                                <ul class="collapse">
                                <?php if($active == 'employees' && $activeList == 'Listagem'): ?>
                                    <li class="active">
                                <?php else: ?>
                                    <li>
                                <?php endif; ?>
                                        <a href="<?php echo e(route('employees.index')); ?>">Listagem</a></li>
                                <?php if($active == 'employees' && $activeList == 'Cadastro'): ?>
                                    <li class="active">
                                <?php else: ?>
                                    <li>
                                <?php endif; ?>
                                        <a href="<?php echo e(route('employees.create')); ?>">Cadastro</a></li>
                                </ul>
                            </li>
                        </ul>
                    </nav>
                </div>
            </div>
        </div>
        <!-- sidebar menu area end --><?php /**PATH /home/kleiton/Projetos/assinaturas/resources/views/templates/srtdash/inc/sidebar.blade.php ENDPATH**/ ?>