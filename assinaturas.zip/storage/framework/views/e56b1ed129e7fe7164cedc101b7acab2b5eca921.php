<?php $__env->startPush('styles'); ?>
    <?php echo $__env->make('templates.srtdash.inc.datatablecss', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopPush(); ?>

<?php $__env->startPush('scripts'); ?>
    <?php echo $__env->make('templates.srtdash.inc.datatablejs', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopPush(); ?>

<?php $__env->startSection('content'); ?>
<div class="row">

    <?php if(isset($errors) && count($errors) > 0): ?>

    <div class="col-md-12 mt-3">
        <div class="alert alert-danger w-100">
           <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <p><?php echo e($error); ?></p>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>

    <?php endif; ?>
    
    <?php if(session()->has('status')): ?>

    <div class="col-md-12 mt-3">
        <div class="alert alert-success w-100">
            <p><?php echo e(session()->get('status')); ?></p>
        </div>
    </div>
    <?php endif; ?>

	<!-- <div class="col-12 mt-5 text-center"><div class="pull-right">{-- $companies->links() --}</div></div> -->

    <!-- data table start -->
    <div class="col-12 mt-5">
        <div class="card">
            <div class="card-body">
                <div class="data-tables">
                    <table id="dataTable" class="table table-hover text-center">
                        <thead class="text-capitalize bg-info">
                            <tr class="text-white">
                                <th>ID</th>
                                <th>Nome</th>
                                <th>Site</th>
                                <th>Telefone</th>
                                <th>Logo</th>
                                <th>Action</th>
                            </tr>
                        </thead>
                        <tbody>
                        <?php $__currentLoopData = $companies; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $company): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <th scope="row"><?php echo e($company->id); ?></th>
                                <td><?php echo e($company->name); ?></td>
                                <td><?php echo e($company->site); ?></td>
                                <td><?php echo e($company->phone); ?></td>
                                <td><img src="<?php echo e(url('uploads/assets/images/companies/'.$company->image)); ?>" class="logocompany"></td>
                                <td>
                                    <ul class="d-flex justify-content-center">
                                        <li class="mr-3"><a href="<?php echo e(route('companies.show', $company->id)); ?>" class="text-secondary text-info" data-toggle="tooltip" data-placement="bottom" title="Visualizar" alt="Visualizar"><i class="fa fa-eye"></i></a></li>
                                        <li class="mr-3"><a href="<?php echo e(route('companies.edit', $company->id)); ?>" class="text-secondary" data-toggle="tooltip" data-placement="bottom" title="Editar" alt="Editar"><i class="fa fa-edit"></i></a></li>
                                        <li>
                                            <?php echo Form::open(['route' => ['companies.destroy', $company->id], 'class' => '', 'method' => 'DELETE']); ?>

                                                <button type="submit" class="text-danger bnt-excluir" data-toggle="tooltip" data-placement="bottom" title="Excluir" alt="Excluir"><i class="ti-trash"></i></button>
                                            <?php echo Form::close(); ?>

                                        </li>
                                    </ul>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
    <!-- data table end -->

</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('templates.srtdash.template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/kleiton/Projetos/assinaturas/resources/views/company/index.blade.php ENDPATH**/ ?>