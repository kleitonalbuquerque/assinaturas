<?php

symlink ("/home/storage/b/4e/bb/datainfo/public_html/assinaturas/storage/app/public", "/home/storage/b/4e/bb/datainfo/public_html/assinaturas/public/storage");

?>