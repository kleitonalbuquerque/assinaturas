<?php

use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;

class CityTableSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
    	// ADD ESTADOS
		DB::table('states')->insert([
			'id' => 1,
			'name' => 'Acre',
			'uf' => 'AC',
		]);
		DB::table('states')->insert([
			'id' => 2,
			'name' => 'Alagoas',
			'uf' => 'AL',
		]);
		DB::table('states')->insert([
			'id' => 3,
			'name' => 'Amazonas',
			'uf' => 'AM',
		]);
		DB::table('states')->insert([
			'id' => 4,
			'name' => 'Amapá',
			'uf' => 'AP',
		]);
		DB::table('states')->insert([
			'id' => 5,
			'name' => 'Bahia',
			'uf' => 'BA',
		]);
		DB::table('states')->insert([
			'id' => 6,
			'name' => 'Ceará',
			'uf' => 'CE',
		]);
		DB::table('states')->insert([
			'id' => 7,
			'name' => 'Distrito Federal',
			'uf' => 'DF',
		]);
		DB::table('states')->insert([
			'id' => 8,
			'name' => 'Espírito Santo',
			'uf' => 'ES',
		]);
		DB::table('states')->insert([
			'id' => 9,
			'name' => 'Goiás',
			'uf' => 'GO',
		]);
		DB::table('states')->insert([
			'id' => 10,
			'name' => 'Maranhão',
			'uf' => 'MA',
		]);
		DB::table('states')->insert([
			'id' => 11,
			'name' => 'Minas Gerais',
			'uf' => 'MG',
		]);
		DB::table('states')->insert([
			'id' => 12,
			'name' => 'Mato Grosso do Sul',
			'uf' => 'MS',
		]);
		DB::table('states')->insert([
			'id' => 13,
			'name' => 'Mato Grosso',
			'uf' => 'MT',
		]);
		DB::table('states')->insert([
			'id' => 14,
			'name' => 'Pará',
			'uf' => 'PA',
		]);
		DB::table('states')->insert([
			'id' => 15,
			'name' => 'Paraíba',
			'uf' => 'PB',
		]);
		DB::table('states')->insert([
			'id' => 16,
			'name' => 'Pernambuco',
			'uf' => 'PE',
		]);
		DB::table('states')->insert([
			'id' => 17,
			'name' => 'Piauí',
			'uf' => 'PI',
		]);
		DB::table('states')->insert([
			'id' => 18,
			'name' => 'Paraná',
			'uf' => 'PR',
		]);
		DB::table('states')->insert([
			'id' => 19,
			'name' => 'Rio de Janeiro',
			'uf' => 'RJ',
		]);
		DB::table('states')->insert([
			'id' => 20,
			'name' => 'Rio Grande do Norte',
			'uf' => 'RN',
		]);
		DB::table('states')->insert([
			'id' => 21,
			'name' => 'Rondônia',
			'uf' => 'RO',
		]);
		DB::table('states')->insert([
			'id' => 22,
			'name' => 'Roraima',
			'uf' => 'RR',
		]);
		DB::table('states')->insert([
			'id' => 23,
			'name' => 'Rio Grande do Sul',
			'uf' => 'RS',
		]);
		DB::table('states')->insert([
			'id' => 24,
			'name' => 'Santa Catarina',
			'uf' => 'SC',
		]);
		DB::table('states')->insert([
			'id' => 25,
			'name' => 'Sergipe',
			'uf' => 'SE',
		]);
		DB::table('states')->insert([
			'id' => 26,
			'name' => 'São Paulo',
			'uf' => 'SP',
		]);
		DB::table('states')->insert([
			'id' => 27,
			'name' => 'Tocantins',
			'uf' => 'TO',
		]);

		// ADD CIDADES
		DB::table('cities')->insert([
			'id' => 1, 
			'name' => 'Afonso Cláudio',
			'state' => 8,
		]);
		DB::table('cities')->insert([
			'id' => 2, 
			'name' => 'Água Doce do Norte',
			'state' => 8,
		]);
		DB::table('cities')->insert([
			'id' => 3, 
			'name' => 'Águia Branca',
			'state' => 8,
		]);
		DB::table('cities')->insert([
			'id' => 4, 
			'name' => 'Alegre',
			'state' => 8,
		]);
		DB::table('cities')->insert([
			'id' => 5, 
			'name' => 'Alfredo Chaves',
			'state' => 8,
		]);
		DB::table('cities')->insert([
			'id' => 6, 
			'name' => 'Alto Rio Novo',
			'state' => 8,
		]);
		DB::table('cities')->insert([
			'id' => 7, 
			'name' => 'Anchieta',
			'state' => 8,
		]);
		DB::table('cities')->insert([
			'id' => 8, 
			'name' => 'Apiacá',
			'state' => 8,
		]);
		DB::table('cities')->insert([
			'id' => 9, 
			'name' => 'Aracruz',
			'state' => 8,
		]);
		DB::table('cities')->insert([
			'id' => 10, 
			'name' => 'Atilio Vivacqua',
			'state' => 8,
		]);
		DB::table('cities')->insert([
			'id' => 11, 
			'name' => 'Baixo Guandu',
			'state' => 8,
		]);
		DB::table('cities')->insert([
			'id' => 12, 
			'name' => 'Barra de São Francisco',
			'state' => 8,
		]);
		DB::table('cities')->insert([
			'id' => 13, 
			'name' => 'Boa Esperança',
			'state' => 8,
		]);
		DB::table('cities')->insert([
			'id' => 14, 
			'name' => 'Bom Jesus do Norte',
			'state' => 8,
		]);
		DB::table('cities')->insert([
			'id' => 15, 
			'name' => 'Brejetuba',
			'state' => 8,
		]);
		DB::table('cities')->insert([
			'id' => 16, 
			'name' => 'Cachoeiro de Itapemirim',
			'state' => 8,
		]);
		DB::table('cities')->insert([
			'id' => 17, 
			'name' => 'Cariacica',
			'state' => 8,
		]);
		DB::table('cities')->insert([
			'id' => 18, 
			'name' => 'Castelo',
			'state' => 8,
		]);
		DB::table('cities')->insert([
			'id' => 19, 
			'name' => 'Colatina',
			'state' => 8,
		]);
		DB::table('cities')->insert([
			'id' => 20, 
			'name' => 'Conceição da Barra',
			'state' => 8,
		]);
		DB::table('cities')->insert([
			'id' => 21, 
			'name' => 'Conceição do Castelo',
			'state' => 8,
		]);
		DB::table('cities')->insert([
			'id' => 22, 
			'name' => 'Divino de São Lourenço',
			'state' => 8,
		]);
		DB::table('cities')->insert([
			'id' => 23, 
			'name' => 'Domingos Martins',
			'state' => 8,
		]);
		DB::table('cities')->insert([
			'id' => 24, 
			'name' => 'Dores do Rio Preto',
			'state' => 8,
		]);
		DB::table('cities')->insert([
			'id' => 25, 
			'name' => 'Ecoporanga',
			'state' => 8,
		]);
		DB::table('cities')->insert([
			'id' => 26, 
			'name' => 'Fundão',
			'state' => 8,
		]);
		DB::table('cities')->insert([
			'id' => 27, 
			'name' => 'Governador Lindenberg',
			'state' => 8,
		]);
		DB::table('cities')->insert([
			'id' => 28, 
			'name' => 'Guaçuí',
			'state' => 8,
		]);
		DB::table('cities')->insert([
			'id' => 29, 
			'name' => 'Guarapari',
			'state' => 8,
		]);
		DB::table('cities')->insert([
			'id' => 30, 
			'name' => 'Ibatiba',
			'state' => 8,
		]);
		DB::table('cities')->insert([
			'id' => 31, 
			'name' => 'Ibiraçu',
			'state' => 8,
		]);
		DB::table('cities')->insert([
			'id' => 32, 
			'name' => 'Ibitirama',
			'state' => 8,
		]);
		DB::table('cities')->insert([
			'id' => 33, 
			'name' => 'Iconha',
			'state' => 8,
		]);
		DB::table('cities')->insert([
			'id' => 34, 
			'name' => 'Irupi',
			'state' => 8,
		]);
		DB::table('cities')->insert([
			'id' => 35, 
			'name' => 'Itaguaçu',
			'state' => 8,
		]);
		DB::table('cities')->insert([
			'id' => 36, 
			'name' => 'Itapemirim',
			'state' => 8,
		]);
		DB::table('cities')->insert([
			'id' => 37, 
			'name' => 'Itarana',
			'state' => 8,
		]);
		DB::table('cities')->insert([
			'id' => 38, 
			'name' => 'Iúna',
			'state' => 8,
		]);
		DB::table('cities')->insert([
			'id' => 39, 
			'name' => 'Jaguaré',
			'state' => 8,
		]);
		DB::table('cities')->insert([
			'id' => 40, 
			'name' => 'Jerônimo Monteiro',
			'state' => 8,
		]);
		DB::table('cities')->insert([
			'id' => 41, 
			'name' => 'João Neiva',
			'state' => 8,
		]);
		DB::table('cities')->insert([
			'id' => 42, 
			'name' => 'Laranja da Terra',
			'state' => 8,
		]);
		DB::table('cities')->insert([
			'id' => 43, 
			'name' => 'Linhares',
			'state' => 8,
		]);
		DB::table('cities')->insert([
			'id' => 44, 
			'name' => 'Mantenópolis',
			'state' => 8,
		]);
		DB::table('cities')->insert([
			'id' => 45, 
			'name' => 'Marataízes',
			'state' => 8,
		]);
		DB::table('cities')->insert([
			'id' => 46, 
			'name' => 'Marechal Floriano',
			'state' => 8,
		]);
		DB::table('cities')->insert([
			'id' => 47, 
			'name' => 'Marilândia',
			'state' => 8,
		]);
		DB::table('cities')->insert([
			'id' => 48, 
			'name' => 'Mimoso do Sul',
			'state' => 8,
		]);
		DB::table('cities')->insert([
			'id' => 49, 
			'name' => 'Montanha',
			'state' => 8,
		]);
		DB::table('cities')->insert([
			'id' => 50, 
			'name' => 'Mucurici',
			'state' => 8,
		]);
		DB::table('cities')->insert([
			'id' => 51, 
			'name' => 'Muniz Freire',
			'state' => 8,
		]);
		DB::table('cities')->insert([
			'id' => 52, 
			'name' => 'Muqui',
			'state' => 8,
		]);
		DB::table('cities')->insert([
			'id' => 53, 
			'name' => 'Nova Venécia',
			'state' => 8,
		]);
		DB::table('cities')->insert([
			'id' => 54, 
			'name' => 'Pancas',
			'state' => 8,
		]);
		DB::table('cities')->insert([
			'id' => 55, 
			'name' => 'Pedro Canário',
			'state' => 8,
		]);
		DB::table('cities')->insert([
			'id' => 56, 
			'name' => 'Pinheiros',
			'state' => 8,
		]);
		DB::table('cities')->insert([
			'id' => 57, 
			'name' => 'Piúma',
			'state' => 8,
		]);
		DB::table('cities')->insert([
			'id' => 58, 
			'name' => 'Ponto Belo',
			'state' => 8,
		]);
		DB::table('cities')->insert([
			'id' => 59, 
			'name' => 'Presidente Kennedy',
			'state' => 8,
		]);
		DB::table('cities')->insert([
			'id' => 60, 
			'name' => 'Rio Bananal',
			'state' => 8,
		]);
		DB::table('cities')->insert([
			'id' => 61, 
			'name' => 'Rio Novo do Sul',
			'state' => 8,
		]);
		DB::table('cities')->insert([
			'id' => 62, 
			'name' => 'Santa Leopoldina',
			'state' => 8,
		]);
		DB::table('cities')->insert([
			'id' => 63, 
			'name' => 'Santa Maria de Jetibá',
			'state' => 8,
		]);
		DB::table('cities')->insert([
			'id' => 64, 
			'name' => 'Santa Teresa',
			'state' => 8,
		]);
		DB::table('cities')->insert([
			'id' => 65, 
			'name' => 'São Domingos do Norte',
			'state' => 8,
		]);
		DB::table('cities')->insert([
			'id' => 66, 
			'name' => 'São Gabriel da Palha',
			'state' => 8,
		]);
		DB::table('cities')->insert([
			'id' => 67, 
			'name' => 'São José do Calçado',
			'state' => 8,
		]);
		DB::table('cities')->insert([
			'id' => 68, 
			'name' => 'São Mateus',
			'state' => 8,
		]);
		DB::table('cities')->insert([
			'id' => 69, 
			'name' => 'São Roque do Canaã',
			'state' => 8,
		]);
		DB::table('cities')->insert([
			'id' => 70, 
			'name' => 'Serra',
			'state' => 8,
		]);
		DB::table('cities')->insert([
			'id' => 71, 
			'name' => 'Sooretama',
			'state' => 8,
		]);
		DB::table('cities')->insert([
			'id' => 72, 
			'name' => 'Vargem Alta',
			'state' => 8,
		]);
		DB::table('cities')->insert([
			'id' => 73, 
			'name' => 'Venda Nova do Imigrante',
			'state' => 8,
		]);
		DB::table('cities')->insert([
			'id' => 74, 
			'name' => 'Viana',
			'state' => 8,
		]);
		DB::table('cities')->insert([
			'id' => 75, 
			'name' => 'Vila Pavão',
			'state' => 8,
		]);
		DB::table('cities')->insert([
			'id' => 76, 
			'name' => 'Vila Valério',
			'state' => 8,
		]);
		DB::table('cities')->insert([
			'id' => 77, 
			'name' => 'Vila Velha',
			'state' => 8,
		]);
		DB::table('cities')->insert([
			'id' => 78, 
			'name' => 'Vitória',
			'state' => 8,
		]);
		DB::table('cities')->insert([
			'id' => 79, 
			'name' => 'Acrelândia',
			'state' => 1,
		]);
		DB::table('cities')->insert([
			'id' => 80, 
			'name' => 'Assis Brasil',
			'state' => 1,
		]);
		DB::table('cities')->insert([
			'id' => 81, 
			'name' => 'Brasiléia',
			'state' => 1,
		]);
		DB::table('cities')->insert([
			'id' => 82, 
			'name' => 'Bujari',
			'state' => 1,
		]);
		DB::table('cities')->insert([
			'id' => 83, 
			'name' => 'Capixaba',
			'state' => 1,
		]);
		DB::table('cities')->insert([
			'id' => 84, 
			'name' => 'Cruzeiro do Sul',
			'state' => 1,
		]);
		DB::table('cities')->insert([
			'id' => 85, 
			'name' => 'Epitaciolândia',
			'state' => 1,
		]);
		DB::table('cities')->insert([
			'id' => 86, 
			'name' => 'Feijó',
			'state' => 1,
		]);
		DB::table('cities')->insert([
			'id' => 87, 
			'name' => 'Jordão',
			'state' => 1,
		]);
		DB::table('cities')->insert([
			'id' => 88, 
			'name' => 'Mâncio Lima',
			'state' => 1,
		]);
		DB::table('cities')->insert([
			'id' => 89, 
			'name' => 'Manoel Urbano',
			'state' => 1,
		]);
		DB::table('cities')->insert([
			'id' => 90, 
			'name' => 'Marechal Thaumaturgo',
			'state' => 1,
		]);
		DB::table('cities')->insert([
			'id' => 91, 
			'name' => 'Plácido de Castro',
			'state' => 1,
		]);
		DB::table('cities')->insert([
			'id' => 92, 
			'name' => 'Porto Acre',
			'state' => 1,
		]);
		DB::table('cities')->insert([
			'id' => 93, 
			'name' => 'Porto Walter',
			'state' => 1,
		]);
		DB::table('cities')->insert([
			'id' => 94, 
			'name' => 'Rio Branco',
			'state' => 1,
		]);
		DB::table('cities')->insert([
			'id' => 95, 
			'name' => 'Rodrigues Alves',
			'state' => 1,
		]);
		DB::table('cities')->insert([
			'id' => 96, 
			'name' => 'Santa Rosa do Purus',
			'state' => 1,
		]);
		DB::table('cities')->insert([
			'id' => 97, 
			'name' => 'Sena Madureira',
			'state' => 1,
		]);
		DB::table('cities')->insert([
			'id' => 98, 
			'name' => 'Senador Guiomard',
			'state' => 1,
		]);
		DB::table('cities')->insert([
			'id' => 99, 
			'name' => 'Tarauacá',
			'state' => 1,
		]);
		DB::table('cities')->insert([
			'id' => 100, 
			'name' => 'Xapuri',
			'state' => 1,
		]);
		DB::table('cities')->insert([
			'id' => 101, 
			'name' => 'Água Branca',
			'state' => 2,
		]);
		DB::table('cities')->insert([
			'id' => 102, 
			'name' => 'Anadia',
			'state' => 2,
		]);
		DB::table('cities')->insert([
			'id' => 103, 
			'name' => 'Arapiraca',
			'state' => 2,
		]);
		DB::table('cities')->insert([
			'id' => 104, 
			'name' => 'Atalaia',
			'state' => 2,
		]);
		DB::table('cities')->insert([
			'id' => 105, 
			'name' => 'Barra de Santo Antônio',
			'state' => 2,
		]);
		DB::table('cities')->insert([
			'id' => 106, 
			'name' => 'Barra de São Miguel',
			'state' => 2,
		]);
		DB::table('cities')->insert([
			'id' => 107, 
			'name' => 'Batalha',
			'state' => 2,
		]);
		DB::table('cities')->insert([
			'id' => 108, 
			'name' => 'Belém',
			'state' => 2,
		]);
		DB::table('cities')->insert([
			'id' => 109, 
			'name' => 'Belo Monte',
			'state' => 2,
		]);
		DB::table('cities')->insert([
			'id' => 110, 
			'name' => 'Boca da Mata',
			'state' => 2,
		]);
		DB::table('cities')->insert([
			'id' => 111, 
			'name' => 'Branquinha',
			'state' => 2,
		]);
		DB::table('cities')->insert([
			'id' => 112, 
			'name' => 'Cacimbinhas',
			'state' => 2,
		]);
		DB::table('cities')->insert([
			'id' => 113, 
			'name' => 'Cajueiro',
			'state' => 2,
		]);
		DB::table('cities')->insert([
			'id' => 114, 
			'name' => 'Campestre',
			'state' => 2,
		]);
		DB::table('cities')->insert([
			'id' => 115, 
			'name' => 'Campo Alegre',
			'state' => 2,
		]);
		DB::table('cities')->insert([
			'id' => 116, 
			'name' => 'Campo Grande',
			'state' => 2,
		]);
		DB::table('cities')->insert([
			'id' => 117, 
			'name' => 'Canapi',
			'state' => 2,
		]);
		DB::table('cities')->insert([
			'id' => 118, 
			'name' => 'Capela',
			'state' => 2,
		]);
		DB::table('cities')->insert([
			'id' => 119, 
			'name' => 'Carneiros',
			'state' => 2,
		]);
		DB::table('cities')->insert([
			'id' => 120, 
			'name' => 'Chã Preta',
			'state' => 2,
		]);
		DB::table('cities')->insert([
			'id' => 121, 
			'name' => 'Coité do Nóia',
			'state' => 2,
		]);
		DB::table('cities')->insert([
			'id' => 122, 
			'name' => 'Colônia Leopoldina',
			'state' => 2,
		]);
		DB::table('cities')->insert([
			'id' => 123, 
			'name' => 'Coqueiro Seco',
			'state' => 2,
		]);
		DB::table('cities')->insert([
			'id' => 124, 
			'name' => 'Coruripe',
			'state' => 2,
		]);
		DB::table('cities')->insert([
			'id' => 125, 
			'name' => 'Craíbas',
			'state' => 2,
		]);
		DB::table('cities')->insert([
			'id' => 126, 
			'name' => 'Delmiro Gouveia',
			'state' => 2,
		]);
		DB::table('cities')->insert([
			'id' => 127, 
			'name' => 'Dois Riachos',
			'state' => 2,
		]);
		DB::table('cities')->insert([
			'id' => 128, 
			'name' => 'Estrela de Alagoas',
			'state' => 2,
		]);
		DB::table('cities')->insert([
			'id' => 129, 
			'name' => 'Feira Grande',
			'state' => 2,
		]);
		DB::table('cities')->insert([
			'id' => 130, 
			'name' => 'Feliz Deserto',
			'state' => 2,
		]);
		DB::table('cities')->insert([
			'id' => 131, 
			'name' => 'Flexeiras',
			'state' => 2,
		]);
		DB::table('cities')->insert([
			'id' => 132, 
			'name' => 'Girau do Ponciano',
			'state' => 2,
		]);
		DB::table('cities')->insert([
			'id' => 133, 
			'name' => 'Ibateguara',
			'state' => 2,
		]);
		DB::table('cities')->insert([
			'id' => 134, 
			'name' => 'Igaci',
			'state' => 2,
		]);
		DB::table('cities')->insert([
			'id' => 135, 
			'name' => 'Igreja Nova',
			'state' => 2,
		]);
		DB::table('cities')->insert([
			'id' => 136, 
			'name' => 'Inhapi',
			'state' => 2,
		]);
		DB::table('cities')->insert([
			'id' => 137, 
			'name' => 'Jacaré dos Homens',
			'state' => 2,
		]);
		DB::table('cities')->insert([
			'id' => 138, 
			'name' => 'Jacuípe',
			'state' => 2,
		]);
		DB::table('cities')->insert([
			'id' => 139, 
			'name' => 'Japaratinga',
			'state' => 2,
		]);
		DB::table('cities')->insert([
			'id' => 140, 
			'name' => 'Jaramataia',
			'state' => 2,
		]);
		DB::table('cities')->insert([
			'id' => 141, 
			'name' => 'Jequiá da Praia',
			'state' => 2,
		]);
		DB::table('cities')->insert([
			'id' => 142, 
			'name' => 'Joaquim Gomes',
			'state' => 2,
		]);
		DB::table('cities')->insert([
			'id' => 143, 
			'name' => 'Jundiá',
			'state' => 2,
		]);
		DB::table('cities')->insert([
			'id' => 144, 
			'name' => 'Junqueiro',
			'state' => 2,
		]);
		DB::table('cities')->insert([
			'id' => 145, 
			'name' => 'Lagoa da Canoa',
			'state' => 2,
		]);
		DB::table('cities')->insert([
			'id' => 146, 
			'name' => 'Limoeiro de Anadia',
			'state' => 2,
		]);
		DB::table('cities')->insert([
			'id' => 147, 
			'name' => 'Maceió',
			'state' => 2,
		]);
		DB::table('cities')->insert([
			'id' => 148, 
			'name' => 'Major Isidoro',
			'state' => 2,
		]);
		DB::table('cities')->insert([
			'id' => 149, 
			'name' => 'Mar Vermelho',
			'state' => 2,
		]);
		DB::table('cities')->insert([
			'id' => 150, 
			'name' => 'Maragogi',
			'state' => 2,
		]);
		DB::table('cities')->insert([
			'id' => 151, 
			'name' => 'Maravilha',
			'state' => 2,
		]);
		DB::table('cities')->insert([
			'id' => 152, 
			'name' => 'Marechal Deodoro',
			'state' => 2,
		]);
		DB::table('cities')->insert([
			'id' => 153, 
			'name' => 'Maribondo',
			'state' => 2,
		]);
		DB::table('cities')->insert([
			'id' => 154, 
			'name' => 'Mata Grande',
			'state' => 2,
		]);
		DB::table('cities')->insert([
			'id' => 155, 
			'name' => 'Matriz de Camaragibe',
			'state' => 2,
		]);
		DB::table('cities')->insert([
			'id' => 156, 
			'name' => 'Messias',
			'state' => 2,
		]);
		DB::table('cities')->insert([
			'id' => 157, 
			'name' => 'Minador do Negrão',
			'state' => 2,
		]);
		DB::table('cities')->insert([
			'id' => 158, 
			'name' => 'Monteirópolis',
			'state' => 2,
		]);
		DB::table('cities')->insert([
			'id' => 159, 
			'name' => 'Murici',
			'state' => 2,
		]);
		DB::table('cities')->insert([
			'id' => 160, 
			'name' => 'Novo Lino',
			'state' => 2,
		]);
		DB::table('cities')->insert([
			'id' => 161, 
			'name' => 'Olho d`Água das Flores',
			'state' => 2,
		]);
		DB::table('cities')->insert([
			'id' => 162, 
			'name' => 'Olho d`Água do Casado',
			'state' => 2,
		]);
		DB::table('cities')->insert([
			'id' => 163, 
			'name' => 'Olho d`Água Grande',
			'state' => 2,
		]);
		DB::table('cities')->insert([
			'id' => 164, 
			'name' => 'Olivença',
			'state' => 2,
		]);
		DB::table('cities')->insert([
			'id' => 165, 
			'name' => 'Ouro Branco',
			'state' => 2,
		]);
		DB::table('cities')->insert([
			'id' => 166, 
			'name' => 'Palestina',
			'state' => 2,
		]);
		DB::table('cities')->insert([
			'id' => 167, 
			'name' => 'Palmeira dos Índios',
			'state' => 2,
		]);
		DB::table('cities')->insert([
			'id' => 168, 
			'name' => 'Pão de Açúcar',
			'state' => 2,
		]);
		DB::table('cities')->insert([
			'id' => 169, 
			'name' => 'Pariconha',
			'state' => 2,
		]);
		DB::table('cities')->insert([
			'id' => 170, 
			'name' => 'Paripueira',
			'state' => 2,
		]);
		DB::table('cities')->insert([
			'id' => 171, 
			'name' => 'Passo de Camaragibe',
			'state' => 2,
		]);
		DB::table('cities')->insert([
			'id' => 172, 
			'name' => 'Paulo Jacinto',
			'state' => 2,
		]);
		DB::table('cities')->insert([
			'id' => 173, 
			'name' => 'Penedo',
			'state' => 2,
		]);
		DB::table('cities')->insert([
			'id' => 174, 
			'name' => 'Piaçabuçu',
			'state' => 2,
		]);
		DB::table('cities')->insert([
			'id' => 175, 
			'name' => 'Pilar',
			'state' => 2,
		]);
		DB::table('cities')->insert([
			'id' => 176, 
			'name' => 'Pindoba',
			'state' => 2,
		]);
		DB::table('cities')->insert([
			'id' => 177, 
			'name' => 'Piranhas',
			'state' => 2,
		]);
		DB::table('cities')->insert([
			'id' => 178, 
			'name' => 'Poço das Trincheiras',
			'state' => 2,
		]);
		DB::table('cities')->insert([
			'id' => 179, 
			'name' => 'Porto Calvo',
			'state' => 2,
		]);
		DB::table('cities')->insert([
			'id' => 180, 
			'name' => 'Porto de Pedras',
			'state' => 2,
		]);
		DB::table('cities')->insert([
			'id' => 181, 
			'name' => 'Porto Real do Colégio',
			'state' => 2,
		]);
		DB::table('cities')->insert([
			'id' => 182, 
			'name' => 'Quebrangulo',
			'state' => 2,
		]);
		DB::table('cities')->insert([
			'id' => 183, 
			'name' => 'Rio Largo',
			'state' => 2,
		]);
		DB::table('cities')->insert([
			'id' => 184, 
			'name' => 'Roteiro',
			'state' => 2,
		]);
		DB::table('cities')->insert([
			'id' => 185, 
			'name' => 'Santa Luzia do Norte',
			'state' => 2,
		]);
		DB::table('cities')->insert([
			'id' => 186, 
			'name' => 'Santana do Ipanema',
			'state' => 2,
		]);
		DB::table('cities')->insert([
			'id' => 187, 
			'name' => 'Santana do Mundaú',
			'state' => 2,
		]);
		DB::table('cities')->insert([
			'id' => 188, 
			'name' => 'São Brás',
			'state' => 2,
		]);
		DB::table('cities')->insert([
			'id' => 189, 
			'name' => 'São José da Laje',
			'state' => 2,
		]);
		DB::table('cities')->insert([
			'id' => 190, 
			'name' => 'São José da Tapera',
			'state' => 2,
		]);
		DB::table('cities')->insert([
			'id' => 191, 
			'name' => 'São Luís do Quitunde',
			'state' => 2,
		]);
		DB::table('cities')->insert([
			'id' => 192, 
			'name' => 'São Miguel dos Campos',
			'state' => 2,
		]);
		DB::table('cities')->insert([
			'id' => 193, 
			'name' => 'São Miguel dos Milagres',
			'state' => 2,
		]);
		DB::table('cities')->insert([
			'id' => 194, 
			'name' => 'São Sebastião',
			'state' => 2,
		]);
		DB::table('cities')->insert([
			'id' => 195, 
			'name' => 'Satuba',
			'state' => 2,
		]);
		DB::table('cities')->insert([
			'id' => 196, 
			'name' => 'Senador Rui Palmeira',
			'state' => 2,
		]);
		DB::table('cities')->insert([
			'id' => 197, 
			'name' => 'Tanque d`Arca',
			'state' => 2,
		]);
		DB::table('cities')->insert([
			'id' => 198, 
			'name' => 'Taquarana',
			'state' => 2,
		]);
		DB::table('cities')->insert([
			'id' => 199, 
			'name' => 'Teotônio Vilela',
			'state' => 2,
		]);
		DB::table('cities')->insert([
			'id' => 200, 
			'name' => 'Traipu',
			'state' => 2,
		]);
		DB::table('cities')->insert([
			'id' => 201, 
			'name' => 'União dos Palmares',
			'state' => 2,
		]);
		DB::table('cities')->insert([
			'id' => 202, 
			'name' => 'Viçosa',
			'state' => 2,
		]);
		DB::table('cities')->insert([
			'id' => 203, 
			'name' => 'Amapá',
			'state' => 4,
		]);
		DB::table('cities')->insert([
			'id' => 204, 
			'name' => 'Calçoene',
			'state' => 4,
		]);
		DB::table('cities')->insert([
			'id' => 205, 
			'name' => 'Cutias',
			'state' => 4,
		]);
		DB::table('cities')->insert([
			'id' => 206, 
			'name' => 'Ferreira Gomes',
			'state' => 4,
		]);
		DB::table('cities')->insert([
			'id' => 207, 
			'name' => 'Itaubal',
			'state' => 4,
		]);
		DB::table('cities')->insert([
			'id' => 208, 
			'name' => 'Laranjal do Jari',
			'state' => 4,
		]);
		DB::table('cities')->insert([
			'id' => 209, 
			'name' => 'Macapá',
			'state' => 4,
		]);
		DB::table('cities')->insert([
			'id' => 210, 
			'name' => 'Mazagão',
			'state' => 4,
		]);
		DB::table('cities')->insert([
			'id' => 211, 
			'name' => 'Oiapoque',
			'state' => 4,
		]);
		DB::table('cities')->insert([
			'id' => 212, 
			'name' => 'Pedra Branca do Amaparí',
			'state' => 4,
		]);
		DB::table('cities')->insert([
			'id' => 213, 
			'name' => 'Porto Grande',
			'state' => 4,
		]);
		DB::table('cities')->insert([
			'id' => 214, 
			'name' => 'Pracuúba',
			'state' => 4,
		]);
		DB::table('cities')->insert([
			'id' => 215, 
			'name' => 'Santana',
			'state' => 4,
		]);
		DB::table('cities')->insert([
			'id' => 216, 
			'name' => 'Serra do Navio',
			'state' => 4,
		]);
		DB::table('cities')->insert([
			'id' => 217, 
			'name' => 'Tartarugalzinho',
			'state' => 4,
		]);
		DB::table('cities')->insert([
			'id' => 218, 
			'name' => 'Vitória do Jari',
			'state' => 4,
		]);
		DB::table('cities')->insert([
			'id' => 219, 
			'name' => 'Alvarães',
			'state' => 3,
		]);
		DB::table('cities')->insert([
			'id' => 220, 
			'name' => 'Amaturá',
			'state' => 3,
		]);
		DB::table('cities')->insert([
			'id' => 221, 
			'name' => 'Anamã',
			'state' => 3,
		]);
		DB::table('cities')->insert([
			'id' => 222, 
			'name' => 'Anori',
			'state' => 3,
		]);
		DB::table('cities')->insert([
			'id' => 223, 
			'name' => 'Apuí',
			'state' => 3,
		]);
		DB::table('cities')->insert([
			'id' => 224, 
			'name' => 'Atalaia do Norte',
			'state' => 3,
		]);
		DB::table('cities')->insert([
			'id' => 225, 
			'name' => 'Autazes',
			'state' => 3,
		]);
		DB::table('cities')->insert([
			'id' => 226, 
			'name' => 'Barcelos',
			'state' => 3,
		]);
		DB::table('cities')->insert([
			'id' => 227, 
			'name' => 'Barreirinha',
			'state' => 3,
		]);
		DB::table('cities')->insert([
			'id' => 228, 
			'name' => 'Benjamin Constant',
			'state' => 3,
		]);
		DB::table('cities')->insert([
			'id' => 229, 
			'name' => 'Beruri',
			'state' => 3,
		]);
		DB::table('cities')->insert([
			'id' => 230, 
			'name' => 'Boa Vista do Ramos',
			'state' => 3,
		]);
		DB::table('cities')->insert([
			'id' => 231, 
			'name' => 'Boca do Acre',
			'state' => 3,
		]);
		DB::table('cities')->insert([
			'id' => 232, 
			'name' => 'Borba',
			'state' => 3,
		]);
		DB::table('cities')->insert([
			'id' => 233, 
			'name' => 'Caapiranga',
			'state' => 3,
		]);
		DB::table('cities')->insert([
			'id' => 234, 
			'name' => 'Canutama',
			'state' => 3,
		]);
		DB::table('cities')->insert([
			'id' => 235, 
			'name' => 'Carauari',
			'state' => 3,
		]);
		DB::table('cities')->insert([
			'id' => 236, 
			'name' => 'Careiro',
			'state' => 3,
		]);
		DB::table('cities')->insert([
			'id' => 237, 
			'name' => 'Careiro da Várzea',
			'state' => 3,
		]);
		DB::table('cities')->insert([
			'id' => 238, 
			'name' => 'Coari',
			'state' => 3,
		]);
		DB::table('cities')->insert([
			'id' => 239, 
			'name' => 'Codajás',
			'state' => 3,
		]);
		DB::table('cities')->insert([
			'id' => 240, 
			'name' => 'Eirunepé',
			'state' => 3,
		]);
		DB::table('cities')->insert([
			'id' => 241, 
			'name' => 'Envira',
			'state' => 3,
		]);
		DB::table('cities')->insert([
			'id' => 242, 
			'name' => 'Fonte Boa',
			'state' => 3,
		]);
		DB::table('cities')->insert([
			'id' => 243, 
			'name' => 'Guajará',
			'state' => 3,
		]);
		DB::table('cities')->insert([
			'id' => 244, 
			'name' => 'Humaitá',
			'state' => 3,
		]);
		DB::table('cities')->insert([
			'id' => 245, 
			'name' => 'Ipixuna',
			'state' => 3,
		]);
		DB::table('cities')->insert([
			'id' => 246, 
			'name' => 'Iranduba',
			'state' => 3,
		]);
		DB::table('cities')->insert([
			'id' => 247, 
			'name' => 'Itacoatiara',
			'state' => 3,
		]);
		DB::table('cities')->insert([
			'id' => 248, 
			'name' => 'Itamarati',
			'state' => 3,
		]);
		DB::table('cities')->insert([
			'id' => 249, 
			'name' => 'Itapiranga',
			'state' => 3,
		]);
		DB::table('cities')->insert([
			'id' => 250, 
			'name' => 'Japurá',
			'state' => 3,
		]);
		DB::table('cities')->insert([
			'id' => 251, 
			'name' => 'Juruá',
			'state' => 3,
		]);
		DB::table('cities')->insert([
			'id' => 252, 
			'name' => 'Jutaí',
			'state' => 3,
		]);
		DB::table('cities')->insert([
			'id' => 253, 
			'name' => 'Lábrea',
			'state' => 3,
		]);
		DB::table('cities')->insert([
			'id' => 254, 
			'name' => 'Manacapuru',
			'state' => 3,
		]);
		DB::table('cities')->insert([
			'id' => 255, 
			'name' => 'Manaquiri',
			'state' => 3,
		]);
		DB::table('cities')->insert([
			'id' => 256, 
			'name' => 'Manaus',
			'state' => 3,
		]);
		DB::table('cities')->insert([
			'id' => 257, 
			'name' => 'Manicoré',
			'state' => 3,
		]);
		DB::table('cities')->insert([
			'id' => 258, 
			'name' => 'Maraã',
			'state' => 3,
		]);
		DB::table('cities')->insert([
			'id' => 259, 
			'name' => 'Maués',
			'state' => 3,
		]);
		DB::table('cities')->insert([
			'id' => 260, 
			'name' => 'Nhamundá',
			'state' => 3,
		]);
		DB::table('cities')->insert([
			'id' => 261, 
			'name' => 'Nova Olinda do Norte',
			'state' => 3,
		]);
		DB::table('cities')->insert([
			'id' => 262, 
			'name' => 'Novo Airão',
			'state' => 3,
		]);
		DB::table('cities')->insert([
			'id' => 263, 
			'name' => 'Novo Aripuanã',
			'state' => 3,
		]);
		DB::table('cities')->insert([
			'id' => 264, 
			'name' => 'Parintins',
			'state' => 3,
		]);
		DB::table('cities')->insert([
			'id' => 265, 
			'name' => 'Pauini',
			'state' => 3,
		]);
		DB::table('cities')->insert([
			'id' => 266, 
			'name' => 'Presidente Figueiredo',
			'state' => 3,
		]);
		DB::table('cities')->insert([
			'id' => 267, 
			'name' => 'Rio Preto da Eva',
			'state' => 3,
		]);
		DB::table('cities')->insert([
			'id' => 268, 
			'name' => 'Santa Isabel do Rio Negro',
			'state' => 3,
		]);
		DB::table('cities')->insert([
			'id' => 269, 
			'name' => 'Santo Antônio do Içá',
			'state' => 3,
		]);
		DB::table('cities')->insert([
			'id' => 270, 
			'name' => 'São Gabriel da Cachoeira',
			'state' => 3,
		]);
		DB::table('cities')->insert([
			'id' => 271, 
			'name' => 'São Paulo de Olivença',
			'state' => 3,
		]);
		DB::table('cities')->insert([
			'id' => 272, 
			'name' => 'São Sebastião do Uatumã',
			'state' => 3,
		]);
		DB::table('cities')->insert([
			'id' => 273, 
			'name' => 'Silves',
			'state' => 3,
		]);
		DB::table('cities')->insert([
			'id' => 274, 
			'name' => 'Tabatinga',
			'state' => 3,
		]);
		DB::table('cities')->insert([
			'id' => 275, 
			'name' => 'Tapauá',
			'state' => 3,
		]);
		DB::table('cities')->insert([
			'id' => 276, 
			'name' => 'Tefé',
			'state' => 3,
		]);
		DB::table('cities')->insert([
			'id' => 277, 
			'name' => 'Tonantins',
			'state' => 3,
		]);
		DB::table('cities')->insert([
			'id' => 278, 
			'name' => 'Uarini',
			'state' => 3,
		]);
		DB::table('cities')->insert([
			'id' => 279, 
			'name' => 'Urucará',
			'state' => 3,
		]);
		DB::table('cities')->insert([
			'id' => 280, 
			'name' => 'Urucurituba',
			'state' => 3,
		]);
		DB::table('cities')->insert([
			'id' => 281, 
			'name' => 'Abaíra',
			'state' => 5,
		]);
		DB::table('cities')->insert([
			'id' => 282, 
			'name' => 'Abaré',
			'state' => 5,
		]);
		DB::table('cities')->insert([
			'id' => 283, 
			'name' => 'Acajutiba',
			'state' => 5,
		]);
		DB::table('cities')->insert([
			'id' => 284, 
			'name' => 'Adustina',
			'state' => 5,
		]);
		DB::table('cities')->insert([
			'id' => 285, 
			'name' => 'Água Fria',
			'state' => 5,
		]);
		DB::table('cities')->insert([
			'id' => 286, 
			'name' => 'Aiquara',
			'state' => 5,
		]);
		DB::table('cities')->insert([
			'id' => 287, 
			'name' => 'Alagoinhas',
			'state' => 5,
		]);
		DB::table('cities')->insert([
			'id' => 288, 
			'name' => 'Alcobaça',
			'state' => 5,
		]);
		DB::table('cities')->insert([
			'id' => 289, 
			'name' => 'Almadina',
			'state' => 5,
		]);
		DB::table('cities')->insert([
			'id' => 290, 
			'name' => 'Amargosa',
			'state' => 5,
		]);
		DB::table('cities')->insert([
			'id' => 291, 
			'name' => 'Amélia Rodrigues',
			'state' => 5,
		]);
		DB::table('cities')->insert([
			'id' => 292, 
			'name' => 'América Dourada',
			'state' => 5,
		]);
		DB::table('cities')->insert([
			'id' => 293, 
			'name' => 'Anagé',
			'state' => 5,
		]);
		DB::table('cities')->insert([
			'id' => 294, 
			'name' => 'Andaraí',
			'state' => 5,
		]);
		DB::table('cities')->insert([
			'id' => 295, 
			'name' => 'Andorinha',
			'state' => 5,
		]);
		DB::table('cities')->insert([
			'id' => 296, 
			'name' => 'Angical',
			'state' => 5,
		]);
		DB::table('cities')->insert([
			'id' => 297, 
			'name' => 'Anguera',
			'state' => 5,
		]);
		DB::table('cities')->insert([
			'id' => 298, 
			'name' => 'Antas',
			'state' => 5,
		]);
		DB::table('cities')->insert([
			'id' => 299, 
			'name' => 'Antônio Cardoso',
			'state' => 5,
		]);
		DB::table('cities')->insert([
			'id' => 300, 
			'name' => 'Antônio Gonçalves',
			'state' => 5,
		]);
		DB::table('cities')->insert([
			'id' => 301, 
			'name' => 'Aporá',
			'state' => 5,
		]);
		DB::table('cities')->insert([
			'id' => 302, 
			'name' => 'Apuarema',
			'state' => 5,
		]);
		DB::table('cities')->insert([
			'id' => 303, 
			'name' => 'Araças',
			'state' => 5,
		]);
		DB::table('cities')->insert([
			'id' => 304, 
			'name' => 'Aracatu',
			'state' => 5,
		]);
		DB::table('cities')->insert([
			'id' => 305, 
			'name' => 'Araci',
			'state' => 5,
		]);
		DB::table('cities')->insert([
			'id' => 306, 
			'name' => 'Aramari',
			'state' => 5,
		]);
		DB::table('cities')->insert([
			'id' => 307, 
			'name' => 'Arataca',
			'state' => 5,
		]);
		DB::table('cities')->insert([
			'id' => 308, 
			'name' => 'Aratuípe',
			'state' => 5,
		]);
		DB::table('cities')->insert([
			'id' => 309, 
			'name' => 'Aurelino Leal',
			'state' => 5,
		]);
		DB::table('cities')->insert([
			'id' => 310, 
			'name' => 'Baianópolis',
			'state' => 5,
		]);
		DB::table('cities')->insert([
			'id' => 311, 
			'name' => 'Baixa Grande',
			'state' => 5,
		]);
		DB::table('cities')->insert([
			'id' => 312, 
			'name' => 'Banzaê',
			'state' => 5,
		]);
		DB::table('cities')->insert([
			'id' => 313, 
			'name' => 'Barra',
			'state' => 5,
		]);
		DB::table('cities')->insert([
			'id' => 314, 
			'name' => 'Barra da Estiva',
			'state' => 5,
		]);
		DB::table('cities')->insert([
			'id' => 315, 
			'name' => 'Barra do Choça',
			'state' => 5,
		]);
		DB::table('cities')->insert([
			'id' => 316, 
			'name' => 'Barra do Mendes',
			'state' => 5,
		]);
		DB::table('cities')->insert([
			'id' => 317, 
			'name' => 'Barra do Rocha',
			'state' => 5,
		]);
		DB::table('cities')->insert([
			'id' => 318, 
			'name' => 'Barreiras',
			'state' => 5,
		]);
		DB::table('cities')->insert([
			'id' => 319, 
			'name' => 'Barro Alto',
			'state' => 5,
		]);
		DB::table('cities')->insert([
			'id' => 320, 
			'name' => 'Barro Preto (antigo Gov. Lomanto Jr.)',
			'state' => 5,
		]);
		DB::table('cities')->insert([
			'id' => 321,
			'name' => 'Barrocas',
			'state' => 5,
		]);
		DB::table('cities')->insert([
			'id' => 322, 
			'name' => 'Belmonte',
			'state' => 5,
		]);
		DB::table('cities')->insert([
			'id' => 323, 
			'name' => 'Belo Campo',
			'state' => 5,
		]);
		DB::table('cities')->insert([
			'id' => 324, 
			'name' => 'Biritinga',
			'state' => 5,
		]);
		DB::table('cities')->insert([
			'id' => 325, 
			'name' => 'Boa Nova',
			'state' => 5,
		]);
		DB::table('cities')->insert([
			'id' => 326, 
			'name' => 'Boa Vista do Tupim',
			'state' => 5,
		]);
		DB::table('cities')->insert([
			'id' => 327, 
			'name' => 'Bom Jesus da Lapa',
			'state' => 5,
		]);
		DB::table('cities')->insert([
			'id' => 328, 
			'name' => 'Bom Jesus da Serra',
			'state' => 5,
		]);
		DB::table('cities')->insert([
			'id' => 329, 
			'name' => 'Boninal',
			'state' => 5,
		]);
		DB::table('cities')->insert([
			'id' => 330, 
			'name' => 'Bonito',
			'state' => 5,
		]);
		DB::table('cities')->insert([
			'id' => 331, 
			'name' => 'Boquira',
			'state' => 5,
		]);
		DB::table('cities')->insert([
			'id' => 332, 
			'name' => 'Botuporã',
			'state' => 5,
		]);
		DB::table('cities')->insert([
			'id' => 333, 
			'name' => 'Brejões',
			'state' => 5,
		]);
		DB::table('cities')->insert([
			'id' => 334, 
			'name' => 'Brejolândia',
			'state' => 5,
		]);
		DB::table('cities')->insert([
			'id' => 335, 
			'name' => 'Brotas de Macaúbas',
			'state' => 5,
		]);
		DB::table('cities')->insert([
			'id' => 336, 
			'name' => 'Brumado',
			'state' => 5,
		]);
		DB::table('cities')->insert([
			'id' => 337, 
			'name' => 'Buerarema',
			'state' => 5,
		]);
		DB::table('cities')->insert([
			'id' => 338, 
			'name' => 'Buritirama',
			'state' => 5,
		]);
		DB::table('cities')->insert([
			'id' => 339, 
			'name' => 'Caatiba',
			'state' => 5,
		]);
		DB::table('cities')->insert([
			'id' => 340, 
			'name' => 'Cabaceiras do Paraguaçu',
			'state' => 5,
		]);
		DB::table('cities')->insert([
			'id' => 341, 
			'name' => 'Cachoeira',
			'state' => 5,
		]);
		DB::table('cities')->insert([
			'id' => 342, 
			'name' => 'Caculé',
			'state' => 5,
		]);
		DB::table('cities')->insert([
			'id' => 343, 
			'name' => 'Caém',
			'state' => 5,
		]);
		DB::table('cities')->insert([
			'id' => 344, 
			'name' => 'Caetanos',
			'state' => 5,
		]);
		DB::table('cities')->insert([
			'id' => 345, 
			'name' => 'Caetité',
			'state' => 5,
		]);
		DB::table('cities')->insert([
			'id' => 346, 
			'name' => 'Cafarnaum',
			'state' => 5,
		]);
		DB::table('cities')->insert([
			'id' => 347, 
			'name' => 'Cairu',
			'state' => 5,
		]);
		DB::table('cities')->insert([
			'id' => 348, 
			'name' => 'Caldeirão Grande',
			'state' => 5,
		]);
		DB::table('cities')->insert([
			'id' => 349, 
			'name' => 'Camacan',
			'state' => 5,
		]);
		DB::table('cities')->insert([
			'id' => 350, 
			'name' => 'Camaçari',
			'state' => 5,
		]);
		DB::table('cities')->insert([
			'id' => 351, 
			'name' => 'Camamu',
			'state' => 5,
		]);
		DB::table('cities')->insert([
			'id' => 352, 
			'name' => 'Campo Alegre de Lourdes',
			'state' => 5,
		]);
		DB::table('cities')->insert([
			'id' => 353, 
			'name' => 'Campo Formoso',
			'state' => 5,
		]);
		DB::table('cities')->insert([
			'id' => 354, 
			'name' => 'Canápolis',
			'state' => 5,
		]);
		DB::table('cities')->insert([
			'id' => 355, 
			'name' => 'Canarana',
			'state' => 5,
		]);
		DB::table('cities')->insert([
			'id' => 356, 
			'name' => 'Canavieiras',
			'state' => 5,
		]);
		DB::table('cities')->insert([
			'id' => 357, 
			'name' => 'Candeal',
			'state' => 5,
		]);
		DB::table('cities')->insert([
			'id' => 358, 
			'name' => 'Candeias',
			'state' => 5,
		]);
		DB::table('cities')->insert([
			'id' => 359, 
			'name' => 'Candiba',
			'state' => 5,
		]);
		DB::table('cities')->insert([
			'id' => 360, 
			'name' => 'Cândido Sales',
			'state' => 5,
		]);
		DB::table('cities')->insert([
			'id' => 361, 
			'name' => 'Cansanção',
			'state' => 5,
		]);
		DB::table('cities')->insert([
			'id' => 362, 
			'name' => 'Canudos',
			'state' => 5,
		]);
		DB::table('cities')->insert([
			'id' => 363, 
			'name' => 'Capela do Alto Alegre',
			'state' => 5,
		]);
		DB::table('cities')->insert([
			'id' => 364, 
			'name' => 'Capim Grosso',
			'state' => 5,
		]);
		DB::table('cities')->insert([
			'id' => 365, 
			'name' => 'Caraíbas',
			'state' => 5,
		]);
		DB::table('cities')->insert([
			'id' => 366, 
			'name' => 'Caravelas',
			'state' => 5,
		]);
		DB::table('cities')->insert([
			'id' => 367, 
			'name' => 'Cardeal da Silva',
			'state' => 5,
		]);
		DB::table('cities')->insert([
			'id' => 368, 
			'name' => 'Carinhanha',
			'state' => 5,
		]);
		DB::table('cities')->insert([
			'id' => 369, 
			'name' => 'Casa Nova',
			'state' => 5,
		]);
		DB::table('cities')->insert([
			'id' => 370, 
			'name' => 'Castro Alves',
			'state' => 5,
		]);
		DB::table('cities')->insert([
			'id' => 371, 
			'name' => 'Catolândia',
			'state' => 5,
		]);
		DB::table('cities')->insert([
			'id' => 372, 
			'name' => 'Catu',
			'state' => 5,
		]);
		DB::table('cities')->insert([
			'id' => 373, 
			'name' => 'Caturama',
			'state' => 5,
		]);
		DB::table('cities')->insert([
			'id' => 374, 
			'name' => 'Central',
			'state' => 5,
		]);
		DB::table('cities')->insert([
			'id' => 375, 
			'name' => 'Chorrochó',
			'state' => 5,
		]);
		DB::table('cities')->insert([
			'id' => 376, 
			'name' => 'Cícero Dantas',
			'state' => 5,
		]);
		DB::table('cities')->insert([
			'id' => 377, 
			'name' => 'Cipó',
			'state' => 5,
		]);
		DB::table('cities')->insert([
			'id' => 378, 
			'name' => 'Coaraci',
			'state' => 5,
		]);
		DB::table('cities')->insert([
			'id' => 379, 
			'name' => 'Cocos',
			'state' => 5,
		]);
		DB::table('cities')->insert([
			'id' => 380, 
			'name' => 'Conceição da Feira',
			'state' => 5,
		]);
		DB::table('cities')->insert([
			'id' => 381, 
			'name' => 'Conceição do Almeida',
			'state' => 5,
		]);
		DB::table('cities')->insert([
			'id' => 382, 
			'name' => 'Conceição do Coité',
			'state' => 5,
		]);
		DB::table('cities')->insert([
			'id' => 383, 
			'name' => 'Conceição do Jacuípe',
			'state' => 5,
		]);
		DB::table('cities')->insert([
			'id' => 384, 
			'name' => 'Conde',
			'state' => 5,
		]);
		DB::table('cities')->insert([
			'id' => 385, 
			'name' => 'Condeúba',
			'state' => 5,
		]);
		DB::table('cities')->insert([
			'id' => 386, 
			'name' => 'Contendas do Sincorá',
			'state' => 5,
		]);
		DB::table('cities')->insert([
			'id' => 387, 
			'name' => 'Coração de Maria',
			'state' => 5,
		]);
		DB::table('cities')->insert([
			'id' => 388, 
			'name' => 'Cordeiros',
			'state' => 5,
		]);
		DB::table('cities')->insert([
			'id' => 389, 
			'name' => 'Coribe',
			'state' => 5,
		]);
		DB::table('cities')->insert([
			'id' => 390, 
			'name' => 'Coronel João Sá',
			'state' => 5,
		]);
		DB::table('cities')->insert([
			'id' => 391, 
			'name' => 'Correntina',
			'state' => 5,
		]);
		DB::table('cities')->insert([
			'id' => 392, 
			'name' => 'Cotegipe',
			'state' => 5,
		]);
		DB::table('cities')->insert([
			'id' => 393, 
			'name' => 'Cravolândia',
			'state' => 5,
		]);
		DB::table('cities')->insert([
			'id' => 394, 
			'name' => 'Crisópolis',
			'state' => 5,
		]);
		DB::table('cities')->insert([
			'id' => 395, 
			'name' => 'Cristópolis',
			'state' => 5,
		]);
		DB::table('cities')->insert([
			'id' => 396, 
			'name' => 'Cruz das Almas',
			'state' => 5,
		]);
		DB::table('cities')->insert([
			'id' => 397, 
			'name' => 'Curaçá',
			'state' => 5,
		]);
		DB::table('cities')->insert([
			'id' => 398, 
			'name' => 'Dário Meira',
			'state' => 5,
		]);
		DB::table('cities')->insert([
			'id' => 399, 
			'name' => 'Dias d`Ávila',
			'state' => 5,
		]);
		DB::table('cities')->insert([
			'id' => 400, 
			'name' => 'Dom Basílio',
			'state' => 5,
		]);
		DB::table('cities')->insert([
			'id' => 401, 
			'name' => 'Dom Macedo Costa',
			'state' => 5,
		]);
		DB::table('cities')->insert([
			'id' => 402, 
			'name' => 'Elísio Medrado',
			'state' => 5,
		]);
		DB::table('cities')->insert([
			'id' => 403, 
			'name' => 'Encruzilhada',
			'state' => 5,
		]);
		DB::table('cities')->insert([
			'id' => 404, 
			'name' => 'Entre Rios',
			'state' => 5,
		]);
		DB::table('cities')->insert([
			'id' => 405, 
			'name' => 'Érico Cardoso',
			'state' => 5,
		]);
		DB::table('cities')->insert([
			'id' => 406, 
			'name' => 'Esplanada',
			'state' => 5,
		]);
		DB::table('cities')->insert([
			'id' => 407, 
			'name' => 'Euclides da Cunha',
			'state' => 5,
		]);
		DB::table('cities')->insert([
			'id' => 408, 
			'name' => 'Eunápolis',
			'state' => 5,
		]);
		DB::table('cities')->insert([
			'id' => 409, 
			'name' => 'Fátima',
			'state' => 5,
		]);
		DB::table('cities')->insert([
			'id' => 410, 
			'name' => 'Feira da Mata',
			'state' => 5,
		]);
		DB::table('cities')->insert([
			'id' => 411, 
			'name' => 'Feira de Santana',
			'state' => 5,
		]);
		DB::table('cities')->insert([
			'id' => 412, 
			'name' => 'Filadélfia',
			'state' => 5,
		]);
		DB::table('cities')->insert([
			'id' => 413, 
			'name' => 'Firmino Alves',
			'state' => 5,
		]);
		DB::table('cities')->insert([
			'id' => 414, 
			'name' => 'Floresta Azul',
			'state' => 5,
		]);
		DB::table('cities')->insert([
			'id' => 415, 
			'name' => 'Formosa do Rio Preto',
			'state' => 5,
		]);
		DB::table('cities')->insert([
			'id' => 416, 
			'name' => 'Gandu',
			'state' => 5,
		]);
		DB::table('cities')->insert([
			'id' => 417, 
			'name' => 'Gavião',
			'state' => 5,
		]);
		DB::table('cities')->insert([
			'id' => 418, 
			'name' => 'Gentio do Ouro',
			'state' => 5,
		]);
		DB::table('cities')->insert([
			'id' => 419, 
			'name' => 'Glória',
			'state' => 5,
		]);
		DB::table('cities')->insert([
			'id' => 420, 
			'name' => 'Gongogi',
			'state' => 5,
		]);
		DB::table('cities')->insert([
			'id' => 421, 
			'name' => 'Governador Mangabeira',
			'state' => 5,
		]);
		DB::table('cities')->insert([
			'id' => 422, 
			'name' => 'Guajeru',
			'state' => 5,
		]);
		DB::table('cities')->insert([
			'id' => 423, 
			'name' => 'Guanambi',
			'state' => 5,
		]);
		DB::table('cities')->insert([
			'id' => 424, 
			'name' => 'Guaratinga',
			'state' => 5,
		]);
		DB::table('cities')->insert([
			'id' => 425, 
			'name' => 'Heliópolis',
			'state' => 5,
		]);
		DB::table('cities')->insert([
			'id' => 426, 
			'name' => 'Iaçu',
			'state' => 5,
		]);
		DB::table('cities')->insert([
			'id' => 427, 
			'name' => 'Ibiassucê',
			'state' => 5,
		]);
		DB::table('cities')->insert([
			'id' => 428, 
			'name' => 'Ibicaraí',
			'state' => 5,
		]);
		DB::table('cities')->insert([
			'id' => 429, 
			'name' => 'Ibicoara',
			'state' => 5,
		]);
		DB::table('cities')->insert([
			'id' => 430, 
			'name' => 'Ibicuí',
			'state' => 5,
		]);
		DB::table('cities')->insert([
			'id' => 431, 
			'name' => 'Ibipeba',
			'state' => 5,
		]);
		DB::table('cities')->insert([
			'id' => 432, 
			'name' => 'Ibipitanga',
			'state' => 5,
		]);
		DB::table('cities')->insert([
			'id' => 433, 
			'name' => 'Ibiquera',
			'state' => 5,
		]);
		DB::table('cities')->insert([
			'id' => 434, 
			'name' => 'Ibirapitanga',
			'state' => 5,
		]);
		DB::table('cities')->insert([
			'id' => 435, 
			'name' => 'Ibirapuã',
			'state' => 5,
		]);
		DB::table('cities')->insert([
			'id' => 436, 
			'name' => 'Ibirataia',
			'state' => 5,
		]);
		DB::table('cities')->insert([
			'id' => 437, 
			'name' => 'Ibitiara',
			'state' => 5,
		]);
		DB::table('cities')->insert([
			'id' => 438, 
			'name' => 'Ibititá',
			'state' => 5,
		]);
		DB::table('cities')->insert([
			'id' => 439, 
			'name' => 'Ibotirama',
			'state' => 5,
		]);
		DB::table('cities')->insert([
			'id' => 440, 
			'name' => 'Ichu',
			'state' => 5,
		]);
		DB::table('cities')->insert([
			'id' => 441, 
			'name' => 'Igaporã',
			'state' => 5,
		]);
		DB::table('cities')->insert([
			'id' => 442, 
			'name' => 'Igrapiúna',
			'state' => 5,
		]);
		DB::table('cities')->insert([
			'id' => 443, 
			'name' => 'Iguaí',
			'state' => 5,
		]);
		DB::table('cities')->insert([
			'id' => 444, 
			'name' => 'Ilhéus',
			'state' => 5,
		]);
		DB::table('cities')->insert([
			'id' => 445, 
			'name' => 'Inhambupe',
			'state' => 5,
		]);
		DB::table('cities')->insert([
			'id' => 446, 
			'name' => 'Ipecaetá',
			'state' => 5,
		]);
		DB::table('cities')->insert([
			'id' => 447, 
			'name' => 'Ipiaú',
			'state' => 5,
		]);
		DB::table('cities')->insert([
			'id' => 448, 
			'name' => 'Ipirá',
			'state' => 5,
		]);
		DB::table('cities')->insert([
			'id' => 449, 
			'name' => 'Ipupiara',
			'state' => 5,
		]);
		DB::table('cities')->insert([
			'id' => 450, 
			'name' => 'Irajuba',
			'state' => 5,
		]);
		DB::table('cities')->insert([
			'id' => 451, 
			'name' => 'Iramaia',
			'state' => 5,
		]);
		DB::table('cities')->insert([
			'id' => 452, 
			'name' => 'Iraquara',
			'state' => 5,
		]);
		DB::table('cities')->insert([
			'id' => 453, 
			'name' => 'Irará',
			'state' => 5,
		]);
		DB::table('cities')->insert([
			'id' => 454, 
			'name' => 'Irecê',
			'state' => 5,
		]);
		DB::table('cities')->insert([
			'id' => 455, 
			'name' => 'Itabela',
			'state' => 5,
		]);
		DB::table('cities')->insert([
			'id' => 456, 
			'name' => 'Itaberaba',
			'state' => 5,
		]);
		DB::table('cities')->insert([
			'id' => 457, 
			'name' => 'Itabuna',
			'state' => 5,
		]);
		DB::table('cities')->insert([
			'id' => 458, 
			'name' => 'Itacaré',
			'state' => 5,
		]);
		DB::table('cities')->insert([
			'id' => 459, 
			'name' => 'Itaeté',
			'state' => 5,
		]);
		DB::table('cities')->insert([
			'id' => 460, 
			'name' => 'Itagi',
			'state' => 5,
		]);
		DB::table('cities')->insert([
			'id' => 461, 
			'name' => 'Itagibá',
			'state' => 5,
		]);
		DB::table('cities')->insert([
			'id' => 462, 
			'name' => 'Itagimirim',
			'state' => 5,
		]);
		DB::table('cities')->insert([
			'id' => 463, 
			'name' => 'Itaguaçu da Bahia',
			'state' => 5,
		]);
		DB::table('cities')->insert([
			'id' => 464, 
			'name' => 'Itaju do Colônia',
			'state' => 5,
		]);
		DB::table('cities')->insert([
			'id' => 465, 
			'name' => 'Itajuípe',
			'state' => 5,
		]);
		DB::table('cities')->insert([
			'id' => 466, 
			'name' => 'Itamaraju',
			'state' => 5,
		]);
		DB::table('cities')->insert([
			'id' => 467, 
			'name' => 'Itamari',
			'state' => 5,
		]);
		DB::table('cities')->insert([
			'id' => 468, 
			'name' => 'Itambé',
			'state' => 5,
		]);
		DB::table('cities')->insert([
			'id' => 469, 
			'name' => 'Itanagra',
			'state' => 5,
		]);
		DB::table('cities')->insert([
			'id' => 470, 
			'name' => 'Itanhém',
			'state' => 5,
		]);
		DB::table('cities')->insert([
			'id' => 471, 
			'name' => 'Itaparica',
			'state' => 5,
		]);
		DB::table('cities')->insert([
			'id' => 472, 
			'name' => 'Itapé',
			'state' => 5,
		]);
		DB::table('cities')->insert([
			'id' => 473, 
			'name' => 'Itapebi',
			'state' => 5,
		]);
		DB::table('cities')->insert([
			'id' => 474, 
			'name' => 'Itapetinga',
			'state' => 5,
		]);
		DB::table('cities')->insert([
			'id' => 475, 
			'name' => 'Itapicuru',
			'state' => 5,
		]);
		DB::table('cities')->insert([
			'id' => 476, 
			'name' => 'Itapitanga',
			'state' => 5,
		]);
		DB::table('cities')->insert([
			'id' => 477, 
			'name' => 'Itaquara',
			'state' => 5,
		]);
		DB::table('cities')->insert([
			'id' => 478, 
			'name' => 'Itarantim',
			'state' => 5,
		]);
		DB::table('cities')->insert([
			'id' => 479, 
			'name' => 'Itatim',
			'state' => 5,
		]);
		DB::table('cities')->insert([
			'id' => 480, 
			'name' => 'Itiruçu',
			'state' => 5,
		]);
		DB::table('cities')->insert([
			'id' => 481, 
			'name' => 'Itiúba',
			'state' => 5,
		]);
		DB::table('cities')->insert([
			'id' => 482, 
			'name' => 'Itororó',
			'state' => 5,
		]);
		DB::table('cities')->insert([
			'id' => 483, 
			'name' => 'Ituaçu',
			'state' => 5,
		]);
		DB::table('cities')->insert([
			'id' => 484, 
			'name' => 'Ituberá',
			'state' => 5,
		]);
		DB::table('cities')->insert([
			'id' => 485, 
			'name' => 'Iuiú',
			'state' => 5,
		]);
		DB::table('cities')->insert([
			'id' => 486, 
			'name' => 'Jaborandi',
			'state' => 5,
		]);
		DB::table('cities')->insert([
			'id' => 487, 
			'name' => 'Jacaraci',
			'state' => 5,
		]);
		DB::table('cities')->insert([
			'id' => 488, 
			'name' => 'Jacobina',
			'state' => 5,
		]);
		DB::table('cities')->insert([
			'id' => 489, 
			'name' => 'Jaguaquara',
			'state' => 5,
		]);
		DB::table('cities')->insert([
			'id' => 490, 
			'name' => 'Jaguarari',
			'state' => 5,
		]);
		DB::table('cities')->insert([
			'id' => 491, 
			'name' => 'Jaguaripe',
			'state' => 5,
		]);
		DB::table('cities')->insert([
			'id' => 492, 
			'name' => 'Jandaíra',
			'state' => 5,
		]);
		DB::table('cities')->insert([
			'id' => 493, 
			'name' => 'Jequié',
			'state' => 5,
		]);
		DB::table('cities')->insert([
			'id' => 494, 
			'name' => 'Jeremoabo',
			'state' => 5,
		]);
		DB::table('cities')->insert([
			'id' => 495, 
			'name' => 'Jiquiriçá',
			'state' => 5,
		]);
		DB::table('cities')->insert([
			'id' => 496, 
			'name' => 'Jitaúna',
			'state' => 5,
		]);
		DB::table('cities')->insert([
			'id' => 497, 
			'name' => 'João Dourado',
			'state' => 5,
		]);
		DB::table('cities')->insert([
			'id' => 498, 
			'name' => 'Juazeiro',
			'state' => 5,
		]);
		DB::table('cities')->insert([
			'id' => 499, 
			'name' => 'Jucuruçu',
			'state' => 5,
		]);
		DB::table('cities')->insert([
			'id' => 500, 
			'name' => 'Jussara',
			'state' => 5,
		]);
		DB::table('cities')->insert([
			'id' => 501, 
			'name' => 'Jussari',
			'state' => 5,
		]);
		DB::table('cities')->insert([
			'id' => 502, 
			'name' => 'Jussiape',
			'state' => 5,
		]);
		DB::table('cities')->insert([
			'id' => 503, 
			'name' => 'Lafaiete Coutinho',
			'state' => 5,
		]);
		DB::table('cities')->insert([
			'id' => 504, 
			'name' => 'Lagoa Real',
			'state' => 5,
		]);
		DB::table('cities')->insert([
			'id' => 505, 
			'name' => 'Laje',
			'state' => 5,
		]);
		DB::table('cities')->insert([
			'id' => 506, 
			'name' => 'Lajedão',
			'state' => 5,
		]);
		DB::table('cities')->insert([
			'id' => 507, 
			'name' => 'Lajedinho',
			'state' => 5,
		]);
		DB::table('cities')->insert([
			'id' => 508, 
			'name' => 'Lajedo do Tabocal',
			'state' => 5,
		]);
		DB::table('cities')->insert([
			'id' => 509, 
			'name' => 'Lamarão',
			'state' => 5,
		]);
		DB::table('cities')->insert([
			'id' => 510, 
			'name' => 'Lapão',
			'state' => 5,
		]);
		DB::table('cities')->insert([
			'id' => 511, 
			'name' => 'Lauro de Freitas',
			'state' => 5,
		]);
		DB::table('cities')->insert([
			'id' => 512, 
			'name' => 'Lençóis',
			'state' => 5,
		]);
		DB::table('cities')->insert([
			'id' => 513, 
			'name' => 'Licínio de Almeida',
			'state' => 5,
		]);
		DB::table('cities')->insert([
			'id' => 514, 
			'name' => 'Livramento de Nossa Senhora',
			'state' => 5,
		]);
		DB::table('cities')->insert([
			'id' => 515, 
			'name' => 'Luís Eduardo Magalhães',
			'state' => 5,
		]);
		DB::table('cities')->insert([
			'id' => 516, 
			'name' => 'Macajuba',
			'state' => 5,
		]);
		DB::table('cities')->insert([
			'id' => 517, 
			'name' => 'Macarani',
			'state' => 5,
		]);
		DB::table('cities')->insert([
			'id' => 518, 
			'name' => 'Macaúbas',
			'state' => 5,
		]);
		DB::table('cities')->insert([
			'id' => 519, 
			'name' => 'Macururé',
			'state' => 5,
		]);
		DB::table('cities')->insert([
			'id' => 520, 
			'name' => 'Madre de Deus',
			'state' => 5,
		]);
		DB::table('cities')->insert([
			'id' => 521, 
			'name' => 'Maetinga',
			'state' => 5,
		]);
		DB::table('cities')->insert([
			'id' => 522, 
			'name' => 'Maiquinique',
			'state' => 5,
		]);
		DB::table('cities')->insert([
			'id' => 523, 
			'name' => 'Mairi',
			'state' => 5,
		]);
		DB::table('cities')->insert([
			'id' => 524, 
			'name' => 'Malhada',
			'state' => 5,
		]);
		DB::table('cities')->insert([
			'id' => 525, 
			'name' => 'Malhada de Pedras',
			'state' => 5,
		]);
		DB::table('cities')->insert([
			'id' => 526, 
			'name' => 'Manoel Vitorino',
			'state' => 5,
		]);
		DB::table('cities')->insert([
			'id' => 527, 
			'name' => 'Mansidão',
			'state' => 5,
		]);
		DB::table('cities')->insert([
			'id' => 528, 
			'name' => 'Maracás',
			'state' => 5,
		]);
		DB::table('cities')->insert([
			'id' => 529, 
			'name' => 'Maragogipe',
			'state' => 5,
		]);
		DB::table('cities')->insert([
			'id' => 530, 
			'name' => 'Maraú',
			'state' => 5,
		]);
		DB::table('cities')->insert([
			'id' => 531, 
			'name' => 'Marcionílio Souza',
			'state' => 5,
		]);
		DB::table('cities')->insert([
			'id' => 532, 
			'name' => 'Mascote',
			'state' => 5,
		]);
		DB::table('cities')->insert([
			'id' => 533, 
			'name' => 'Mata de São João',
			'state' => 5,
		]);
		DB::table('cities')->insert([
			'id' => 534, 
			'name' => 'Matina',
			'state' => 5,
		]);
		DB::table('cities')->insert([
			'id' => 535, 
			'name' => 'Medeiros Neto',
			'state' => 5,
		]);
		DB::table('cities')->insert([
			'id' => 536, 
			'name' => 'Miguel Calmon',
			'state' => 5,
		]);
		DB::table('cities')->insert([
			'id' => 537, 
			'name' => 'Milagres',
			'state' => 5,
		]);
		DB::table('cities')->insert([
			'id' => 538, 
			'name' => 'Mirangaba',
			'state' => 5,
		]);
		DB::table('cities')->insert([
			'id' => 539, 
			'name' => 'Mirante',
			'state' => 5,
		]);
		DB::table('cities')->insert([
			'id' => 540, 
			'name' => 'Monte Santo',
			'state' => 5,
		]);
		DB::table('cities')->insert([
			'id' => 541, 
			'name' => 'Morpará',
			'state' => 5,
		]);
		DB::table('cities')->insert([
			'id' => 542, 
			'name' => 'Morro do Chapéu',
			'state' => 5,
		]);
		DB::table('cities')->insert([
			'id' => 543, 
			'name' => 'Mortugaba',
			'state' => 5,
		]);
		DB::table('cities')->insert([
			'id' => 544, 
			'name' => 'Mucugê',
			'state' => 5,
		]);
		DB::table('cities')->insert([
			'id' => 545, 
			'name' => 'Mucuri',
			'state' => 5,
		]);
		DB::table('cities')->insert([
			'id' => 546, 
			'name' => 'Mulungu do Morro',
			'state' => 5,
		]);
		DB::table('cities')->insert([
			'id' => 547, 
			'name' => 'Mundo Novo',
			'state' => 5,
		]);
		DB::table('cities')->insert([
			'id' => 548, 
			'name' => 'Muniz Ferreira',
			'state' => 5,
		]);
		DB::table('cities')->insert([
			'id' => 549, 
			'name' => 'Muquém de São Francisco',
			'state' => 5,
		]);
		DB::table('cities')->insert([
			'id' => 550, 
			'name' => 'Muritiba',
			'state' => 5,
		]);
		DB::table('cities')->insert([
			'id' => 551, 
			'name' => 'Mutuípe',
			'state' => 5,
		]);
		DB::table('cities')->insert([
			'id' => 552, 
			'name' => 'Nazaré',
			'state' => 5,
		]);
		DB::table('cities')->insert([
			'id' => 553, 
			'name' => 'Nilo Peçanha',
			'state' => 5,
		]);
		DB::table('cities')->insert([
			'id' => 554, 
			'name' => 'Nordestina',
			'state' => 5,
		]);
		DB::table('cities')->insert([
			'id' => 555, 
			'name' => 'Nova Canaã',
			'state' => 5,
		]);
		DB::table('cities')->insert([
			'id' => 556, 
			'name' => 'Nova Fátima',
			'state' => 5,
		]);
		DB::table('cities')->insert([
			'id' => 557, 
			'name' => 'Nova Ibiá',
			'state' => 5,
		]);
		DB::table('cities')->insert([
			'id' => 558, 
			'name' => 'Nova Itarana',
			'state' => 5,
		]);
		DB::table('cities')->insert([
			'id' => 559, 
			'name' => 'Nova Redenção',
			'state' => 5,
		]);
		DB::table('cities')->insert([
			'id' => 560, 
			'name' => 'Nova Soure',
			'state' => 5,
		]);
		DB::table('cities')->insert([
			'id' => 561, 
			'name' => 'Nova Viçosa',
			'state' => 5,
		]);
		DB::table('cities')->insert([
			'id' => 562, 
			'name' => 'Novo Horizonte',
			'state' => 5,
		]);
		DB::table('cities')->insert([
			'id' => 563, 
			'name' => 'Novo Triunfo',
			'state' => 5,
		]);
		DB::table('cities')->insert([
			'id' => 564, 
			'name' => 'Olindina',
			'state' => 5,
		]);
		DB::table('cities')->insert([
			'id' => 565, 
			'name' => 'Oliveira dos Brejinhos',
			'state' => 5,
		]);
		DB::table('cities')->insert([
			'id' => 566, 
			'name' => 'Ouriçangas',
			'state' => 5,
		]);
		DB::table('cities')->insert([
			'id' => 567, 
			'name' => 'Ourolândia',
			'state' => 5,
		]);
		DB::table('cities')->insert([
			'id' => 568, 
			'name' => 'Palmas de Monte Alto',
			'state' => 5,
		]);
		DB::table('cities')->insert([
			'id' => 569, 
			'name' => 'Palmeiras',
			'state' => 5,
		]);
		DB::table('cities')->insert([
			'id' => 570, 
			'name' => 'Paramirim',
			'state' => 5,
		]);
		DB::table('cities')->insert([
			'id' => 571, 
			'name' => 'Paratinga',
			'state' => 5,
		]);
		DB::table('cities')->insert([
			'id' => 572, 
			'name' => 'Paripiranga',
			'state' => 5,
		]);
		DB::table('cities')->insert([
			'id' => 573, 
			'name' => 'Pau Brasil',
			'state' => 5,
		]);
		DB::table('cities')->insert([
			'id' => 574, 
			'name' => 'Paulo Afonso',
			'state' => 5,
		]);
		DB::table('cities')->insert([
			'id' => 575, 
			'name' => 'Pé de Serra',
			'state' => 5,
		]);
		DB::table('cities')->insert([
			'id' => 576, 
			'name' => 'Pedrão',
			'state' => 5,
		]);
		DB::table('cities')->insert([
			'id' => 577, 
			'name' => 'Pedro Alexandre',
			'state' => 5,
		]);
		DB::table('cities')->insert([
			'id' => 578, 
			'name' => 'Piatã',
			'state' => 5,
		]);
		DB::table('cities')->insert([
			'id' => 579, 
			'name' => 'Pilão Arcado',
			'state' => 5,
		]);
		DB::table('cities')->insert([
			'id' => 580, 
			'name' => 'Pindaí',
			'state' => 5,
		]);
		DB::table('cities')->insert([
			'id' => 581, 
			'name' => 'Pindobaçu',
			'state' => 5,
		]);
		DB::table('cities')->insert([
			'id' => 582, 
			'name' => 'Pintadas',
			'state' => 5,
		]);
		DB::table('cities')->insert([
			'id' => 583, 
			'name' => 'Piraí do Norte',
			'state' => 5,
		]);
		DB::table('cities')->insert([
			'id' => 584, 
			'name' => 'Piripá',
			'state' => 5,
		]);
		DB::table('cities')->insert([
			'id' => 585, 
			'name' => 'Piritiba',
			'state' => 5,
		]);
		DB::table('cities')->insert([
			'id' => 586, 
			'name' => 'Planaltino',
			'state' => 5,
		]);
		DB::table('cities')->insert([
			'id' => 587, 
			'name' => 'Planalto',
			'state' => 5,
		]);
		DB::table('cities')->insert([
			'id' => 588, 
			'name' => 'Poções',
			'state' => 5,
		]);
		DB::table('cities')->insert([
			'id' => 589, 
			'name' => 'Pojuca',
			'state' => 5,
		]);
		DB::table('cities')->insert([
			'id' => 590, 
			'name' => 'Ponto Novo',
			'state' => 5,
		]);
		DB::table('cities')->insert([
			'id' => 591, 
			'name' => 'Porto Seguro',
			'state' => 5,
		]);
		DB::table('cities')->insert([
			'id' => 592, 
			'name' => 'Potiraguá',
			'state' => 5,
		]);
		DB::table('cities')->insert([
			'id' => 593, 
			'name' => 'Prado',
			'state' => 5,
		]);
		DB::table('cities')->insert([
			'id' => 594, 
			'name' => 'Presidente Dutra',
			'state' => 5,
		]);
		DB::table('cities')->insert([
			'id' => 595, 
			'name' => 'Presidente Jânio Quadros',
			'state' => 5,
		]);
		DB::table('cities')->insert([
			'id' => 596, 
			'name' => 'Presidente Tancredo Neves',
			'state' => 5,
		]);
		DB::table('cities')->insert([
			'id' => 597, 
			'name' => 'Queimadas',
			'state' => 5,
		]);
		DB::table('cities')->insert([
			'id' => 598, 
			'name' => 'Quijingue',
			'state' => 5,
		]);
		DB::table('cities')->insert([
			'id' => 599, 
			'name' => 'Quixabeira',
			'state' => 5,
		]);
		DB::table('cities')->insert([
			'id' => 600, 
			'name' => 'Rafael Jambeiro',
			'state' => 5,
		]);
		DB::table('cities')->insert([
			'id' => 601, 
			'name' => 'Remanso',
			'state' => 5,
		]);
		DB::table('cities')->insert([
			'id' => 602, 
			'name' => 'Retirolândia',
			'state' => 5,
		]);
		DB::table('cities')->insert([
			'id' => 603, 
			'name' => 'Riachão das Neves',
			'state' => 5,
		]);
		DB::table('cities')->insert([
			'id' => 604, 
			'name' => 'Riachão do Jacuípe',
			'state' => 5,
		]);
		DB::table('cities')->insert([
			'id' => 605, 
			'name' => 'Riacho de Santana',
			'state' => 5,
		]);
		DB::table('cities')->insert([
			'id' => 606, 
			'name' => 'Ribeira do Amparo',
			'state' => 5,
		]);
		DB::table('cities')->insert([
			'id' => 607, 
			'name' => 'Ribeira do Pombal',
			'state' => 5,
		]);
		DB::table('cities')->insert([
			'id' => 608, 
			'name' => 'Ribeirão do Largo',
			'state' => 5,
		]);
		DB::table('cities')->insert([
			'id' => 609, 
			'name' => 'Rio de Contas',
			'state' => 5,
		]);
		DB::table('cities')->insert([
			'id' => 610, 
			'name' => 'Rio do Antônio',
			'state' => 5,
		]);
		DB::table('cities')->insert([
			'id' => 611, 
			'name' => 'Rio do Pires',
			'state' => 5,
		]);
		DB::table('cities')->insert([
			'id' => 612, 
			'name' => 'Rio Real',
			'state' => 5,
		]);
		DB::table('cities')->insert([
			'id' => 613, 
			'name' => 'Rodelas',
			'state' => 5,
		]);
		DB::table('cities')->insert([
			'id' => 614, 
			'name' => 'Ruy Barbosa',
			'state' => 5,
		]);
		DB::table('cities')->insert([
			'id' => 615, 
			'name' => 'Salinas da Margarida',
			'state' => 5,
		]);
		DB::table('cities')->insert([
			'id' => 616, 
			'name' => 'Salvador',
			'state' => 5,
		]);
		DB::table('cities')->insert([
			'id' => 617, 
			'name' => 'Santa Bárbara',
			'state' => 5,
		]);
		DB::table('cities')->insert([
			'id' => 618, 
			'name' => 'Santa Brígida',
			'state' => 5,
		]);
		DB::table('cities')->insert([
			'id' => 619, 
			'name' => 'Santa Cruz Cabrália',
			'state' => 5,
		]);
		DB::table('cities')->insert([
			'id' => 620, 
			'name' => 'Santa Cruz da Vitória',
			'state' => 5,
		]);
		DB::table('cities')->insert([
			'id' => 621, 
			'name' => 'Santa Inês',
			'state' => 5,
		]);
		DB::table('cities')->insert([
			'id' => 622, 
			'name' => 'Santa Luzia',
			'state' => 5,
		]);
		DB::table('cities')->insert([
			'id' => 623, 
			'name' => 'Santa Maria da Vitória',
			'state' => 5,
		]);
		DB::table('cities')->insert([
			'id' => 624, 
			'name' => 'Santa Rita de Cássia',
			'state' => 5,
		]);
		DB::table('cities')->insert([
			'id' => 625, 
			'name' => 'Santa Teresinha',
			'state' => 5,
		]);
		DB::table('cities')->insert([
			'id' => 626, 
			'name' => 'Santaluz',
			'state' => 5,
		]);
		DB::table('cities')->insert([
			'id' => 627, 
			'name' => 'Santana',
			'state' => 5,
		]);
		DB::table('cities')->insert([
			'id' => 628, 
			'name' => 'Santanópolis',
			'state' => 5,
		]);
		DB::table('cities')->insert([
			'id' => 629, 
			'name' => 'Santo Amaro',
			'state' => 5,
		]);
		DB::table('cities')->insert([
			'id' => 630, 
			'name' => 'Santo Antônio de Jesus',
			'state' => 5,
		]);
		DB::table('cities')->insert([
			'id' => 631, 
			'name' => 'Santo Estêvão',
			'state' => 5,
		]);
		DB::table('cities')->insert([
			'id' => 632, 
			'name' => 'São Desidério',
			'state' => 5,
		]);
		DB::table('cities')->insert([
			'id' => 633, 
			'name' => 'São Domingos',
			'state' => 5,
		]);
		DB::table('cities')->insert([
			'id' => 634, 
			'name' => 'São Felipe',
			'state' => 5,
		]);
		DB::table('cities')->insert([
			'id' => 635, 
			'name' => 'São Félix',
			'state' => 5,
		]);
		DB::table('cities')->insert([
			'id' => 636, 
			'name' => 'São Félix do Coribe',
			'state' => 5,
		]);
		DB::table('cities')->insert([
			'id' => 637, 
			'name' => 'São Francisco do Conde',
			'state' => 5,
		]);
		DB::table('cities')->insert([
			'id' => 638, 
			'name' => 'São Gabriel',
			'state' => 5,
		]);
		DB::table('cities')->insert([
			'id' => 639, 
			'name' => 'São Gonçalo dos Campos',
			'state' => 5,
		]);
		DB::table('cities')->insert([
			'id' => 640, 
			'name' => 'São José da Vitória',
			'state' => 5,
		]);
		DB::table('cities')->insert([
			'id' => 641, 
			'name' => 'São José do Jacuípe',
			'state' => 5,
		]);
		DB::table('cities')->insert([
			'id' => 642, 
			'name' => 'São Miguel das Matas',
			'state' => 5,
		]);
		DB::table('cities')->insert([
			'id' => 643, 
			'name' => 'São Sebastião do Passé',
			'state' => 5,
		]);
		DB::table('cities')->insert([
			'id' => 644, 
			'name' => 'Sapeaçu',
			'state' => 5,
		]);
		DB::table('cities')->insert([
			'id' => 645, 
			'name' => 'Sátiro Dias',
			'state' => 5,
		]);
		DB::table('cities')->insert([
			'id' => 646, 
			'name' => 'Saubara',
			'state' => 5,
		]);
		DB::table('cities')->insert([
			'id' => 647, 
			'name' => 'Saúde',
			'state' => 5,
		]);
		DB::table('cities')->insert([
			'id' => 648, 
			'name' => 'Seabra',
			'state' => 5,
		]);
		DB::table('cities')->insert([
			'id' => 649, 
			'name' => 'Sebastião Laranjeiras',
			'state' => 5,
		]);
		DB::table('cities')->insert([
			'id' => 650, 
			'name' => 'Senhor do Bonfim',
			'state' => 5,
		]);
		DB::table('cities')->insert([
			'id' => 651, 
			'name' => 'Sento Sé',
			'state' => 5,
		]);
		DB::table('cities')->insert([
			'id' => 652, 
			'name' => 'Serra do Ramalho',
			'state' => 5,
		]);
		DB::table('cities')->insert([
			'id' => 653, 
			'name' => 'Serra Dourada',
			'state' => 5,
		]);
		DB::table('cities')->insert([
			'id' => 654, 
			'name' => 'Serra Preta',
			'state' => 5,
		]);
		DB::table('cities')->insert([
			'id' => 655, 
			'name' => 'Serrinha',
			'state' => 5,
		]);
		DB::table('cities')->insert([
			'id' => 656, 
			'name' => 'Serrolândia',
			'state' => 5,
		]);
		DB::table('cities')->insert([
			'id' => 657, 
			'name' => 'Simões Filho',
			'state' => 5,
		]);
		DB::table('cities')->insert([
			'id' => 658, 
			'name' => 'Sítio do Mato',
			'state' => 5,
		]);
		DB::table('cities')->insert([
			'id' => 659, 
			'name' => 'Sítio do Quinto',
			'state' => 5,
		]);
		DB::table('cities')->insert([
			'id' => 660, 
			'name' => 'Sobradinho',
			'state' => 5,
		]);
		DB::table('cities')->insert([
			'id' => 661, 
			'name' => 'Souto Soares',
			'state' => 5,
		]);
		DB::table('cities')->insert([
			'id' => 662, 
			'name' => 'Tabocas do Brejo Velho',
			'state' => 5,
		]);
		DB::table('cities')->insert([
			'id' => 663, 
			'name' => 'Tanhaçu',
			'state' => 5,
		]);
		DB::table('cities')->insert([
			'id' => 664, 
			'name' => 'Tanque Novo',
			'state' => 5,
		]);
		DB::table('cities')->insert([
			'id' => 665, 
			'name' => 'Tanquinho',
			'state' => 5,
		]);
		DB::table('cities')->insert([
			'id' => 666, 
			'name' => 'Taperoá',
			'state' => 5,
		]);
		DB::table('cities')->insert([
			'id' => 667, 
			'name' => 'Tapiramutá',
			'state' => 5,
		]);
		DB::table('cities')->insert([
			'id' => 668, 
			'name' => 'Teixeira de Freitas',
			'state' => 5,
		]);
		DB::table('cities')->insert([
			'id' => 669, 
			'name' => 'Teodoro Sampaio',
			'state' => 5,
		]);
		DB::table('cities')->insert([
			'id' => 670, 
			'name' => 'Teofilândia',
			'state' => 5,
		]);
		DB::table('cities')->insert([
			'id' => 671, 
			'name' => 'Teolândia',
			'state' => 5,
		]);
		DB::table('cities')->insert([
			'id' => 672, 
			'name' => 'Terra Nova',
			'state' => 5,
		]);
		DB::table('cities')->insert([
			'id' => 673, 
			'name' => 'Tremedal',
			'state' => 5,
		]);
		DB::table('cities')->insert([
			'id' => 674, 
			'name' => 'Tucano',
			'state' => 5,
		]);
		DB::table('cities')->insert([
			'id' => 675, 
			'name' => 'Uauá',
			'state' => 5,
		]);
		DB::table('cities')->insert([
			'id' => 676, 
			'name' => 'Ubaíra',
			'state' => 5,
		]);
		DB::table('cities')->insert([
			'id' => 677, 
			'name' => 'Ubaitaba',
			'state' => 5,
		]);
		DB::table('cities')->insert([
			'id' => 678, 
			'name' => 'Ubatã',
			'state' => 5,
		]);
		DB::table('cities')->insert([
			'id' => 679, 
			'name' => 'Uibaí',
			'state' => 5,
		]);
		DB::table('cities')->insert([
			'id' => 680, 
			'name' => 'Umburanas',
			'state' => 5,
		]);
		DB::table('cities')->insert([
			'id' => 681, 
			'name' => 'Una',
			'state' => 5,
		]);
		DB::table('cities')->insert([
			'id' => 682, 
			'name' => 'Urandi',
			'state' => 5,
		]);
		DB::table('cities')->insert([
			'id' => 683, 
			'name' => 'Uruçuca',
			'state' => 5,
		]);
		DB::table('cities')->insert([
			'id' => 684, 
			'name' => 'Utinga',
			'state' => 5,
		]);
		DB::table('cities')->insert([
			'id' => 685, 
			'name' => 'Valença',
			'state' => 5,
		]);
		DB::table('cities')->insert([
			'id' => 686, 
			'name' => 'Valente',
			'state' => 5,
		]);
		DB::table('cities')->insert([
			'id' => 687, 
			'name' => 'Várzea da Roça',
			'state' => 5,
		]);
		DB::table('cities')->insert([
			'id' => 688, 
			'name' => 'Várzea do Poço',
			'state' => 5,
		]);
		DB::table('cities')->insert([
			'id' => 689, 
			'name' => 'Várzea Nova',
			'state' => 5,
		]);
		DB::table('cities')->insert([
			'id' => 690, 
			'name' => 'Varzedo',
			'state' => 5,
		]);
		DB::table('cities')->insert([
			'id' => 691, 
			'name' => 'Vera Cruz',
			'state' => 5,
		]);
		DB::table('cities')->insert([
			'id' => 692, 
			'name' => 'Vereda',
			'state' => 5,
		]);
		DB::table('cities')->insert([
			'id' => 693, 
			'name' => 'Vitória da Conquista',
			'state' => 5,
		]);
		DB::table('cities')->insert([
			'id' => 694, 
			'name' => 'Wagner',
			'state' => 5,
		]);
		DB::table('cities')->insert([
			'id' => 695, 
			'name' => 'Wanderley',
			'state' => 5,
		]);
		DB::table('cities')->insert([
			'id' => 696, 
			'name' => 'Wenceslau Guimarães',
			'state' => 5,
		]);
		DB::table('cities')->insert([
			'id' => 697, 
			'name' => 'Xique-Xique',
			'state' => 5,
		]);
		DB::table('cities')->insert([
			'id' => 698, 
			'name' => 'Abaiara',
			'state' => 6,
		]);
		DB::table('cities')->insert([
			'id' => 699, 
			'name' => 'Acarape',
			'state' => 6,
		]);
		DB::table('cities')->insert([
			'id' => 700, 
			'name' => 'Acaraú',
			'state' => 6,
		]);
		DB::table('cities')->insert([
			'id' => 701, 
			'name' => 'Acopiara',
			'state' => 6,
		]);
		DB::table('cities')->insert([
			'id' => 702, 
			'name' => 'Aiuaba',
			'state' => 6,
		]);
		DB::table('cities')->insert([
			'id' => 703, 
			'name' => 'Alcântaras',
			'state' => 6,
		]);
		DB::table('cities')->insert([
			'id' => 704, 
			'name' => 'Altaneira',
			'state' => 6,
		]);
		DB::table('cities')->insert([
			'id' => 705, 
			'name' => 'Alto Santo',
			'state' => 6,
		]);
		DB::table('cities')->insert([
			'id' => 706, 
			'name' => 'Amontada',
			'state' => 6,
		]);
		DB::table('cities')->insert([
			'id' => 707, 
			'name' => 'Antonina do Norte',
			'state' => 6,
		]);
		DB::table('cities')->insert([
			'id' => 708, 
			'name' => 'Apuiarés',
			'state' => 6,
		]);
		DB::table('cities')->insert([
			'id' => 709, 
			'name' => 'Aquiraz',
			'state' => 6,
		]);
		DB::table('cities')->insert([
			'id' => 710, 
			'name' => 'Aracati',
			'state' => 6,
		]);
		DB::table('cities')->insert([
			'id' => 711, 
			'name' => 'Aracoiaba',
			'state' => 6,
		]);
		DB::table('cities')->insert([
			'id' => 712, 
			'name' => 'Ararendá',
			'state' => 6,
		]);
		DB::table('cities')->insert([
			'id' => 713, 
			'name' => 'Araripe',
			'state' => 6,
		]);
		DB::table('cities')->insert([
			'id' => 714, 
			'name' => 'Aratuba',
			'state' => 6,
		]);
		DB::table('cities')->insert([
			'id' => 715, 
			'name' => 'Arneiroz',
			'state' => 6,
		]);
		DB::table('cities')->insert([
			'id' => 716, 
			'name' => 'Assaré',
			'state' => 6,
		]);
		DB::table('cities')->insert([
			'id' => 717, 
			'name' => 'Aurora',
			'state' => 6,
		]);
		DB::table('cities')->insert([
			'id' => 718, 
			'name' => 'Baixio',
			'state' => 6,
		]);
		DB::table('cities')->insert([
			'id' => 719, 
			'name' => 'Banabuiú',
			'state' => 6,
		]);
		DB::table('cities')->insert([
			'id' => 720, 
			'name' => 'Barbalha',
			'state' => 6,
		]);
		DB::table('cities')->insert([
			'id' => 721, 
			'name' => 'Barreira',
			'state' => 6,
		]);
		DB::table('cities')->insert([
			'id' => 722, 
			'name' => 'Barro',
			'state' => 6,
		]);
		DB::table('cities')->insert([
			'id' => 723, 
			'name' => 'Barroquinha',
			'state' => 6,
		]);
		DB::table('cities')->insert([
			'id' => 724, 
			'name' => 'Baturité',
			'state' => 6,
		]);
		DB::table('cities')->insert([
			'id' => 725, 
			'name' => 'Beberibe',
			'state' => 6,
		]);
		DB::table('cities')->insert([
			'id' => 726, 
			'name' => 'Bela Cruz',
			'state' => 6,
		]);
		DB::table('cities')->insert([
			'id' => 727, 
			'name' => 'Boa Viagem',
			'state' => 6,
		]);
		DB::table('cities')->insert([
			'id' => 728, 
			'name' => 'Brejo Santo',
			'state' => 6,
		]);
		DB::table('cities')->insert([
			'id' => 729, 
			'name' => 'Camocim',
			'state' => 6,
		]);
		DB::table('cities')->insert([
			'id' => 730, 
			'name' => 'Campos Sales',
			'state' => 6,
		]);
		DB::table('cities')->insert([
			'id' => 731, 
			'name' => 'Canindé',
			'state' => 6,
		]);
		DB::table('cities')->insert([
			'id' => 732, 
			'name' => 'Capistrano',
			'state' => 6,
		]);
		DB::table('cities')->insert([
			'id' => 733, 
			'name' => 'Caridade',
			'state' => 6,
		]);
		DB::table('cities')->insert([
			'id' => 734, 
			'name' => 'Cariré',
			'state' => 6,
		]);
		DB::table('cities')->insert([
			'id' => 735, 
			'name' => 'Caririaçu',
			'state' => 6,
		]);
		DB::table('cities')->insert([
			'id' => 736, 
			'name' => 'Cariús',
			'state' => 6,
		]);
		DB::table('cities')->insert([
			'id' => 737, 
			'name' => 'Carnaubal',
			'state' => 6,
		]);
		DB::table('cities')->insert([
			'id' => 738, 
			'name' => 'Cascavel',
			'state' => 6,
		]);
		DB::table('cities')->insert([
			'id' => 739, 
			'name' => 'Catarina',
			'state' => 6,
		]);
		DB::table('cities')->insert([
			'id' => 740, 
			'name' => 'Catunda',
			'state' => 6,
		]);
		DB::table('cities')->insert([
			'id' => 741, 
			'name' => 'Caucaia',
			'state' => 6,
		]);
		DB::table('cities')->insert([
			'id' => 742, 
			'name' => 'Cedro',
			'state' => 6,
		]);
		DB::table('cities')->insert([
			'id' => 743, 
			'name' => 'Chaval',
			'state' => 6,
		]);
		DB::table('cities')->insert([
			'id' => 744, 
			'name' => 'Choró',
			'state' => 6,
		]);
		DB::table('cities')->insert([
			'id' => 745, 
			'name' => 'Chorozinho',
			'state' => 6,
		]);
		DB::table('cities')->insert([
			'id' => 746, 
			'name' => 'Coreaú',
			'state' => 6,
		]);
		DB::table('cities')->insert([
			'id' => 747, 
			'name' => 'Crateús',
			'state' => 6,
		]);
		DB::table('cities')->insert([
			'id' => 748, 
			'name' => 'Crato',
			'state' => 6,
		]);
		DB::table('cities')->insert([
			'id' => 749, 
			'name' => 'Croatá',
			'state' => 6,
		]);
		DB::table('cities')->insert([
			'id' => 750, 
			'name' => 'Cruz',
			'state' => 6,
		]);
		DB::table('cities')->insert([
			'id' => 751, 
			'name' => 'Deputado Irapuan Pinheiro',
			'state' => 6,
		]);
		DB::table('cities')->insert([
			'id' => 752, 
			'name' => 'Ererê',
			'state' => 6,
		]);
		DB::table('cities')->insert([
			'id' => 753, 
			'name' => 'Eusébio',
			'state' => 6,
		]);
		DB::table('cities')->insert([
			'id' => 754, 
			'name' => 'Farias Brito',
			'state' => 6,
		]);
		DB::table('cities')->insert([
			'id' => 755, 
			'name' => 'Forquilha',
			'state' => 6,
		]);
		DB::table('cities')->insert([
			'id' => 756, 
			'name' => 'Fortaleza',
			'state' => 6,
		]);
		DB::table('cities')->insert([
			'id' => 757, 
			'name' => 'Fortim',
			'state' => 6,
		]);
		DB::table('cities')->insert([
			'id' => 758, 
			'name' => 'Frecheirinha',
			'state' => 6,
		]);
		DB::table('cities')->insert([
			'id' => 759, 
			'name' => 'General Sampaio',
			'state' => 6,
		]);
		DB::table('cities')->insert([
			'id' => 760, 
			'name' => 'Graça',
			'state' => 6,
		]);
		DB::table('cities')->insert([
			'id' => 761, 
			'name' => 'Granja',
			'state' => 6,
		]);
		DB::table('cities')->insert([
			'id' => 762, 
			'name' => 'Granjeiro',
			'state' => 6,
		]);
		DB::table('cities')->insert([
			'id' => 763, 
			'name' => 'Groaíras',
			'state' => 6,
		]);
		DB::table('cities')->insert([
			'id' => 764, 
			'name' => 'Guaiúba',
			'state' => 6,
		]);
		DB::table('cities')->insert([
			'id' => 765, 
			'name' => 'Guaraciaba do Norte',
			'state' => 6,
		]);
		DB::table('cities')->insert([
			'id' => 766, 
			'name' => 'Guaramiranga',
			'state' => 6,
		]);
		DB::table('cities')->insert([
			'id' => 767, 
			'name' => 'Hidrolândia',
			'state' => 6,
		]);
		DB::table('cities')->insert([
			'id' => 768, 
			'name' => 'Horizonte',
			'state' => 6,
		]);
		DB::table('cities')->insert([
			'id' => 769, 
			'name' => 'Ibaretama',
			'state' => 6,
		]);
		DB::table('cities')->insert([
			'id' => 770, 
			'name' => 'Ibiapina',
			'state' => 6,
		]);
		DB::table('cities')->insert([
			'id' => 771, 
			'name' => 'Ibicuitinga',
			'state' => 6,
		]);
		DB::table('cities')->insert([
			'id' => 772, 
			'name' => 'Icapuí',
			'state' => 6,
		]);
		DB::table('cities')->insert([
			'id' => 773, 
			'name' => 'Icó',
			'state' => 6,
		]);
		DB::table('cities')->insert([
			'id' => 774, 
			'name' => 'Iguatu',
			'state' => 6,
		]);
		DB::table('cities')->insert([
			'id' => 775, 
			'name' => 'Independência',
			'state' => 6,
		]);
		DB::table('cities')->insert([
			'id' => 776, 
			'name' => 'Ipaporanga',
			'state' => 6,
		]);
		DB::table('cities')->insert([
			'id' => 777, 
			'name' => 'Ipaumirim',
			'state' => 6,
		]);
		DB::table('cities')->insert([
			'id' => 778, 
			'name' => 'Ipu',
			'state' => 6,
		]);
		DB::table('cities')->insert([
			'id' => 779, 
			'name' => 'Ipueiras',
			'state' => 6,
		]);
		DB::table('cities')->insert([
			'id' => 780, 
			'name' => 'Iracema',
			'state' => 6,
		]);
		DB::table('cities')->insert([
			'id' => 781, 
			'name' => 'Irauçuba',
			'state' => 6,
		]);
		DB::table('cities')->insert([
			'id' => 782, 
			'name' => 'Itaiçaba',
			'state' => 6,
		]);
		DB::table('cities')->insert([
			'id' => 783, 
			'name' => 'Itaitinga',
			'state' => 6,
		]);
		DB::table('cities')->insert([
			'id' => 784, 
			'name' => 'Itapagé',
			'state' => 6,
		]);
		DB::table('cities')->insert([
			'id' => 785, 
			'name' => 'Itapipoca',
			'state' => 6,
		]);
		DB::table('cities')->insert([
			'id' => 786, 
			'name' => 'Itapiúna',
			'state' => 6,
		]);
		DB::table('cities')->insert([
			'id' => 787, 
			'name' => 'Itarema',
			'state' => 6,
		]);
		DB::table('cities')->insert([
			'id' => 788, 
			'name' => 'Itatira',
			'state' => 6,
		]);
		DB::table('cities')->insert([
			'id' => 789, 
			'name' => 'Jaguaretama',
			'state' => 6,
		]);
		DB::table('cities')->insert([
			'id' => 790, 
			'name' => 'Jaguaribara',
			'state' => 6,
		]);
		DB::table('cities')->insert([
			'id' => 791, 
			'name' => 'Jaguaribe',
			'state' => 6,
		]);
		DB::table('cities')->insert([
			'id' => 792, 
			'name' => 'Jaguaruana',
			'state' => 6,
		]);
		DB::table('cities')->insert([
			'id' => 793, 
			'name' => 'Jardim',
			'state' => 6,
		]);
		DB::table('cities')->insert([
			'id' => 794, 
			'name' => 'Jati',
			'state' => 6,
		]);
		DB::table('cities')->insert([
			'id' => 795, 
			'name' => 'Jijoca de Jericoacoara',
			'state' => 6,
		]);
		DB::table('cities')->insert([
			'id' => 796, 
			'name' => 'Juazeiro do Norte',
			'state' => 6,
		]);
		DB::table('cities')->insert([
			'id' => 797, 
			'name' => 'Jucás',
			'state' => 6,
		]);
		DB::table('cities')->insert([
			'id' => 798, 
			'name' => 'Lavras da Mangabeira',
			'state' => 6,
		]);
		DB::table('cities')->insert([
			'id' => 799, 
			'name' => 'Limoeiro do Norte',
			'state' => 6,
		]);
		DB::table('cities')->insert([
			'id' => 800, 
			'name' => 'Madalena',
			'state' => 6,
		]);
		DB::table('cities')->insert([
			'id' => 801, 
			'name' => 'Maracanaú',
			'state' => 6,
		]);
		DB::table('cities')->insert([
			'id' => 802, 
			'name' => 'Maranguape',
			'state' => 6,
		]);
		DB::table('cities')->insert([
			'id' => 803, 
			'name' => 'Marco',
			'state' => 6,
		]);
		DB::table('cities')->insert([
			'id' => 804, 
			'name' => 'Martinópole',
			'state' => 6,
		]);
		DB::table('cities')->insert([
			'id' => 805, 
			'name' => 'Massapê',
			'state' => 6,
		]);
		DB::table('cities')->insert([
			'id' => 806, 
			'name' => 'Mauriti',
			'state' => 6,
		]);
		DB::table('cities')->insert([
			'id' => 807, 
			'name' => 'Meruoca',
			'state' => 6,
		]);
		DB::table('cities')->insert([
			'id' => 808, 
			'name' => 'Milagres',
			'state' => 6,
		]);
		DB::table('cities')->insert([
			'id' => 809, 
			'name' => 'Milhã',
			'state' => 6,
		]);
		DB::table('cities')->insert([
			'id' => 810, 
			'name' => 'Miraíma',
			'state' => 6,
		]);
		DB::table('cities')->insert([
			'id' => 811, 
			'name' => 'Missão Velha',
			'state' => 6,
		]);
		DB::table('cities')->insert([
			'id' => 812, 
			'name' => 'Mombaça',
			'state' => 6,
		]);
		DB::table('cities')->insert([
			'id' => 813, 
			'name' => 'Monsenhor Tabosa',
			'state' => 6,
		]);
		DB::table('cities')->insert([
			'id' => 814, 
			'name' => 'Morada Nova',
			'state' => 6,
		]);
		DB::table('cities')->insert([
			'id' => 815, 
			'name' => 'Moraújo',
			'state' => 6,
		]);
		DB::table('cities')->insert([
			'id' => 816, 
			'name' => 'Morrinhos',
			'state' => 6,
		]);
		DB::table('cities')->insert([
			'id' => 817, 
			'name' => 'Mucambo',
			'state' => 6,
		]);
		DB::table('cities')->insert([
			'id' => 818, 
			'name' => 'Mulungu',
			'state' => 6,
		]);
		DB::table('cities')->insert([
			'id' => 819, 
			'name' => 'Nova Olinda',
			'state' => 6,
		]);
		DB::table('cities')->insert([
			'id' => 820, 
			'name' => 'Nova Russas',
			'state' => 6,
		]);
		DB::table('cities')->insert([
			'id' => 821, 
			'name' => 'Novo Oriente',
			'state' => 6,
		]);
		DB::table('cities')->insert([
			'id' => 822, 
			'name' => 'Ocara',
			'state' => 6,
		]);
		DB::table('cities')->insert([
			'id' => 823, 
			'name' => 'Orós',
			'state' => 6,
		]);
		DB::table('cities')->insert([
			'id' => 824, 
			'name' => 'Pacajus',
			'state' => 6,
		]);
		DB::table('cities')->insert([
			'id' => 825, 
			'name' => 'Pacatuba',
			'state' => 6,
		]);
		DB::table('cities')->insert([
			'id' => 826, 
			'name' => 'Pacoti',
			'state' => 6,
		]);
		DB::table('cities')->insert([
			'id' => 827, 
			'name' => 'Pacujá',
			'state' => 6,
		]);
		DB::table('cities')->insert([
			'id' => 828, 
			'name' => 'Palhano',
			'state' => 6,
		]);
		DB::table('cities')->insert([
			'id' => 829, 
			'name' => 'Palmácia',
			'state' => 6,
		]);
		DB::table('cities')->insert([
			'id' => 830, 
			'name' => 'Paracuru',
			'state' => 6,
		]);
		DB::table('cities')->insert([
			'id' => 831, 
			'name' => 'Paraipaba',
			'state' => 6,
		]);
		DB::table('cities')->insert([
			'id' => 832, 
			'name' => 'Parambu',
			'state' => 6,
		]);
		DB::table('cities')->insert([
			'id' => 833, 
			'name' => 'Paramoti',
			'state' => 6,
		]);
		DB::table('cities')->insert([
			'id' => 834, 
			'name' => 'Pedra Branca',
			'state' => 6,
		]);
		DB::table('cities')->insert([
			'id' => 835, 
			'name' => 'Penaforte',
			'state' => 6,
		]);
		DB::table('cities')->insert([
			'id' => 836, 
			'name' => 'Pentecoste',
			'state' => 6,
		]);
		DB::table('cities')->insert([
			'id' => 837, 
			'name' => 'Pereiro',
			'state' => 6,
		]);
		DB::table('cities')->insert([
			'id' => 838, 
			'name' => 'Pindoretama',
			'state' => 6,
		]);
		DB::table('cities')->insert([
			'id' => 839, 
			'name' => 'Piquet Carneiro',
			'state' => 6,
		]);
		DB::table('cities')->insert([
			'id' => 840, 
			'name' => 'Pires Ferreira',
			'state' => 6,
		]);
		DB::table('cities')->insert([
			'id' => 841, 
			'name' => 'Poranga',
			'state' => 6,
		]);
		DB::table('cities')->insert([
			'id' => 842, 
			'name' => 'Porteiras',
			'state' => 6,
		]);
		DB::table('cities')->insert([
			'id' => 843, 
			'name' => 'Potengi',
			'state' => 6,
		]);
		DB::table('cities')->insert([
			'id' => 844, 
			'name' => 'Potiretama',
			'state' => 6,
		]);
		DB::table('cities')->insert([
			'id' => 845, 
			'name' => 'Quiterianópolis',
			'state' => 6,
		]);
		DB::table('cities')->insert([
			'id' => 846, 
			'name' => 'Quixadá',
			'state' => 6,
		]);
		DB::table('cities')->insert([
			'id' => 847, 
			'name' => 'Quixelô',
			'state' => 6,
		]);
		DB::table('cities')->insert([
			'id' => 848, 
			'name' => 'Quixeramobim',
			'state' => 6,
		]);
		DB::table('cities')->insert([
			'id' => 849, 
			'name' => 'Quixeré',
			'state' => 6,
		]);
		DB::table('cities')->insert([
			'id' => 850, 
			'name' => 'Redenção',
			'state' => 6,
		]);
		DB::table('cities')->insert([
			'id' => 851, 
			'name' => 'Reriutaba',
			'state' => 6,
		]);
		DB::table('cities')->insert([
			'id' => 852, 
			'name' => 'Russas',
			'state' => 6,
		]);
		DB::table('cities')->insert([
			'id' => 853, 
			'name' => 'Saboeiro',
			'state' => 6,
		]);
		DB::table('cities')->insert([
			'id' => 854, 
			'name' => 'Salitre',
			'state' => 6,
		]);
		DB::table('cities')->insert([
			'id' => 855, 
			'name' => 'Santa Quitéria',
			'state' => 6,
		]);
		DB::table('cities')->insert([
			'id' => 856, 
			'name' => 'Santana do Acaraú',
			'state' => 6,
		]);
		DB::table('cities')->insert([
			'id' => 857, 
			'name' => 'Santana do Cariri',
			'state' => 6,
		]);
		DB::table('cities')->insert([
			'id' => 858, 
			'name' => 'São Benedito',
			'state' => 6,
		]);
		DB::table('cities')->insert([
			'id' => 859, 
			'name' => 'São Gonçalo do Amarante',
			'state' => 6,
		]);
		DB::table('cities')->insert([
			'id' => 860, 
			'name' => 'São João do Jaguaribe',
			'state' => 6,
		]);
		DB::table('cities')->insert([
			'id' => 861, 
			'name' => 'São Luís do Curu',
			'state' => 6,
		]);
		DB::table('cities')->insert([
			'id' => 862, 
			'name' => 'Senador Pompeu',
			'state' => 6,
		]);
		DB::table('cities')->insert([
			'id' => 863, 
			'name' => 'Senador Sá',
			'state' => 6,
		]);
		DB::table('cities')->insert([
			'id' => 864, 
			'name' => 'Sobral',
			'state' => 6,
		]);
		DB::table('cities')->insert([
			'id' => 865, 
			'name' => 'Solonópole',
			'state' => 6,
		]);
		DB::table('cities')->insert([
			'id' => 866, 
			'name' => 'Tabuleiro do Norte',
			'state' => 6,
		]);
		DB::table('cities')->insert([
			'id' => 867, 
			'name' => 'Tamboril',
			'state' => 6,
		]);
		DB::table('cities')->insert([
			'id' => 868, 
			'name' => 'Tarrafas',
			'state' => 6,
		]);
		DB::table('cities')->insert([
			'id' => 869, 
			'name' => 'Tauá',
			'state' => 6,
		]);
		DB::table('cities')->insert([
			'id' => 870, 
			'name' => 'Tejuçuoca',
			'state' => 6,
		]);
		DB::table('cities')->insert([
			'id' => 871, 
			'name' => 'Tianguá',
			'state' => 6,
		]);
		DB::table('cities')->insert([
			'id' => 872, 
			'name' => 'Trairi',
			'state' => 6,
		]);
		DB::table('cities')->insert([
			'id' => 873, 
			'name' => 'Tururu',
			'state' => 6,
		]);
		DB::table('cities')->insert([
			'id' => 874, 
			'name' => 'Ubajara',
			'state' => 6,
		]);
		DB::table('cities')->insert([
			'id' => 875, 
			'name' => 'Umari',
			'state' => 6,
		]);
		DB::table('cities')->insert([
			'id' => 876, 
			'name' => 'Umirim',
			'state' => 6,
		]);
		DB::table('cities')->insert([
			'id' => 877, 
			'name' => 'Uruburetama',
			'state' => 6,
		]);
		DB::table('cities')->insert([
			'id' => 878, 
			'name' => 'Uruoca',
			'state' => 6,
		]);
		DB::table('cities')->insert([
			'id' => 879, 
			'name' => 'Varjota',
			'state' => 6,
		]);
		DB::table('cities')->insert([
			'id' => 880, 
			'name' => 'Várzea Alegre',
			'state' => 6,
		]);
		DB::table('cities')->insert([
			'id' => 881, 
			'name' => 'Viçosa do Ceará',
			'state' => 6,
		]);
		DB::table('cities')->insert([
			'id' => 882, 
			'name' => 'Brasília',
			'state' => 7,
		]);
		DB::table('cities')->insert([
			'id' => 883, 
			'name' => 'Abadia de Goiás',
			'state' => 9,
		]);
		DB::table('cities')->insert([
			'id' => 884, 
			'name' => 'Abadiânia',
			'state' => 9,
		]);
		DB::table('cities')->insert([
			'id' => 885, 
			'name' => 'Acreúna',
			'state' => 9,
		]);
		DB::table('cities')->insert([
			'id' => 886, 
			'name' => 'Adelândia',
			'state' => 9,
		]);
		DB::table('cities')->insert([
			'id' => 887, 
			'name' => 'Água Fria de Goiás',
			'state' => 9,
		]);
		DB::table('cities')->insert([
			'id' => 888, 
			'name' => 'Água Limpa',
			'state' => 9,
		]);
		DB::table('cities')->insert([
			'id' => 889, 
			'name' => 'Águas Lindas de Goiás',
			'state' => 9,
		]);
		DB::table('cities')->insert([
			'id' => 890, 
			'name' => 'Alexânia',
			'state' => 9,
		]);
		DB::table('cities')->insert([
			'id' => 891, 
			'name' => 'Aloândia',
			'state' => 9,
		]);
		DB::table('cities')->insert([
			'id' => 892, 
			'name' => 'Alto Horizonte',
			'state' => 9,
		]);
		DB::table('cities')->insert([
			'id' => 893, 
			'name' => 'Alto Paraíso de Goiás',
			'state' => 9,
		]);
		DB::table('cities')->insert([
			'id' => 894, 
			'name' => 'Alvorada do Norte',
			'state' => 9,
		]);
		DB::table('cities')->insert([
			'id' => 895, 
			'name' => 'Amaralina',
			'state' => 9,
		]);
		DB::table('cities')->insert([
			'id' => 896, 
			'name' => 'Americano do Brasil',
			'state' => 9,
		]);
		DB::table('cities')->insert([
			'id' => 897, 
			'name' => 'Amorinópolis',
			'state' => 9,
		]);
		DB::table('cities')->insert([
			'id' => 898, 
			'name' => 'Anápolis',
			'state' => 9,
		]);
		DB::table('cities')->insert([
			'id' => 899, 
			'name' => 'Anhanguera',
			'state' => 9,
		]);
		DB::table('cities')->insert([
			'id' => 900, 
			'name' => 'Anicuns',
			'state' => 9,
		]);
		DB::table('cities')->insert([
			'id' => 901, 
			'name' => 'Aparecida de Goiânia',
			'state' => 9,
		]);
		DB::table('cities')->insert([
			'id' => 902, 
			'name' => 'Aparecida do Rio Doce',
			'state' => 9,
		]);
		DB::table('cities')->insert([
			'id' => 903, 
			'name' => 'Aporé',
			'state' => 9,
		]);
		DB::table('cities')->insert([
			'id' => 904, 
			'name' => 'Araçu',
			'state' => 9,
		]);
		DB::table('cities')->insert([
			'id' => 905, 
			'name' => 'Aragarças',
			'state' => 9,
		]);
		DB::table('cities')->insert([
			'id' => 906, 
			'name' => 'Aragoiânia',
			'state' => 9,
		]);
		DB::table('cities')->insert([
			'id' => 907, 
			'name' => 'Araguapaz',
			'state' => 9,
		]);
		DB::table('cities')->insert([
			'id' => 908, 
			'name' => 'Arenópolis',
			'state' => 9,
		]);
		DB::table('cities')->insert([
			'id' => 909, 
			'name' => 'Aruanã',
			'state' => 9,
		]);
		DB::table('cities')->insert([
			'id' => 910, 
			'name' => 'Aurilândia',
			'state' => 9,
		]);
		DB::table('cities')->insert([
			'id' => 911, 
			'name' => 'Avelinópolis',
			'state' => 9,
		]);
		DB::table('cities')->insert([
			'id' => 912, 
			'name' => 'Baliza',
			'state' => 9,
		]);
		DB::table('cities')->insert([
			'id' => 913, 
			'name' => 'Barro Alto',
			'state' => 9,
		]);
		DB::table('cities')->insert([
			'id' => 914, 
			'name' => 'Bela Vista de Goiás',
			'state' => 9,
		]);
		DB::table('cities')->insert([
			'id' => 915, 
			'name' => 'Bom Jardim de Goiás',
			'state' => 9,
		]);
		DB::table('cities')->insert([
			'id' => 916, 
			'name' => 'Bom Jesus de Goiás',
			'state' => 9,
		]);
		DB::table('cities')->insert([
			'id' => 917, 
			'name' => 'Bonfinópolis',
			'state' => 9,
		]);
		DB::table('cities')->insert([
			'id' => 918, 
			'name' => 'Bonópolis',
			'state' => 9,
		]);
		DB::table('cities')->insert([
			'id' => 919, 
			'name' => 'Brazabrantes',
			'state' => 9,
		]);
		DB::table('cities')->insert([
			'id' => 920, 
			'name' => 'Britânia',
			'state' => 9,
		]);
		DB::table('cities')->insert([
			'id' => 921, 
			'name' => 'Buriti Alegre',
			'state' => 9,
		]);
		DB::table('cities')->insert([
			'id' => 922, 
			'name' => 'Buriti de Goiás',
			'state' => 9,
		]);
		DB::table('cities')->insert([
			'id' => 923, 
			'name' => 'Buritinópolis',
			'state' => 9,
		]);
		DB::table('cities')->insert([
			'id' => 924, 
			'name' => 'Cabeceiras',
			'state' => 9,
		]);
		DB::table('cities')->insert([
			'id' => 925, 
			'name' => 'Cachoeira Alta',
			'state' => 9,
		]);
		DB::table('cities')->insert([
			'id' => 926, 
			'name' => 'Cachoeira de Goiás',
			'state' => 9,
		]);
		DB::table('cities')->insert([
			'id' => 927, 
			'name' => 'Cachoeira Dourada',
			'state' => 9,
		]);
		DB::table('cities')->insert([
			'id' => 928, 
			'name' => 'Caçu',
			'state' => 9,
		]);
		DB::table('cities')->insert([
			'id' => 929, 
			'name' => 'Caiapônia',
			'state' => 9,
		]);
		DB::table('cities')->insert([
			'id' => 930, 
			'name' => 'Caldas Novas',
			'state' => 9,
		]);
		DB::table('cities')->insert([
			'id' => 931, 
			'name' => 'Caldazinha',
			'state' => 9,
		]);
		DB::table('cities')->insert([
			'id' => 932, 
			'name' => 'Campestre de Goiás',
			'state' => 9,
		]);
		DB::table('cities')->insert([
			'id' => 933, 
			'name' => 'Campinaçu',
			'state' => 9,
		]);
		DB::table('cities')->insert([
			'id' => 934, 
			'name' => 'Campinorte',
			'state' => 9,
		]);
		DB::table('cities')->insert([
			'id' => 935, 
			'name' => 'Campo Alegre de Goiás',
			'state' => 9,
		]);
		DB::table('cities')->insert([
			'id' => 936, 
			'name' => 'Campo Limpo de Goiás',
			'state' => 9,
		]);
		DB::table('cities')->insert([
			'id' => 937, 
			'name' => 'Campos Belos',
			'state' => 9,
		]);
		DB::table('cities')->insert([
			'id' => 938, 
			'name' => 'Campos Verdes',
			'state' => 9,
		]);
		DB::table('cities')->insert([
			'id' => 939, 
			'name' => 'Carmo do Rio Verde',
			'state' => 9,
		]);
		DB::table('cities')->insert([
			'id' => 940, 
			'name' => 'Castelândia',
			'state' => 9,
		]);
		DB::table('cities')->insert([
			'id' => 941, 
			'name' => 'Catalão',
			'state' => 9,
		]);
		DB::table('cities')->insert([
			'id' => 942, 
			'name' => 'Caturaí',
			'state' => 9,
		]);
		DB::table('cities')->insert([
			'id' => 943, 
			'name' => 'Cavalcante',
			'state' => 9,
		]);
		DB::table('cities')->insert([
			'id' => 944, 
			'name' => 'Ceres',
			'state' => 9,
		]);
		DB::table('cities')->insert([
			'id' => 945, 
			'name' => 'Cezarina',
			'state' => 9,
		]);
		DB::table('cities')->insert([
			'id' => 946, 
			'name' => 'Chapadão do Céu',
			'state' => 9,
		]);
		DB::table('cities')->insert([
			'id' => 947, 
			'name' => 'Cidade Ocidental',
			'state' => 9,
		]);
		DB::table('cities')->insert([
			'id' => 948, 
			'name' => 'Cocalzinho de Goiás',
			'state' => 9,
		]);
		DB::table('cities')->insert([
			'id' => 949, 
			'name' => 'Colinas do Sul',
			'state' => 9,
		]);
		DB::table('cities')->insert([
			'id' => 950, 
			'name' => 'Córrego do Ouro',
			'state' => 9,
		]);
		DB::table('cities')->insert([
			'id' => 951, 
			'name' => 'Corumbá de Goiás',
			'state' => 9,
		]);
		DB::table('cities')->insert([
			'id' => 952, 
			'name' => 'Corumbaíba',
			'state' => 9,
		]);
		DB::table('cities')->insert([
			'id' => 953, 
			'name' => 'Cristalina',
			'state' => 9,
		]);
		DB::table('cities')->insert([
			'id' => 954, 
			'name' => 'Cristianópolis',
			'state' => 9,
		]);
		DB::table('cities')->insert([
			'id' => 955, 
			'name' => 'Crixás',
			'state' => 9,
		]);
		DB::table('cities')->insert([
			'id' => 956, 
			'name' => 'Cromínia',
			'state' => 9,
		]);
		DB::table('cities')->insert([
			'id' => 957, 
			'name' => 'Cumari',
			'state' => 9,
		]);
		DB::table('cities')->insert([
			'id' => 958, 
			'name' => 'Damianópolis',
			'state' => 9,
		]);
		DB::table('cities')->insert([
			'id' => 959, 
			'name' => 'Damolândia',
			'state' => 9,
		]);
		DB::table('cities')->insert([
			'id' => 960, 
			'name' => 'Davinópolis',
			'state' => 9,
		]);
		DB::table('cities')->insert([
			'id' => 961, 
			'name' => 'Diorama',
			'state' => 9,
		]);
		DB::table('cities')->insert([
			'id' => 962, 
			'name' => 'Divinópolis de Goiás',
			'state' => 9,
		]);
		DB::table('cities')->insert([
			'id' => 963, 
			'name' => 'Doverlândia',
			'state' => 9,
		]);
		DB::table('cities')->insert([
			'id' => 964, 
			'name' => 'Edealina',
			'state' => 9,
		]);
		DB::table('cities')->insert([
			'id' => 965, 
			'name' => 'Edéia',
			'state' => 9,
		]);
		DB::table('cities')->insert([
			'id' => 966, 
			'name' => 'Estrela do Norte',
			'state' => 9,
		]);
		DB::table('cities')->insert([
			'id' => 967, 
			'name' => 'Faina',
			'state' => 9,
		]);
		DB::table('cities')->insert([
			'id' => 968, 
			'name' => 'Fazenda Nova',
			'state' => 9,
		]);
		DB::table('cities')->insert([
			'id' => 969, 
			'name' => 'Firminópolis',
			'state' => 9,
		]);
		DB::table('cities')->insert([
			'id' => 970, 
			'name' => 'Flores de Goiás',
			'state' => 9,
		]);
		DB::table('cities')->insert([
			'id' => 971, 
			'name' => 'Formosa',
			'state' => 9,
		]);
		DB::table('cities')->insert([
			'id' => 972, 
			'name' => 'Formoso',
			'state' => 9,
		]);
		DB::table('cities')->insert([
			'id' => 973, 
			'name' => 'Gameleira de Goiás',
			'state' => 9,
		]);
		DB::table('cities')->insert([
			'id' => 974, 
			'name' => 'Goianápolis',
			'state' => 9,
		]);
		DB::table('cities')->insert([
			'id' => 975, 
			'name' => 'Goiandira',
			'state' => 9,
		]);
		DB::table('cities')->insert([
			'id' => 976, 
			'name' => 'Goianésia',
			'state' => 9,
		]);
		DB::table('cities')->insert([
			'id' => 977, 
			'name' => 'Goiânia',
			'state' => 9,
		]);
		DB::table('cities')->insert([
			'id' => 978, 
			'name' => 'Goianira',
			'state' => 9,
		]);
		DB::table('cities')->insert([
			'id' => 979, 
			'name' => 'Goiás',
			'state' => 9,
		]);
		DB::table('cities')->insert([
			'id' => 980, 
			'name' => 'Goiatuba',
			'state' => 9,
		]);
		DB::table('cities')->insert([
			'id' => 981, 
			'name' => 'Gouvelândia',
			'state' => 9,
		]);
		DB::table('cities')->insert([
			'id' => 982, 
			'name' => 'Guapó',
			'state' => 9,
		]);
		DB::table('cities')->insert([
			'id' => 983, 
			'name' => 'Guaraíta',
			'state' => 9,
		]);
		DB::table('cities')->insert([
			'id' => 984, 
			'name' => 'Guarani de Goiás',
			'state' => 9,
		]);
		DB::table('cities')->insert([
			'id' => 985, 
			'name' => 'Guarinos',
			'state' => 9,
		]);
		DB::table('cities')->insert([
			'id' => 986, 
			'name' => 'Heitoraí',
			'state' => 9,
		]);
		DB::table('cities')->insert([
			'id' => 987, 
			'name' => 'Hidrolândia',
			'state' => 9,
		]);
		DB::table('cities')->insert([
			'id' => 988, 
			'name' => 'Hidrolina',
			'state' => 9,
		]);
		DB::table('cities')->insert([
			'id' => 989, 
			'name' => 'Iaciara',
			'state' => 9,
		]);
		DB::table('cities')->insert([
			'id' => 990, 
			'name' => 'Inaciolândia',
			'state' => 9,
		]);
		DB::table('cities')->insert([
			'id' => 991, 
			'name' => 'Indiara',
			'state' => 9,
		]);
		DB::table('cities')->insert([
			'id' => 992, 
			'name' => 'Inhumas',
			'state' => 9,
		]);
		DB::table('cities')->insert([
			'id' => 993, 
			'name' => 'Ipameri',
			'state' => 9,
		]);
		DB::table('cities')->insert([
			'id' => 994, 
			'name' => 'Ipiranga de Goiás',
			'state' => 9,
		]);
		DB::table('cities')->insert([
			'id' => 995, 
			'name' => 'Iporá',
			'state' => 9,
		]);
		DB::table('cities')->insert([
			'id' => 996, 
			'name' => 'Israelândia',
			'state' => 9,
		]);
		DB::table('cities')->insert([
			'id' => 997, 
			'name' => 'Itaberaí',
			'state' => 9,
		]);
		DB::table('cities')->insert([
			'id' => 998, 
			'name' => 'Itaguari',
			'state' => 9,
		]);
		DB::table('cities')->insert([
			'id' => 999, 
			'name' => 'Itaguaru',
			'state' => 9,
		]);
		DB::table('cities')->insert([
			'id' => 1000, 
			'name' => 'Itajá',
			'state' => 9,
		]);
		DB::table('cities')->insert([
			'id' => 1001, 
			'name' => 'Itapaci',
			'state' => 9,
		]);
		DB::table('cities')->insert([
			'id' => 1002, 
			'name' => 'Itapirapuã',
			'state' => 9,
		]);
		DB::table('cities')->insert([
			'id' => 1003, 
			'name' => 'Itapuranga',
			'state' => 9,
		]);
		DB::table('cities')->insert([
			'id' => 1004, 
			'name' => 'Itarumã',
			'state' => 9,
		]);
		DB::table('cities')->insert([
			'id' => 1005, 
			'name' => 'Itauçu',
			'state' => 9,
		]);
		DB::table('cities')->insert([
			'id' => 1006, 
			'name' => 'Itumbiara',
			'state' => 9,
		]);
		DB::table('cities')->insert([
			'id' => 1007, 
			'name' => 'Ivolândia',
			'state' => 9,
		]);
		DB::table('cities')->insert([
			'id' => 1008, 
			'name' => 'Jandaia',
			'state' => 9,
		]);
		DB::table('cities')->insert([
			'id' => 1009, 
			'name' => 'Jaraguá',
			'state' => 9,
		]);
		DB::table('cities')->insert([
			'id' => 1010, 
			'name' => 'Jataí',
			'state' => 9,
		]);
		DB::table('cities')->insert([
			'id' => 1011, 
			'name' => 'Jaupaci',
			'state' => 9,
		]);
		DB::table('cities')->insert([
			'id' => 1012, 
			'name' => 'Jesúpolis',
			'state' => 9,
		]);
		DB::table('cities')->insert([
			'id' => 1013, 
			'name' => 'Joviânia',
			'state' => 9,
		]);
		DB::table('cities')->insert([
			'id' => 1014, 
			'name' => 'Jussara',
			'state' => 9,
		]);
		DB::table('cities')->insert([
			'id' => 1015, 
			'name' => 'Lagoa Santa',
			'state' => 9,
		]);
		DB::table('cities')->insert([
			'id' => 1016, 
			'name' => 'Leopoldo de Bulhões',
			'state' => 9,
		]);
		DB::table('cities')->insert([
			'id' => 1017, 
			'name' => 'Luziânia',
			'state' => 9,
		]);
		DB::table('cities')->insert([
			'id' => 1018, 
			'name' => 'Mairipotaba',
			'state' => 9,
		]);
		DB::table('cities')->insert([
			'id' => 1019, 
			'name' => 'Mambaí',
			'state' => 9,
		]);
		DB::table('cities')->insert([
			'id' => 1020, 
			'name' => 'Mara Rosa',
			'state' => 9,
		]);
		DB::table('cities')->insert([
			'id' => 1021, 
			'name' => 'Marzagão',
			'state' => 9,
		]);
		DB::table('cities')->insert([
			'id' => 1022, 
			'name' => 'Matrinchã',
			'state' => 9,
		]);
		DB::table('cities')->insert([
			'id' => 1023, 
			'name' => 'Maurilândia',
			'state' => 9,
		]);
		DB::table('cities')->insert([
			'id' => 1024, 
			'name' => 'Mimoso de Goiás',
			'state' => 9,
		]);
		DB::table('cities')->insert([
			'id' => 1025, 
			'name' => 'Minaçu',
			'state' => 9,
		]);
		DB::table('cities')->insert([
			'id' => 1026, 
			'name' => 'Mineiros',
			'state' => 9,
		]);
		DB::table('cities')->insert([
			'id' => 1027, 
			'name' => 'Moiporá',
			'state' => 9,
		]);
		DB::table('cities')->insert([
			'id' => 1028, 
			'name' => 'Monte Alegre de Goiás',
			'state' => 9,
		]);
		DB::table('cities')->insert([
			'id' => 1029, 
			'name' => 'Montes Claros de Goiás',
			'state' => 9,
		]);
		DB::table('cities')->insert([
			'id' => 1030, 
			'name' => 'Montividiu',
			'state' => 9,
		]);
		DB::table('cities')->insert([
			'id' => 1031, 
			'name' => 'Montividiu do Norte',
			'state' => 9,
		]);
		DB::table('cities')->insert([
			'id' => 1032, 
			'name' => 'Morrinhos',
			'state' => 9,
		]);
		DB::table('cities')->insert([
			'id' => 1033, 
			'name' => 'Morro Agudo de Goiás',
			'state' => 9,
		]);
		DB::table('cities')->insert([
			'id' => 1034, 
			'name' => 'Mossâmedes',
			'state' => 9,
		]);
		DB::table('cities')->insert([
			'id' => 1035, 
			'name' => 'Mozarlândia',
			'state' => 9,
		]);
		DB::table('cities')->insert([
			'id' => 1036, 
			'name' => 'Mundo Novo',
			'state' => 9,
		]);
		DB::table('cities')->insert([
			'id' => 1037, 
			'name' => 'Mutunópolis',
			'state' => 9,
		]);
		DB::table('cities')->insert([
			'id' => 1038, 
			'name' => 'Nazário',
			'state' => 9,
		]);
		DB::table('cities')->insert([
			'id' => 1039, 
			'name' => 'Nerópolis',
			'state' => 9,
		]);
		DB::table('cities')->insert([
			'id' => 1040, 
			'name' => 'Niquelândia',
			'state' => 9,
		]);
		DB::table('cities')->insert([
			'id' => 1041, 
			'name' => 'Nova América',
			'state' => 9,
		]);
		DB::table('cities')->insert([
			'id' => 1042, 
			'name' => 'Nova Aurora',
			'state' => 9,
		]);
		DB::table('cities')->insert([
			'id' => 1043, 
			'name' => 'Nova Crixás',
			'state' => 9,
		]);
		DB::table('cities')->insert([
			'id' => 1044, 
			'name' => 'Nova Glória',
			'state' => 9,
		]);
		DB::table('cities')->insert([
			'id' => 1045, 
			'name' => 'Nova Iguaçu de Goiás',
			'state' => 9,
		]);
		DB::table('cities')->insert([
			'id' => 1046, 
			'name' => 'Nova Roma',
			'state' => 9,
		]);
		DB::table('cities')->insert([
			'id' => 1047, 
			'name' => 'Nova Veneza',
			'state' => 9,
		]);
		DB::table('cities')->insert([
			'id' => 1048, 
			'name' => 'Novo Brasil',
			'state' => 9,
		]);
		DB::table('cities')->insert([
			'id' => 1049, 
			'name' => 'Novo Gama',
			'state' => 9,
		]);
		DB::table('cities')->insert([
			'id' => 1050, 
			'name' => 'Novo Planalto',
			'state' => 9,
		]);
		DB::table('cities')->insert([
			'id' => 1051, 
			'name' => 'Orizona',
			'state' => 9,
		]);
		DB::table('cities')->insert([
			'id' => 1052, 
			'name' => 'Ouro Verde de Goiás',
			'state' => 9,
		]);
		DB::table('cities')->insert([
			'id' => 1053, 
			'name' => 'Ouvidor',
			'state' => 9,
		]);
		DB::table('cities')->insert([
			'id' => 1054, 
			'name' => 'Padre Bernardo',
			'state' => 9,
		]);
		DB::table('cities')->insert([
			'id' => 1055, 
			'name' => 'Palestina de Goiás',
			'state' => 9,
		]);
		DB::table('cities')->insert([
			'id' => 1056, 
			'name' => 'Palmeiras de Goiás',
			'state' => 9,
		]);
		DB::table('cities')->insert([
			'id' => 1057, 
			'name' => 'Palmelo',
			'state' => 9,
		]);
		DB::table('cities')->insert([
			'id' => 1058, 
			'name' => 'Palminópolis',
			'state' => 9,
		]);
		DB::table('cities')->insert([
			'id' => 1059, 
			'name' => 'Panamá',
			'state' => 9,
		]);
		DB::table('cities')->insert([
			'id' => 1060, 
			'name' => 'Paranaiguara',
			'state' => 9,
		]);
		DB::table('cities')->insert([
			'id' => 1061, 
			'name' => 'Paraúna',
			'state' => 9,
		]);
		DB::table('cities')->insert([
			'id' => 1062, 
			'name' => 'Perolândia',
			'state' => 9,
		]);
		DB::table('cities')->insert([
			'id' => 1063, 
			'name' => 'Petrolina de Goiás',
			'state' => 9,
		]);
		DB::table('cities')->insert([
			'id' => 1064, 
			'name' => 'Pilar de Goiás',
			'state' => 9,
		]);
		DB::table('cities')->insert([
			'id' => 1065, 
			'name' => 'Piracanjuba',
			'state' => 9,
		]);
		DB::table('cities')->insert([
			'id' => 1066, 
			'name' => 'Piranhas',
			'state' => 9,
		]);
		DB::table('cities')->insert([
			'id' => 1067, 
			'name' => 'Pirenópolis',
			'state' => 9,
		]);
		DB::table('cities')->insert([
			'id' => 1068, 
			'name' => 'Pires do Rio',
			'state' => 9,
		]);
		DB::table('cities')->insert([
			'id' => 1069, 
			'name' => 'Planaltina',
			'state' => 9,
		]);
		DB::table('cities')->insert([
			'id' => 1070, 
			'name' => 'Pontalina',
			'state' => 9,
		]);
		DB::table('cities')->insert([
			'id' => 1071, 
			'name' => 'Porangatu',
			'state' => 9,
		]);
		DB::table('cities')->insert([
			'id' => 1072, 
			'name' => 'Porteirão',
			'state' => 9,
		]);
		DB::table('cities')->insert([
			'id' => 1073, 
			'name' => 'Portelândia',
			'state' => 9,
		]);
		DB::table('cities')->insert([
			'id' => 1074, 
			'name' => 'Posse',
			'state' => 9,
		]);
		DB::table('cities')->insert([
			'id' => 1075, 
			'name' => 'Professor Jamil',
			'state' => 9,
		]);
		DB::table('cities')->insert([
			'id' => 1076, 
			'name' => 'Quirinópolis',
			'state' => 9,
		]);
		DB::table('cities')->insert([
			'id' => 1077, 
			'name' => 'Rialma',
			'state' => 9,
		]);
		DB::table('cities')->insert([
			'id' => 1078, 
			'name' => 'Rianápolis',
			'state' => 9,
		]);
		DB::table('cities')->insert([
			'id' => 1079, 
			'name' => 'Rio Quente',
			'state' => 9,
		]);
		DB::table('cities')->insert([
			'id' => 1080, 
			'name' => 'Rio Verde',
			'state' => 9,
		]);
		DB::table('cities')->insert([
			'id' => 1081, 
			'name' => 'Rubiataba',
			'state' => 9,
		]);
		DB::table('cities')->insert([
			'id' => 1082, 
			'name' => 'Sanclerlândia',
			'state' => 9,
		]);
		DB::table('cities')->insert([
			'id' => 1083, 
			'name' => 'Santa Bárbara de Goiás',
			'state' => 9,
		]);
		DB::table('cities')->insert([
			'id' => 1084, 
			'name' => 'Santa Cruz de Goiás',
			'state' => 9,
		]);
		DB::table('cities')->insert([
			'id' => 1085, 
			'name' => 'Santa Fé de Goiás',
			'state' => 9,
		]);
		DB::table('cities')->insert([
			'id' => 1086, 
			'name' => 'Santa Helena de Goiás',
			'state' => 9,
		]);
		DB::table('cities')->insert([
			'id' => 1087, 
			'name' => 'Santa Isabel',
			'state' => 9,
		]);
		DB::table('cities')->insert([
			'id' => 1088, 
			'name' => 'Santa Rita do Araguaia',
			'state' => 9,
		]);
		DB::table('cities')->insert([
			'id' => 1089, 
			'name' => 'Santa Rita do Novo Destino',
			'state' => 9,
		]);
		DB::table('cities')->insert([
			'id' => 1090, 
			'name' => 'Santa Rosa de Goiás',
			'state' => 9,
		]);
		DB::table('cities')->insert([
			'id' => 1091, 
			'name' => 'Santa Tereza de Goiás',
			'state' => 9,
		]);
		DB::table('cities')->insert([
			'id' => 1092, 
			'name' => 'Santa Terezinha de Goiás',
			'state' => 9,
		]);
		DB::table('cities')->insert([
			'id' => 1093, 
			'name' => 'Santo Antônio da Barra',
			'state' => 9,
		]);
		DB::table('cities')->insert([
			'id' => 1094, 
			'name' => 'Santo Antônio de Goiás',
			'state' => 9,
		]);
		DB::table('cities')->insert([
			'id' => 1095, 
			'name' => 'Santo Antônio do Descoberto',
			'state' => 9,
		]);
		DB::table('cities')->insert([
			'id' => 1096, 
			'name' => 'São Domingos',
			'state' => 9,
		]);
		DB::table('cities')->insert([
			'id' => 1097, 
			'name' => 'São Francisco de Goiás',
			'state' => 9,
		]);
		DB::table('cities')->insert([
			'id' => 1098, 
			'name' => 'São João d`Aliança',
			'state' => 9,
		]);
		DB::table('cities')->insert([
			'id' => 1099, 
			'name' => 'São João da Paraúna',
			'state' => 9,
		]);
		DB::table('cities')->insert([
			'id' => 1100, 
			'name' => 'São Luís de Montes Belos',
			'state' => 9,
		]);
		DB::table('cities')->insert([
			'id' => 1101, 
			'name' => 'São Luíz do Norte',
			'state' => 9,
		]);
		DB::table('cities')->insert([
			'id' => 1102, 
			'name' => 'São Miguel do Araguaia',
			'state' => 9,
		]);
		DB::table('cities')->insert([
			'id' => 1103, 
			'name' => 'São Miguel do Passa Quatro',
			'state' => 9,
		]);
		DB::table('cities')->insert([
			'id' => 1104, 
			'name' => 'São Patrício',
			'state' => 9,
		]);
		DB::table('cities')->insert([
			'id' => 1105, 
			'name' => 'São Simão',
			'state' => 9,
		]);
		DB::table('cities')->insert([
			'id' => 1106, 
			'name' => 'Senador Canedo',
			'state' => 9,
		]);
		DB::table('cities')->insert([
			'id' => 1107, 
			'name' => 'Serranópolis',
			'state' => 9,
		]);
		DB::table('cities')->insert([
			'id' => 1108, 
			'name' => 'Silvânia',
			'state' => 9,
		]);
		DB::table('cities')->insert([
			'id' => 1109, 
			'name' => 'Simolândia',
			'state' => 9,
		]);
		DB::table('cities')->insert([
			'id' => 1110, 
			'name' => 'Sítio d`Abadia',
			'state' => 9,
		]);
		DB::table('cities')->insert([
			'id' => 1111, 
			'name' => 'Taquaral de Goiás',
			'state' => 9,
		]);
		DB::table('cities')->insert([
			'id' => 1112, 
			'name' => 'Teresina de Goiás',
			'state' => 9,
		]);
		DB::table('cities')->insert([
			'id' => 1113, 
			'name' => 'Terezópolis de Goiás',
			'state' => 9,
		]);
		DB::table('cities')->insert([
			'id' => 1114, 
			'name' => 'Três Ranchos',
			'state' => 9,
		]);
		DB::table('cities')->insert([
			'id' => 1115, 
			'name' => 'Trindade',
			'state' => 9,
		]);
		DB::table('cities')->insert([
			'id' => 1116, 
			'name' => 'Trombas',
			'state' => 9,
		]);
		DB::table('cities')->insert([
			'id' => 1117, 
			'name' => 'Turvânia',
			'state' => 9,
		]);
		DB::table('cities')->insert([
			'id' => 1118, 
			'name' => 'Turvelândia',
			'state' => 9,
		]);
		DB::table('cities')->insert([
			'id' => 1119, 
			'name' => 'Uirapuru',
			'state' => 9,
		]);
		DB::table('cities')->insert([
			'id' => 1120, 
			'name' => 'Uruaçu',
			'state' => 9,
		]);
		DB::table('cities')->insert([
			'id' => 1121, 
			'name' => 'Uruana',
			'state' => 9,
		]);
		DB::table('cities')->insert([
			'id' => 1122, 
			'name' => 'Urutaí',
			'state' => 9,
		]);
		DB::table('cities')->insert([
			'id' => 1123, 
			'name' => 'Valparaíso de Goiás',
			'state' => 9,
		]);
		DB::table('cities')->insert([
			'id' => 1124, 
			'name' => 'Varjão',
			'state' => 9,
		]);
		DB::table('cities')->insert([
			'id' => 1125, 
			'name' => 'Vianópolis',
			'state' => 9,
		]);
		DB::table('cities')->insert([
			'id' => 1126, 
			'name' => 'Vicentinópolis',
			'state' => 9,
		]);
		DB::table('cities')->insert([
			'id' => 1127, 
			'name' => 'Vila Boa',
			'state' => 9,
		]);
		DB::table('cities')->insert([
			'id' => 1128, 
			'name' => 'Vila Propício',
			'state' => 9,
		]);
		DB::table('cities')->insert([
			'id' => 1129, 
			'name' => 'Açailândia',
			'state' => 10,
		]);
		DB::table('cities')->insert([
			'id' => 1130, 
			'name' => 'Afonso Cunha',
			'state' => 10,
		]);
		DB::table('cities')->insert([
			'id' => 1131, 
			'name' => 'Água Doce do Maranhão',
			'state' => 10,
		]);
		DB::table('cities')->insert([
			'id' => 1132, 
			'name' => 'Alcântara',
			'state' => 10,
		]);
		DB::table('cities')->insert([
			'id' => 1133, 
			'name' => 'Aldeias Altas',
			'state' => 10,
		]);
		DB::table('cities')->insert([
			'id' => 1134, 
			'name' => 'Altamira do Maranhão',
			'state' => 10,
		]);
		DB::table('cities')->insert([
			'id' => 1135, 
			'name' => 'Alto Alegre do Maranhão',
			'state' => 10,
		]);
		DB::table('cities')->insert([
			'id' => 1136, 
			'name' => 'Alto Alegre do Pindaré',
			'state' => 10,
		]);
		DB::table('cities')->insert([
			'id' => 1137, 
			'name' => 'Alto Parnaíba',
			'state' => 10,
		]);
		DB::table('cities')->insert([
			'id' => 1138, 
			'name' => 'Amapá do Maranhão',
			'state' => 10,
		]);
		DB::table('cities')->insert([
			'id' => 1139, 
			'name' => 'Amarante do Maranhão',
			'state' => 10,
		]);
		DB::table('cities')->insert([
			'id' => 1140, 
			'name' => 'Anajatuba',
			'state' => 10,
		]);
		DB::table('cities')->insert([
			'id' => 1141, 
			'name' => 'Anapurus',
			'state' => 10,
		]);
		DB::table('cities')->insert([
			'id' => 1142, 
			'name' => 'Apicum-Açu',
			'state' => 10,
		]);
		DB::table('cities')->insert([
			'id' => 1143, 
			'name' => 'Araguanã',
			'state' => 10,
		]);
		DB::table('cities')->insert([
			'id' => 1144, 
			'name' => 'Araioses',
			'state' => 10,
		]);
		DB::table('cities')->insert([
			'id' => 1145, 
			'name' => 'Arame',
			'state' => 10,
		]);
		DB::table('cities')->insert([
			'id' => 1146, 
			'name' => 'Arari',
			'state' => 10,
		]);
		DB::table('cities')->insert([
			'id' => 1147, 
			'name' => 'Axixá',
			'state' => 10,
		]);
		DB::table('cities')->insert([
			'id' => 1148, 
			'name' => 'Bacabal',
			'state' => 10,
		]);
		DB::table('cities')->insert([
			'id' => 1149, 
			'name' => 'Bacabeira',
			'state' => 10,
		]);
		DB::table('cities')->insert([
			'id' => 1150, 
			'name' => 'Bacuri',
			'state' => 10,
		]);
		DB::table('cities')->insert([
			'id' => 1151, 
			'name' => 'Bacurituba',
			'state' => 10,
		]);
		DB::table('cities')->insert([
			'id' => 1152, 
			'name' => 'Balsas',
			'state' => 10,
		]);
		DB::table('cities')->insert([
			'id' => 1153, 
			'name' => 'Barão de Grajaú',
			'state' => 10,
		]);
		DB::table('cities')->insert([
			'id' => 1154, 
			'name' => 'Barra do Corda',
			'state' => 10,
		]);
		DB::table('cities')->insert([
			'id' => 1155, 
			'name' => 'Barreirinhas',
			'state' => 10,
		]);
		DB::table('cities')->insert([
			'id' => 1156, 
			'name' => 'Bela Vista do Maranhão',
			'state' => 10,
		]);
		DB::table('cities')->insert([
			'id' => 1157, 
			'name' => 'Belágua',
			'state' => 10,
		]);
		DB::table('cities')->insert([
			'id' => 1158, 
			'name' => 'Benedito Leite',
			'state' => 10,
		]);
		DB::table('cities')->insert([
			'id' => 1159, 
			'name' => 'Bequimão',
			'state' => 10,
		]);
		DB::table('cities')->insert([
			'id' => 1160, 
			'name' => 'Bernardo do Mearim',
			'state' => 10,
		]);
		DB::table('cities')->insert([
			'id' => 1161, 
			'name' => 'Boa Vista do Gurupi',
			'state' => 10,
		]);
		DB::table('cities')->insert([
			'id' => 1162, 
			'name' => 'Bom Jardim',
			'state' => 10,
		]);
		DB::table('cities')->insert([
			'id' => 1163, 
			'name' => 'Bom Jesus das Selvas',
			'state' => 10,
		]);
		DB::table('cities')->insert([
			'id' => 1164, 
			'name' => 'Bom Lugar',
			'state' => 10,
		]);
		DB::table('cities')->insert([
			'id' => 1165, 
			'name' => 'Brejo',
			'state' => 10,
		]);
		DB::table('cities')->insert([
			'id' => 1166, 
			'name' => 'Brejo de Areia',
			'state' => 10,
		]);
		DB::table('cities')->insert([
			'id' => 1167, 
			'name' => 'Buriti',
			'state' => 10,
		]);
		DB::table('cities')->insert([
			'id' => 1168, 
			'name' => 'Buriti Bravo',
			'state' => 10,
		]);
		DB::table('cities')->insert([
			'id' => 1169, 
			'name' => 'Buriticupu',
			'state' => 10,
		]);
		DB::table('cities')->insert([
			'id' => 1170, 
			'name' => 'Buritirana',
			'state' => 10,
		]);
		DB::table('cities')->insert([
			'id' => 1171, 
			'name' => 'Cachoeira Grande',
			'state' => 10,
		]);
		DB::table('cities')->insert([
			'id' => 1172, 
			'name' => 'Cajapió',
			'state' => 10,
		]);
		DB::table('cities')->insert([
			'id' => 1173, 
			'name' => 'Cajari',
			'state' => 10,
		]);
		DB::table('cities')->insert([
			'id' => 1174, 
			'name' => 'Campestre do Maranhão',
			'state' => 10,
		]);
		DB::table('cities')->insert([
			'id' => 1175, 
			'name' => 'Cândido Mendes',
			'state' => 10,
		]);
		DB::table('cities')->insert([
			'id' => 1176, 
			'name' => 'Cantanhede',
			'state' => 10,
		]);
		DB::table('cities')->insert([
			'id' => 1177, 
			'name' => 'Capinzal do Norte',
			'state' => 10,
		]);
		DB::table('cities')->insert([
			'id' => 1178, 
			'name' => 'Carolina',
			'state' => 10,
		]);
		DB::table('cities')->insert([
			'id' => 1179, 
			'name' => 'Carutapera',
			'state' => 10,
		]);
		DB::table('cities')->insert([
			'id' => 1180, 
			'name' => 'Caxias',
			'state' => 10,
		]);
		DB::table('cities')->insert([
			'id' => 1181, 
			'name' => 'Cedral',
			'state' => 10,
		]);
		DB::table('cities')->insert([
			'id' => 1182, 
			'name' => 'Central do Maranhão',
			'state' => 10,
		]);
		DB::table('cities')->insert([
			'id' => 1183, 
			'name' => 'Centro do Guilherme',
			'state' => 10,
		]);
		DB::table('cities')->insert([
			'id' => 1184, 
			'name' => 'Centro Novo do Maranhão',
			'state' => 10,
		]);
		DB::table('cities')->insert([
			'id' => 1185, 
			'name' => 'Chapadinha',
			'state' => 10,
		]);
		DB::table('cities')->insert([
			'id' => 1186, 
			'name' => 'Cidelândia',
			'state' => 10,
		]);
		DB::table('cities')->insert([
			'id' => 1187, 
			'name' => 'Codó',
			'state' => 10,
		]);
		DB::table('cities')->insert([
			'id' => 1188, 
			'name' => 'Coelho Neto',
			'state' => 10,
		]);
		DB::table('cities')->insert([
			'id' => 1189, 
			'name' => 'Colinas',
			'state' => 10,
		]);
		DB::table('cities')->insert([
			'id' => 1190, 
			'name' => 'Conceição do Lago-Açu',
			'state' => 10,
		]);
		DB::table('cities')->insert([
			'id' => 1191, 
			'name' => 'Coroatá',
			'state' => 10,
		]);
		DB::table('cities')->insert([
			'id' => 1192, 
			'name' => 'Cururupu',
			'state' => 10,
		]);
		DB::table('cities')->insert([
			'id' => 1193, 
			'name' => 'Davinópolis',
			'state' => 10,
		]);
		DB::table('cities')->insert([
			'id' => 1194, 
			'name' => 'Dom Pedro',
			'state' => 10,
		]);
		DB::table('cities')->insert([
			'id' => 1195, 
			'name' => 'Duque Bacelar',
			'state' => 10,
		]);
		DB::table('cities')->insert([
			'id' => 1196, 
			'name' => 'Esperantinópolis',
			'state' => 10,
		]);
		DB::table('cities')->insert([
			'id' => 1197, 
			'name' => 'Estreito',
			'state' => 10,
		]);
		DB::table('cities')->insert([
			'id' => 1198, 
			'name' => 'Feira Nova do Maranhão',
			'state' => 10,
		]);
		DB::table('cities')->insert([
			'id' => 1199, 
			'name' => 'Fernando Falcão',
			'state' => 10,
		]);
		DB::table('cities')->insert([
			'id' => 1200, 
			'name' => 'Formosa da Serra Negra',
			'state' => 10,
		]);
		DB::table('cities')->insert([
			'id' => 1201, 
			'name' => 'Fortaleza dos Nogueiras',
			'state' => 10,
		]);
		DB::table('cities')->insert([
			'id' => 1202, 
			'name' => 'Fortuna',
			'state' => 10,
		]);
		DB::table('cities')->insert([
			'id' => 1203, 
			'name' => 'Godofredo Viana',
			'state' => 10,
		]);
		DB::table('cities')->insert([
			'id' => 1204, 
			'name' => 'Gonçalves Dias',
			'state' => 10,
		]);
		DB::table('cities')->insert([
			'id' => 1205, 
			'name' => 'Governador Archer',
			'state' => 10,
		]);
		DB::table('cities')->insert([
			'id' => 1206, 
			'name' => 'Governador Edison Lobão',
			'state' => 10,
		]);
		DB::table('cities')->insert([
			'id' => 1207, 
			'name' => 'Governador Eugênio Barros',
			'state' => 10,
		]);
		DB::table('cities')->insert([
			'id' => 1208, 
			'name' => 'Governador Luiz Rocha',
			'state' => 10,
		]);
		DB::table('cities')->insert([
			'id' => 1209, 
			'name' => 'Governador Newton Bello',
			'state' => 10,
		]);
		DB::table('cities')->insert([
			'id' => 1210, 
			'name' => 'Governador Nunes Freire',
			'state' => 10,
		]);
		DB::table('cities')->insert([
			'id' => 1211, 
			'name' => 'Graça Aranha',
			'state' => 10,
		]);
		DB::table('cities')->insert([
			'id' => 1212, 
			'name' => 'Grajaú',
			'state' => 10,
		]);
		DB::table('cities')->insert([
			'id' => 1213, 
			'name' => 'Guimarães',
			'state' => 10,
		]);
		DB::table('cities')->insert([
			'id' => 1214, 
			'name' => 'Humberto de Campos',
			'state' => 10,
		]);
		DB::table('cities')->insert([
			'id' => 1215, 
			'name' => 'Icatu',
			'state' => 10,
		]);
		DB::table('cities')->insert([
			'id' => 1216, 
			'name' => 'Igarapé do Meio',
			'state' => 10,
		]);
		DB::table('cities')->insert([
			'id' => 1217, 
			'name' => 'Igarapé Grande',
			'state' => 10,
		]);
		DB::table('cities')->insert([
			'id' => 1218, 
			'name' => 'Imperatriz',
			'state' => 10,
		]);
		DB::table('cities')->insert([
			'id' => 1219, 
			'name' => 'Itaipava do Grajaú',
			'state' => 10,
		]);
		DB::table('cities')->insert([
			'id' => 1220, 
			'name' => 'Itapecuru Mirim',
			'state' => 10,
		]);
		DB::table('cities')->insert([
			'id' => 1221, 
			'name' => 'Itinga do Maranhão',
			'state' => 10,
		]);
		DB::table('cities')->insert([
			'id' => 1222, 
			'name' => 'Jatobá',
			'state' => 10,
		]);
		DB::table('cities')->insert([
			'id' => 1223, 
			'name' => 'Jenipapo dos Vieiras',
			'state' => 10,
		]);
		DB::table('cities')->insert([
			'id' => 1224, 
			'name' => 'João Lisboa',
			'state' => 10,
		]);
		DB::table('cities')->insert([
			'id' => 1225, 
			'name' => 'Joselândia',
			'state' => 10,
		]);
		DB::table('cities')->insert([
			'id' => 1226, 
			'name' => 'Junco do Maranhão',
			'state' => 10,
		]);
		DB::table('cities')->insert([
			'id' => 1227, 
			'name' => 'Lago da Pedra',
			'state' => 10,
		]);
		DB::table('cities')->insert([
			'id' => 1228, 
			'name' => 'Lago do Junco',
			'state' => 10,
		]);
		DB::table('cities')->insert([
			'id' => 1229, 
			'name' => 'Lago dos Rodrigues',
			'state' => 10,
		]);
		DB::table('cities')->insert([
			'id' => 1230, 
			'name' => 'Lago Verde',
			'state' => 10,
		]);
		DB::table('cities')->insert([
			'id' => 1231, 
			'name' => 'Lagoa do Mato',
			'state' => 10,
		]);
		DB::table('cities')->insert([
			'id' => 1232, 
			'name' => 'Lagoa Grande do Maranhão',
			'state' => 10,
		]);
		DB::table('cities')->insert([
			'id' => 1233, 
			'name' => 'Lajeado Novo',
			'state' => 10,
		]);
		DB::table('cities')->insert([
			'id' => 1234, 
			'name' => 'Lima Campos',
			'state' => 10,
		]);
		DB::table('cities')->insert([
			'id' => 1235, 
			'name' => 'Loreto',
			'state' => 10,
		]);
		DB::table('cities')->insert([
			'id' => 1236, 
			'name' => 'Luís Domingues',
			'state' => 10,
		]);
		DB::table('cities')->insert([
			'id' => 1237, 
			'name' => 'Magalhães de Almeida',
			'state' => 10,
		]);
		DB::table('cities')->insert([
			'id' => 1238, 
			'name' => 'Maracaçumé',
			'state' => 10,
		]);
		DB::table('cities')->insert([
			'id' => 1239, 
			'name' => 'Marajá do Sena',
			'state' => 10,
		]);
		DB::table('cities')->insert([
			'id' => 1240, 
			'name' => 'Maranhãozinho',
			'state' => 10,
		]);
		DB::table('cities')->insert([
			'id' => 1241, 
			'name' => 'Mata Roma',
			'state' => 10,
		]);
		DB::table('cities')->insert([
			'id' => 1242, 
			'name' => 'Matinha',
			'state' => 10,
		]);
		DB::table('cities')->insert([
			'id' => 1243, 
			'name' => 'Matões',
			'state' => 10,
		]);
		DB::table('cities')->insert([
			'id' => 1244, 
			'name' => 'Matões do Norte',
			'state' => 10,
		]);
		DB::table('cities')->insert([
			'id' => 1245, 
			'name' => 'Milagres do Maranhão',
			'state' => 10,
		]);
		DB::table('cities')->insert([
			'id' => 1246, 
			'name' => 'Mirador',
			'state' => 10,
		]);
		DB::table('cities')->insert([
			'id' => 1247, 
			'name' => 'Miranda do Norte',
			'state' => 10,
		]);
		DB::table('cities')->insert([
			'id' => 1248, 
			'name' => 'Mirinzal',
			'state' => 10,
		]);
		DB::table('cities')->insert([
			'id' => 1249, 
			'name' => 'Monção',
			'state' => 10,
		]);
		DB::table('cities')->insert([
			'id' => 1250, 
			'name' => 'Montes Altos',
			'state' => 10,
		]);
		DB::table('cities')->insert([
			'id' => 1251, 
			'name' => 'Morros',
			'state' => 10,
		]);
		DB::table('cities')->insert([
			'id' => 1252, 
			'name' => 'Nina Rodrigues',
			'state' => 10,
		]);
		DB::table('cities')->insert([
			'id' => 1253, 
			'name' => 'Nova Colinas',
			'state' => 10,
		]);
		DB::table('cities')->insert([
			'id' => 1254, 
			'name' => 'Nova Iorque',
			'state' => 10,
		]);
		DB::table('cities')->insert([
			'id' => 1255, 
			'name' => 'Nova Olinda do Maranhão',
			'state' => 10,
		]);
		DB::table('cities')->insert([
			'id' => 1256, 
			'name' => 'Olho d`Água das Cunhãs',
			'state' => 10,
		]);
		DB::table('cities')->insert([
			'id' => 1257, 
			'name' => 'Olinda Nova do Maranhão',
			'state' => 10,
		]);
		DB::table('cities')->insert([
			'id' => 1258, 
			'name' => 'Paço do Lumiar',
			'state' => 10,
		]);
		DB::table('cities')->insert([
			'id' => 1259, 
			'name' => 'Palmeirândia',
			'state' => 10,
		]);
		DB::table('cities')->insert([
			'id' => 1260, 
			'name' => 'Paraibano',
			'state' => 10,
		]);
		DB::table('cities')->insert([
			'id' => 1261, 
			'name' => 'Parnarama',
			'state' => 10,
		]);
		DB::table('cities')->insert([
			'id' => 1262, 
			'name' => 'Passagem Franca',
			'state' => 10,
		]);
		DB::table('cities')->insert([
			'id' => 1263, 
			'name' => 'Pastos Bons',
			'state' => 10,
		]);
		DB::table('cities')->insert([
			'id' => 1264, 
			'name' => 'Paulino Neves',
			'state' => 10,
		]);
		DB::table('cities')->insert([
			'id' => 1265, 
			'name' => 'Paulo Ramos',
			'state' => 10,
		]);
		DB::table('cities')->insert([
			'id' => 1266, 
			'name' => 'Pedreiras',
			'state' => 10,
		]);
		DB::table('cities')->insert([
			'id' => 1267, 
			'name' => 'Pedro do Rosário',
			'state' => 10,
		]);
		DB::table('cities')->insert([
			'id' => 1268, 
			'name' => 'Penalva',
			'state' => 10,
		]);
		DB::table('cities')->insert([
			'id' => 1269, 
			'name' => 'Peri Mirim',
			'state' => 10,
		]);
		DB::table('cities')->insert([
			'id' => 1270, 
			'name' => 'Peritoró',
			'state' => 10,
		]);
		DB::table('cities')->insert([
			'id' => 1271, 
			'name' => 'Pindaré-Mirim',
			'state' => 10,
		]);
		DB::table('cities')->insert([
			'id' => 1272, 
			'name' => 'Pinheiro',
			'state' => 10,
		]);
		DB::table('cities')->insert([
			'id' => 1273, 
			'name' => 'Pio XII',
			'state' => 10,
		]);
		DB::table('cities')->insert([
			'id' => 1274, 
			'name' => 'Pirapemas',
			'state' => 10,
		]);
		DB::table('cities')->insert([
			'id' => 1275, 
			'name' => 'Poção de Pedras',
			'state' => 10,
		]);
		DB::table('cities')->insert([
			'id' => 1276, 
			'name' => 'Porto Franco',
			'state' => 10,
		]);
		DB::table('cities')->insert([
			'id' => 1277, 
			'name' => 'Porto Rico do Maranhão',
			'state' => 10,
		]);
		DB::table('cities')->insert([
			'id' => 1278, 
			'name' => 'Presidente Dutra',
			'state' => 10,
		]);
		DB::table('cities')->insert([
			'id' => 1279, 
			'name' => 'Presidente Juscelino',
			'state' => 10,
		]);
		DB::table('cities')->insert([
			'id' => 1280, 
			'name' => 'Presidente Médici',
			'state' => 10,
		]);
		DB::table('cities')->insert([
			'id' => 1281, 
			'name' => 'Presidente Sarney',
			'state' => 10,
		]);
		DB::table('cities')->insert([
			'id' => 1282, 
			'name' => 'Presidente Vargas',
			'state' => 10,
		]);
		DB::table('cities')->insert([
			'id' => 1283, 
			'name' => 'Primeira Cruz',
			'state' => 10,
		]);
		DB::table('cities')->insert([
			'id' => 1284, 
			'name' => 'Raposa',
			'state' => 10,
		]);
		DB::table('cities')->insert([
			'id' => 1285, 
			'name' => 'Riachão',
			'state' => 10,
		]);
		DB::table('cities')->insert([
			'id' => 1286, 
			'name' => 'Ribamar Fiquene',
			'state' => 10,
		]);
		DB::table('cities')->insert([
			'id' => 1287, 
			'name' => 'Rosário',
			'state' => 10,
		]);
		DB::table('cities')->insert([
			'id' => 1288, 
			'name' => 'Sambaíba',
			'state' => 10,
		]);
		DB::table('cities')->insert([
			'id' => 1289, 
			'name' => 'Santa Filomena do Maranhão',
			'state' => 10,
		]);
		DB::table('cities')->insert([
			'id' => 1290, 
			'name' => 'Santa Helena',
			'state' => 10,
		]);
		DB::table('cities')->insert([
			'id' => 1291, 
			'name' => 'Santa Inês',
			'state' => 10,
		]);
		DB::table('cities')->insert([
			'id' => 1292, 
			'name' => 'Santa Luzia',
			'state' => 10,
		]);
		DB::table('cities')->insert([
			'id' => 1293, 
			'name' => 'Santa Luzia do Paruá',
			'state' => 10,
		]);
		DB::table('cities')->insert([
			'id' => 1294, 
			'name' => 'Santa Quitéria do Maranhão',
			'state' => 10,
		]);
		DB::table('cities')->insert([
			'id' => 1295, 
			'name' => 'Santa Rita',
			'state' => 10,
		]);
		DB::table('cities')->insert([
			'id' => 1296, 
			'name' => 'Santana do Maranhão',
			'state' => 10,
		]);
		DB::table('cities')->insert([
			'id' => 1297, 
			'name' => 'Santo Amaro do Maranhão',
			'state' => 10,
		]);
		DB::table('cities')->insert([
			'id' => 1298, 
			'name' => 'Santo Antônio dos Lopes',
			'state' => 10,
		]);
		DB::table('cities')->insert([
			'id' => 1299, 
			'name' => 'São Benedito do Rio Preto',
			'state' => 10,
		]);
		DB::table('cities')->insert([
			'id' => 1300, 
			'name' => 'São Bento',
			'state' => 10,
		]);
		DB::table('cities')->insert([
			'id' => 1301, 
			'name' => 'São Bernardo',
			'state' => 10,
		]);
		DB::table('cities')->insert([
			'id' => 1302, 
			'name' => 'São Domingos do Azeitão',
			'state' => 10,
		]);
		DB::table('cities')->insert([
			'id' => 1303, 
			'name' => 'São Domingos do Maranhão',
			'state' => 10,
		]);
		DB::table('cities')->insert([
			'id' => 1304, 
			'name' => 'São Félix de Balsas',
			'state' => 10,
		]);
		DB::table('cities')->insert([
			'id' => 1305, 
			'name' => 'São Francisco do Brejão',
			'state' => 10,
		]);
		DB::table('cities')->insert([
			'id' => 1306, 
			'name' => 'São Francisco do Maranhão',
			'state' => 10,
		]);
		DB::table('cities')->insert([
			'id' => 1307, 
			'name' => 'São João Batista',
			'state' => 10,
		]);
		DB::table('cities')->insert([
			'id' => 1308, 
			'name' => 'São João do Carú',
			'state' => 10,
		]);
		DB::table('cities')->insert([
			'id' => 1309, 
			'name' => 'São João do Paraíso',
			'state' => 10,
		]);
		DB::table('cities')->insert([
			'id' => 1310, 
			'name' => 'São João do Soter',
			'state' => 10,
		]);
		DB::table('cities')->insert([
			'id' => 1311, 
			'name' => 'São João dos Patos',
			'state' => 10,
		]);
		DB::table('cities')->insert([
			'id' => 1312, 
			'name' => 'São José de Ribamar',
			'state' => 10,
		]);
		DB::table('cities')->insert([
			'id' => 1313, 
			'name' => 'São José dos Basílios',
			'state' => 10,
		]);
		DB::table('cities')->insert([
			'id' => 1314, 
			'name' => 'São Luís',
			'state' => 10,
		]);
		DB::table('cities')->insert([
			'id' => 1315, 
			'name' => 'São Luís Gonzaga do Maranhão',
			'state' => 10,
		]);
		DB::table('cities')->insert([
			'id' => 1316, 
			'name' => 'São Mateus do Maranhão',
			'state' => 10,
		]);
		DB::table('cities')->insert([
			'id' => 1317, 
			'name' => 'São Pedro da Água Branca',
			'state' => 10,
		]);
		DB::table('cities')->insert([
			'id' => 1318, 
			'name' => 'São Pedro dos Crentes',
			'state' => 10,
		]);
		DB::table('cities')->insert([
			'id' => 1319, 
			'name' => 'São Raimundo das Mangabeiras',
			'state' => 10,
		]);
		DB::table('cities')->insert([
			'id' => 1320, 
			'name' => 'São Raimundo do Doca Bezerra',
			'state' => 10,
		]);
		DB::table('cities')->insert([
			'id' => 1321, 
			'name' => 'São Roberto',
			'state' => 10,
		]);
		DB::table('cities')->insert([
			'id' => 1322, 
			'name' => 'São Vicente Ferrer',
			'state' => 10,
		]);
		DB::table('cities')->insert([
			'id' => 1323, 
			'name' => 'Satubinha',
			'state' => 10,
		]);
		DB::table('cities')->insert([
			'id' => 1324, 
			'name' => 'Senador Alexandre Costa',
			'state' => 10,
		]);
		DB::table('cities')->insert([
			'id' => 1325, 
			'name' => 'Senador La Rocque',
			'state' => 10,
		]);
		DB::table('cities')->insert([
			'id' => 1326, 
			'name' => 'Serrano do Maranhão',
			'state' => 10,
		]);
		DB::table('cities')->insert([
			'id' => 1327, 
			'name' => 'Sítio Novo',
			'state' => 10,
		]);
		DB::table('cities')->insert([
			'id' => 1328, 
			'name' => 'Sucupira do Norte',
			'state' => 10,
		]);
		DB::table('cities')->insert([
			'id' => 1329, 
			'name' => 'Sucupira do Riachão',
			'state' => 10,
		]);
		DB::table('cities')->insert([
			'id' => 1330, 
			'name' => 'Tasso Fragoso',
			'state' => 10,
		]);
		DB::table('cities')->insert([
			'id' => 1331, 
			'name' => 'Timbiras',
			'state' => 10,
		]);
		DB::table('cities')->insert([
			'id' => 1332, 
			'name' => 'Timon',
			'state' => 10,
		]);
		DB::table('cities')->insert([
			'id' => 1333, 
			'name' => 'Trizidela do Vale',
			'state' => 10,
		]);
		DB::table('cities')->insert([
			'id' => 1334, 
			'name' => 'Tufilândia',
			'state' => 10,
		]);
		DB::table('cities')->insert([
			'id' => 1335, 
			'name' => 'Tuntum',
			'state' => 10,
		]);
		DB::table('cities')->insert([
			'id' => 1336, 
			'name' => 'Turiaçu',
			'state' => 10,
		]);
		DB::table('cities')->insert([
			'id' => 1337, 
			'name' => 'Turilândia',
			'state' => 10,
		]);
		DB::table('cities')->insert([
			'id' => 1338, 
			'name' => 'Tutóia',
			'state' => 10,
		]);
		DB::table('cities')->insert([
			'id' => 1339, 
			'name' => 'Urbano Santos',
			'state' => 10,
		]);
		DB::table('cities')->insert([
			'id' => 1340, 
			'name' => 'Vargem Grande',
			'state' => 10,
		]);
		DB::table('cities')->insert([
			'id' => 1341, 
			'name' => 'Viana',
			'state' => 10,
		]);
		DB::table('cities')->insert([
			'id' => 1342, 
			'name' => 'Vila Nova dos Martírios',
			'state' => 10,
		]);
		DB::table('cities')->insert([
			'id' => 1343, 
			'name' => 'Vitória do Mearim',
			'state' => 10,
		]);
		DB::table('cities')->insert([
			'id' => 1344, 
			'name' => 'Vitorino Freire',
			'state' => 10,
		]);
		DB::table('cities')->insert([
			'id' => 1345, 
			'name' => 'Zé Doca',
			'state' => 10,
		]);
		DB::table('cities')->insert([
			'id' => 1346, 
			'name' => 'Acorizal',
			'state' => 13,
		]);
		DB::table('cities')->insert([
			'id' => 1347, 
			'name' => 'Água Boa',
			'state' => 13,
		]);
		DB::table('cities')->insert([
			'id' => 1348, 
			'name' => 'Alta Floresta',
			'state' => 13,
		]);
		DB::table('cities')->insert([
			'id' => 1349, 
			'name' => 'Alto Araguaia',
			'state' => 13,
		]);
		DB::table('cities')->insert([
			'id' => 1350, 
			'name' => 'Alto Boa Vista',
			'state' => 13,
		]);
		DB::table('cities')->insert([
			'id' => 1351, 
			'name' => 'Alto Garças',
			'state' => 13,
		]);
		DB::table('cities')->insert([
			'id' => 1352, 
			'name' => 'Alto Paraguai',
			'state' => 13,
		]);
		DB::table('cities')->insert([
			'id' => 1353, 
			'name' => 'Alto Taquari',
			'state' => 13,
		]);
		DB::table('cities')->insert([
			'id' => 1354, 
			'name' => 'Apiacás',
			'state' => 13,
		]);
		DB::table('cities')->insert([
			'id' => 1355, 
			'name' => 'Araguaiana',
			'state' => 13,
		]);
		DB::table('cities')->insert([
			'id' => 1356, 
			'name' => 'Araguainha',
			'state' => 13,
		]);
		DB::table('cities')->insert([
			'id' => 1357, 
			'name' => 'Araputanga',
			'state' => 13,
		]);
		DB::table('cities')->insert([
			'id' => 1358, 
			'name' => 'Arenápolis',
			'state' => 13,
		]);
		DB::table('cities')->insert([
			'id' => 1359, 
			'name' => 'Aripuanã',
			'state' => 13,
		]);
		DB::table('cities')->insert([
			'id' => 1360, 
			'name' => 'Barão de Melgaço',
			'state' => 13,
		]);
		DB::table('cities')->insert([
			'id' => 1361, 
			'name' => 'Barra do Bugres',
			'state' => 13,
		]);
		DB::table('cities')->insert([
			'id' => 1362, 
			'name' => 'Barra do Garças',
			'state' => 13,
		]);
		DB::table('cities')->insert([
			'id' => 1363, 
			'name' => 'Bom Jesus do Araguaia',
			'state' => 13,
		]);
		DB::table('cities')->insert([
			'id' => 1364, 
			'name' => 'Brasnorte',
			'state' => 13,
		]);
		DB::table('cities')->insert([
			'id' => 1365, 
			'name' => 'Cáceres',
			'state' => 13,
		]);
		DB::table('cities')->insert([
			'id' => 1366, 
			'name' => 'Campinápolis',
			'state' => 13,
		]);
		DB::table('cities')->insert([
			'id' => 1367, 
			'name' => 'Campo Novo do Parecis',
			'state' => 13,
		]);
		DB::table('cities')->insert([
			'id' => 1368, 
			'name' => 'Campo Verde',
			'state' => 13,
		]);
		DB::table('cities')->insert([
			'id' => 1369, 
			'name' => 'Campos de Júlio',
			'state' => 13,
		]);
		DB::table('cities')->insert([
			'id' => 1370, 
			'name' => 'Canabrava do Norte',
			'state' => 13,
		]);
		DB::table('cities')->insert([
			'id' => 1371, 
			'name' => 'Canarana',
			'state' => 13,
		]);
		DB::table('cities')->insert([
			'id' => 1372, 
			'name' => 'Carlinda',
			'state' => 13,
		]);
		DB::table('cities')->insert([
			'id' => 1373, 
			'name' => 'Castanheira',
			'state' => 13,
		]);
		DB::table('cities')->insert([
			'id' => 1374, 
			'name' => 'Chapada dos Guimarães',
			'state' => 13,
		]);
		DB::table('cities')->insert([
			'id' => 1375, 
			'name' => 'Cláudia',
			'state' => 13,
		]);
		DB::table('cities')->insert([
			'id' => 1376, 
			'name' => 'Cocalinho',
			'state' => 13,
		]);
		DB::table('cities')->insert([
			'id' => 1377, 
			'name' => 'Colíder',
			'state' => 13,
		]);
		DB::table('cities')->insert([
			'id' => 1378, 
			'name' => 'Colniza',
			'state' => 13,
		]);
		DB::table('cities')->insert([
			'id' => 1379, 
			'name' => 'Comodoro',
			'state' => 13,
		]);
		DB::table('cities')->insert([
			'id' => 1380, 
			'name' => 'Confresa',
			'state' => 13,
		]);
		DB::table('cities')->insert([
			'id' => 1381, 
			'name' => 'Conquista d`Oeste',
			'state' => 13,
		]);
		DB::table('cities')->insert([
			'id' => 1382, 
			'name' => 'Cotriguaçu',
			'state' => 13,
		]);
		DB::table('cities')->insert([
			'id' => 1383, 
			'name' => 'Cuiabá',
			'state' => 13,
		]);
		DB::table('cities')->insert([
			'id' => 1384, 
			'name' => 'Curvelândia',
			'state' => 13,
		]);
		DB::table('cities')->insert([
			'id' => 1385, 
			'name' => 'Curvelândia',
			'state' => 13,
		]);
		DB::table('cities')->insert([
			'id' => 1386, 
			'name' => 'Denise',
			'state' => 13,
		]);
		DB::table('cities')->insert([
			'id' => 1387, 
			'name' => 'Diamantino',
			'state' => 13,
		]);
		DB::table('cities')->insert([
			'id' => 1388, 
			'name' => 'Dom Aquino',
			'state' => 13,
		]);
		DB::table('cities')->insert([
			'id' => 1389, 
			'name' => 'Feliz Natal',
			'state' => 13,
		]);
		DB::table('cities')->insert([
			'id' => 1390, 
			'name' => 'Figueirópolis d`Oeste',
			'state' => 13,
		]);
		DB::table('cities')->insert([
			'id' => 1391, 
			'name' => 'Gaúcha do Norte',
			'state' => 13,
		]);
		DB::table('cities')->insert([
			'id' => 1392, 
			'name' => 'General Carneiro',
			'state' => 13,
		]);
		DB::table('cities')->insert([
			'id' => 1393, 
			'name' => 'Glória d`Oeste',
			'state' => 13,
		]);
		DB::table('cities')->insert([
			'id' => 1394, 
			'name' => 'Guarantã do Norte',
			'state' => 13,
		]);
		DB::table('cities')->insert([
			'id' => 1395, 
			'name' => 'Guiratinga',
			'state' => 13,
		]);
		DB::table('cities')->insert([
			'id' => 1396, 
			'name' => 'Indiavaí',
			'state' => 13,
		]);
		DB::table('cities')->insert([
			'id' => 1397, 
			'name' => 'Ipiranga do Norte',
			'state' => 13,
		]);
		DB::table('cities')->insert([
			'id' => 1398, 
			'name' => 'Itanhangá',
			'state' => 13,
		]);
		DB::table('cities')->insert([
			'id' => 1399, 
			'name' => 'Itaúba',
			'state' => 13,
		]);
		DB::table('cities')->insert([
			'id' => 1400, 
			'name' => 'Itiquira',
			'state' => 13,
		]);
		DB::table('cities')->insert([
			'id' => 1401, 
			'name' => 'Jaciara',
			'state' => 13,
		]);
		DB::table('cities')->insert([
			'id' => 1402, 
			'name' => 'Jangada',
			'state' => 13,
		]);
		DB::table('cities')->insert([
			'id' => 1403, 
			'name' => 'Jauru',
			'state' => 13,
		]);
		DB::table('cities')->insert([
			'id' => 1404, 
			'name' => 'Juara',
			'state' => 13,
		]);
		DB::table('cities')->insert([
			'id' => 1405, 
			'name' => 'Juína',
			'state' => 13,
		]);
		DB::table('cities')->insert([
			'id' => 1406, 
			'name' => 'Juruena',
			'state' => 13,
		]);
		DB::table('cities')->insert([
			'id' => 1407, 
			'name' => 'Juscimeira',
			'state' => 13,
		]);
		DB::table('cities')->insert([
			'id' => 1408, 
			'name' => 'Lambari d`Oeste',
			'state' => 13,
		]);
		DB::table('cities')->insert([
			'id' => 1409, 
			'name' => 'Lucas do Rio Verde',
			'state' => 13,
		]);
		DB::table('cities')->insert([
			'id' => 1410, 
			'name' => 'Luciára',
			'state' => 13,
		]);
		DB::table('cities')->insert([
			'id' => 1411, 
			'name' => 'Marcelândia',
			'state' => 13,
		]);
		DB::table('cities')->insert([
			'id' => 1412, 
			'name' => 'Matupá',
			'state' => 13,
		]);
		DB::table('cities')->insert([
			'id' => 1413, 
			'name' => 'Mirassol d`Oeste',
			'state' => 13,
		]);
		DB::table('cities')->insert([
			'id' => 1414, 
			'name' => 'Nobres',
			'state' => 13,
		]);
		DB::table('cities')->insert([
			'id' => 1415, 
			'name' => 'Nortelândia',
			'state' => 13,
		]);
		DB::table('cities')->insert([
			'id' => 1416, 
			'name' => 'Nossa Senhora do Livramento',
			'state' => 13,
		]);
		DB::table('cities')->insert([
			'id' => 1417, 
			'name' => 'Nova Bandeirantes',
			'state' => 13,
		]);
		DB::table('cities')->insert([
			'id' => 1418, 
			'name' => 'Nova Brasilândia',
			'state' => 13,
		]);
		DB::table('cities')->insert([
			'id' => 1419, 
			'name' => 'Nova Canaã do Norte',
			'state' => 13,
		]);
		DB::table('cities')->insert([
			'id' => 1420, 
			'name' => 'Nova Guarita',
			'state' => 13,
		]);
		DB::table('cities')->insert([
			'id' => 1421, 
			'name' => 'Nova Lacerda',
			'state' => 13,
		]);
		DB::table('cities')->insert([
			'id' => 1422, 
			'name' => 'Nova Marilândia',
			'state' => 13,
		]);
		DB::table('cities')->insert([
			'id' => 1423, 
			'name' => 'Nova Maringá',
			'state' => 13,
		]);
		DB::table('cities')->insert([
			'id' => 1424, 
			'name' => 'Nova Monte verde',
			'state' => 13,
		]);
		DB::table('cities')->insert([
			'id' => 1425, 
			'name' => 'Nova Mutum',
			'state' => 13,
		]);
		DB::table('cities')->insert([
			'id' => 1426, 
			'name' => 'Nova Olímpia',
			'state' => 13,
		]);
		DB::table('cities')->insert([
			'id' => 1427, 
			'name' => 'Nova Santa Helena',
			'state' => 13,
		]);
		DB::table('cities')->insert([
			'id' => 1428, 
			'name' => 'Nova Ubiratã',
			'state' => 13,
		]);
		DB::table('cities')->insert([
			'id' => 1429, 
			'name' => 'Nova Xavantina',
			'state' => 13,
		]);
		DB::table('cities')->insert([
			'id' => 1430, 
			'name' => 'Novo Horizonte do Norte',
			'state' => 13,
		]);
		DB::table('cities')->insert([
			'id' => 1431, 
			'name' => 'Novo Mundo',
			'state' => 13,
		]);
		DB::table('cities')->insert([
			'id' => 1432, 
			'name' => 'Novo Santo Antônio',
			'state' => 13,
		]);
		DB::table('cities')->insert([
			'id' => 1433, 
			'name' => 'Novo São Joaquim',
			'state' => 13,
		]);
		DB::table('cities')->insert([
			'id' => 1434, 
			'name' => 'Paranaíta',
			'state' => 13,
		]);
		DB::table('cities')->insert([
			'id' => 1435, 
			'name' => 'Paranatinga',
			'state' => 13,
		]);
		DB::table('cities')->insert([
			'id' => 1436, 
			'name' => 'Pedra Preta',
			'state' => 13,
		]);
		DB::table('cities')->insert([
			'id' => 1437, 
			'name' => 'Peixoto de Azevedo',
			'state' => 13,
		]);
		DB::table('cities')->insert([
			'id' => 1438, 
			'name' => 'Planalto da Serra',
			'state' => 13,
		]);
		DB::table('cities')->insert([
			'id' => 1439, 
			'name' => 'Poconé',
			'state' => 13,
		]);
		DB::table('cities')->insert([
			'id' => 1440, 
			'name' => 'Pontal do Araguaia',
			'state' => 13,
		]);
		DB::table('cities')->insert([
			'id' => 1441, 
			'name' => 'Ponte Branca',
			'state' => 13,
		]);
		DB::table('cities')->insert([
			'id' => 1442, 
			'name' => 'Pontes e Lacerda',
			'state' => 13,
		]);
		DB::table('cities')->insert([
			'id' => 1443, 
			'name' => 'Porto Alegre do Norte',
			'state' => 13,
		]);
		DB::table('cities')->insert([
			'id' => 1444, 
			'name' => 'Porto dos Gaúchos',
			'state' => 13,
		]);
		DB::table('cities')->insert([
			'id' => 1445, 
			'name' => 'Porto Esperidião',
			'state' => 13,
		]);
		DB::table('cities')->insert([
			'id' => 1446, 
			'name' => 'Porto Estrela',
			'state' => 13,
		]);
		DB::table('cities')->insert([
			'id' => 1447, 
			'name' => 'Poxoréo',
			'state' => 13,
		]);
		DB::table('cities')->insert([
			'id' => 1448, 
			'name' => 'Primavera do Leste',
			'state' => 13,
		]);
		DB::table('cities')->insert([
			'id' => 1449, 
			'name' => 'Querência',
			'state' => 13,
		]);
		DB::table('cities')->insert([
			'id' => 1450, 
			'name' => 'Reserva do Cabaçal',
			'state' => 13,
		]);
		DB::table('cities')->insert([
			'id' => 1451, 
			'name' => 'Ribeirão Cascalheira',
			'state' => 13,
		]);
		DB::table('cities')->insert([
			'id' => 1452, 
			'name' => 'Ribeirãozinho',
			'state' => 13,
		]);
		DB::table('cities')->insert([
			'id' => 1453, 
			'name' => 'Rio Branco',
			'state' => 13,
		]);
		DB::table('cities')->insert([
			'id' => 1454, 
			'name' => 'Rondolândia',
			'state' => 13,
		]);
		DB::table('cities')->insert([
			'id' => 1455, 
			'name' => 'Rondonópolis',
			'state' => 13,
		]);
		DB::table('cities')->insert([
			'id' => 1456, 
			'name' => 'Rosário Oeste',
			'state' => 13,
		]);
		DB::table('cities')->insert([
			'id' => 1457, 
			'name' => 'Salto do Céu',
			'state' => 13,
		]);
		DB::table('cities')->insert([
			'id' => 1458, 
			'name' => 'Santa Carmem',
			'state' => 13,
		]);
		DB::table('cities')->insert([
			'id' => 1459, 
			'name' => 'Santa Cruz do Xingu',
			'state' => 13,
		]);
		DB::table('cities')->insert([
			'id' => 1460, 
			'name' => 'Santa Rita do Trivelato',
			'state' => 13,
		]);
		DB::table('cities')->insert([
			'id' => 1461, 
			'name' => 'Santa Terezinha',
			'state' => 13,
		]);
		DB::table('cities')->insert([
			'id' => 1462, 
			'name' => 'Santo Afonso',
			'state' => 13,
		]);
		DB::table('cities')->insert([
			'id' => 1463, 
			'name' => 'Santo Antônio do Leste',
			'state' => 13,
		]);
		DB::table('cities')->insert([
			'id' => 1464, 
			'name' => 'Santo Antônio do Leverger',
			'state' => 13,
		]);
		DB::table('cities')->insert([
			'id' => 1465, 
			'name' => 'São Félix do Araguaia',
			'state' => 13,
		]);
		DB::table('cities')->insert([
			'id' => 1466, 
			'name' => 'São José do Povo',
			'state' => 13,
		]);
		DB::table('cities')->insert([
			'id' => 1467, 
			'name' => 'São José do Rio Claro',
			'state' => 13,
		]);
		DB::table('cities')->insert([
			'id' => 1468, 
			'name' => 'São José do Xingu',
			'state' => 13,
		]);
		DB::table('cities')->insert([
			'id' => 1469, 
			'name' => 'São José dos Quatro Marcos',
			'state' => 13,
		]);
		DB::table('cities')->insert([
			'id' => 1470, 
			'name' => 'São Pedro da Cipa',
			'state' => 13,
		]);
		DB::table('cities')->insert([
			'id' => 1471, 
			'name' => 'Sapezal',
			'state' => 13,
		]);
		DB::table('cities')->insert([
			'id' => 1472, 
			'name' => 'Serra Nova Dourada',
			'state' => 13,
		]);
		DB::table('cities')->insert([
			'id' => 1473, 
			'name' => 'Sinop',
			'state' => 13,
		]);
		DB::table('cities')->insert([
			'id' => 1474, 
			'name' => 'Sorriso',
			'state' => 13,
		]);
		DB::table('cities')->insert([
			'id' => 1475, 
			'name' => 'Tabaporã',
			'state' => 13,
		]);
		DB::table('cities')->insert([
			'id' => 1476, 
			'name' => 'Tangará da Serra',
			'state' => 13,
		]);
		DB::table('cities')->insert([
			'id' => 1477, 
			'name' => 'Tapurah',
			'state' => 13,
		]);
		DB::table('cities')->insert([
			'id' => 1478, 
			'name' => 'Terra Nova do Norte',
			'state' => 13,
		]);
		DB::table('cities')->insert([
			'id' => 1479, 
			'name' => 'Tesouro',
			'state' => 13,
		]);
		DB::table('cities')->insert([
			'id' => 1480, 
			'name' => 'Torixoréu',
			'state' => 13,
		]);
		DB::table('cities')->insert([
			'id' => 1481, 
			'name' => 'União do Sul',
			'state' => 13,
		]);
		DB::table('cities')->insert([
			'id' => 1482, 
			'name' => 'Vale de São Domingos',
			'state' => 13,
		]);
		DB::table('cities')->insert([
			'id' => 1483, 
			'name' => 'Várzea Grande',
			'state' => 13,
		]);
		DB::table('cities')->insert([
			'id' => 1484, 
			'name' => 'Vera',
			'state' => 13,
		]);
		DB::table('cities')->insert([
			'id' => 1485, 
			'name' => 'Vila Bela da Santíssima Trindade',
			'state' => 13,
		]);
		DB::table('cities')->insert([
			'id' => 1486, 
			'name' => 'Vila Rica',
			'state' => 13,
		]);
		DB::table('cities')->insert([
			'id' => 1487, 
			'name' => 'Água Clara',
			'state' => 12,
		]);
		DB::table('cities')->insert([
			'id' => 1488, 
			'name' => 'Alcinópolis',
			'state' => 12,
		]);
		DB::table('cities')->insert([
			'id' => 1489, 
			'name' => 'Amambaí',
			'state' => 12,
		]);
		DB::table('cities')->insert([
			'id' => 1490, 
			'name' => 'Anastácio',
			'state' => 12,
		]);
		DB::table('cities')->insert([
			'id' => 1491, 
			'name' => 'Anaurilândia',
			'state' => 12,
		]);
		DB::table('cities')->insert([
			'id' => 1492, 
			'name' => 'Angélica',
			'state' => 12,
		]);
		DB::table('cities')->insert([
			'id' => 1493, 
			'name' => 'Antônio João',
			'state' => 12,
		]);
		DB::table('cities')->insert([
			'id' => 1494, 
			'name' => 'Aparecida do Taboado',
			'state' => 12,
		]);
		DB::table('cities')->insert([
			'id' => 1495, 
			'name' => 'Aquidauana',
			'state' => 12,
		]);
		DB::table('cities')->insert([
			'id' => 1496, 
			'name' => 'Aral Moreira',
			'state' => 12,
		]);
		DB::table('cities')->insert([
			'id' => 1497, 
			'name' => 'Bandeirantes',
			'state' => 12,
		]);
		DB::table('cities')->insert([
			'id' => 1498, 
			'name' => 'Bataguassu',
			'state' => 12,
		]);
		DB::table('cities')->insert([
			'id' => 1499, 
			'name' => 'Bataiporã',
			'state' => 12,
		]);
		DB::table('cities')->insert([
			'id' => 1500, 
			'name' => 'Bela Vista',
			'state' => 12,
		]);
		DB::table('cities')->insert([
			'id' => 1501, 
			'name' => 'Bodoquena',
			'state' => 12,
		]);
		DB::table('cities')->insert([
			'id' => 1502, 
			'name' => 'Bonito',
			'state' => 12,
		]);
		DB::table('cities')->insert([
			'id' => 1503, 
			'name' => 'Brasilândia',
			'state' => 12,
		]);
		DB::table('cities')->insert([
			'id' => 1504, 
			'name' => 'Caarapó',
			'state' => 12,
		]);
		DB::table('cities')->insert([
			'id' => 1505, 
			'name' => 'Camapuã',
			'state' => 12,
		]);
		DB::table('cities')->insert([
			'id' => 1506, 
			'name' => 'Campo Grande',
			'state' => 12,
		]);
		DB::table('cities')->insert([
			'id' => 1507, 
			'name' => 'Caracol',
			'state' => 12,
		]);
		DB::table('cities')->insert([
			'id' => 1508, 
			'name' => 'Cassilândia',
			'state' => 12,
		]);
		DB::table('cities')->insert([
			'id' => 1509, 
			'name' => 'Chapadão do Sul',
			'state' => 12,
		]);
		DB::table('cities')->insert([
			'id' => 1510, 
			'name' => 'Corguinho',
			'state' => 12,
		]);
		DB::table('cities')->insert([
			'id' => 1511, 
			'name' => 'Coronel Sapucaia',
			'state' => 12,
		]);
		DB::table('cities')->insert([
			'id' => 1512, 
			'name' => 'Corumbá',
			'state' => 12,
		]);
		DB::table('cities')->insert([
			'id' => 1513, 
			'name' => 'Costa Rica',
			'state' => 12,
		]);
		DB::table('cities')->insert([
			'id' => 1514, 
			'name' => 'Coxim',
			'state' => 12,
		]);
		DB::table('cities')->insert([
			'id' => 1515, 
			'name' => 'Deodápolis',
			'state' => 12,
		]);
		DB::table('cities')->insert([
			'id' => 1516, 
			'name' => 'Dois Irmãos do Buriti',
			'state' => 12,
		]);
		DB::table('cities')->insert([
			'id' => 1517, 
			'name' => 'Douradina',
			'state' => 12,
		]);
		DB::table('cities')->insert([
			'id' => 1518, 
			'name' => 'Dourados',
			'state' => 12,
		]);
		DB::table('cities')->insert([
			'id' => 1519, 
			'name' => 'Eldorado',
			'state' => 12,
		]);
		DB::table('cities')->insert([
			'id' => 1520, 
			'name' => 'Fátima do Sul',
			'state' => 12,
		]);
		DB::table('cities')->insert([
			'id' => 1521, 
			'name' => 'Figueirão',
			'state' => 12,
		]);
		DB::table('cities')->insert([
			'id' => 1522, 
			'name' => 'Glória de Dourados',
			'state' => 12,
		]);
		DB::table('cities')->insert([
			'id' => 1523, 
			'name' => 'Guia Lopes da Laguna',
			'state' => 12,
		]);
		DB::table('cities')->insert([
			'id' => 1524, 
			'name' => 'Iguatemi',
			'state' => 12,
		]);
		DB::table('cities')->insert([
			'id' => 1525, 
			'name' => 'Inocência',
			'state' => 12,
		]);
		DB::table('cities')->insert([
			'id' => 1526, 
			'name' => 'Itaporã',
			'state' => 12,
		]);
		DB::table('cities')->insert([
			'id' => 1527, 
			'name' => 'Itaquiraí',
			'state' => 12,
		]);
		DB::table('cities')->insert([
			'id' => 1528, 
			'name' => 'Ivinhema',
			'state' => 12,
		]);
		DB::table('cities')->insert([
			'id' => 1529, 
			'name' => 'Japorã',
			'state' => 12,
		]);
		DB::table('cities')->insert([
			'id' => 1530, 
			'name' => 'Jaraguari',
			'state' => 12,
		]);
		DB::table('cities')->insert([
			'id' => 1531, 
			'name' => 'Jardim',
			'state' => 12,
		]);
		DB::table('cities')->insert([
			'id' => 1532, 
			'name' => 'Jateí',
			'state' => 12,
		]);
		DB::table('cities')->insert([
			'id' => 1533, 
			'name' => 'Juti',
			'state' => 12,
		]);
		DB::table('cities')->insert([
			'id' => 1534, 
			'name' => 'Ladário',
			'state' => 12,
		]);
		DB::table('cities')->insert([
			'id' => 1535, 
			'name' => 'Laguna Carapã',
			'state' => 12,
		]);
		DB::table('cities')->insert([
			'id' => 1536, 
			'name' => 'Maracaju',
			'state' => 12,
		]);
		DB::table('cities')->insert([
			'id' => 1537, 
			'name' => 'Miranda',
			'state' => 12,
		]);
		DB::table('cities')->insert([
			'id' => 1538, 
			'name' => 'Mundo Novo',
			'state' => 12,
		]);
		DB::table('cities')->insert([
			'id' => 1539, 
			'name' => 'Naviraí',
			'state' => 12,
		]);
		DB::table('cities')->insert([
			'id' => 1540, 
			'name' => 'Nioaque',
			'state' => 12,
		]);
		DB::table('cities')->insert([
			'id' => 1541, 
			'name' => 'Nova Alvorada do Sul',
			'state' => 12,
		]);
		DB::table('cities')->insert([
			'id' => 1542, 
			'name' => 'Nova Andradina',
			'state' => 12,
		]);
		DB::table('cities')->insert([
			'id' => 1543, 
			'name' => 'Novo Horizonte do Sul',
			'state' => 12,
		]);
		DB::table('cities')->insert([
			'id' => 1544, 
			'name' => 'Paranaíba',
			'state' => 12,
		]);
		DB::table('cities')->insert([
			'id' => 1545, 
			'name' => 'Paranhos',
			'state' => 12,
		]);
		DB::table('cities')->insert([
			'id' => 1546, 
			'name' => 'Pedro Gomes',
			'state' => 12,
		]);
		DB::table('cities')->insert([
			'id' => 1547, 
			'name' => 'Ponta Porã',
			'state' => 12,
		]);
		DB::table('cities')->insert([
			'id' => 1548, 
			'name' => 'Porto Murtinho',
			'state' => 12,
		]);
		DB::table('cities')->insert([
			'id' => 1549, 
			'name' => 'Ribas do Rio Pardo',
			'state' => 12,
		]);
		DB::table('cities')->insert([
			'id' => 1550, 
			'name' => 'Rio Brilhante',
			'state' => 12,
		]);
		DB::table('cities')->insert([
			'id' => 1551, 
			'name' => 'Rio Negro',
			'state' => 12,
		]);
		DB::table('cities')->insert([
			'id' => 1552, 
			'name' => 'Rio Verde de Mato Grosso',
			'state' => 12,
		]);
		DB::table('cities')->insert([
			'id' => 1553, 
			'name' => 'Rochedo',
			'state' => 12,
		]);
		DB::table('cities')->insert([
			'id' => 1554, 
			'name' => 'Santa Rita do Pardo',
			'state' => 12,
		]);
		DB::table('cities')->insert([
			'id' => 1555, 
			'name' => 'São Gabriel do Oeste',
			'state' => 12,
		]);
		DB::table('cities')->insert([
			'id' => 1556, 
			'name' => 'Selvíria',
			'state' => 12,
		]);
		DB::table('cities')->insert([
			'id' => 1557, 
			'name' => 'Sete Quedas',
			'state' => 12,
		]);
		DB::table('cities')->insert([
			'id' => 1558, 
			'name' => 'Sidrolândia',
			'state' => 12,
		]);
		DB::table('cities')->insert([
			'id' => 1559, 
			'name' => 'Sonora',
			'state' => 12,
		]);
		DB::table('cities')->insert([
			'id' => 1560, 
			'name' => 'Tacuru',
			'state' => 12,
		]);
		DB::table('cities')->insert([
			'id' => 1561, 
			'name' => 'Taquarussu',
			'state' => 12,
		]);
		DB::table('cities')->insert([
			'id' => 1562, 
			'name' => 'Terenos',
			'state' => 12,
		]);
		DB::table('cities')->insert([
			'id' => 1563, 
			'name' => 'Três Lagoas',
			'state' => 12,
		]);
		DB::table('cities')->insert([
			'id' => 1564, 
			'name' => 'Vicentina',
			'state' => 12,
		]);
		DB::table('cities')->insert([
			'id' => 1565, 
			'name' => 'Abadia dos Dourados',
			'state' => 11,
		]);
		DB::table('cities')->insert([
			'id' => 1566, 
			'name' => 'Abaeté',
			'state' => 11,
		]);
		DB::table('cities')->insert([
			'id' => 1567, 
			'name' => 'Abre Campo',
			'state' => 11,
		]);
		DB::table('cities')->insert([
			'id' => 1568, 
			'name' => 'Acaiaca',
			'state' => 11,
		]);
		DB::table('cities')->insert([
			'id' => 1569, 
			'name' => 'Açucena',
			'state' => 11,
		]);
		DB::table('cities')->insert([
			'id' => 1570, 
			'name' => 'Água Boa',
			'state' => 11,
		]);
		DB::table('cities')->insert([
			'id' => 1571, 
			'name' => 'Água Comprida',
			'state' => 11,
		]);
		DB::table('cities')->insert([
			'id' => 1572, 
			'name' => 'Aguanil',
			'state' => 11,
		]);
		DB::table('cities')->insert([
			'id' => 1573, 
			'name' => 'Águas Formosas',
			'state' => 11,
		]);
		DB::table('cities')->insert([
			'id' => 1574, 
			'name' => 'Águas Vermelhas',
			'state' => 11,
		]);
		DB::table('cities')->insert([
			'id' => 1575, 
			'name' => 'Aimorés',
			'state' => 11,
		]);
		DB::table('cities')->insert([
			'id' => 1576, 
			'name' => 'Aiuruoca',
			'state' => 11,
		]);
		DB::table('cities')->insert([
			'id' => 1577, 
			'name' => 'Alagoa',
			'state' => 11,
		]);
		DB::table('cities')->insert([
			'id' => 1578, 
			'name' => 'Albertina',
			'state' => 11,
		]);
		DB::table('cities')->insert([
			'id' => 1579, 
			'name' => 'Além Paraíba',
			'state' => 11,
		]);
		DB::table('cities')->insert([
			'id' => 1580, 
			'name' => 'Alfenas',
			'state' => 11,
		]);
		DB::table('cities')->insert([
			'id' => 1581, 
			'name' => 'Alfredo Vasconcelos',
			'state' => 11,
		]);
		DB::table('cities')->insert([
			'id' => 1582, 
			'name' => 'Almenara',
			'state' => 11,
		]);
		DB::table('cities')->insert([
			'id' => 1583, 
			'name' => 'Alpercata',
			'state' => 11,
		]);
		DB::table('cities')->insert([
			'id' => 1584, 
			'name' => 'Alpinópolis',
			'state' => 11,
		]);
		DB::table('cities')->insert([
			'id' => 1585, 
			'name' => 'Alterosa',
			'state' => 11,
		]);
		DB::table('cities')->insert([
			'id' => 1586, 
			'name' => 'Alto Caparaó',
			'state' => 11,
		]);
		DB::table('cities')->insert([
			'id' => 1587, 
			'name' => 'Alto Jequitibá',
			'state' => 11,
		]);
		DB::table('cities')->insert([
			'id' => 1588, 
			'name' => 'Alto Rio Doce',
			'state' => 11,
		]);
		DB::table('cities')->insert([
			'id' => 1589, 
			'name' => 'Alvarenga',
			'state' => 11,
		]);
		DB::table('cities')->insert([
			'id' => 1590, 
			'name' => 'Alvinópolis',
			'state' => 11,
		]);
		DB::table('cities')->insert([
			'id' => 1591, 
			'name' => 'Alvorada de Minas',
			'state' => 11,
		]);
		DB::table('cities')->insert([
			'id' => 1592, 
			'name' => 'Amparo do Serra',
			'state' => 11,
		]);
		DB::table('cities')->insert([
			'id' => 1593, 
			'name' => 'Andradas',
			'state' => 11,
		]);
		DB::table('cities')->insert([
			'id' => 1594, 
			'name' => 'Andrelândia',
			'state' => 11,
		]);
		DB::table('cities')->insert([
			'id' => 1595, 
			'name' => 'Angelândia',
			'state' => 11,
		]);
		DB::table('cities')->insert([
			'id' => 1596, 
			'name' => 'Antônio Carlos',
			'state' => 11,
		]);
		DB::table('cities')->insert([
			'id' => 1597, 
			'name' => 'Antônio Dias',
			'state' => 11,
		]);
		DB::table('cities')->insert([
			'id' => 1598, 
			'name' => 'Antônio Prado de Minas',
			'state' => 11,
		]);
		DB::table('cities')->insert([
			'id' => 1599, 
			'name' => 'Araçaí',
			'state' => 11,
		]);
		DB::table('cities')->insert([
			'id' => 1600, 
			'name' => 'Aracitaba',
			'state' => 11,
		]);
		DB::table('cities')->insert([
			'id' => 1601, 
			'name' => 'Araçuaí',
			'state' => 11,
		]);
		DB::table('cities')->insert([
			'id' => 1602, 
			'name' => 'Araguari',
			'state' => 11,
		]);
		DB::table('cities')->insert([
			'id' => 1603, 
			'name' => 'Arantina',
			'state' => 11,
		]);
		DB::table('cities')->insert([
			'id' => 1604, 
			'name' => 'Araponga',
			'state' => 11,
		]);
		DB::table('cities')->insert([
			'id' => 1605, 
			'name' => 'Araporã',
			'state' => 11,
		]);
		DB::table('cities')->insert([
			'id' => 1606, 
			'name' => 'Arapuá',
			'state' => 11,
		]);
		DB::table('cities')->insert([
			'id' => 1607, 
			'name' => 'Araújos',
			'state' => 11,
		]);
		DB::table('cities')->insert([
			'id' => 1608, 
			'name' => 'Araxá',
			'state' => 11,
		]);
		DB::table('cities')->insert([
			'id' => 1609, 
			'name' => 'Arceburgo',
			'state' => 11,
		]);
		DB::table('cities')->insert([
			'id' => 1610, 
			'name' => 'Arcos',
			'state' => 11,
		]);
		DB::table('cities')->insert([
			'id' => 1611, 
			'name' => 'Areado',
			'state' => 11,
		]);
		DB::table('cities')->insert([
			'id' => 1612, 
			'name' => 'Argirita',
			'state' => 11,
		]);
		DB::table('cities')->insert([
			'id' => 1613, 
			'name' => 'Aricanduva',
			'state' => 11,
		]);
		DB::table('cities')->insert([
			'id' => 1614, 
			'name' => 'Arinos',
			'state' => 11,
		]);
		DB::table('cities')->insert([
			'id' => 1615, 
			'name' => 'Astolfo Dutra',
			'state' => 11,
		]);
		DB::table('cities')->insert([
			'id' => 1616, 
			'name' => 'Ataléia',
			'state' => 11,
		]);
		DB::table('cities')->insert([
			'id' => 1617, 
			'name' => 'Augusto de Lima',
			'state' => 11,
		]);
		DB::table('cities')->insert([
			'id' => 1618, 
			'name' => 'Baependi',
			'state' => 11,
		]);
		DB::table('cities')->insert([
			'id' => 1619, 
			'name' => 'Baldim',
			'state' => 11,
		]);
		DB::table('cities')->insert([
			'id' => 1620, 
			'name' => 'Bambuí',
			'state' => 11,
		]);
		DB::table('cities')->insert([
			'id' => 1621, 
			'name' => 'Bandeira',
			'state' => 11,
		]);
		DB::table('cities')->insert([
			'id' => 1622, 
			'name' => 'Bandeira do Sul',
			'state' => 11,
		]);
		DB::table('cities')->insert([
			'id' => 1623, 
			'name' => 'Barão de Cocais',
			'state' => 11,
		]);
		DB::table('cities')->insert([
			'id' => 1624, 
			'name' => 'Barão de Monte Alto',
			'state' => 11,
		]);
		DB::table('cities')->insert([
			'id' => 1625, 
			'name' => 'Barbacena',
			'state' => 11,
		]);
		DB::table('cities')->insert([
			'id' => 1626, 
			'name' => 'Barra Longa',
			'state' => 11,
		]);
		DB::table('cities')->insert([
			'id' => 1627, 
			'name' => 'Barroso',
			'state' => 11,
		]);
		DB::table('cities')->insert([
			'id' => 1628, 
			'name' => 'Bela Vista de Minas',
			'state' => 11,
		]);
		DB::table('cities')->insert([
			'id' => 1629, 
			'name' => 'Belmiro Braga',
			'state' => 11,
		]);
		DB::table('cities')->insert([
			'id' => 1630, 
			'name' => 'Belo Horizonte',
			'state' => 11,
		]);
		DB::table('cities')->insert([
			'id' => 1631, 
			'name' => 'Belo Oriente',
			'state' => 11,
		]);
		DB::table('cities')->insert([
			'id' => 1632, 
			'name' => 'Belo Vale',
			'state' => 11,
		]);
		DB::table('cities')->insert([
			'id' => 1633, 
			'name' => 'Berilo',
			'state' => 11,
		]);
		DB::table('cities')->insert([
			'id' => 1634, 
			'name' => 'Berizal',
			'state' => 11,
		]);
		DB::table('cities')->insert([
			'id' => 1635, 
			'name' => 'Bertópolis',
			'state' => 11,
		]);
		DB::table('cities')->insert([
			'id' => 1636, 
			'name' => 'Betim',
			'state' => 11,
		]);
		DB::table('cities')->insert([
			'id' => 1637, 
			'name' => 'Bias Fortes',
			'state' => 11,
		]);
		DB::table('cities')->insert([
			'id' => 1638, 
			'name' => 'Bicas',
			'state' => 11,
		]);
		DB::table('cities')->insert([
			'id' => 1639, 
			'name' => 'Biquinhas',
			'state' => 11,
		]);
		DB::table('cities')->insert([
			'id' => 1640, 
			'name' => 'Boa Esperança',
			'state' => 11,
		]);
		DB::table('cities')->insert([
			'id' => 1641, 
			'name' => 'Bocaina de Minas',
			'state' => 11,
		]);
		DB::table('cities')->insert([
			'id' => 1642, 
			'name' => 'Bocaiúva',
			'state' => 11,
		]);
		DB::table('cities')->insert([
			'id' => 1643, 
			'name' => 'Bom Despacho',
			'state' => 11,
		]);
		DB::table('cities')->insert([
			'id' => 1644, 
			'name' => 'Bom Jardim de Minas',
			'state' => 11,
		]);
		DB::table('cities')->insert([
			'id' => 1645, 
			'name' => 'Bom Jesus da Penha',
			'state' => 11,
		]);
		DB::table('cities')->insert([
			'id' => 1646, 
			'name' => 'Bom Jesus do Amparo',
			'state' => 11,
		]);
		DB::table('cities')->insert([
			'id' => 1647, 
			'name' => 'Bom Jesus do Galho',
			'state' => 11,
		]);
		DB::table('cities')->insert([
			'id' => 1648, 
			'name' => 'Bom Repouso',
			'state' => 11,
		]);
		DB::table('cities')->insert([
			'id' => 1649, 
			'name' => 'Bom Sucesso',
			'state' => 11,
		]);
		DB::table('cities')->insert([
			'id' => 1650, 
			'name' => 'Bonfim',
			'state' => 11,
		]);
		DB::table('cities')->insert([
			'id' => 1651, 
			'name' => 'Bonfinópolis de Minas',
			'state' => 11,
		]);
		DB::table('cities')->insert([
			'id' => 1652, 
			'name' => 'Bonito de Minas',
			'state' => 11,
		]);
		DB::table('cities')->insert([
			'id' => 1653, 
			'name' => 'Borda da Mata',
			'state' => 11,
		]);
		DB::table('cities')->insert([
			'id' => 1654, 
			'name' => 'Botelhos',
			'state' => 11,
		]);
		DB::table('cities')->insert([
			'id' => 1655, 
			'name' => 'Botumirim',
			'state' => 11,
		]);
		DB::table('cities')->insert([
			'id' => 1656, 
			'name' => 'Brás Pires',
			'state' => 11,
		]);
		DB::table('cities')->insert([
			'id' => 1657, 
			'name' => 'Brasilândia de Minas',
			'state' => 11,
		]);
		DB::table('cities')->insert([
			'id' => 1658, 
			'name' => 'Brasília de Minas',
			'state' => 11,
		]);
		DB::table('cities')->insert([
			'id' => 1659, 
			'name' => 'Brasópolis',
			'state' => 11,
		]);
		DB::table('cities')->insert([
			'id' => 1660, 
			'name' => 'Braúnas',
			'state' => 11,
		]);
		DB::table('cities')->insert([
			'id' => 1661, 
			'name' => 'Brumadinho',
			'state' => 11,
		]);
		DB::table('cities')->insert([
			'id' => 1662, 
			'name' => 'Bueno Brandão',
			'state' => 11,
		]);
		DB::table('cities')->insert([
			'id' => 1663, 
			'name' => 'Buenópolis',
			'state' => 11,
		]);
		DB::table('cities')->insert([
			'id' => 1664, 
			'name' => 'Bugre',
			'state' => 11,
		]);
		DB::table('cities')->insert([
			'id' => 1665, 
			'name' => 'Buritis',
			'state' => 11,
		]);
		DB::table('cities')->insert([
			'id' => 1666, 
			'name' => 'Buritizeiro',
			'state' => 11,
		]);
		DB::table('cities')->insert([
			'id' => 1667, 
			'name' => 'Cabeceira Grande',
			'state' => 11,
		]);
		DB::table('cities')->insert([
			'id' => 1668, 
			'name' => 'Cabo Verde',
			'state' => 11,
		]);
		DB::table('cities')->insert([
			'id' => 1669, 
			'name' => 'Cachoeira da Prata',
			'state' => 11,
		]);
		DB::table('cities')->insert([
			'id' => 1670, 
			'name' => 'Cachoeira de Minas',
			'state' => 11,
		]);
		DB::table('cities')->insert([
			'id' => 1671, 
			'name' => 'Cachoeira de Pajeú',
			'state' => 11,
		]);
		DB::table('cities')->insert([
			'id' => 1672, 
			'name' => 'Cachoeira Dourada',
			'state' => 11,
		]);
		DB::table('cities')->insert([
			'id' => 1673, 
			'name' => 'Caetanópolis',
			'state' => 11,
		]);
		DB::table('cities')->insert([
			'id' => 1674, 
			'name' => 'Caeté',
			'state' => 11,
		]);
		DB::table('cities')->insert([
			'id' => 1675, 
			'name' => 'Caiana',
			'state' => 11,
		]);
		DB::table('cities')->insert([
			'id' => 1676, 
			'name' => 'Cajuri',
			'state' => 11,
		]);
		DB::table('cities')->insert([
			'id' => 1677, 
			'name' => 'Caldas',
			'state' => 11,
		]);
		DB::table('cities')->insert([
			'id' => 1678, 
			'name' => 'Camacho',
			'state' => 11,
		]);
		DB::table('cities')->insert([
			'id' => 1679, 
			'name' => 'Camanducaia',
			'state' => 11,
		]);
		DB::table('cities')->insert([
			'id' => 1680, 
			'name' => 'Cambuí',
			'state' => 11,
		]);
		DB::table('cities')->insert([
			'id' => 1681, 
			'name' => 'Cambuquira',
			'state' => 11,
		]);
		DB::table('cities')->insert([
			'id' => 1682, 
			'name' => 'Campanário',
			'state' => 11,
		]);
		DB::table('cities')->insert([
			'id' => 1683, 
			'name' => 'Campanha',
			'state' => 11,
		]);
		DB::table('cities')->insert([
			'id' => 1684, 
			'name' => 'Campestre',
			'state' => 11,
		]);
		DB::table('cities')->insert([
			'id' => 1685, 
			'name' => 'Campina Verde',
			'state' => 11,
		]);
		DB::table('cities')->insert([
			'id' => 1686, 
			'name' => 'Campo Azul',
			'state' => 11,
		]);
		DB::table('cities')->insert([
			'id' => 1687, 
			'name' => 'Campo Belo',
			'state' => 11,
		]);
		DB::table('cities')->insert([
			'id' => 1688, 
			'name' => 'Campo do Meio',
			'state' => 11,
		]);
		DB::table('cities')->insert([
			'id' => 1689, 
			'name' => 'Campo Florido',
			'state' => 11,
		]);
		DB::table('cities')->insert([
			'id' => 1690, 
			'name' => 'Campos Altos',
			'state' => 11,
		]);
		DB::table('cities')->insert([
			'id' => 1691, 
			'name' => 'Campos Gerais',
			'state' => 11,
		]);
		DB::table('cities')->insert([
			'id' => 1692, 
			'name' => 'Cana Verde',
			'state' => 11,
		]);
		DB::table('cities')->insert([
			'id' => 1693, 
			'name' => 'Canaã',
			'state' => 11,
		]);
		DB::table('cities')->insert([
			'id' => 1694, 
			'name' => 'Canápolis',
			'state' => 11,
		]);
		DB::table('cities')->insert([
			'id' => 1695, 
			'name' => 'Candeias',
			'state' => 11,
		]);
		DB::table('cities')->insert([
			'id' => 1696, 
			'name' => 'Cantagalo',
			'state' => 11,
		]);
		DB::table('cities')->insert([
			'id' => 1697, 
			'name' => 'Caparaó',
			'state' => 11,
		]);
		DB::table('cities')->insert([
			'id' => 1698, 
			'name' => 'Capela Nova',
			'state' => 11,
		]);
		DB::table('cities')->insert([
			'id' => 1699, 
			'name' => 'Capelinha',
			'state' => 11,
		]);
		DB::table('cities')->insert([
			'id' => 1700, 
			'name' => 'Capetinga',
			'state' => 11,
		]);
		DB::table('cities')->insert([
			'id' => 1701, 
			'name' => 'Capim Branco',
			'state' => 11,
		]);
		DB::table('cities')->insert([
			'id' => 1702, 
			'name' => 'Capinópolis',
			'state' => 11,
		]);
		DB::table('cities')->insert([
			'id' => 1703, 
			'name' => 'Capitão Andrade',
			'state' => 11,
		]);
		DB::table('cities')->insert([
			'id' => 1704, 
			'name' => 'Capitão Enéas',
			'state' => 11,
		]);
		DB::table('cities')->insert([
			'id' => 1705, 
			'name' => 'Capitólio',
			'state' => 11,
		]);
		DB::table('cities')->insert([
			'id' => 1706, 
			'name' => 'Caputira',
			'state' => 11,
		]);
		DB::table('cities')->insert([
			'id' => 1707, 
			'name' => 'Caraí',
			'state' => 11,
		]);
		DB::table('cities')->insert([
			'id' => 1708, 
			'name' => 'Caranaíba',
			'state' => 11,
		]);
		DB::table('cities')->insert([
			'id' => 1709, 
			'name' => 'Carandaí',
			'state' => 11,
		]);
		DB::table('cities')->insert([
			'id' => 1710, 
			'name' => 'Carangola',
			'state' => 11,
		]);
		DB::table('cities')->insert([
			'id' => 1711, 
			'name' => 'Caratinga',
			'state' => 11,
		]);
		DB::table('cities')->insert([
			'id' => 1712, 
			'name' => 'Carbonita',
			'state' => 11,
		]);
		DB::table('cities')->insert([
			'id' => 1713, 
			'name' => 'Careaçu',
			'state' => 11,
		]);
		DB::table('cities')->insert([
			'id' => 1714, 
			'name' => 'Carlos Chagas',
			'state' => 11,
		]);
		DB::table('cities')->insert([
			'id' => 1715, 
			'name' => 'Carmésia',
			'state' => 11,
		]);
		DB::table('cities')->insert([
			'id' => 1716, 
			'name' => 'Carmo da Cachoeira',
			'state' => 11,
		]);
		DB::table('cities')->insert([
			'id' => 1717, 
			'name' => 'Carmo da Mata',
			'state' => 11,
		]);
		DB::table('cities')->insert([
			'id' => 1718, 
			'name' => 'Carmo de Minas',
			'state' => 11,
		]);
		DB::table('cities')->insert([
			'id' => 1719, 
			'name' => 'Carmo do Cajuru',
			'state' => 11,
		]);
		DB::table('cities')->insert([
			'id' => 1720, 
			'name' => 'Carmo do Paranaíba',
			'state' => 11,
		]);
		DB::table('cities')->insert([
			'id' => 1721, 
			'name' => 'Carmo do Rio Claro',
			'state' => 11,
		]);
		DB::table('cities')->insert([
			'id' => 1722, 
			'name' => 'Carmópolis de Minas',
			'state' => 11,
		]);
		DB::table('cities')->insert([
			'id' => 1723, 
			'name' => 'Carneirinho',
			'state' => 11,
		]);
		DB::table('cities')->insert([
			'id' => 1724, 
			'name' => 'Carrancas',
			'state' => 11,
		]);
		DB::table('cities')->insert([
			'id' => 1725, 
			'name' => 'Carvalhópolis',
			'state' => 11,
		]);
		DB::table('cities')->insert([
			'id' => 1726, 
			'name' => 'Carvalhos',
			'state' => 11,
		]);
		DB::table('cities')->insert([
			'id' => 1727, 
			'name' => 'Casa Grande',
			'state' => 11,
		]);
		DB::table('cities')->insert([
			'id' => 1728, 
			'name' => 'Cascalho Rico',
			'state' => 11,
		]);
		DB::table('cities')->insert([
			'id' => 1729, 
			'name' => 'Cássia',
			'state' => 11,
		]);
		DB::table('cities')->insert([
			'id' => 1730, 
			'name' => 'Cataguases',
			'state' => 11,
		]);
		DB::table('cities')->insert([
			'id' => 1731, 
			'name' => 'Catas Altas',
			'state' => 11,
		]);
		DB::table('cities')->insert([
			'id' => 1732, 
			'name' => 'Catas Altas da Noruega',
			'state' => 11,
		]);
		DB::table('cities')->insert([
			'id' => 1733, 
			'name' => 'Catuji',
			'state' => 11,
		]);
		DB::table('cities')->insert([
			'id' => 1734, 
			'name' => 'Catuti',
			'state' => 11,
		]);
		DB::table('cities')->insert([
			'id' => 1735, 
			'name' => 'Caxambu',
			'state' => 11,
		]);
		DB::table('cities')->insert([
			'id' => 1736, 
			'name' => 'Cedro do Abaeté',
			'state' => 11,
		]);
		DB::table('cities')->insert([
			'id' => 1737, 
			'name' => 'Central de Minas',
			'state' => 11,
		]);
		DB::table('cities')->insert([
			'id' => 1738, 
			'name' => 'Centralina',
			'state' => 11,
		]);
		DB::table('cities')->insert([
			'id' => 1739, 
			'name' => 'Chácara',
			'state' => 11,
		]);
		DB::table('cities')->insert([
			'id' => 1740, 
			'name' => 'Chalé',
			'state' => 11,
		]);
		DB::table('cities')->insert([
			'id' => 1741, 
			'name' => 'Chapada do Norte',
			'state' => 11,
		]);
		DB::table('cities')->insert([
			'id' => 1742, 
			'name' => 'Chapada Gaúcha',
			'state' => 11,
		]);
		DB::table('cities')->insert([
			'id' => 1743, 
			'name' => 'Chiador',
			'state' => 11,
		]);
		DB::table('cities')->insert([
			'id' => 1744, 
			'name' => 'Cipotânea',
			'state' => 11,
		]);
		DB::table('cities')->insert([
			'id' => 1745, 
			'name' => 'Claraval',
			'state' => 11,
		]);
		DB::table('cities')->insert([
			'id' => 1746, 
			'name' => 'Claro dos Poções',
			'state' => 11,
		]);
		DB::table('cities')->insert([
			'id' => 1747, 
			'name' => 'Cláudio',
			'state' => 11,
		]);
		DB::table('cities')->insert([
			'id' => 1748, 
			'name' => 'Coimbra',
			'state' => 11,
		]);
		DB::table('cities')->insert([
			'id' => 1749, 
			'name' => 'Coluna',
			'state' => 11,
		]);
		DB::table('cities')->insert([
			'id' => 1750, 
			'name' => 'Comendador Gomes',
			'state' => 11,
		]);
		DB::table('cities')->insert([
			'id' => 1751, 
			'name' => 'Comercinho',
			'state' => 11,
		]);
		DB::table('cities')->insert([
			'id' => 1752, 
			'name' => 'Conceição da Aparecida',
			'state' => 11,
		]);
		DB::table('cities')->insert([
			'id' => 1753, 
			'name' => 'Conceição da Barra de Minas',
			'state' => 11,
		]);
		DB::table('cities')->insert([
			'id' => 1754, 
			'name' => 'Conceição das Alagoas',
			'state' => 11,
		]);
		DB::table('cities')->insert([
			'id' => 1755, 
			'name' => 'Conceição das Pedras',
			'state' => 11,
		]);
		DB::table('cities')->insert([
			'id' => 1756, 
			'name' => 'Conceição de Ipanema',
			'state' => 11,
		]);
		DB::table('cities')->insert([
			'id' => 1757, 
			'name' => 'Conceição do Mato Dentro',
			'state' => 11,
		]);
		DB::table('cities')->insert([
			'id' => 1758, 
			'name' => 'Conceição do Pará',
			'state' => 11,
		]);
		DB::table('cities')->insert([
			'id' => 1759, 
			'name' => 'Conceição do Rio Verde',
			'state' => 11,
		]);
		DB::table('cities')->insert([
			'id' => 1760, 
			'name' => 'Conceição dos Ouros',
			'state' => 11,
		]);
		DB::table('cities')->insert([
			'id' => 1761, 
			'name' => 'Cônego Marinho',
			'state' => 11,
		]);
		DB::table('cities')->insert([
			'id' => 1762, 
			'name' => 'Confins',
			'state' => 11,
		]);
		DB::table('cities')->insert([
			'id' => 1763, 
			'name' => 'Congonhal',
			'state' => 11,
		]);
		DB::table('cities')->insert([
			'id' => 1764, 
			'name' => 'Congonhas',
			'state' => 11,
		]);
		DB::table('cities')->insert([
			'id' => 1765, 
			'name' => 'Congonhas do Norte',
			'state' => 11,
		]);
		DB::table('cities')->insert([
			'id' => 1766, 
			'name' => 'Conquista',
			'state' => 11,
		]);
		DB::table('cities')->insert([
			'id' => 1767, 
			'name' => 'Conselheiro Lafaiete',
			'state' => 11,
		]);
		DB::table('cities')->insert([
			'id' => 1768, 
			'name' => 'Conselheiro Pena',
			'state' => 11,
		]);
		DB::table('cities')->insert([
			'id' => 1769, 
			'name' => 'Consolação',
			'state' => 11,
		]);
		DB::table('cities')->insert([
			'id' => 1770, 
			'name' => 'Contagem',
			'state' => 11,
		]);
		DB::table('cities')->insert([
			'id' => 1771, 
			'name' => 'Coqueiral',
			'state' => 11,
		]);
		DB::table('cities')->insert([
			'id' => 1772, 
			'name' => 'Coração de Jesus',
			'state' => 11,
		]);
		DB::table('cities')->insert([
			'id' => 1773, 
			'name' => 'Cordisburgo',
			'state' => 11,
		]);
		DB::table('cities')->insert([
			'id' => 1774, 
			'name' => 'Cordislândia',
			'state' => 11,
		]);
		DB::table('cities')->insert([
			'id' => 1775, 
			'name' => 'Corinto',
			'state' => 11,
		]);
		DB::table('cities')->insert([
			'id' => 1776, 
			'name' => 'Coroaci',
			'state' => 11,
		]);
		DB::table('cities')->insert([
			'id' => 1777, 
			'name' => 'Coromandel',
			'state' => 11,
		]);
		DB::table('cities')->insert([
			'id' => 1778, 
			'name' => 'Coronel Fabriciano',
			'state' => 11,
		]);
		DB::table('cities')->insert([
			'id' => 1779, 
			'name' => 'Coronel Murta',
			'state' => 11,
		]);
		DB::table('cities')->insert([
			'id' => 1780, 
			'name' => 'Coronel Pacheco',
			'state' => 11,
		]);
		DB::table('cities')->insert([
			'id' => 1781, 
			'name' => 'Coronel Xavier Chaves',
			'state' => 11,
		]);
		DB::table('cities')->insert([
			'id' => 1782, 
			'name' => 'Córrego Danta',
			'state' => 11,
		]);
		DB::table('cities')->insert([
			'id' => 1783, 
			'name' => 'Córrego do Bom Jesus',
			'state' => 11,
		]);
		DB::table('cities')->insert([
			'id' => 1784, 
			'name' => 'Córrego Fundo',
			'state' => 11,
		]);
		DB::table('cities')->insert([
			'id' => 1785, 
			'name' => 'Córrego Novo',
			'state' => 11,
		]);
		DB::table('cities')->insert([
			'id' => 1786, 
			'name' => 'Couto de Magalhães de Minas',
			'state' => 11,
		]);
		DB::table('cities')->insert([
			'id' => 1787, 
			'name' => 'Crisólita',
			'state' => 11,
		]);
		DB::table('cities')->insert([
			'id' => 1788, 
			'name' => 'Cristais',
			'state' => 11,
		]);
		DB::table('cities')->insert([
			'id' => 1789, 
			'name' => 'Cristália',
			'state' => 11,
		]);
		DB::table('cities')->insert([
			'id' => 1790, 
			'name' => 'Cristiano Otoni',
			'state' => 11,
		]);
		DB::table('cities')->insert([
			'id' => 1791, 
			'name' => 'Cristina',
			'state' => 11,
		]);
		DB::table('cities')->insert([
			'id' => 1792, 
			'name' => 'Crucilândia',
			'state' => 11,
		]);
		DB::table('cities')->insert([
			'id' => 1793, 
			'name' => 'Cruzeiro da Fortaleza',
			'state' => 11,
		]);
		DB::table('cities')->insert([
			'id' => 1794, 
			'name' => 'Cruzília',
			'state' => 11,
		]);
		DB::table('cities')->insert([
			'id' => 1795, 
			'name' => 'Cuparaque',
			'state' => 11,
		]);
		DB::table('cities')->insert([
			'id' => 1796, 
			'name' => 'Curral de Dentro',
			'state' => 11,
		]);
		DB::table('cities')->insert([
			'id' => 1797, 
			'name' => 'Curvelo',
			'state' => 11,
		]);
		DB::table('cities')->insert([
			'id' => 1798, 
			'name' => 'Datas',
			'state' => 11,
		]);
		DB::table('cities')->insert([
			'id' => 1799, 
			'name' => 'Delfim Moreira',
			'state' => 11,
		]);
		DB::table('cities')->insert([
			'id' => 1800, 
			'name' => 'Delfinópolis',
			'state' => 11,
		]);
		DB::table('cities')->insert([
			'id' => 1801, 
			'name' => 'Delta',
			'state' => 11,
		]);
		DB::table('cities')->insert([
			'id' => 1802, 
			'name' => 'Descoberto',
			'state' => 11,
		]);
		DB::table('cities')->insert([
			'id' => 1803, 
			'name' => 'Desterro de Entre Rios',
			'state' => 11,
		]);
		DB::table('cities')->insert([
			'id' => 1804, 
			'name' => 'Desterro do Melo',
			'state' => 11,
		]);
		DB::table('cities')->insert([
			'id' => 1805, 
			'name' => 'Diamantina',
			'state' => 11,
		]);
		DB::table('cities')->insert([
			'id' => 1806, 
			'name' => 'Diogo de Vasconcelos',
			'state' => 11,
		]);
		DB::table('cities')->insert([
			'id' => 1807, 
			'name' => 'Dionísio',
			'state' => 11,
		]);
		DB::table('cities')->insert([
			'id' => 1808, 
			'name' => 'Divinésia',
			'state' => 11,
		]);
		DB::table('cities')->insert([
			'id' => 1809, 
			'name' => 'Divino',
			'state' => 11,
		]);
		DB::table('cities')->insert([
			'id' => 1810, 
			'name' => 'Divino das Laranjeiras',
			'state' => 11,
		]);
		DB::table('cities')->insert([
			'id' => 1811, 
			'name' => 'Divinolândia de Minas',
			'state' => 11,
		]);
		DB::table('cities')->insert([
			'id' => 1812, 
			'name' => 'Divinópolis',
			'state' => 11,
		]);
		DB::table('cities')->insert([
			'id' => 1813, 
			'name' => 'Divisa Alegre',
			'state' => 11,
		]);
		DB::table('cities')->insert([
			'id' => 1814, 
			'name' => 'Divisa Nova',
			'state' => 11,
		]);
		DB::table('cities')->insert([
			'id' => 1815, 
			'name' => 'Divisópolis',
			'state' => 11,
		]);
		DB::table('cities')->insert([
			'id' => 1816, 
			'name' => 'Dom Bosco',
			'state' => 11,
		]);
		DB::table('cities')->insert([
			'id' => 1817, 
			'name' => 'Dom Cavati',
			'state' => 11,
		]);
		DB::table('cities')->insert([
			'id' => 1818, 
			'name' => 'Dom Joaquim',
			'state' => 11,
		]);
		DB::table('cities')->insert([
			'id' => 1819, 
			'name' => 'Dom Silvério',
			'state' => 11,
		]);
		DB::table('cities')->insert([
			'id' => 1820, 
			'name' => 'Dom Viçoso',
			'state' => 11,
		]);
		DB::table('cities')->insert([
			'id' => 1821, 
			'name' => 'Dona Eusébia',
			'state' => 11,
		]);
		DB::table('cities')->insert([
			'id' => 1822, 
			'name' => 'Dores de Campos',
			'state' => 11,
		]);
		DB::table('cities')->insert([
			'id' => 1823, 
			'name' => 'Dores de Guanhães',
			'state' => 11,
		]);
		DB::table('cities')->insert([
			'id' => 1824, 
			'name' => 'Dores do Indaiá',
			'state' => 11,
		]);
		DB::table('cities')->insert([
			'id' => 1825, 
			'name' => 'Dores do Turvo',
			'state' => 11,
		]);
		DB::table('cities')->insert([
			'id' => 1826, 
			'name' => 'Doresópolis',
			'state' => 11,
		]);
		DB::table('cities')->insert([
			'id' => 1827, 
			'name' => 'Douradoquara',
			'state' => 11,
		]);
		DB::table('cities')->insert([
			'id' => 1828, 
			'name' => 'Durandé',
			'state' => 11,
		]);
		DB::table('cities')->insert([
			'id' => 1829, 
			'name' => 'Elói Mendes',
			'state' => 11,
		]);
		DB::table('cities')->insert([
			'id' => 1830, 
			'name' => 'Engenheiro Caldas',
			'state' => 11,
		]);
		DB::table('cities')->insert([
			'id' => 1831, 
			'name' => 'Engenheiro Navarro',
			'state' => 11,
		]);
		DB::table('cities')->insert([
			'id' => 1832, 
			'name' => 'Entre Folhas',
			'state' => 11,
		]);
		DB::table('cities')->insert([
			'id' => 1833, 
			'name' => 'Entre Rios de Minas',
			'state' => 11,
		]);
		DB::table('cities')->insert([
			'id' => 1834, 
			'name' => 'Ervália',
			'state' => 11,
		]);
		DB::table('cities')->insert([
			'id' => 1835, 
			'name' => 'Esmeraldas',
			'state' => 11,
		]);
		DB::table('cities')->insert([
			'id' => 1836, 
			'name' => 'Espera Feliz',
			'state' => 11,
		]);
		DB::table('cities')->insert([
			'id' => 1837, 
			'name' => 'Espinosa',
			'state' => 11,
		]);
		DB::table('cities')->insert([
			'id' => 1838, 
			'name' => 'Espírito Santo do Dourado',
			'state' => 11,
		]);
		DB::table('cities')->insert([
			'id' => 1839, 
			'name' => 'Estiva',
			'state' => 11,
		]);
		DB::table('cities')->insert([
			'id' => 1840, 
			'name' => 'Estrela Dalva',
			'state' => 11,
		]);
		DB::table('cities')->insert([
			'id' => 1841, 
			'name' => 'Estrela do Indaiá',
			'state' => 11,
		]);
		DB::table('cities')->insert([
			'id' => 1842, 
			'name' => 'Estrela do Sul',
			'state' => 11,
		]);
		DB::table('cities')->insert([
			'id' => 1843, 
			'name' => 'Eugenópolis',
			'state' => 11,
		]);
		DB::table('cities')->insert([
			'id' => 1844, 
			'name' => 'Ewbank da Câmara',
			'state' => 11,
		]);
		DB::table('cities')->insert([
			'id' => 1845, 
			'name' => 'Extrema',
			'state' => 11,
		]);
		DB::table('cities')->insert([
			'id' => 1846, 
			'name' => 'Fama',
			'state' => 11,
		]);
		DB::table('cities')->insert([
			'id' => 1847, 
			'name' => 'Faria Lemos',
			'state' => 11,
		]);
		DB::table('cities')->insert([
			'id' => 1848, 
			'name' => 'Felício dos Santos',
			'state' => 11,
		]);
		DB::table('cities')->insert([
			'id' => 1849, 
			'name' => 'Felisburgo',
			'state' => 11,
		]);
		DB::table('cities')->insert([
			'id' => 1850, 
			'name' => 'Felixlândia',
			'state' => 11,
		]);
		DB::table('cities')->insert([
			'id' => 1851, 
			'name' => 'Fernandes Tourinho',
			'state' => 11,
		]);
		DB::table('cities')->insert([
			'id' => 1852, 
			'name' => 'Ferros',
			'state' => 11,
		]);
		DB::table('cities')->insert([
			'id' => 1853, 
			'name' => 'Fervedouro',
			'state' => 11,
		]);
		DB::table('cities')->insert([
			'id' => 1854, 
			'name' => 'Florestal',
			'state' => 11,
		]);
		DB::table('cities')->insert([
			'id' => 1855, 
			'name' => 'Formiga',
			'state' => 11,
		]);
		DB::table('cities')->insert([
			'id' => 1856, 
			'name' => 'Formoso',
			'state' => 11,
		]);
		DB::table('cities')->insert([
			'id' => 1857, 
			'name' => 'Fortaleza de Minas',
			'state' => 11,
		]);
		DB::table('cities')->insert([
			'id' => 1858, 
			'name' => 'Fortuna de Minas',
			'state' => 11,
		]);
		DB::table('cities')->insert([
			'id' => 1859, 
			'name' => 'Francisco Badaró',
			'state' => 11,
		]);
		DB::table('cities')->insert([
			'id' => 1860, 
			'name' => 'Francisco Dumont',
			'state' => 11,
		]);
		DB::table('cities')->insert([
			'id' => 1861, 
			'name' => 'Francisco Sá',
			'state' => 11,
		]);
		DB::table('cities')->insert([
			'id' => 1862, 
			'name' => 'Franciscópolis',
			'state' => 11,
		]);
		DB::table('cities')->insert([
			'id' => 1863, 
			'name' => 'Frei Gaspar',
			'state' => 11,
		]);
		DB::table('cities')->insert([
			'id' => 1864, 
			'name' => 'Frei Inocêncio',
			'state' => 11,
		]);
		DB::table('cities')->insert([
			'id' => 1865, 
			'name' => 'Frei Lagonegro',
			'state' => 11,
		]);
		DB::table('cities')->insert([
			'id' => 1866, 
			'name' => 'Fronteira',
			'state' => 11,
		]);
		DB::table('cities')->insert([
			'id' => 1867, 
			'name' => 'Fronteira dos Vales',
			'state' => 11,
		]);
		DB::table('cities')->insert([
			'id' => 1868, 
			'name' => 'Fruta de Leite',
			'state' => 11,
		]);
		DB::table('cities')->insert([
			'id' => 1869, 
			'name' => 'Frutal',
			'state' => 11,
		]);
		DB::table('cities')->insert([
			'id' => 1870, 
			'name' => 'Funilândia',
			'state' => 11,
		]);
		DB::table('cities')->insert([
			'id' => 1871, 
			'name' => 'Galiléia',
			'state' => 11,
		]);
		DB::table('cities')->insert([
			'id' => 1872, 
			'name' => 'Gameleiras',
			'state' => 11,
		]);
		DB::table('cities')->insert([
			'id' => 1873, 
			'name' => 'Glaucilândia',
			'state' => 11,
		]);
		DB::table('cities')->insert([
			'id' => 1874, 
			'name' => 'Goiabeira',
			'state' => 11,
		]);
		DB::table('cities')->insert([
			'id' => 1875, 
			'name' => 'Goianá',
			'state' => 11,
		]);
		DB::table('cities')->insert([
			'id' => 1876, 
			'name' => 'Gonçalves',
			'state' => 11,
		]);
		DB::table('cities')->insert([
			'id' => 1877, 
			'name' => 'Gonzaga',
			'state' => 11,
		]);
		DB::table('cities')->insert([
			'id' => 1878, 
			'name' => 'Gouveia',
			'state' => 11,
		]);
		DB::table('cities')->insert([
			'id' => 1879, 
			'name' => 'Governador Valadares',
			'state' => 11,
		]);
		DB::table('cities')->insert([
			'id' => 1880, 
			'name' => 'Grão Mogol',
			'state' => 11,
		]);
		DB::table('cities')->insert([
			'id' => 1881, 
			'name' => 'Grupiara',
			'state' => 11,
		]);
		DB::table('cities')->insert([
			'id' => 1882, 
			'name' => 'Guanhães',
			'state' => 11,
		]);
		DB::table('cities')->insert([
			'id' => 1883, 
			'name' => 'Guapé',
			'state' => 11,
		]);
		DB::table('cities')->insert([
			'id' => 1884, 
			'name' => 'Guaraciaba',
			'state' => 11,
		]);
		DB::table('cities')->insert([
			'id' => 1885, 
			'name' => 'Guaraciama',
			'state' => 11,
		]);
		DB::table('cities')->insert([
			'id' => 1886, 
			'name' => 'Guaranésia',
			'state' => 11,
		]);
		DB::table('cities')->insert([
			'id' => 1887, 
			'name' => 'Guarani',
			'state' => 11,
		]);
		DB::table('cities')->insert([
			'id' => 1888, 
			'name' => 'Guarará',
			'state' => 11,
		]);
		DB::table('cities')->insert([
			'id' => 1889, 
			'name' => 'Guarda-Mor',
			'state' => 11,
		]);
		DB::table('cities')->insert([
			'id' => 1890, 
			'name' => 'Guaxupé',
			'state' => 11,
		]);
		DB::table('cities')->insert([
			'id' => 1891, 
			'name' => 'Guidoval',
			'state' => 11,
		]);
		DB::table('cities')->insert([
			'id' => 1892, 
			'name' => 'Guimarânia',
			'state' => 11,
		]);
		DB::table('cities')->insert([
			'id' => 1893, 
			'name' => 'Guiricema',
			'state' => 11,
		]);
		DB::table('cities')->insert([
			'id' => 1894, 
			'name' => 'Gurinhatã',
			'state' => 11,
		]);
		DB::table('cities')->insert([
			'id' => 1895, 
			'name' => 'Heliodora',
			'state' => 11,
		]);
		DB::table('cities')->insert([
			'id' => 1896, 
			'name' => 'Iapu',
			'state' => 11,
		]);
		DB::table('cities')->insert([
			'id' => 1897, 
			'name' => 'Ibertioga',
			'state' => 11,
		]);
		DB::table('cities')->insert([
			'id' => 1898, 
			'name' => 'Ibiá',
			'state' => 11,
		]);
		DB::table('cities')->insert([
			'id' => 1899, 
			'name' => 'Ibiaí',
			'state' => 11,
		]);
		DB::table('cities')->insert([
			'id' => 1900, 
			'name' => 'Ibiracatu',
			'state' => 11,
		]);
		DB::table('cities')->insert([
			'id' => 1901, 
			'name' => 'Ibiraci',
			'state' => 11,
		]);
		DB::table('cities')->insert([
			'id' => 1902, 
			'name' => 'Ibirité',
			'state' => 11,
		]);
		DB::table('cities')->insert([
			'id' => 1903, 
			'name' => 'Ibitiúra de Minas',
			'state' => 11,
		]);
		DB::table('cities')->insert([
			'id' => 1904, 
			'name' => 'Ibituruna',
			'state' => 11,
		]);
		DB::table('cities')->insert([
			'id' => 1905, 
			'name' => 'Icaraí de Minas',
			'state' => 11,
		]);
		DB::table('cities')->insert([
			'id' => 1906, 
			'name' => 'Igarapé',
			'state' => 11,
		]);
		DB::table('cities')->insert([
			'id' => 1907, 
			'name' => 'Igaratinga',
			'state' => 11,
		]);
		DB::table('cities')->insert([
			'id' => 1908, 
			'name' => 'Iguatama',
			'state' => 11,
		]);
		DB::table('cities')->insert([
			'id' => 1909, 
			'name' => 'Ijaci',
			'state' => 11,
		]);
		DB::table('cities')->insert([
			'id' => 1910, 
			'name' => 'Ilicínea',
			'state' => 11,
		]);
		DB::table('cities')->insert([
			'id' => 1911, 
			'name' => 'Imbé de Minas',
			'state' => 11,
		]);
		DB::table('cities')->insert([
			'id' => 1912, 
			'name' => 'Inconfidentes',
			'state' => 11,
		]);
		DB::table('cities')->insert([
			'id' => 1913, 
			'name' => 'Indaiabira',
			'state' => 11,
		]);
		DB::table('cities')->insert([
			'id' => 1914, 
			'name' => 'Indianópolis',
			'state' => 11,
		]);
		DB::table('cities')->insert([
			'id' => 1915, 
			'name' => 'Ingaí',
			'state' => 11,
		]);
		DB::table('cities')->insert([
			'id' => 1916, 
			'name' => 'Inhapim',
			'state' => 11,
		]);
		DB::table('cities')->insert([
			'id' => 1917, 
			'name' => 'Inhaúma',
			'state' => 11,
		]);
		DB::table('cities')->insert([
			'id' => 1918, 
			'name' => 'Inimutaba',
			'state' => 11,
		]);
		DB::table('cities')->insert([
			'id' => 1919, 
			'name' => 'Ipaba',
			'state' => 11,
		]);
		DB::table('cities')->insert([
			'id' => 1920, 
			'name' => 'Ipanema',
			'state' => 11,
		]);
		DB::table('cities')->insert([
			'id' => 1921, 
			'name' => 'Ipatinga',
			'state' => 11,
		]);
		DB::table('cities')->insert([
			'id' => 1922, 
			'name' => 'Ipiaçu',
			'state' => 11,
		]);
		DB::table('cities')->insert([
			'id' => 1923, 
			'name' => 'Ipuiúna',
			'state' => 11,
		]);
		DB::table('cities')->insert([
			'id' => 1924, 
			'name' => 'Iraí de Minas',
			'state' => 11,
		]);
		DB::table('cities')->insert([
			'id' => 1925, 
			'name' => 'Itabira',
			'state' => 11,
		]);
		DB::table('cities')->insert([
			'id' => 1926, 
			'name' => 'Itabirinha de Mantena',
			'state' => 11,
		]);
		DB::table('cities')->insert([
			'id' => 1927, 
			'name' => 'Itabirito',
			'state' => 11,
		]);
		DB::table('cities')->insert([
			'id' => 1928, 
			'name' => 'Itacambira',
			'state' => 11,
		]);
		DB::table('cities')->insert([
			'id' => 1929, 
			'name' => 'Itacarambi',
			'state' => 11,
		]);
		DB::table('cities')->insert([
			'id' => 1930, 
			'name' => 'Itaguara',
			'state' => 11,
		]);
		DB::table('cities')->insert([
			'id' => 1931, 
			'name' => 'Itaipé',
			'state' => 11,
		]);
		DB::table('cities')->insert([
			'id' => 1932, 
			'name' => 'Itajubá',
			'state' => 11,
		]);
		DB::table('cities')->insert([
			'id' => 1933, 
			'name' => 'Itamarandiba',
			'state' => 11,
		]);
		DB::table('cities')->insert([
			'id' => 1934, 
			'name' => 'Itamarati de Minas',
			'state' => 11,
		]);
		DB::table('cities')->insert([
			'id' => 1935, 
			'name' => 'Itambacuri',
			'state' => 11,
		]);
		DB::table('cities')->insert([
			'id' => 1936, 
			'name' => 'Itambé do Mato Dentro',
			'state' => 11,
		]);
		DB::table('cities')->insert([
			'id' => 1937, 
			'name' => 'Itamogi',
			'state' => 11,
		]);
		DB::table('cities')->insert([
			'id' => 1938, 
			'name' => 'Itamonte',
			'state' => 11,
		]);
		DB::table('cities')->insert([
			'id' => 1939, 
			'name' => 'Itanhandu',
			'state' => 11,
		]);
		DB::table('cities')->insert([
			'id' => 1940, 
			'name' => 'Itanhomi',
			'state' => 11,
		]);
		DB::table('cities')->insert([
			'id' => 1941, 
			'name' => 'Itaobim',
			'state' => 11,
		]);
		DB::table('cities')->insert([
			'id' => 1942, 
			'name' => 'Itapagipe',
			'state' => 11,
		]);
		DB::table('cities')->insert([
			'id' => 1943, 
			'name' => 'Itapecerica',
			'state' => 11,
		]);
		DB::table('cities')->insert([
			'id' => 1944, 
			'name' => 'Itapeva',
			'state' => 11,
		]);
		DB::table('cities')->insert([
			'id' => 1945, 
			'name' => 'Itatiaiuçu',
			'state' => 11,
		]);
		DB::table('cities')->insert([
			'id' => 1946, 
			'name' => 'Itaú de Minas',
			'state' => 11,
		]);
		DB::table('cities')->insert([
			'id' => 1947, 
			'name' => 'Itaúna',
			'state' => 11,
		]);
		DB::table('cities')->insert([
			'id' => 1948, 
			'name' => 'Itaverava',
			'state' => 11,
		]);
		DB::table('cities')->insert([
			'id' => 1949, 
			'name' => 'Itinga',
			'state' => 11,
		]);
		DB::table('cities')->insert([
			'id' => 1950, 
			'name' => 'Itueta',
			'state' => 11,
		]);
		DB::table('cities')->insert([
			'id' => 1951, 
			'name' => 'Ituiutaba',
			'state' => 11,
		]);
		DB::table('cities')->insert([
			'id' => 1952, 
			'name' => 'Itumirim',
			'state' => 11,
		]);
		DB::table('cities')->insert([
			'id' => 1953, 
			'name' => 'Iturama',
			'state' => 11,
		]);
		DB::table('cities')->insert([
			'id' => 1954, 
			'name' => 'Itutinga',
			'state' => 11,
		]);
		DB::table('cities')->insert([
			'id' => 1955, 
			'name' => 'Jaboticatubas',
			'state' => 11,
		]);
		DB::table('cities')->insert([
			'id' => 1956, 
			'name' => 'Jacinto',
			'state' => 11,
		]);
		DB::table('cities')->insert([
			'id' => 1957, 
			'name' => 'Jacuí',
			'state' => 11,
		]);
		DB::table('cities')->insert([
			'id' => 1958, 
			'name' => 'Jacutinga',
			'state' => 11,
		]);
		DB::table('cities')->insert([
			'id' => 1959, 
			'name' => 'Jaguaraçu',
			'state' => 11,
		]);
		DB::table('cities')->insert([
			'id' => 1960, 
			'name' => 'Jaíba',
			'state' => 11,
		]);
		DB::table('cities')->insert([
			'id' => 1961, 
			'name' => 'Jampruca',
			'state' => 11,
		]);
		DB::table('cities')->insert([
			'id' => 1962, 
			'name' => 'Janaúba',
			'state' => 11,
		]);
		DB::table('cities')->insert([
			'id' => 1963, 
			'name' => 'Januária',
			'state' => 11,
		]);
		DB::table('cities')->insert([
			'id' => 1964, 
			'name' => 'Japaraíba',
			'state' => 11,
		]);
		DB::table('cities')->insert([
			'id' => 1965, 
			'name' => 'Japonvar',
			'state' => 11,
		]);
		DB::table('cities')->insert([
			'id' => 1966, 
			'name' => 'Jeceaba',
			'state' => 11,
		]);
		DB::table('cities')->insert([
			'id' => 1967, 
			'name' => 'Jenipapo de Minas',
			'state' => 11,
		]);
		DB::table('cities')->insert([
			'id' => 1968, 
			'name' => 'Jequeri',
			'state' => 11,
		]);
		DB::table('cities')->insert([
			'id' => 1969, 
			'name' => 'Jequitaí',
			'state' => 11,
		]);
		DB::table('cities')->insert([
			'id' => 1970, 
			'name' => 'Jequitibá',
			'state' => 11,
		]);
		DB::table('cities')->insert([
			'id' => 1971, 
			'name' => 'Jequitinhonha',
			'state' => 11,
		]);
		DB::table('cities')->insert([
			'id' => 1972, 
			'name' => 'Jesuânia',
			'state' => 11,
		]);
		DB::table('cities')->insert([
			'id' => 1973, 
			'name' => 'Joaíma',
			'state' => 11,
		]);
		DB::table('cities')->insert([
			'id' => 1974, 
			'name' => 'Joanésia',
			'state' => 11,
		]);
		DB::table('cities')->insert([
			'id' => 1975, 
			'name' => 'João Monlevade',
			'state' => 11,
		]);
		DB::table('cities')->insert([
			'id' => 1976, 
			'name' => 'João Pinheiro',
			'state' => 11,
		]);
		DB::table('cities')->insert([
			'id' => 1977, 
			'name' => 'Joaquim Felício',
			'state' => 11,
		]);
		DB::table('cities')->insert([
			'id' => 1978, 
			'name' => 'Jordânia',
			'state' => 11,
		]);
		DB::table('cities')->insert([
			'id' => 1979, 
			'name' => 'José Gonçalves de Minas',
			'state' => 11,
		]);
		DB::table('cities')->insert([
			'id' => 1980, 
			'name' => 'José Raydan',
			'state' => 11,
		]);
		DB::table('cities')->insert([
			'id' => 1981, 
			'name' => 'Josenópolis',
			'state' => 11,
		]);
		DB::table('cities')->insert([
			'id' => 1982, 
			'name' => 'Juatuba',
			'state' => 11,
		]);
		DB::table('cities')->insert([
			'id' => 1983, 
			'name' => 'Juiz de Fora',
			'state' => 11,
		]);
		DB::table('cities')->insert([
			'id' => 1984, 
			'name' => 'Juramento',
			'state' => 11,
		]);
		DB::table('cities')->insert([
			'id' => 1985, 
			'name' => 'Juruaia',
			'state' => 11,
		]);
		DB::table('cities')->insert([
			'id' => 1986, 
			'name' => 'Juvenília',
			'state' => 11,
		]);
		DB::table('cities')->insert([
			'id' => 1987, 
			'name' => 'Ladainha',
			'state' => 11,
		]);
		DB::table('cities')->insert([
			'id' => 1988, 
			'name' => 'Lagamar',
			'state' => 11,
		]);
		DB::table('cities')->insert([
			'id' => 1989, 
			'name' => 'Lagoa da Prata',
			'state' => 11,
		]);
		DB::table('cities')->insert([
			'id' => 1990, 
			'name' => 'Lagoa dos Patos',
			'state' => 11,
		]);
		DB::table('cities')->insert([
			'id' => 1991, 
			'name' => 'Lagoa Dourada',
			'state' => 11,
		]);
		DB::table('cities')->insert([
			'id' => 1992, 
			'name' => 'Lagoa Formosa',
			'state' => 11,
		]);
		DB::table('cities')->insert([
			'id' => 1993, 
			'name' => 'Lagoa Grande',
			'state' => 11,
		]);
		DB::table('cities')->insert([
			'id' => 1994, 
			'name' => 'Lagoa Santa',
			'state' => 11,
		]);
		DB::table('cities')->insert([
			'id' => 1995, 
			'name' => 'Lajinha',
			'state' => 11,
		]);
		DB::table('cities')->insert([
			'id' => 1996, 
			'name' => 'Lambari',
			'state' => 11,
		]);
		DB::table('cities')->insert([
			'id' => 1997, 
			'name' => 'Lamim',
			'state' => 11,
		]);
		DB::table('cities')->insert([
			'id' => 1998, 
			'name' => 'Laranjal',
			'state' => 11,
		]);
		DB::table('cities')->insert([
			'id' => 1999, 
			'name' => 'Lassance',
			'state' => 11,
		]);
		DB::table('cities')->insert([
			'id' => 2000, 
			'name' => 'Lavras',
			'state' => 11,
		]);
		DB::table('cities')->insert([
			'id' => 2001, 
			'name' => 'Leandro Ferreira',
			'state' => 11,
		]);
		DB::table('cities')->insert([
			'id' => 2002, 
			'name' => 'Leme do Prado',
			'state' => 11,
		]);
		DB::table('cities')->insert([
			'id' => 2003, 
			'name' => 'Leopoldina',
			'state' => 11,
		]);
		DB::table('cities')->insert([
			'id' => 2004, 
			'name' => 'Liberdade',
			'state' => 11,
		]);
		DB::table('cities')->insert([
			'id' => 2005, 
			'name' => 'Lima Duarte',
			'state' => 11,
		]);
		DB::table('cities')->insert([
			'id' => 2006, 
			'name' => 'Limeira do Oeste',
			'state' => 11,
		]);
		DB::table('cities')->insert([
			'id' => 2007, 
			'name' => 'Lontra',
			'state' => 11,
		]);
		DB::table('cities')->insert([
			'id' => 2008, 
			'name' => 'Luisburgo',
			'state' => 11,
		]);
		DB::table('cities')->insert([
			'id' => 2009, 
			'name' => 'Luislândia',
			'state' => 11,
		]);
		DB::table('cities')->insert([
			'id' => 2010, 
			'name' => 'Luminárias',
			'state' => 11,
		]);
		DB::table('cities')->insert([
			'id' => 2011, 
			'name' => 'Luz',
			'state' => 11,
		]);
		DB::table('cities')->insert([
			'id' => 2012, 
			'name' => 'Machacalis',
			'state' => 11,
		]);
		DB::table('cities')->insert([
			'id' => 2013, 
			'name' => 'Machado',
			'state' => 11,
		]);
		DB::table('cities')->insert([
			'id' => 2014, 
			'name' => 'Madre de Deus de Minas',
			'state' => 11,
		]);
		DB::table('cities')->insert([
			'id' => 2015, 
			'name' => 'Malacacheta',
			'state' => 11,
		]);
		DB::table('cities')->insert([
			'id' => 2016, 
			'name' => 'Mamonas',
			'state' => 11,
		]);
		DB::table('cities')->insert([
			'id' => 2017, 
			'name' => 'Manga',
			'state' => 11,
		]);
		DB::table('cities')->insert([
			'id' => 2018, 
			'name' => 'Manhuaçu',
			'state' => 11,
		]);
		DB::table('cities')->insert([
			'id' => 2019, 
			'name' => 'Manhumirim',
			'state' => 11,
		]);
		DB::table('cities')->insert([
			'id' => 2020, 
			'name' => 'Mantena',
			'state' => 11,
		]);
		DB::table('cities')->insert([
			'id' => 2021, 
			'name' => 'Mar de Espanha',
			'state' => 11,
		]);
		DB::table('cities')->insert([
			'id' => 2022, 
			'name' => 'Maravilhas',
			'state' => 11,
		]);
		DB::table('cities')->insert([
			'id' => 2023, 
			'name' => 'Maria da Fé',
			'state' => 11,
		]);
		DB::table('cities')->insert([
			'id' => 2024, 
			'name' => 'Mariana',
			'state' => 11,
		]);
		DB::table('cities')->insert([
			'id' => 2025, 
			'name' => 'Marilac',
			'state' => 11,
		]);
		DB::table('cities')->insert([
			'id' => 2026, 
			'name' => 'Mário Campos',
			'state' => 11,
		]);
		DB::table('cities')->insert([
			'id' => 2027, 
			'name' => 'Maripá de Minas',
			'state' => 11,
		]);
		DB::table('cities')->insert([
			'id' => 2028, 
			'name' => 'Marliéria',
			'state' => 11,
		]);
		DB::table('cities')->insert([
			'id' => 2029, 
			'name' => 'Marmelópolis',
			'state' => 11,
		]);
		DB::table('cities')->insert([
			'id' => 2030, 
			'name' => 'Martinho Campos',
			'state' => 11,
		]);
		DB::table('cities')->insert([
			'id' => 2031, 
			'name' => 'Martins Soares',
			'state' => 11,
		]);
		DB::table('cities')->insert([
			'id' => 2032, 
			'name' => 'Mata Verde',
			'state' => 11,
		]);
		DB::table('cities')->insert([
			'id' => 2033, 
			'name' => 'Materlândia',
			'state' => 11,
		]);
		DB::table('cities')->insert([
			'id' => 2034, 
			'name' => 'Mateus Leme',
			'state' => 11,
		]);
		DB::table('cities')->insert([
			'id' => 2035, 
			'name' => 'Mathias Lobato',
			'state' => 11,
		]);
		DB::table('cities')->insert([
			'id' => 2036, 
			'name' => 'Matias Barbosa',
			'state' => 11,
		]);
		DB::table('cities')->insert([
			'id' => 2037, 
			'name' => 'Matias Cardoso',
			'state' => 11,
		]);
		DB::table('cities')->insert([
			'id' => 2038, 
			'name' => 'Matipó',
			'state' => 11,
		]);
		DB::table('cities')->insert([
			'id' => 2039, 
			'name' => 'Mato Verde',
			'state' => 11,
		]);
		DB::table('cities')->insert([
			'id' => 2040, 
			'name' => 'Matozinhos',
			'state' => 11,
		]);
		DB::table('cities')->insert([
			'id' => 2041, 
			'name' => 'Matutina',
			'state' => 11,
		]);
		DB::table('cities')->insert([
			'id' => 2042, 
			'name' => 'Medeiros',
			'state' => 11,
		]);
		DB::table('cities')->insert([
			'id' => 2043, 
			'name' => 'Medina',
			'state' => 11,
		]);
		DB::table('cities')->insert([
			'id' => 2044, 
			'name' => 'Mendes Pimentel',
			'state' => 11,
		]);
		DB::table('cities')->insert([
			'id' => 2045, 
			'name' => 'Mercês',
			'state' => 11,
		]);
		DB::table('cities')->insert([
			'id' => 2046, 
			'name' => 'Mesquita',
			'state' => 11,
		]);
		DB::table('cities')->insert([
			'id' => 2047, 
			'name' => 'Minas Novas',
			'state' => 11,
		]);
		DB::table('cities')->insert([
			'id' => 2048, 
			'name' => 'Minduri',
			'state' => 11,
		]);
		DB::table('cities')->insert([
			'id' => 2049, 
			'name' => 'Mirabela',
			'state' => 11,
		]);
		DB::table('cities')->insert([
			'id' => 2050, 
			'name' => 'Miradouro',
			'state' => 11,
		]);
		DB::table('cities')->insert([
			'id' => 2051, 
			'name' => 'Miraí',
			'state' => 11,
		]);
		DB::table('cities')->insert([
			'id' => 2052, 
			'name' => 'Miravânia',
			'state' => 11,
		]);
		DB::table('cities')->insert([
			'id' => 2053, 
			'name' => 'Moeda',
			'state' => 11,
		]);
		DB::table('cities')->insert([
			'id' => 2054, 
			'name' => 'Moema',
			'state' => 11,
		]);
		DB::table('cities')->insert([
			'id' => 2055, 
			'name' => 'Monjolos',
			'state' => 11,
		]);
		DB::table('cities')->insert([
			'id' => 2056, 
			'name' => 'Monsenhor Paulo',
			'state' => 11,
		]);
		DB::table('cities')->insert([
			'id' => 2057, 
			'name' => 'Montalvânia',
			'state' => 11,
		]);
		DB::table('cities')->insert([
			'id' => 2058, 
			'name' => 'Monte Alegre de Minas',
			'state' => 11,
		]);
		DB::table('cities')->insert([
			'id' => 2059, 
			'name' => 'Monte Azul',
			'state' => 11,
		]);
		DB::table('cities')->insert([
			'id' => 2060, 
			'name' => 'Monte Belo',
			'state' => 11,
		]);
		DB::table('cities')->insert([
			'id' => 2061, 
			'name' => 'Monte Carmelo',
			'state' => 11,
		]);
		DB::table('cities')->insert([
			'id' => 2062, 
			'name' => 'Monte Formoso',
			'state' => 11,
		]);
		DB::table('cities')->insert([
			'id' => 2063, 
			'name' => 'Monte Santo de Minas',
			'state' => 11,
		]);
		DB::table('cities')->insert([
			'id' => 2064, 
			'name' => 'Monte Sião',
			'state' => 11,
		]);
		DB::table('cities')->insert([
			'id' => 2065, 
			'name' => 'Montes Claros',
			'state' => 11,
		]);
		DB::table('cities')->insert([
			'id' => 2066, 
			'name' => 'Montezuma',
			'state' => 11,
		]);
		DB::table('cities')->insert([
			'id' => 2067, 
			'name' => 'Morada Nova de Minas',
			'state' => 11,
		]);
		DB::table('cities')->insert([
			'id' => 2068, 
			'name' => 'Morro da Garça',
			'state' => 11,
		]);
		DB::table('cities')->insert([
			'id' => 2069, 
			'name' => 'Morro do Pilar',
			'state' => 11,
		]);
		DB::table('cities')->insert([
			'id' => 2070, 
			'name' => 'Munhoz',
			'state' => 11,
		]);
		DB::table('cities')->insert([
			'id' => 2071, 
			'name' => 'Muriaé',
			'state' => 11,
		]);
		DB::table('cities')->insert([
			'id' => 2072, 
			'name' => 'Mutum',
			'state' => 11,
		]);
		DB::table('cities')->insert([
			'id' => 2073, 
			'name' => 'Muzambinho',
			'state' => 11,
		]);
		DB::table('cities')->insert([
			'id' => 2074, 
			'name' => 'Nacip Raydan',
			'state' => 11,
		]);
		DB::table('cities')->insert([
			'id' => 2075, 
			'name' => 'Nanuque',
			'state' => 11,
		]);
		DB::table('cities')->insert([
			'id' => 2076, 
			'name' => 'Naque',
			'state' => 11,
		]);
		DB::table('cities')->insert([
			'id' => 2077, 
			'name' => 'Natalândia',
			'state' => 11,
		]);
		DB::table('cities')->insert([
			'id' => 2078, 
			'name' => 'Natércia',
			'state' => 11,
		]);
		DB::table('cities')->insert([
			'id' => 2079, 
			'name' => 'Nazareno',
			'state' => 11,
		]);
		DB::table('cities')->insert([
			'id' => 2080, 
			'name' => 'Nepomuceno',
			'state' => 11,
		]);
		DB::table('cities')->insert([
			'id' => 2081, 
			'name' => 'Ninheira',
			'state' => 11,
		]);
		DB::table('cities')->insert([
			'id' => 2082, 
			'name' => 'Nova Belém',
			'state' => 11,
		]);
		DB::table('cities')->insert([
			'id' => 2083, 
			'name' => 'Nova Era',
			'state' => 11,
		]);
		DB::table('cities')->insert([
			'id' => 2084, 
			'name' => 'Nova Lima',
			'state' => 11,
		]);
		DB::table('cities')->insert([
			'id' => 2085, 
			'name' => 'Nova Módica',
			'state' => 11,
		]);
		DB::table('cities')->insert([
			'id' => 2086, 
			'name' => 'Nova Ponte',
			'state' => 11,
		]);
		DB::table('cities')->insert([
			'id' => 2087, 
			'name' => 'Nova Porteirinha',
			'state' => 11,
		]);
		DB::table('cities')->insert([
			'id' => 2088, 
			'name' => 'Nova Resende',
			'state' => 11,
		]);
		DB::table('cities')->insert([
			'id' => 2089, 
			'name' => 'Nova Serrana',
			'state' => 11,
		]);
		DB::table('cities')->insert([
			'id' => 2090, 
			'name' => 'Nova União',
			'state' => 11,
		]);
		DB::table('cities')->insert([
			'id' => 2091, 
			'name' => 'Novo Cruzeiro',
			'state' => 11,
		]);
		DB::table('cities')->insert([
			'id' => 2092, 
			'name' => 'Novo Oriente de Minas',
			'state' => 11,
		]);
		DB::table('cities')->insert([
			'id' => 2093, 
			'name' => 'Novorizonte',
			'state' => 11,
		]);
		DB::table('cities')->insert([
			'id' => 2094, 
			'name' => 'Olaria',
			'state' => 11,
		]);
		DB::table('cities')->insert([
			'id' => 2095, 
			'name' => 'Olhos-d`Água',
			'state' => 11,
		]);
		DB::table('cities')->insert([
			'id' => 2096, 
			'name' => 'Olímpio Noronha',
			'state' => 11,
		]);
		DB::table('cities')->insert([
			'id' => 2097, 
			'name' => 'Oliveira',
			'state' => 11,
		]);
		DB::table('cities')->insert([
			'id' => 2098, 
			'name' => 'Oliveira Fortes',
			'state' => 11,
		]);
		DB::table('cities')->insert([
			'id' => 2099, 
			'name' => 'Onça de Pitangui',
			'state' => 11,
		]);
		DB::table('cities')->insert([
			'id' => 2100, 
			'name' => 'Oratórios',
			'state' => 11,
		]);
		DB::table('cities')->insert([
			'id' => 2101, 
			'name' => 'Orizânia',
			'state' => 11,
		]);
		DB::table('cities')->insert([
			'id' => 2102, 
			'name' => 'Ouro Branco',
			'state' => 11,
		]);
		DB::table('cities')->insert([
			'id' => 2103, 
			'name' => 'Ouro Fino',
			'state' => 11,
		]);
		DB::table('cities')->insert([
			'id' => 2104, 
			'name' => 'Ouro Preto',
			'state' => 11,
		]);
		DB::table('cities')->insert([
			'id' => 2105, 
			'name' => 'Ouro Verde de Minas',
			'state' => 11,
		]);
		DB::table('cities')->insert([
			'id' => 2106, 
			'name' => 'Padre Carvalho',
			'state' => 11,
		]);
		DB::table('cities')->insert([
			'id' => 2107, 
			'name' => 'Padre Paraíso',
			'state' => 11,
		]);
		DB::table('cities')->insert([
			'id' => 2108, 
			'name' => 'Pai Pedro',
			'state' => 11,
		]);
		DB::table('cities')->insert([
			'id' => 2109, 
			'name' => 'Paineiras',
			'state' => 11,
		]);
		DB::table('cities')->insert([
			'id' => 2110, 
			'name' => 'Pains',
			'state' => 11,
		]);
		DB::table('cities')->insert([
			'id' => 2111, 
			'name' => 'Paiva',
			'state' => 11,
		]);
		DB::table('cities')->insert([
			'id' => 2112, 
			'name' => 'Palma',
			'state' => 11,
		]);
		DB::table('cities')->insert([
			'id' => 2113, 
			'name' => 'Palmópolis',
			'state' => 11,
		]);
		DB::table('cities')->insert([
			'id' => 2114, 
			'name' => 'Papagaios',
			'state' => 11,
		]);
		DB::table('cities')->insert([
			'id' => 2115, 
			'name' => 'Pará de Minas',
			'state' => 11,
		]);
		DB::table('cities')->insert([
			'id' => 2116, 
			'name' => 'Paracatu',
			'state' => 11,
		]);
		DB::table('cities')->insert([
			'id' => 2117, 
			'name' => 'Paraguaçu',
			'state' => 11,
		]);
		DB::table('cities')->insert([
			'id' => 2118, 
			'name' => 'Paraisópolis',
			'state' => 11,
		]);
		DB::table('cities')->insert([
			'id' => 2119, 
			'name' => 'Paraopeba',
			'state' => 11,
		]);
		DB::table('cities')->insert([
			'id' => 2120, 
			'name' => 'Passa Quatro',
			'state' => 11,
		]);
		DB::table('cities')->insert([
			'id' => 2121, 
			'name' => 'Passa Tempo',
			'state' => 11,
		]);
		DB::table('cities')->insert([
			'id' => 2122, 
			'name' => 'Passabém',
			'state' => 11,
		]);
		DB::table('cities')->insert([
			'id' => 2123, 
			'name' => 'Passa-Vinte',
			'state' => 11,
		]);
		DB::table('cities')->insert([
			'id' => 2124, 
			'name' => 'Passos',
			'state' => 11,
		]);
		DB::table('cities')->insert([
			'id' => 2125, 
			'name' => 'Patis',
			'state' => 11,
		]);
		DB::table('cities')->insert([
			'id' => 2126, 
			'name' => 'Patos de Minas',
			'state' => 11,
		]);
		DB::table('cities')->insert([
			'id' => 2127, 
			'name' => 'Patrocínio',
			'state' => 11,
		]);
		DB::table('cities')->insert([
			'id' => 2128, 
			'name' => 'Patrocínio do Muriaé',
			'state' => 11,
		]);
		DB::table('cities')->insert([
			'id' => 2129, 
			'name' => 'Paula Cândido',
			'state' => 11,
		]);
		DB::table('cities')->insert([
			'id' => 2130, 
			'name' => 'Paulistas',
			'state' => 11,
		]);
		DB::table('cities')->insert([
			'id' => 2131, 
			'name' => 'Pavão',
			'state' => 11,
		]);
		DB::table('cities')->insert([
			'id' => 2132, 
			'name' => 'Peçanha',
			'state' => 11,
		]);
		DB::table('cities')->insert([
			'id' => 2133, 
			'name' => 'Pedra Azul',
			'state' => 11,
		]);
		DB::table('cities')->insert([
			'id' => 2134, 
			'name' => 'Pedra Bonita',
			'state' => 11,
		]);
		DB::table('cities')->insert([
			'id' => 2135, 
			'name' => 'Pedra do Anta',
			'state' => 11,
		]);
		DB::table('cities')->insert([
			'id' => 2136, 
			'name' => 'Pedra do Indaiá',
			'state' => 11,
		]);
		DB::table('cities')->insert([
			'id' => 2137, 
			'name' => 'Pedra Dourada',
			'state' => 11,
		]);
		DB::table('cities')->insert([
			'id' => 2138, 
			'name' => 'Pedralva',
			'state' => 11,
		]);
		DB::table('cities')->insert([
			'id' => 2139, 
			'name' => 'Pedras de Maria da Cruz',
			'state' => 11,
		]);
		DB::table('cities')->insert([
			'id' => 2140, 
			'name' => 'Pedrinópolis',
			'state' => 11,
		]);
		DB::table('cities')->insert([
			'id' => 2141, 
			'name' => 'Pedro Leopoldo',
			'state' => 11,
		]);
		DB::table('cities')->insert([
			'id' => 2142, 
			'name' => 'Pedro Teixeira',
			'state' => 11,
		]);
		DB::table('cities')->insert([
			'id' => 2143, 
			'name' => 'Pequeri',
			'state' => 11,
		]);
		DB::table('cities')->insert([
			'id' => 2144, 
			'name' => 'Pequi',
			'state' => 11,
		]);
		DB::table('cities')->insert([
			'id' => 2145, 
			'name' => 'Perdigão',
			'state' => 11,
		]);
		DB::table('cities')->insert([
			'id' => 2146, 
			'name' => 'Perdizes',
			'state' => 11,
		]);
		DB::table('cities')->insert([
			'id' => 2147, 
			'name' => 'Perdões',
			'state' => 11,
		]);
		DB::table('cities')->insert([
			'id' => 2148, 
			'name' => 'Periquito',
			'state' => 11,
		]);
		DB::table('cities')->insert([
			'id' => 2149, 
			'name' => 'Pescador',
			'state' => 11,
		]);
		DB::table('cities')->insert([
			'id' => 2150, 
			'name' => 'Piau',
			'state' => 11,
		]);
		DB::table('cities')->insert([
			'id' => 2151, 
			'name' => 'Piedade de Caratinga',
			'state' => 11,
		]);
		DB::table('cities')->insert([
			'id' => 2152, 
			'name' => 'Piedade de Ponte Nova',
			'state' => 11,
		]);
		DB::table('cities')->insert([
			'id' => 2153, 
			'name' => 'Piedade do Rio Grande',
			'state' => 11,
		]);
		DB::table('cities')->insert([
			'id' => 2154, 
			'name' => 'Piedade dos Gerais',
			'state' => 11,
		]);
		DB::table('cities')->insert([
			'id' => 2155, 
			'name' => 'Pimenta',
			'state' => 11,
		]);
		DB::table('cities')->insert([
			'id' => 2156, 
			'name' => 'Pingo-d`Água',
			'state' => 11,
		]);
		DB::table('cities')->insert([
			'id' => 2157, 
			'name' => 'Pintópolis',
			'state' => 11,
		]);
		DB::table('cities')->insert([
			'id' => 2158, 
			'name' => 'Piracema',
			'state' => 11,
		]);
		DB::table('cities')->insert([
			'id' => 2159, 
			'name' => 'Pirajuba',
			'state' => 11,
		]);
		DB::table('cities')->insert([
			'id' => 2160, 
			'name' => 'Piranga',
			'state' => 11,
		]);
		DB::table('cities')->insert([
			'id' => 2161, 
			'name' => 'Piranguçu',
			'state' => 11,
		]);
		DB::table('cities')->insert([
			'id' => 2162, 
			'name' => 'Piranguinho',
			'state' => 11,
		]);
		DB::table('cities')->insert([
			'id' => 2163, 
			'name' => 'Pirapetinga',
			'state' => 11,
		]);
		DB::table('cities')->insert([
			'id' => 2164, 
			'name' => 'Pirapora',
			'state' => 11,
		]);
		DB::table('cities')->insert([
			'id' => 2165, 
			'name' => 'Piraúba',
			'state' => 11,
		]);
		DB::table('cities')->insert([
			'id' => 2166, 
			'name' => 'Pitangui',
			'state' => 11,
		]);
		DB::table('cities')->insert([
			'id' => 2167, 
			'name' => 'Piumhi',
			'state' => 11,
		]);
		DB::table('cities')->insert([
			'id' => 2168, 
			'name' => 'Planura',
			'state' => 11,
		]);
		DB::table('cities')->insert([
			'id' => 2169, 
			'name' => 'Poço Fundo',
			'state' => 11,
		]);
		DB::table('cities')->insert([
			'id' => 2170, 
			'name' => 'Poços de Caldas',
			'state' => 11,
		]);
		DB::table('cities')->insert([
			'id' => 2171, 
			'name' => 'Pocrane',
			'state' => 11,
		]);
		DB::table('cities')->insert([
			'id' => 2172, 
			'name' => 'Pompéu',
			'state' => 11,
		]);
		DB::table('cities')->insert([
			'id' => 2173, 
			'name' => 'Ponte Nova',
			'state' => 11,
		]);
		DB::table('cities')->insert([
			'id' => 2174, 
			'name' => 'Ponto Chique',
			'state' => 11,
		]);
		DB::table('cities')->insert([
			'id' => 2175, 
			'name' => 'Ponto dos Volantes',
			'state' => 11,
		]);
		DB::table('cities')->insert([
			'id' => 2176, 
			'name' => 'Porteirinha',
			'state' => 11,
		]);
		DB::table('cities')->insert([
			'id' => 2177, 
			'name' => 'Porto Firme',
			'state' => 11,
		]);
		DB::table('cities')->insert([
			'id' => 2178, 
			'name' => 'Poté',
			'state' => 11,
		]);
		DB::table('cities')->insert([
			'id' => 2179, 
			'name' => 'Pouso Alegre',
			'state' => 11,
		]);
		DB::table('cities')->insert([
			'id' => 2180, 
			'name' => 'Pouso Alto',
			'state' => 11,
		]);
		DB::table('cities')->insert([
			'id' => 2181, 
			'name' => 'Prados',
			'state' => 11,
		]);
		DB::table('cities')->insert([
			'id' => 2182, 
			'name' => 'Prata',
			'state' => 11,
		]);
		DB::table('cities')->insert([
			'id' => 2183, 
			'name' => 'Pratápolis',
			'state' => 11,
		]);
		DB::table('cities')->insert([
			'id' => 2184, 
			'name' => 'Pratinha',
			'state' => 11,
		]);
		DB::table('cities')->insert([
			'id' => 2185, 
			'name' => 'Presidente Bernardes',
			'state' => 11,
		]);
		DB::table('cities')->insert([
			'id' => 2186, 
			'name' => 'Presidente Juscelino',
			'state' => 11,
		]);
		DB::table('cities')->insert([
			'id' => 2187, 
			'name' => 'Presidente Kubitschek',
			'state' => 11,
		]);
		DB::table('cities')->insert([
			'id' => 2188, 
			'name' => 'Presidente Olegário',
			'state' => 11,
		]);
		DB::table('cities')->insert([
			'id' => 2189, 
			'name' => 'Prudente de Morais',
			'state' => 11,
		]);
		DB::table('cities')->insert([
			'id' => 2190, 
			'name' => 'Quartel Geral',
			'state' => 11,
		]);
		DB::table('cities')->insert([
			'id' => 2191, 
			'name' => 'Queluzito',
			'state' => 11,
		]);
		DB::table('cities')->insert([
			'id' => 2192, 
			'name' => 'Raposos',
			'state' => 11,
		]);
		DB::table('cities')->insert([
			'id' => 2193, 
			'name' => 'Raul Soares',
			'state' => 11,
		]);
		DB::table('cities')->insert([
			'id' => 2194, 
			'name' => 'Recreio',
			'state' => 11,
		]);
		DB::table('cities')->insert([
			'id' => 2195, 
			'name' => 'Reduto',
			'state' => 11,
		]);
		DB::table('cities')->insert([
			'id' => 2196, 
			'name' => 'Resende Costa',
			'state' => 11,
		]);
		DB::table('cities')->insert([
			'id' => 2197, 
			'name' => 'Resplendor',
			'state' => 11,
		]);
		DB::table('cities')->insert([
			'id' => 2198, 
			'name' => 'Ressaquinha',
			'state' => 11,
		]);
		DB::table('cities')->insert([
			'id' => 2199, 
			'name' => 'Riachinho',
			'state' => 11,
		]);
		DB::table('cities')->insert([
			'id' => 2200, 
			'name' => 'Riacho dos Machados',
			'state' => 11,
		]);
		DB::table('cities')->insert([
			'id' => 2201, 
			'name' => 'Ribeirão das Neves',
			'state' => 11,
		]);
		DB::table('cities')->insert([
			'id' => 2202, 
			'name' => 'Ribeirão Vermelho',
			'state' => 11,
		]);
		DB::table('cities')->insert([
			'id' => 2203, 
			'name' => 'Rio Acima',
			'state' => 11,
		]);
		DB::table('cities')->insert([
			'id' => 2204, 
			'name' => 'Rio Casca',
			'state' => 11,
		]);
		DB::table('cities')->insert([
			'id' => 2205, 
			'name' => 'Rio do Prado',
			'state' => 11,
		]);
		DB::table('cities')->insert([
			'id' => 2206, 
			'name' => 'Rio Doce',
			'state' => 11,
		]);
		DB::table('cities')->insert([
			'id' => 2207, 
			'name' => 'Rio Espera',
			'state' => 11,
		]);
		DB::table('cities')->insert([
			'id' => 2208, 
			'name' => 'Rio Manso',
			'state' => 11,
		]);
		DB::table('cities')->insert([
			'id' => 2209, 
			'name' => 'Rio Novo',
			'state' => 11,
		]);
		DB::table('cities')->insert([
			'id' => 2210, 
			'name' => 'Rio Paranaíba',
			'state' => 11,
		]);
		DB::table('cities')->insert([
			'id' => 2211, 
			'name' => 'Rio Pardo de Minas',
			'state' => 11,
		]);
		DB::table('cities')->insert([
			'id' => 2212, 
			'name' => 'Rio Piracicaba',
			'state' => 11,
		]);
		DB::table('cities')->insert([
			'id' => 2213, 
			'name' => 'Rio Pomba',
			'state' => 11,
		]);
		DB::table('cities')->insert([
			'id' => 2214, 
			'name' => 'Rio Preto',
			'state' => 11,
		]);
		DB::table('cities')->insert([
			'id' => 2215, 
			'name' => 'Rio Vermelho',
			'state' => 11,
		]);
		DB::table('cities')->insert([
			'id' => 2216, 
			'name' => 'Ritápolis',
			'state' => 11,
		]);
		DB::table('cities')->insert([
			'id' => 2217, 
			'name' => 'Rochedo de Minas',
			'state' => 11,
		]);
		DB::table('cities')->insert([
			'id' => 2218, 
			'name' => 'Rodeiro',
			'state' => 11,
		]);
		DB::table('cities')->insert([
			'id' => 2219, 
			'name' => 'Romaria',
			'state' => 11,
		]);
		DB::table('cities')->insert([
			'id' => 2220, 
			'name' => 'Rosário da Limeira',
			'state' => 11,
		]);
		DB::table('cities')->insert([
			'id' => 2221, 
			'name' => 'Rubelita',
			'state' => 11,
		]);
		DB::table('cities')->insert([
			'id' => 2222, 
			'name' => 'Rubim',
			'state' => 11,
		]);
		DB::table('cities')->insert([
			'id' => 2223, 
			'name' => 'Sabará',
			'state' => 11,
		]);
		DB::table('cities')->insert([
			'id' => 2224, 
			'name' => 'Sabinópolis',
			'state' => 11,
		]);
		DB::table('cities')->insert([
			'id' => 2225, 
			'name' => 'Sacramento',
			'state' => 11,
		]);
		DB::table('cities')->insert([
			'id' => 2226, 
			'name' => 'Salinas',
			'state' => 11,
		]);
		DB::table('cities')->insert([
			'id' => 2227, 
			'name' => 'Salto da Divisa',
			'state' => 11,
		]);
		DB::table('cities')->insert([
			'id' => 2228, 
			'name' => 'Santa Bárbara',
			'state' => 11,
		]);
		DB::table('cities')->insert([
			'id' => 2229, 
			'name' => 'Santa Bárbara do Leste',
			'state' => 11,
		]);
		DB::table('cities')->insert([
			'id' => 2230, 
			'name' => 'Santa Bárbara do Monte Verde',
			'state' => 11,
		]);
		DB::table('cities')->insert([
			'id' => 2231, 
			'name' => 'Santa Bárbara do Tugúrio',
			'state' => 11,
		]);
		DB::table('cities')->insert([
			'id' => 2232, 
			'name' => 'Santa Cruz de Minas',
			'state' => 11,
		]);
		DB::table('cities')->insert([
			'id' => 2233, 
			'name' => 'Santa Cruz de Salinas',
			'state' => 11,
		]);
		DB::table('cities')->insert([
			'id' => 2234, 
			'name' => 'Santa Cruz do Escalvado',
			'state' => 11,
		]);
		DB::table('cities')->insert([
			'id' => 2235, 
			'name' => 'Santa Efigênia de Minas',
			'state' => 11,
		]);
		DB::table('cities')->insert([
			'id' => 2236, 
			'name' => 'Santa Fé de Minas',
			'state' => 11,
		]);
		DB::table('cities')->insert([
			'id' => 2237, 
			'name' => 'Santa Helena de Minas',
			'state' => 11,
		]);
		DB::table('cities')->insert([
			'id' => 2238, 
			'name' => 'Santa Juliana',
			'state' => 11,
		]);
		DB::table('cities')->insert([
			'id' => 2239, 
			'name' => 'Santa Luzia',
			'state' => 11,
		]);
		DB::table('cities')->insert([
			'id' => 2240, 
			'name' => 'Santa Margarida',
			'state' => 11,
		]);
		DB::table('cities')->insert([
			'id' => 2241, 
			'name' => 'Santa Maria de Itabira',
			'state' => 11,
		]);
		DB::table('cities')->insert([
			'id' => 2242, 
			'name' => 'Santa Maria do Salto',
			'state' => 11,
		]);
		DB::table('cities')->insert([
			'id' => 2243, 
			'name' => 'Santa Maria do Suaçuí',
			'state' => 11,
		]);
		DB::table('cities')->insert([
			'id' => 2244, 
			'name' => 'Santa Rita de Caldas',
			'state' => 11,
		]);
		DB::table('cities')->insert([
			'id' => 2245, 
			'name' => 'Santa Rita de Ibitipoca',
			'state' => 11,
		]);
		DB::table('cities')->insert([
			'id' => 2246, 
			'name' => 'Santa Rita de Jacutinga',
			'state' => 11,
		]);
		DB::table('cities')->insert([
			'id' => 2247, 
			'name' => 'Santa Rita de Minas',
			'state' => 11,
		]);
		DB::table('cities')->insert([
			'id' => 2248, 
			'name' => 'Santa Rita do Itueto',
			'state' => 11,
		]);
		DB::table('cities')->insert([
			'id' => 2249, 
			'name' => 'Santa Rita do Sapucaí',
			'state' => 11,
		]);
		DB::table('cities')->insert([
			'id' => 2250, 
			'name' => 'Santa Rosa da Serra',
			'state' => 11,
		]);
		DB::table('cities')->insert([
			'id' => 2251, 
			'name' => 'Santa Vitória',
			'state' => 11,
		]);
		DB::table('cities')->insert([
			'id' => 2252, 
			'name' => 'Santana da Vargem',
			'state' => 11,
		]);
		DB::table('cities')->insert([
			'id' => 2253, 
			'name' => 'Santana de Cataguases',
			'state' => 11,
		]);
		DB::table('cities')->insert([
			'id' => 2254, 
			'name' => 'Santana de Pirapama',
			'state' => 11,
		]);
		DB::table('cities')->insert([
			'id' => 2255, 
			'name' => 'Santana do Deserto',
			'state' => 11,
		]);
		DB::table('cities')->insert([
			'id' => 2256, 
			'name' => 'Santana do Garambéu',
			'state' => 11,
		]);
		DB::table('cities')->insert([
			'id' => 2257, 
			'name' => 'Santana do Jacaré',
			'state' => 11,
		]);
		DB::table('cities')->insert([
			'id' => 2258, 
			'name' => 'Santana do Manhuaçu',
			'state' => 11,
		]);
		DB::table('cities')->insert([
			'id' => 2259, 
			'name' => 'Santana do Paraíso',
			'state' => 11,
		]);
		DB::table('cities')->insert([
			'id' => 2260, 
			'name' => 'Santana do Riacho',
			'state' => 11,
		]);
		DB::table('cities')->insert([
			'id' => 2261, 
			'name' => 'Santana dos Montes',
			'state' => 11,
		]);
		DB::table('cities')->insert([
			'id' => 2262, 
			'name' => 'Santo Antônio do Amparo',
			'state' => 11,
		]);
		DB::table('cities')->insert([
			'id' => 2263, 
			'name' => 'Santo Antônio do Aventureiro',
			'state' => 11,
		]);
		DB::table('cities')->insert([
			'id' => 2264, 
			'name' => 'Santo Antônio do Grama',
			'state' => 11,
		]);
		DB::table('cities')->insert([
			'id' => 2265, 
			'name' => 'Santo Antônio do Itambé',
			'state' => 11,
		]);
		DB::table('cities')->insert([
			'id' => 2266, 
			'name' => 'Santo Antônio do Jacinto',
			'state' => 11,
		]);
		DB::table('cities')->insert([
			'id' => 2267, 
			'name' => 'Santo Antônio do Monte',
			'state' => 11,
		]);
		DB::table('cities')->insert([
			'id' => 2268, 
			'name' => 'Santo Antônio do Retiro',
			'state' => 11,
		]);
		DB::table('cities')->insert([
			'id' => 2269, 
			'name' => 'Santo Antônio do Rio Abaixo',
			'state' => 11,
		]);
		DB::table('cities')->insert([
			'id' => 2270, 
			'name' => 'Santo Hipólito',
			'state' => 11,
		]);
		DB::table('cities')->insert([
			'id' => 2271, 
			'name' => 'Santos Dumont',
			'state' => 11,
		]);
		DB::table('cities')->insert([
			'id' => 2272, 
			'name' => 'São Bento Abade',
			'state' => 11,
		]);
		DB::table('cities')->insert([
			'id' => 2273, 
			'name' => 'São Brás do Suaçuí',
			'state' => 11,
		]);
		DB::table('cities')->insert([
			'id' => 2274, 
			'name' => 'São Domingos das Dores',
			'state' => 11,
		]);
		DB::table('cities')->insert([
			'id' => 2275, 
			'name' => 'São Domingos do Prata',
			'state' => 11,
		]);
		DB::table('cities')->insert([
			'id' => 2276, 
			'name' => 'São Félix de Minas',
			'state' => 11,
		]);
		DB::table('cities')->insert([
			'id' => 2277, 
			'name' => 'São Francisco',
			'state' => 11,
		]);
		DB::table('cities')->insert([
			'id' => 2278, 
			'name' => 'São Francisco de Paula',
			'state' => 11,
		]);
		DB::table('cities')->insert([
			'id' => 2279, 
			'name' => 'São Francisco de Sales',
			'state' => 11,
		]);
		DB::table('cities')->insert([
			'id' => 2280, 
			'name' => 'São Francisco do Glória',
			'state' => 11,
		]);
		DB::table('cities')->insert([
			'id' => 2281, 
			'name' => 'São Geraldo',
			'state' => 11,
		]);
		DB::table('cities')->insert([
			'id' => 2282, 
			'name' => 'São Geraldo da Piedade',
			'state' => 11,
		]);
		DB::table('cities')->insert([
			'id' => 2283, 
			'name' => 'São Geraldo do Baixio',
			'state' => 11,
		]);
		DB::table('cities')->insert([
			'id' => 2284, 
			'name' => 'São Gonçalo do Abaeté',
			'state' => 11,
		]);
		DB::table('cities')->insert([
			'id' => 2285, 
			'name' => 'São Gonçalo do Pará',
			'state' => 11,
		]);
		DB::table('cities')->insert([
			'id' => 2286, 
			'name' => 'São Gonçalo do Rio Abaixo',
			'state' => 11,
		]);
		DB::table('cities')->insert([
			'id' => 2287, 
			'name' => 'São Gonçalo do Rio Preto',
			'state' => 11,
		]);
		DB::table('cities')->insert([
			'id' => 2288, 
			'name' => 'São Gonçalo do Sapucaí',
			'state' => 11,
		]);
		DB::table('cities')->insert([
			'id' => 2289, 
			'name' => 'São Gotardo',
			'state' => 11,
		]);
		DB::table('cities')->insert([
			'id' => 2290, 
			'name' => 'São João Batista do Glória',
			'state' => 11,
		]);
		DB::table('cities')->insert([
			'id' => 2291, 
			'name' => 'São João da Lagoa',
			'state' => 11,
		]);
		DB::table('cities')->insert([
			'id' => 2292, 
			'name' => 'São João da Mata',
			'state' => 11,
		]);
		DB::table('cities')->insert([
			'id' => 2293, 
			'name' => 'São João da Ponte',
			'state' => 11,
		]);
		DB::table('cities')->insert([
			'id' => 2294, 
			'name' => 'São João das Missões',
			'state' => 11,
		]);
		DB::table('cities')->insert([
			'id' => 2295, 
			'name' => 'São João del Rei',
			'state' => 11,
		]);
		DB::table('cities')->insert([
			'id' => 2296, 
			'name' => 'São João do Manhuaçu',
			'state' => 11,
		]);
		DB::table('cities')->insert([
			'id' => 2297, 
			'name' => 'São João do Manteninha',
			'state' => 11,
		]);
		DB::table('cities')->insert([
			'id' => 2298, 
			'name' => 'São João do Oriente',
			'state' => 11,
		]);
		DB::table('cities')->insert([
			'id' => 2299, 
			'name' => 'São João do Pacuí',
			'state' => 11,
		]);
		DB::table('cities')->insert([
			'id' => 2300, 
			'name' => 'São João do Paraíso',
			'state' => 11,
		]);
		DB::table('cities')->insert([
			'id' => 2301, 
			'name' => 'São João Evangelista',
			'state' => 11,
		]);
		DB::table('cities')->insert([
			'id' => 2302, 
			'name' => 'São João Nepomuceno',
			'state' => 11,
		]);
		DB::table('cities')->insert([
			'id' => 2303, 
			'name' => 'São Joaquim de Bicas',
			'state' => 11,
		]);
		DB::table('cities')->insert([
			'id' => 2304, 
			'name' => 'São José da Barra',
			'state' => 11,
		]);
		DB::table('cities')->insert([
			'id' => 2305, 
			'name' => 'São José da Lapa',
			'state' => 11,
		]);
		DB::table('cities')->insert([
			'id' => 2306, 
			'name' => 'São José da Safira',
			'state' => 11,
		]);
		DB::table('cities')->insert([
			'id' => 2307, 
			'name' => 'São José da Varginha',
			'state' => 11,
		]);
		DB::table('cities')->insert([
			'id' => 2308, 
			'name' => 'São José do Alegre',
			'state' => 11,
		]);
		DB::table('cities')->insert([
			'id' => 2309, 
			'name' => 'São José do Divino',
			'state' => 11,
		]);
		DB::table('cities')->insert([
			'id' => 2310, 
			'name' => 'São José do Goiabal',
			'state' => 11,
		]);
		DB::table('cities')->insert([
			'id' => 2311, 
			'name' => 'São José do Jacuri',
			'state' => 11,
		]);
		DB::table('cities')->insert([
			'id' => 2312, 
			'name' => 'São José do Mantimento',
			'state' => 11,
		]);
		DB::table('cities')->insert([
			'id' => 2313, 
			'name' => 'São Lourenço',
			'state' => 11,
		]);
		DB::table('cities')->insert([
			'id' => 2314, 
			'name' => 'São Miguel do Anta',
			'state' => 11,
		]);
		DB::table('cities')->insert([
			'id' => 2315, 
			'name' => 'São Pedro da União',
			'state' => 11,
		]);
		DB::table('cities')->insert([
			'id' => 2316, 
			'name' => 'São Pedro do Suaçuí',
			'state' => 11,
		]);
		DB::table('cities')->insert([
			'id' => 2317, 
			'name' => 'São Pedro dos Ferros',
			'state' => 11,
		]);
		DB::table('cities')->insert([
			'id' => 2318, 
			'name' => 'São Romão',
			'state' => 11,
		]);
		DB::table('cities')->insert([
			'id' => 2319, 
			'name' => 'São Roque de Minas',
			'state' => 11,
		]);
		DB::table('cities')->insert([
			'id' => 2320, 
			'name' => 'São Sebastião da Bela Vista',
			'state' => 11,
		]);
		DB::table('cities')->insert([
			'id' => 2321, 
			'name' => 'São Sebastião da Vargem Alegre',
			'state' => 11,
		]);
		DB::table('cities')->insert([
			'id' => 2322, 
			'name' => 'São Sebastião do Anta',
			'state' => 11,
		]);
		DB::table('cities')->insert([
			'id' => 2323, 
			'name' => 'São Sebastião do Maranhão',
			'state' => 11,
		]);
		DB::table('cities')->insert([
			'id' => 2324, 
			'name' => 'São Sebastião do Oeste',
			'state' => 11,
		]);
		DB::table('cities')->insert([
			'id' => 2325, 
			'name' => 'São Sebastião do Paraíso',
			'state' => 11,
		]);
		DB::table('cities')->insert([
			'id' => 2326, 
			'name' => 'São Sebastião do Rio Preto',
			'state' => 11,
		]);
		DB::table('cities')->insert([
			'id' => 2327, 
			'name' => 'São Sebastião do Rio Verde',
			'state' => 11,
		]);
		DB::table('cities')->insert([
			'id' => 2328, 
			'name' => 'São Thomé das Letras',
			'state' => 11,
		]);
		DB::table('cities')->insert([
			'id' => 2329, 
			'name' => 'São Tiago',
			'state' => 11,
		]);
		DB::table('cities')->insert([
			'id' => 2330, 
			'name' => 'São Tomás de Aquino',
			'state' => 11,
		]);
		DB::table('cities')->insert([
			'id' => 2331, 
			'name' => 'São Vicente de Minas',
			'state' => 11,
		]);
		DB::table('cities')->insert([
			'id' => 2332, 
			'name' => 'Sapucaí-Mirim',
			'state' => 11,
		]);
		DB::table('cities')->insert([
			'id' => 2333, 
			'name' => 'Sardoá',
			'state' => 11,
		]);
		DB::table('cities')->insert([
			'id' => 2334, 
			'name' => 'Sarzedo',
			'state' => 11,
		]);
		DB::table('cities')->insert([
			'id' => 2335, 
			'name' => 'Sem-Peixe',
			'state' => 11,
		]);
		DB::table('cities')->insert([
			'id' => 2336, 
			'name' => 'Senador Amaral',
			'state' => 11,
		]);
		DB::table('cities')->insert([
			'id' => 2337, 
			'name' => 'Senador Cortes',
			'state' => 11,
		]);
		DB::table('cities')->insert([
			'id' => 2338, 
			'name' => 'Senador Firmino',
			'state' => 11,
		]);
		DB::table('cities')->insert([
			'id' => 2339, 
			'name' => 'Senador José Bento',
			'state' => 11,
		]);
		DB::table('cities')->insert([
			'id' => 2340, 
			'name' => 'Senador Modestino Gonçalves',
			'state' => 11,
		]);
		DB::table('cities')->insert([
			'id' => 2341, 
			'name' => 'Senhora de Oliveira',
			'state' => 11,
		]);
		DB::table('cities')->insert([
			'id' => 2342, 
			'name' => 'Senhora do Porto',
			'state' => 11,
		]);
		DB::table('cities')->insert([
			'id' => 2343, 
			'name' => 'Senhora dos Remédios',
			'state' => 11,
		]);
		DB::table('cities')->insert([
			'id' => 2344, 
			'name' => 'Sericita',
			'state' => 11,
		]);
		DB::table('cities')->insert([
			'id' => 2345, 
			'name' => 'Seritinga',
			'state' => 11,
		]);
		DB::table('cities')->insert([
			'id' => 2346, 
			'name' => 'Serra Azul de Minas',
			'state' => 11,
		]);
		DB::table('cities')->insert([
			'id' => 2347, 
			'name' => 'Serra da Saudade',
			'state' => 11,
		]);
		DB::table('cities')->insert([
			'id' => 2348, 
			'name' => 'Serra do Salitre',
			'state' => 11,
		]);
		DB::table('cities')->insert([
			'id' => 2349, 
			'name' => 'Serra dos Aimorés',
			'state' => 11,
		]);
		DB::table('cities')->insert([
			'id' => 2350, 
			'name' => 'Serrania',
			'state' => 11,
		]);
		DB::table('cities')->insert([
			'id' => 2351, 
			'name' => 'Serranópolis de Minas',
			'state' => 11,
		]);
		DB::table('cities')->insert([
			'id' => 2352, 
			'name' => 'Serranos',
			'state' => 11,
		]);
		DB::table('cities')->insert([
			'id' => 2353, 
			'name' => 'Serro',
			'state' => 11,
		]);
		DB::table('cities')->insert([
			'id' => 2354, 
			'name' => 'Sete Lagoas',
			'state' => 11,
		]);
		DB::table('cities')->insert([
			'id' => 2355, 
			'name' => 'Setubinha',
			'state' => 11,
		]);
		DB::table('cities')->insert([
			'id' => 2356, 
			'name' => 'Silveirânia',
			'state' => 11,
		]);
		DB::table('cities')->insert([
			'id' => 2357, 
			'name' => 'Silvianópolis',
			'state' => 11,
		]);
		DB::table('cities')->insert([
			'id' => 2358, 
			'name' => 'Simão Pereira',
			'state' => 11,
		]);
		DB::table('cities')->insert([
			'id' => 2359, 
			'name' => 'Simonésia',
			'state' => 11,
		]);
		DB::table('cities')->insert([
			'id' => 2360, 
			'name' => 'Sobrália',
			'state' => 11,
		]);
		DB::table('cities')->insert([
			'id' => 2361, 
			'name' => 'Soledade de Minas',
			'state' => 11,
		]);
		DB::table('cities')->insert([
			'id' => 2362, 
			'name' => 'Tabuleiro',
			'state' => 11,
		]);
		DB::table('cities')->insert([
			'id' => 2363, 
			'name' => 'Taiobeiras',
			'state' => 11,
		]);
		DB::table('cities')->insert([
			'id' => 2364, 
			'name' => 'Taparuba',
			'state' => 11,
		]);
		DB::table('cities')->insert([
			'id' => 2365, 
			'name' => 'Tapira',
			'state' => 11,
		]);
		DB::table('cities')->insert([
			'id' => 2366, 
			'name' => 'Tapiraí',
			'state' => 11,
		]);
		DB::table('cities')->insert([
			'id' => 2367, 
			'name' => 'Taquaraçu de Minas',
			'state' => 11,
		]);
		DB::table('cities')->insert([
			'id' => 2368, 
			'name' => 'Tarumirim',
			'state' => 11,
		]);
		DB::table('cities')->insert([
			'id' => 2369, 
			'name' => 'Teixeiras',
			'state' => 11,
		]);
		DB::table('cities')->insert([
			'id' => 2370, 
			'name' => 'Teófilo Otoni',
			'state' => 11,
		]);
		DB::table('cities')->insert([
			'id' => 2371, 
			'name' => 'Timóteo',
			'state' => 11,
		]);
		DB::table('cities')->insert([
			'id' => 2372, 
			'name' => 'Tiradentes',
			'state' => 11,
		]);
		DB::table('cities')->insert([
			'id' => 2373, 
			'name' => 'Tiros',
			'state' => 11,
		]);
		DB::table('cities')->insert([
			'id' => 2374, 
			'name' => 'Tocantins',
			'state' => 11,
		]);
		DB::table('cities')->insert([
			'id' => 2375, 
			'name' => 'Tocos do Moji',
			'state' => 11,
		]);
		DB::table('cities')->insert([
			'id' => 2376, 
			'name' => 'Toledo',
			'state' => 11,
		]);
		DB::table('cities')->insert([
			'id' => 2377, 
			'name' => 'Tombos',
			'state' => 11,
		]);
		DB::table('cities')->insert([
			'id' => 2378, 
			'name' => 'Três Corações',
			'state' => 11,
		]);
		DB::table('cities')->insert([
			'id' => 2379, 
			'name' => 'Três Marias',
			'state' => 11,
		]);
		DB::table('cities')->insert([
			'id' => 2380, 
			'name' => 'Três Pontas',
			'state' => 11,
		]);
		DB::table('cities')->insert([
			'id' => 2381, 
			'name' => 'Tumiritinga',
			'state' => 11,
		]);
		DB::table('cities')->insert([
			'id' => 2382, 
			'name' => 'Tupaciguara',
			'state' => 11,
		]);
		DB::table('cities')->insert([
			'id' => 2383, 
			'name' => 'Turmalina',
			'state' => 11,
		]);
		DB::table('cities')->insert([
			'id' => 2384, 
			'name' => 'Turvolândia',
			'state' => 11,
		]);
		DB::table('cities')->insert([
			'id' => 2385, 
			'name' => 'Ubá',
			'state' => 11,
		]);
		DB::table('cities')->insert([
			'id' => 2386, 
			'name' => 'Ubaí',
			'state' => 11,
		]);
		DB::table('cities')->insert([
			'id' => 2387, 
			'name' => 'Ubaporanga',
			'state' => 11,
		]);
		DB::table('cities')->insert([
			'id' => 2388, 
			'name' => 'Uberaba',
			'state' => 11,
		]);
		DB::table('cities')->insert([
			'id' => 2389, 
			'name' => 'Uberlândia',
			'state' => 11,
		]);
		DB::table('cities')->insert([
			'id' => 2390, 
			'name' => 'Umburatiba',
			'state' => 11,
		]);
		DB::table('cities')->insert([
			'id' => 2391, 
			'name' => 'Unaí',
			'state' => 11,
		]);
		DB::table('cities')->insert([
			'id' => 2392, 
			'name' => 'União de Minas',
			'state' => 11,
		]);
		DB::table('cities')->insert([
			'id' => 2393, 
			'name' => 'Uruana de Minas',
			'state' => 11,
		]);
		DB::table('cities')->insert([
			'id' => 2394, 
			'name' => 'Urucânia',
			'state' => 11,
		]);
		DB::table('cities')->insert([
			'id' => 2395, 
			'name' => 'Urucuia',
			'state' => 11,
		]);
		DB::table('cities')->insert([
			'id' => 2396, 
			'name' => 'Vargem Alegre',
			'state' => 11,
		]);
		DB::table('cities')->insert([
			'id' => 2397, 
			'name' => 'Vargem Bonita',
			'state' => 11,
		]);
		DB::table('cities')->insert([
			'id' => 2398, 
			'name' => 'Vargem Grande do Rio Pardo',
			'state' => 11,
		]);
		DB::table('cities')->insert([
			'id' => 2399, 
			'name' => 'Varginha',
			'state' => 11,
		]);
		DB::table('cities')->insert([
			'id' => 2400, 
			'name' => 'Varjão de Minas',
			'state' => 11,
		]);
		DB::table('cities')->insert([
			'id' => 2401, 
			'name' => 'Várzea da Palma',
			'state' => 11,
		]);
		DB::table('cities')->insert([
			'id' => 2402, 
			'name' => 'Varzelândia',
			'state' => 11,
		]);
		DB::table('cities')->insert([
			'id' => 2403, 
			'name' => 'Vazante',
			'state' => 11,
		]);
		DB::table('cities')->insert([
			'id' => 2404, 
			'name' => 'Verdelândia',
			'state' => 11,
		]);
		DB::table('cities')->insert([
			'id' => 2405, 
			'name' => 'Veredinha',
			'state' => 11,
		]);
		DB::table('cities')->insert([
			'id' => 2406, 
			'name' => 'Veríssimo',
			'state' => 11,
		]);
		DB::table('cities')->insert([
			'id' => 2407, 
			'name' => 'Vermelho Novo',
			'state' => 11,
		]);
		DB::table('cities')->insert([
			'id' => 2408, 
			'name' => 'Vespasiano',
			'state' => 11,
		]);
		DB::table('cities')->insert([
			'id' => 2409, 
			'name' => 'Viçosa',
			'state' => 11,
		]);
		DB::table('cities')->insert([
			'id' => 2410, 
			'name' => 'Vieiras',
			'state' => 11,
		]);
		DB::table('cities')->insert([
			'id' => 2411, 
			'name' => 'Virgem da Lapa',
			'state' => 11,
		]);
		DB::table('cities')->insert([
			'id' => 2412, 
			'name' => 'Virgínia',
			'state' => 11,
		]);
		DB::table('cities')->insert([
			'id' => 2413, 
			'name' => 'Virginópolis',
			'state' => 11,
		]);
		DB::table('cities')->insert([
			'id' => 2414, 
			'name' => 'Virgolândia',
			'state' => 11,
		]);
		DB::table('cities')->insert([
			'id' => 2415, 
			'name' => 'Visconde do Rio Branco',
			'state' => 11,
		]);
		DB::table('cities')->insert([
			'id' => 2416, 
			'name' => 'Volta Grande',
			'state' => 11,
		]);
		DB::table('cities')->insert([
			'id' => 2417, 
			'name' => 'Wenceslau Braz',
			'state' => 11,
		]);
		DB::table('cities')->insert([
			'id' => 2418, 
			'name' => 'Abaetetuba',
			'state' => 14,
		]);
		DB::table('cities')->insert([
			'id' => 2419, 
			'name' => 'Abel Figueiredo',
			'state' => 14,
		]);
		DB::table('cities')->insert([
			'id' => 2420, 
			'name' => 'Acará',
			'state' => 14,
		]);
		DB::table('cities')->insert([
			'id' => 2421, 
			'name' => 'Afuá',
			'state' => 14,
		]);
		DB::table('cities')->insert([
			'id' => 2422, 
			'name' => 'Água Azul do Norte',
			'state' => 14,
		]);
		DB::table('cities')->insert([
			'id' => 2423, 
			'name' => 'Alenquer',
			'state' => 14,
		]);
		DB::table('cities')->insert([
			'id' => 2424, 
			'name' => 'Almeirim',
			'state' => 14,
		]);
		DB::table('cities')->insert([
			'id' => 2425, 
			'name' => 'Altamira',
			'state' => 14,
		]);
		DB::table('cities')->insert([
			'id' => 2426, 
			'name' => 'Anajás',
			'state' => 14,
		]);
		DB::table('cities')->insert([
			'id' => 2427, 
			'name' => 'Ananindeua',
			'state' => 14,
		]);
		DB::table('cities')->insert([
			'id' => 2428, 
			'name' => 'Anapu',
			'state' => 14,
		]);
		DB::table('cities')->insert([
			'id' => 2429, 
			'name' => 'Augusto Corrêa',
			'state' => 14,
		]);
		DB::table('cities')->insert([
			'id' => 2430, 
			'name' => 'Aurora do Pará',
			'state' => 14,
		]);
		DB::table('cities')->insert([
			'id' => 2431, 
			'name' => 'Aveiro',
			'state' => 14,
		]);
		DB::table('cities')->insert([
			'id' => 2432, 
			'name' => 'Bagre',
			'state' => 14,
		]);
		DB::table('cities')->insert([
			'id' => 2433, 
			'name' => 'Baião',
			'state' => 14,
		]);
		DB::table('cities')->insert([
			'id' => 2434, 
			'name' => 'Bannach',
			'state' => 14,
		]);
		DB::table('cities')->insert([
			'id' => 2435, 
			'name' => 'Barcarena',
			'state' => 14,
		]);
		DB::table('cities')->insert([
			'id' => 2436, 
			'name' => 'Belém',
			'state' => 14,
		]);
		DB::table('cities')->insert([
			'id' => 2437, 
			'name' => 'Belterra',
			'state' => 14,
		]);
		DB::table('cities')->insert([
			'id' => 2438, 
			'name' => 'Benevides',
			'state' => 14,
		]);
		DB::table('cities')->insert([
			'id' => 2439, 
			'name' => 'Bom Jesus do Tocantins',
			'state' => 14,
		]);
		DB::table('cities')->insert([
			'id' => 2440, 
			'name' => 'Bonito',
			'state' => 14,
		]);
		DB::table('cities')->insert([
			'id' => 2441, 
			'name' => 'Bragança',
			'state' => 14,
		]);
		DB::table('cities')->insert([
			'id' => 2442, 
			'name' => 'Brasil Novo',
			'state' => 14,
		]);
		DB::table('cities')->insert([
			'id' => 2443, 
			'name' => 'Brejo Grande do Araguaia',
			'state' => 14,
		]);
		DB::table('cities')->insert([
			'id' => 2444, 
			'name' => 'Breu Branco',
			'state' => 14,
		]);
		DB::table('cities')->insert([
			'id' => 2445, 
			'name' => 'Breves',
			'state' => 14,
		]);
		DB::table('cities')->insert([
			'id' => 2446, 
			'name' => 'Bujaru',
			'state' => 14,
		]);
		DB::table('cities')->insert([
			'id' => 2447, 
			'name' => 'Cachoeira do Arari',
			'state' => 14,
		]);
		DB::table('cities')->insert([
			'id' => 2448, 
			'name' => 'Cachoeira do Piriá',
			'state' => 14,
		]);
		DB::table('cities')->insert([
			'id' => 2449, 
			'name' => 'Cametá',
			'state' => 14,
		]);
		DB::table('cities')->insert([
			'id' => 2450, 
			'name' => 'Canaã dos Carajás',
			'state' => 14,
		]);
		DB::table('cities')->insert([
			'id' => 2451, 
			'name' => 'Capanema',
			'state' => 14,
		]);
		DB::table('cities')->insert([
			'id' => 2452, 
			'name' => 'Capitão Poço',
			'state' => 14,
		]);
		DB::table('cities')->insert([
			'id' => 2453, 
			'name' => 'Castanhal',
			'state' => 14,
		]);
		DB::table('cities')->insert([
			'id' => 2454, 
			'name' => 'Chaves',
			'state' => 14,
		]);
		DB::table('cities')->insert([
			'id' => 2455, 
			'name' => 'Colares',
			'state' => 14,
		]);
		DB::table('cities')->insert([
			'id' => 2456, 
			'name' => 'Conceição do Araguaia',
			'state' => 14,
		]);
		DB::table('cities')->insert([
			'id' => 2457, 
			'name' => 'Concórdia do Pará',
			'state' => 14,
		]);
		DB::table('cities')->insert([
			'id' => 2458, 
			'name' => 'Cumaru do Norte',
			'state' => 14,
		]);
		DB::table('cities')->insert([
			'id' => 2459, 
			'name' => 'Curionópolis',
			'state' => 14,
		]);
		DB::table('cities')->insert([
			'id' => 2460, 
			'name' => 'Curralinho',
			'state' => 14,
		]);
		DB::table('cities')->insert([
			'id' => 2461, 
			'name' => 'Curuá',
			'state' => 14,
		]);
		DB::table('cities')->insert([
			'id' => 2462, 
			'name' => 'Curuçá',
			'state' => 14,
		]);
		DB::table('cities')->insert([
			'id' => 2463, 
			'name' => 'Dom Eliseu',
			'state' => 14,
		]);
		DB::table('cities')->insert([
			'id' => 2464, 
			'name' => 'Eldorado dos Carajás',
			'state' => 14,
		]);
		DB::table('cities')->insert([
			'id' => 2465, 
			'name' => 'Faro',
			'state' => 14,
		]);
		DB::table('cities')->insert([
			'id' => 2466, 
			'name' => 'Floresta do Araguaia',
			'state' => 14,
		]);
		DB::table('cities')->insert([
			'id' => 2467, 
			'name' => 'Garrafão do Norte',
			'state' => 14,
		]);
		DB::table('cities')->insert([
			'id' => 2468, 
			'name' => 'Goianésia do Pará',
			'state' => 14,
		]);
		DB::table('cities')->insert([
			'id' => 2469, 
			'name' => 'Gurupá',
			'state' => 14,
		]);
		DB::table('cities')->insert([
			'id' => 2470, 
			'name' => 'Igarapé-Açu',
			'state' => 14,
		]);
		DB::table('cities')->insert([
			'id' => 2471, 
			'name' => 'Igarapé-Miri',
			'state' => 14,
		]);
		DB::table('cities')->insert([
			'id' => 2472, 
			'name' => 'Inhangapi',
			'state' => 14,
		]);
		DB::table('cities')->insert([
			'id' => 2473, 
			'name' => 'Ipixuna do Pará',
			'state' => 14,
		]);
		DB::table('cities')->insert([
			'id' => 2474, 
			'name' => 'Irituia',
			'state' => 14,
		]);
		DB::table('cities')->insert([
			'id' => 2475, 
			'name' => 'Itaituba',
			'state' => 14,
		]);
		DB::table('cities')->insert([
			'id' => 2476, 
			'name' => 'Itupiranga',
			'state' => 14,
		]);
		DB::table('cities')->insert([
			'id' => 2477, 
			'name' => 'Jacareacanga',
			'state' => 14,
		]);
		DB::table('cities')->insert([
			'id' => 2478, 
			'name' => 'Jacundá',
			'state' => 14,
		]);
		DB::table('cities')->insert([
			'id' => 2479, 
			'name' => 'Juruti',
			'state' => 14,
		]);
		DB::table('cities')->insert([
			'id' => 2480, 
			'name' => 'Limoeiro do Ajuru',
			'state' => 14,
		]);
		DB::table('cities')->insert([
			'id' => 2481, 
			'name' => 'Mãe do Rio',
			'state' => 14,
		]);
		DB::table('cities')->insert([
			'id' => 2482, 
			'name' => 'Magalhães Barata',
			'state' => 14,
		]);
		DB::table('cities')->insert([
			'id' => 2483, 
			'name' => 'Marabá',
			'state' => 14,
		]);
		DB::table('cities')->insert([
			'id' => 2484, 
			'name' => 'Maracanã',
			'state' => 14,
		]);
		DB::table('cities')->insert([
			'id' => 2485, 
			'name' => 'Marapanim',
			'state' => 14,
		]);
		DB::table('cities')->insert([
			'id' => 2486, 
			'name' => 'Marituba',
			'state' => 14,
		]);
		DB::table('cities')->insert([
			'id' => 2487, 
			'name' => 'Medicilândia',
			'state' => 14,
		]);
		DB::table('cities')->insert([
			'id' => 2488, 
			'name' => 'Melgaço',
			'state' => 14,
		]);
		DB::table('cities')->insert([
			'id' => 2489, 
			'name' => 'Mocajuba',
			'state' => 14,
		]);
		DB::table('cities')->insert([
			'id' => 2490, 
			'name' => 'Moju',
			'state' => 14,
		]);
		DB::table('cities')->insert([
			'id' => 2491, 
			'name' => 'Monte Alegre',
			'state' => 14,
		]);
		DB::table('cities')->insert([
			'id' => 2492, 
			'name' => 'Muaná',
			'state' => 14,
		]);
		DB::table('cities')->insert([
			'id' => 2493, 
			'name' => 'Nova Esperança do Piriá',
			'state' => 14,
		]);
		DB::table('cities')->insert([
			'id' => 2494, 
			'name' => 'Nova Ipixuna',
			'state' => 14,
		]);
		DB::table('cities')->insert([
			'id' => 2495, 
			'name' => 'Nova Timboteua',
			'state' => 14,
		]);
		DB::table('cities')->insert([
			'id' => 2496, 
			'name' => 'Novo Progresso',
			'state' => 14,
		]);
		DB::table('cities')->insert([
			'id' => 2497, 
			'name' => 'Novo Repartimento',
			'state' => 14,
		]);
		DB::table('cities')->insert([
			'id' => 2498, 
			'name' => 'Óbidos',
			'state' => 14,
		]);
		DB::table('cities')->insert([
			'id' => 2499, 
			'name' => 'Oeiras do Pará',
			'state' => 14,
		]);
		DB::table('cities')->insert([
			'id' => 2500, 
			'name' => 'Oriximiná',
			'state' => 14,
		]);
		DB::table('cities')->insert([
			'id' => 2501, 
			'name' => 'Ourém',
			'state' => 14,
		]);
		DB::table('cities')->insert([
			'id' => 2502, 
			'name' => 'Ourilândia do Norte',
			'state' => 14,
		]);
		DB::table('cities')->insert([
			'id' => 2503, 
			'name' => 'Pacajá',
			'state' => 14,
		]);
		DB::table('cities')->insert([
			'id' => 2504, 
			'name' => 'Palestina do Pará',
			'state' => 14,
		]);
		DB::table('cities')->insert([
			'id' => 2505, 
			'name' => 'Paragominas',
			'state' => 14,
		]);
		DB::table('cities')->insert([
			'id' => 2506, 
			'name' => 'Parauapebas',
			'state' => 14,
		]);
		DB::table('cities')->insert([
			'id' => 2507, 
			'name' => 'Pau d`Arco',
			'state' => 14,
		]);
		DB::table('cities')->insert([
			'id' => 2508, 
			'name' => 'Peixe-Boi',
			'state' => 14,
		]);
		DB::table('cities')->insert([
			'id' => 2509, 
			'name' => 'Piçarra',
			'state' => 14,
		]);
		DB::table('cities')->insert([
			'id' => 2510, 
			'name' => 'Placas',
			'state' => 14,
		]);
		DB::table('cities')->insert([
			'id' => 2511, 
			'name' => 'Ponta de Pedras',
			'state' => 14,
		]);
		DB::table('cities')->insert([
			'id' => 2512, 
			'name' => 'Portel',
			'state' => 14,
		]);
		DB::table('cities')->insert([
			'id' => 2513, 
			'name' => 'Porto de Moz',
			'state' => 14,
		]);
		DB::table('cities')->insert([
			'id' => 2514, 
			'name' => 'Prainha',
			'state' => 14,
		]);
		DB::table('cities')->insert([
			'id' => 2515, 
			'name' => 'Primavera',
			'state' => 14,
		]);
		DB::table('cities')->insert([
			'id' => 2516, 
			'name' => 'Quatipuru',
			'state' => 14,
		]);
		DB::table('cities')->insert([
			'id' => 2517, 
			'name' => 'Redenção',
			'state' => 14,
		]);
		DB::table('cities')->insert([
			'id' => 2518, 
			'name' => 'Rio Maria',
			'state' => 14,
		]);
		DB::table('cities')->insert([
			'id' => 2519, 
			'name' => 'Rondon do Pará',
			'state' => 14,
		]);
		DB::table('cities')->insert([
			'id' => 2520, 
			'name' => 'Rurópolis',
			'state' => 14,
		]);
		DB::table('cities')->insert([
			'id' => 2521, 
			'name' => 'Salinópolis',
			'state' => 14,
		]);
		DB::table('cities')->insert([
			'id' => 2522, 
			'name' => 'Salvaterra',
			'state' => 14,
		]);
		DB::table('cities')->insert([
			'id' => 2523, 
			'name' => 'Santa Bárbara do Pará',
			'state' => 14,
		]);
		DB::table('cities')->insert([
			'id' => 2524, 
			'name' => 'Santa Cruz do Arari',
			'state' => 14,
		]);
		DB::table('cities')->insert([
			'id' => 2525, 
			'name' => 'Santa Isabel do Pará',
			'state' => 14,
		]);
		DB::table('cities')->insert([
			'id' => 2526, 
			'name' => 'Santa Luzia do Pará',
			'state' => 14,
		]);
		DB::table('cities')->insert([
			'id' => 2527, 
			'name' => 'Santa Maria das Barreiras',
			'state' => 14,
		]);
		DB::table('cities')->insert([
			'id' => 2528, 
			'name' => 'Santa Maria do Pará',
			'state' => 14,
		]);
		DB::table('cities')->insert([
			'id' => 2529, 
			'name' => 'Santana do Araguaia',
			'state' => 14,
		]);
		DB::table('cities')->insert([
			'id' => 2530, 
			'name' => 'Santarém',
			'state' => 14,
		]);
		DB::table('cities')->insert([
			'id' => 2531, 
			'name' => 'Santarém Novo',
			'state' => 14,
		]);
		DB::table('cities')->insert([
			'id' => 2532, 
			'name' => 'Santo Antônio do Tauá',
			'state' => 14,
		]);
		DB::table('cities')->insert([
			'id' => 2533, 
			'name' => 'São Caetano de Odivelas',
			'state' => 14,
		]);
		DB::table('cities')->insert([
			'id' => 2534, 
			'name' => 'São Domingos do Araguaia',
			'state' => 14,
		]);
		DB::table('cities')->insert([
			'id' => 2535, 
			'name' => 'São Domingos do Capim',
			'state' => 14,
		]);
		DB::table('cities')->insert([
			'id' => 2536, 
			'name' => 'São Félix do Xingu',
			'state' => 14,
		]);
		DB::table('cities')->insert([
			'id' => 2537, 
			'name' => 'São Francisco do Pará',
			'state' => 14,
		]);
		DB::table('cities')->insert([
			'id' => 2538, 
			'name' => 'São Geraldo do Araguaia',
			'state' => 14,
		]);
		DB::table('cities')->insert([
			'id' => 2539, 
			'name' => 'São João da Ponta',
			'state' => 14,
		]);
		DB::table('cities')->insert([
			'id' => 2540, 
			'name' => 'São João de Pirabas',
			'state' => 14,
		]);
		DB::table('cities')->insert([
			'id' => 2541, 
			'name' => 'São João do Araguaia',
			'state' => 14,
		]);
		DB::table('cities')->insert([
			'id' => 2542, 
			'name' => 'São Miguel do Guamá',
			'state' => 14,
		]);
		DB::table('cities')->insert([
			'id' => 2543, 
			'name' => 'São Sebastião da Boa Vista',
			'state' => 14,
		]);
		DB::table('cities')->insert([
			'id' => 2544, 
			'name' => 'Sapucaia',
			'state' => 14,
		]);
		DB::table('cities')->insert([
			'id' => 2545, 
			'name' => 'Senador José Porfírio',
			'state' => 14,
		]);
		DB::table('cities')->insert([
			'id' => 2546, 
			'name' => 'Soure',
			'state' => 14,
		]);
		DB::table('cities')->insert([
			'id' => 2547, 
			'name' => 'Tailândia',
			'state' => 14,
		]);
		DB::table('cities')->insert([
			'id' => 2548, 
			'name' => 'Terra Alta',
			'state' => 14,
		]);
		DB::table('cities')->insert([
			'id' => 2549, 
			'name' => 'Terra Santa',
			'state' => 14,
		]);
		DB::table('cities')->insert([
			'id' => 2550, 
			'name' => 'Tomé-Açu',
			'state' => 14,
		]);
		DB::table('cities')->insert([
			'id' => 2551, 
			'name' => 'Tracuateua',
			'state' => 14,
		]);
		DB::table('cities')->insert([
			'id' => 2552, 
			'name' => 'Trairão',
			'state' => 14,
		]);
		DB::table('cities')->insert([
			'id' => 2553, 
			'name' => 'Tucumã',
			'state' => 14,
		]);
		DB::table('cities')->insert([
			'id' => 2554, 
			'name' => 'Tucuruí',
			'state' => 14,
		]);
		DB::table('cities')->insert([
			'id' => 2555, 
			'name' => 'Ulianópolis',
			'state' => 14,
		]);
		DB::table('cities')->insert([
			'id' => 2556, 
			'name' => 'Uruará',
			'state' => 14,
		]);
		DB::table('cities')->insert([
			'id' => 2557, 
			'name' => 'Vigia',
			'state' => 14,
		]);
		DB::table('cities')->insert([
			'id' => 2558, 
			'name' => 'Viseu',
			'state' => 14,
		]);
		DB::table('cities')->insert([
			'id' => 2559, 
			'name' => 'Vitória do Xingu',
			'state' => 14,
		]);
		DB::table('cities')->insert([
			'id' => 2560, 
			'name' => 'Xinguara',
			'state' => 14,
		]);
		DB::table('cities')->insert([
			'id' => 2561, 
			'name' => 'Água Branca',
			'state' => 15,
		]);
		DB::table('cities')->insert([
			'id' => 2562, 
			'name' => 'Aguiar',
			'state' => 15,
		]);
		DB::table('cities')->insert([
			'id' => 2563, 
			'name' => 'Alagoa Grande',
			'state' => 15,
		]);
		DB::table('cities')->insert([
			'id' => 2564, 
			'name' => 'Alagoa Nova',
			'state' => 15,
		]);
		DB::table('cities')->insert([
			'id' => 2565, 
			'name' => 'Alagoinha',
			'state' => 15,
		]);
		DB::table('cities')->insert([
			'id' => 2566, 
			'name' => 'Alcantil',
			'state' => 15,
		]);
		DB::table('cities')->insert([
			'id' => 2567, 
			'name' => 'Algodão de Jandaíra',
			'state' => 15,
		]);
		DB::table('cities')->insert([
			'id' => 2568, 
			'name' => 'Alhandra',
			'state' => 15,
		]);
		DB::table('cities')->insert([
			'id' => 2569, 
			'name' => 'Amparo',
			'state' => 15,
		]);
		DB::table('cities')->insert([
			'id' => 2570, 
			'name' => 'Aparecida',
			'state' => 15,
		]);
		DB::table('cities')->insert([
			'id' => 2571, 
			'name' => 'Araçagi',
			'state' => 15,
		]);
		DB::table('cities')->insert([
			'id' => 2572, 
			'name' => 'Arara',
			'state' => 15,
		]);
		DB::table('cities')->insert([
			'id' => 2573, 
			'name' => 'Araruna',
			'state' => 15,
		]);
		DB::table('cities')->insert([
			'id' => 2574, 
			'name' => 'Areia',
			'state' => 15,
		]);
		DB::table('cities')->insert([
			'id' => 2575, 
			'name' => 'Areia de Baraúnas',
			'state' => 15,
		]);
		DB::table('cities')->insert([
			'id' => 2576, 
			'name' => 'Areial',
			'state' => 15,
		]);
		DB::table('cities')->insert([
			'id' => 2577, 
			'name' => 'Aroeiras',
			'state' => 15,
		]);
		DB::table('cities')->insert([
			'id' => 2578, 
			'name' => 'Assunção',
			'state' => 15,
		]);
		DB::table('cities')->insert([
			'id' => 2579, 
			'name' => 'Baía da Traição',
			'state' => 15,
		]);
		DB::table('cities')->insert([
			'id' => 2580, 
			'name' => 'Bananeiras',
			'state' => 15,
		]);
		DB::table('cities')->insert([
			'id' => 2581, 
			'name' => 'Baraúna',
			'state' => 15,
		]);
		DB::table('cities')->insert([
			'id' => 2582, 
			'name' => 'Barra de Santa Rosa',
			'state' => 15,
		]);
		DB::table('cities')->insert([
			'id' => 2583, 
			'name' => 'Barra de Santana',
			'state' => 15,
		]);
		DB::table('cities')->insert([
			'id' => 2584, 
			'name' => 'Barra de São Miguel',
			'state' => 15,
		]);
		DB::table('cities')->insert([
			'id' => 2585, 
			'name' => 'Bayeux',
			'state' => 15,
		]);
		DB::table('cities')->insert([
			'id' => 2586, 
			'name' => 'Belém',
			'state' => 15,
		]);
		DB::table('cities')->insert([
			'id' => 2587, 
			'name' => 'Belém do Brejo do Cruz',
			'state' => 15,
		]);
		DB::table('cities')->insert([
			'id' => 2588, 
			'name' => 'Bernardino Batista',
			'state' => 15,
		]);
		DB::table('cities')->insert([
			'id' => 2589, 
			'name' => 'Boa Ventura',
			'state' => 15,
		]);
		DB::table('cities')->insert([
			'id' => 2590, 
			'name' => 'Boa Vista',
			'state' => 15,
		]);
		DB::table('cities')->insert([
			'id' => 2591, 
			'name' => 'Bom Jesus',
			'state' => 15,
		]);
		DB::table('cities')->insert([
			'id' => 2592, 
			'name' => 'Bom Sucesso',
			'state' => 15,
		]);
		DB::table('cities')->insert([
			'id' => 2593, 
			'name' => 'Bonito de Santa Fé',
			'state' => 15,
		]);
		DB::table('cities')->insert([
			'id' => 2594, 
			'name' => 'Boqueirão',
			'state' => 15,
		]);
		DB::table('cities')->insert([
			'id' => 2595, 
			'name' => 'Borborema',
			'state' => 15,
		]);
		DB::table('cities')->insert([
			'id' => 2596, 
			'name' => 'Brejo do Cruz',
			'state' => 15,
		]);
		DB::table('cities')->insert([
			'id' => 2597, 
			'name' => 'Brejo dos Santos',
			'state' => 15,
		]);
		DB::table('cities')->insert([
			'id' => 2598, 
			'name' => 'Caaporã',
			'state' => 15,
		]);
		DB::table('cities')->insert([
			'id' => 2599, 
			'name' => 'Cabaceiras',
			'state' => 15,
		]);
		DB::table('cities')->insert([
			'id' => 2600, 
			'name' => 'Cabedelo',
			'state' => 15,
		]);
		DB::table('cities')->insert([
			'id' => 2601, 
			'name' => 'Cachoeira dos Índios',
			'state' => 15,
		]);
		DB::table('cities')->insert([
			'id' => 2602, 
			'name' => 'Cacimba de Areia',
			'state' => 15,
		]);
		DB::table('cities')->insert([
			'id' => 2603, 
			'name' => 'Cacimba de Dentro',
			'state' => 15,
		]);
		DB::table('cities')->insert([
			'id' => 2604, 
			'name' => 'Cacimbas',
			'state' => 15,
		]);
		DB::table('cities')->insert([
			'id' => 2605, 
			'name' => 'Caiçara',
			'state' => 15,
		]);
		DB::table('cities')->insert([
			'id' => 2606, 
			'name' => 'Cajazeiras',
			'state' => 15,
		]);
		DB::table('cities')->insert([
			'id' => 2607, 
			'name' => 'Cajazeirinhas',
			'state' => 15,
		]);
		DB::table('cities')->insert([
			'id' => 2608, 
			'name' => 'Caldas Brandão',
			'state' => 15,
		]);
		DB::table('cities')->insert([
			'id' => 2609, 
			'name' => 'Camalaú',
			'state' => 15,
		]);
		DB::table('cities')->insert([
			'id' => 2610, 
			'name' => 'Campina Grande',
			'state' => 15,
		]);
		DB::table('cities')->insert([
			'id' => 2611, 
			'name' => 'Campo de Santana',
			'state' => 15,
		]);
		DB::table('cities')->insert([
			'id' => 2612, 
			'name' => 'Capim',
			'state' => 15,
		]);
		DB::table('cities')->insert([
			'id' => 2613, 
			'name' => 'Caraúbas',
			'state' => 15,
		]);
		DB::table('cities')->insert([
			'id' => 2614, 
			'name' => 'Carrapateira',
			'state' => 15,
		]);
		DB::table('cities')->insert([
			'id' => 2615, 
			'name' => 'Casserengue',
			'state' => 15,
		]);
		DB::table('cities')->insert([
			'id' => 2616, 
			'name' => 'Catingueira',
			'state' => 15,
		]);
		DB::table('cities')->insert([
			'id' => 2617, 
			'name' => 'Catolé do Rocha',
			'state' => 15,
		]);
		DB::table('cities')->insert([
			'id' => 2618, 
			'name' => 'Caturité',
			'state' => 15,
		]);
		DB::table('cities')->insert([
			'id' => 2619, 
			'name' => 'Conceição',
			'state' => 15,
		]);
		DB::table('cities')->insert([
			'id' => 2620, 
			'name' => 'Condado',
			'state' => 15,
		]);
		DB::table('cities')->insert([
			'id' => 2621, 
			'name' => 'Conde',
			'state' => 15,
		]);
		DB::table('cities')->insert([
			'id' => 2622, 
			'name' => 'Congo',
			'state' => 15,
		]);
		DB::table('cities')->insert([
			'id' => 2623, 
			'name' => 'Coremas',
			'state' => 15,
		]);
		DB::table('cities')->insert([
			'id' => 2624, 
			'name' => 'Coxixola',
			'state' => 15,
		]);
		DB::table('cities')->insert([
			'id' => 2625, 
			'name' => 'Cruz do Espírito Santo',
			'state' => 15,
		]);
		DB::table('cities')->insert([
			'id' => 2626, 
			'name' => 'Cubati',
			'state' => 15,
		]);
		DB::table('cities')->insert([
			'id' => 2627, 
			'name' => 'Cuité',
			'state' => 15,
		]);
		DB::table('cities')->insert([
			'id' => 2628, 
			'name' => 'Cuité de Mamanguape',
			'state' => 15,
		]);
		DB::table('cities')->insert([
			'id' => 2629, 
			'name' => 'Cuitegi',
			'state' => 15,
		]);
		DB::table('cities')->insert([
			'id' => 2630, 
			'name' => 'Curral de Cima',
			'state' => 15,
		]);
		DB::table('cities')->insert([
			'id' => 2631, 
			'name' => 'Curral Velho',
			'state' => 15,
		]);
		DB::table('cities')->insert([
			'id' => 2632, 
			'name' => 'Damião',
			'state' => 15,
		]);
		DB::table('cities')->insert([
			'id' => 2633, 
			'name' => 'Desterro',
			'state' => 15,
		]);
		DB::table('cities')->insert([
			'id' => 2634, 
			'name' => 'Diamante',
			'state' => 15,
		]);
		DB::table('cities')->insert([
			'id' => 2635, 
			'name' => 'Dona Inês',
			'state' => 15,
		]);
		DB::table('cities')->insert([
			'id' => 2636, 
			'name' => 'Duas Estradas',
			'state' => 15,
		]);
		DB::table('cities')->insert([
			'id' => 2637, 
			'name' => 'Emas',
			'state' => 15,
		]);
		DB::table('cities')->insert([
			'id' => 2638, 
			'name' => 'Esperança',
			'state' => 15,
		]);
		DB::table('cities')->insert([
			'id' => 2639, 
			'name' => 'Fagundes',
			'state' => 15,
		]);
		DB::table('cities')->insert([
			'id' => 2640, 
			'name' => 'Frei Martinho',
			'state' => 15,
		]);
		DB::table('cities')->insert([
			'id' => 2641, 
			'name' => 'Gado Bravo',
			'state' => 15,
		]);
		DB::table('cities')->insert([
			'id' => 2642, 
			'name' => 'Guarabira',
			'state' => 15,
		]);
		DB::table('cities')->insert([
			'id' => 2643, 
			'name' => 'Gurinhém',
			'state' => 15,
		]);
		DB::table('cities')->insert([
			'id' => 2644, 
			'name' => 'Gurjão',
			'state' => 15,
		]);
		DB::table('cities')->insert([
			'id' => 2645, 
			'name' => 'Ibiara',
			'state' => 15,
		]);
		DB::table('cities')->insert([
			'id' => 2646, 
			'name' => 'Igaracy',
			'state' => 15,
		]);
		DB::table('cities')->insert([
			'id' => 2647, 
			'name' => 'Imaculada',
			'state' => 15,
		]);
		DB::table('cities')->insert([
			'id' => 2648, 
			'name' => 'Ingá',
			'state' => 15,
		]);
		DB::table('cities')->insert([
			'id' => 2649, 
			'name' => 'Itabaiana',
			'state' => 15,
		]);
		DB::table('cities')->insert([
			'id' => 2650, 
			'name' => 'Itaporanga',
			'state' => 15,
		]);
		DB::table('cities')->insert([
			'id' => 2651, 
			'name' => 'Itapororoca',
			'state' => 15,
		]);
		DB::table('cities')->insert([
			'id' => 2652, 
			'name' => 'Itatuba',
			'state' => 15,
		]);
		DB::table('cities')->insert([
			'id' => 2653, 
			'name' => 'Jacaraú',
			'state' => 15,
		]);
		DB::table('cities')->insert([
			'id' => 2654, 
			'name' => 'Jericó',
			'state' => 15,
		]);
		DB::table('cities')->insert([
			'id' => 2655, 
			'name' => 'João Pessoa',
			'state' => 15,
		]);
		DB::table('cities')->insert([
			'id' => 2656, 
			'name' => 'Juarez Távora',
			'state' => 15,
		]);
		DB::table('cities')->insert([
			'id' => 2657, 
			'name' => 'Juazeirinho',
			'state' => 15,
		]);
		DB::table('cities')->insert([
			'id' => 2658, 
			'name' => 'Junco do Seridó',
			'state' => 15,
		]);
		DB::table('cities')->insert([
			'id' => 2659, 
			'name' => 'Juripiranga',
			'state' => 15,
		]);
		DB::table('cities')->insert([
			'id' => 2660, 
			'name' => 'Juru',
			'state' => 15,
		]);
		DB::table('cities')->insert([
			'id' => 2661, 
			'name' => 'Lagoa',
			'state' => 15,
		]);
		DB::table('cities')->insert([
			'id' => 2662, 
			'name' => 'Lagoa de Dentro',
			'state' => 15,
		]);
		DB::table('cities')->insert([
			'id' => 2663, 
			'name' => 'Lagoa Seca',
			'state' => 15,
		]);
		DB::table('cities')->insert([
			'id' => 2664, 
			'name' => 'Lastro',
			'state' => 15,
		]);
		DB::table('cities')->insert([
			'id' => 2665, 
			'name' => 'Livramento',
			'state' => 15,
		]);
		DB::table('cities')->insert([
			'id' => 2666, 
			'name' => 'Logradouro',
			'state' => 15,
		]);
		DB::table('cities')->insert([
			'id' => 2667, 
			'name' => 'Lucena',
			'state' => 15,
		]);
		DB::table('cities')->insert([
			'id' => 2668, 
			'name' => 'Mãe d`Água',
			'state' => 15,
		]);
		DB::table('cities')->insert([
			'id' => 2669, 
			'name' => 'Malta',
			'state' => 15,
		]);
		DB::table('cities')->insert([
			'id' => 2670, 
			'name' => 'Mamanguape',
			'state' => 15,
		]);
		DB::table('cities')->insert([
			'id' => 2671, 
			'name' => 'Manaíra',
			'state' => 15,
		]);
		DB::table('cities')->insert([
			'id' => 2672, 
			'name' => 'Marcação',
			'state' => 15,
		]);
		DB::table('cities')->insert([
			'id' => 2673, 
			'name' => 'Mari',
			'state' => 15,
		]);
		DB::table('cities')->insert([
			'id' => 2674, 
			'name' => 'Marizópolis',
			'state' => 15,
		]);
		DB::table('cities')->insert([
			'id' => 2675, 
			'name' => 'Massaranduba',
			'state' => 15,
		]);
		DB::table('cities')->insert([
			'id' => 2676, 
			'name' => 'Mataraca',
			'state' => 15,
		]);
		DB::table('cities')->insert([
			'id' => 2677, 
			'name' => 'Matinhas',
			'state' => 15,
		]);
		DB::table('cities')->insert([
			'id' => 2678, 
			'name' => 'Mato Grosso',
			'state' => 15,
		]);
		DB::table('cities')->insert([
			'id' => 2679, 
			'name' => 'Maturéia',
			'state' => 15,
		]);
		DB::table('cities')->insert([
			'id' => 2680, 
			'name' => 'Mogeiro',
			'state' => 15,
		]);
		DB::table('cities')->insert([
			'id' => 2681, 
			'name' => 'Montadas',
			'state' => 15,
		]);
		DB::table('cities')->insert([
			'id' => 2682, 
			'name' => 'Monte Horebe',
			'state' => 15,
		]);
		DB::table('cities')->insert([
			'id' => 2683, 
			'name' => 'Monteiro',
			'state' => 15,
		]);
		DB::table('cities')->insert([
			'id' => 2684, 
			'name' => 'Mulungu',
			'state' => 15,
		]);
		DB::table('cities')->insert([
			'id' => 2685, 
			'name' => 'Natuba',
			'state' => 15,
		]);
		DB::table('cities')->insert([
			'id' => 2686, 
			'name' => 'Nazarezinho',
			'state' => 15,
		]);
		DB::table('cities')->insert([
			'id' => 2687, 
			'name' => 'Nova Floresta',
			'state' => 15,
		]);
		DB::table('cities')->insert([
			'id' => 2688, 
			'name' => 'Nova Olinda',
			'state' => 15,
		]);
		DB::table('cities')->insert([
			'id' => 2689, 
			'name' => 'Nova Palmeira',
			'state' => 15,
		]);
		DB::table('cities')->insert([
			'id' => 2690, 
			'name' => 'Olho d`Água',
			'state' => 15,
		]);
		DB::table('cities')->insert([
			'id' => 2691, 
			'name' => 'Olivedos',
			'state' => 15,
		]);
		DB::table('cities')->insert([
			'id' => 2692, 
			'name' => 'Ouro Velho',
			'state' => 15,
		]);
		DB::table('cities')->insert([
			'id' => 2693, 
			'name' => 'Parari',
			'state' => 15,
		]);
		DB::table('cities')->insert([
			'id' => 2694, 
			'name' => 'Passagem',
			'state' => 15,
		]);
		DB::table('cities')->insert([
			'id' => 2695, 
			'name' => 'Patos',
			'state' => 15,
		]);
		DB::table('cities')->insert([
			'id' => 2696, 
			'name' => 'Paulista',
			'state' => 15,
		]);
		DB::table('cities')->insert([
			'id' => 2697, 
			'name' => 'Pedra Branca',
			'state' => 15,
		]);
		DB::table('cities')->insert([
			'id' => 2698, 
			'name' => 'Pedra Lavrada',
			'state' => 15,
		]);
		DB::table('cities')->insert([
			'id' => 2699, 
			'name' => 'Pedras de Fogo',
			'state' => 15,
		]);
		DB::table('cities')->insert([
			'id' => 2700, 
			'name' => 'Pedro Régis',
			'state' => 15,
		]);
		DB::table('cities')->insert([
			'id' => 2701, 
			'name' => 'Piancó',
			'state' => 15,
		]);
		DB::table('cities')->insert([
			'id' => 2702, 
			'name' => 'Picuí',
			'state' => 15,
		]);
		DB::table('cities')->insert([
			'id' => 2703, 
			'name' => 'Pilar',
			'state' => 15,
		]);
		DB::table('cities')->insert([
			'id' => 2704, 
			'name' => 'Pilões',
			'state' => 15,
		]);
		DB::table('cities')->insert([
			'id' => 2705, 
			'name' => 'Pilõezinhos',
			'state' => 15,
		]);
		DB::table('cities')->insert([
			'id' => 2706, 
			'name' => 'Pirpirituba',
			'state' => 15,
		]);
		DB::table('cities')->insert([
			'id' => 2707, 
			'name' => 'Pitimbu',
			'state' => 15,
		]);
		DB::table('cities')->insert([
			'id' => 2708, 
			'name' => 'Pocinhos',
			'state' => 15,
		]);
		DB::table('cities')->insert([
			'id' => 2709, 
			'name' => 'Poço Dantas',
			'state' => 15,
		]);
		DB::table('cities')->insert([
			'id' => 2710, 
			'name' => 'Poço de José de Moura',
			'state' => 15,
		]);
		DB::table('cities')->insert([
			'id' => 2711, 
			'name' => 'Pombal',
			'state' => 15,
		]);
		DB::table('cities')->insert([
			'id' => 2712, 
			'name' => 'Prata',
			'state' => 15,
		]);
		DB::table('cities')->insert([
			'id' => 2713, 
			'name' => 'Princesa Isabel',
			'state' => 15,
		]);
		DB::table('cities')->insert([
			'id' => 2714, 
			'name' => 'Puxinanã',
			'state' => 15,
		]);
		DB::table('cities')->insert([
			'id' => 2715, 
			'name' => 'Queimadas',
			'state' => 15,
		]);
		DB::table('cities')->insert([
			'id' => 2716, 
			'name' => 'Quixabá',
			'state' => 15,
		]);
		DB::table('cities')->insert([
			'id' => 2717, 
			'name' => 'Remígio',
			'state' => 15,
		]);
		DB::table('cities')->insert([
			'id' => 2718, 
			'name' => 'Riachão',
			'state' => 15,
		]);
		DB::table('cities')->insert([
			'id' => 2719, 
			'name' => 'Riachão do Bacamarte',
			'state' => 15,
		]);
		DB::table('cities')->insert([
			'id' => 2720, 
			'name' => 'Riachão do Poço',
			'state' => 15,
		]);
		DB::table('cities')->insert([
			'id' => 2721, 
			'name' => 'Riacho de Santo Antônio',
			'state' => 15,
		]);
		DB::table('cities')->insert([
			'id' => 2722, 
			'name' => 'Riacho dos Cavalos',
			'state' => 15,
		]);
		DB::table('cities')->insert([
			'id' => 2723, 
			'name' => 'Rio Tinto',
			'state' => 15,
		]);
		DB::table('cities')->insert([
			'id' => 2724, 
			'name' => 'Salgadinho',
			'state' => 15,
		]);
		DB::table('cities')->insert([
			'id' => 2725, 
			'name' => 'Salgado de São Félix',
			'state' => 15,
		]);
		DB::table('cities')->insert([
			'id' => 2726, 
			'name' => 'Santa Cecília',
			'state' => 15,
		]);
		DB::table('cities')->insert([
			'id' => 2727, 
			'name' => 'Santa Cruz',
			'state' => 15,
		]);
		DB::table('cities')->insert([
			'id' => 2728, 
			'name' => 'Santa Helena',
			'state' => 15,
		]);
		DB::table('cities')->insert([
			'id' => 2729, 
			'name' => 'Santa Inês',
			'state' => 15,
		]);
		DB::table('cities')->insert([
			'id' => 2730, 
			'name' => 'Santa Luzia',
			'state' => 15,
		]);
		DB::table('cities')->insert([
			'id' => 2731, 
			'name' => 'Santa Rita',
			'state' => 15,
		]);
		DB::table('cities')->insert([
			'id' => 2732, 
			'name' => 'Santa Teresinha',
			'state' => 15,
		]);
		DB::table('cities')->insert([
			'id' => 2733, 
			'name' => 'Santana de Mangueira',
			'state' => 15,
		]);
		DB::table('cities')->insert([
			'id' => 2734, 
			'name' => 'Santana dos Garrotes',
			'state' => 15,
		]);
		DB::table('cities')->insert([
			'id' => 2735, 
			'name' => 'Santarém',
			'state' => 15,
		]);
		DB::table('cities')->insert([
			'id' => 2736, 
			'name' => 'Santo André',
			'state' => 15,
		]);
		DB::table('cities')->insert([
			'id' => 2737, 
			'name' => 'São Bentinho',
			'state' => 15,
		]);
		DB::table('cities')->insert([
			'id' => 2738, 
			'name' => 'São Bento',
			'state' => 15,
		]);
		DB::table('cities')->insert([
			'id' => 2739, 
			'name' => 'São Domingos de Pombal',
			'state' => 15,
		]);
		DB::table('cities')->insert([
			'id' => 2740, 
			'name' => 'São Domingos do Cariri',
			'state' => 15,
		]);
		DB::table('cities')->insert([
			'id' => 2741, 
			'name' => 'São Francisco',
			'state' => 15,
		]);
		DB::table('cities')->insert([
			'id' => 2742, 
			'name' => 'São João do Cariri',
			'state' => 15,
		]);
		DB::table('cities')->insert([
			'id' => 2743, 
			'name' => 'São João do Rio do Peixe',
			'state' => 15,
		]);
		DB::table('cities')->insert([
			'id' => 2744, 
			'name' => 'São João do Tigre',
			'state' => 15,
		]);
		DB::table('cities')->insert([
			'id' => 2745, 
			'name' => 'São José da Lagoa Tapada',
			'state' => 15,
		]);
		DB::table('cities')->insert([
			'id' => 2746, 
			'name' => 'São José de Caiana',
			'state' => 15,
		]);
		DB::table('cities')->insert([
			'id' => 2747, 
			'name' => 'São José de Espinharas',
			'state' => 15,
		]);
		DB::table('cities')->insert([
			'id' => 2748, 
			'name' => 'São José de Piranhas',
			'state' => 15,
		]);
		DB::table('cities')->insert([
			'id' => 2749, 
			'name' => 'São José de Princesa',
			'state' => 15,
		]);
		DB::table('cities')->insert([
			'id' => 2750, 
			'name' => 'São José do Bonfim',
			'state' => 15,
		]);
		DB::table('cities')->insert([
			'id' => 2751, 
			'name' => 'São José do Brejo do Cruz',
			'state' => 15,
		]);
		DB::table('cities')->insert([
			'id' => 2752, 
			'name' => 'São José do Sabugi',
			'state' => 15,
		]);
		DB::table('cities')->insert([
			'id' => 2753, 
			'name' => 'São José dos Cordeiros',
			'state' => 15,
		]);
		DB::table('cities')->insert([
			'id' => 2754, 
			'name' => 'São José dos Ramos',
			'state' => 15,
		]);
		DB::table('cities')->insert([
			'id' => 2755, 
			'name' => 'São Mamede',
			'state' => 15,
		]);
		DB::table('cities')->insert([
			'id' => 2756, 
			'name' => 'São Miguel de Taipu',
			'state' => 15,
		]);
		DB::table('cities')->insert([
			'id' => 2757, 
			'name' => 'São Sebastião de Lagoa de Roça',
			'state' => 15,
		]);
		DB::table('cities')->insert([
			'id' => 2758, 
			'name' => 'São Sebastião do Umbuzeiro',
			'state' => 15,
		]);
		DB::table('cities')->insert([
			'id' => 2759, 
			'name' => 'Sapé',
			'state' => 15,
		]);
		DB::table('cities')->insert([
			'id' => 2760, 
			'name' => 'Seridó',
			'state' => 15,
		]);
		DB::table('cities')->insert([
			'id' => 2761, 
			'name' => 'Serra Branca',
			'state' => 15,
		]);
		DB::table('cities')->insert([
			'id' => 2762, 
			'name' => 'Serra da Raiz',
			'state' => 15,
		]);
		DB::table('cities')->insert([
			'id' => 2763, 
			'name' => 'Serra Grande',
			'state' => 15,
		]);
		DB::table('cities')->insert([
			'id' => 2764, 
			'name' => 'Serra Redonda',
			'state' => 15,
		]);
		DB::table('cities')->insert([
			'id' => 2765, 
			'name' => 'Serraria',
			'state' => 15,
		]);
		DB::table('cities')->insert([
			'id' => 2766, 
			'name' => 'Sertãozinho',
			'state' => 15,
		]);
		DB::table('cities')->insert([
			'id' => 2767, 
			'name' => 'Sobrado',
			'state' => 15,
		]);
		DB::table('cities')->insert([
			'id' => 2768, 
			'name' => 'Solânea',
			'state' => 15,
		]);
		DB::table('cities')->insert([
			'id' => 2769, 
			'name' => 'Soledade',
			'state' => 15,
		]);
		DB::table('cities')->insert([
			'id' => 2770, 
			'name' => 'Sossêgo',
			'state' => 15,
		]);
		DB::table('cities')->insert([
			'id' => 2771, 
			'name' => 'Sousa',
			'state' => 15,
		]);
		DB::table('cities')->insert([
			'id' => 2772, 
			'name' => 'Sumé',
			'state' => 15,
		]);
		DB::table('cities')->insert([
			'id' => 2773, 
			'name' => 'Taperoá',
			'state' => 15,
		]);
		DB::table('cities')->insert([
			'id' => 2774, 
			'name' => 'Tavares',
			'state' => 15,
		]);
		DB::table('cities')->insert([
			'id' => 2775, 
			'name' => 'Teixeira',
			'state' => 15,
		]);
		DB::table('cities')->insert([
			'id' => 2776, 
			'name' => 'Tenório',
			'state' => 15,
		]);
		DB::table('cities')->insert([
			'id' => 2777, 
			'name' => 'Triunfo',
			'state' => 15,
		]);
		DB::table('cities')->insert([
			'id' => 2778, 
			'name' => 'Uiraúna',
			'state' => 15,
		]);
		DB::table('cities')->insert([
			'id' => 2779, 
			'name' => 'Umbuzeiro',
			'state' => 15,
		]);
		DB::table('cities')->insert([
			'id' => 2780, 
			'name' => 'Várzea',
			'state' => 15,
		]);
		DB::table('cities')->insert([
			'id' => 2781, 
			'name' => 'Vieirópolis',
			'state' => 15,
		]);
		DB::table('cities')->insert([
			'id' => 2782, 
			'name' => 'Vista Serrana',
			'state' => 15,
		]);
		DB::table('cities')->insert([
			'id' => 2783, 
			'name' => 'Zabelê',
			'state' => 15,
		]);
		DB::table('cities')->insert([
			'id' => 2784, 
			'name' => 'Abatiá',
			'state' => 18,
		]);
		DB::table('cities')->insert([
			'id' => 2785, 
			'name' => 'Adrianópolis',
			'state' => 18,
		]);
		DB::table('cities')->insert([
			'id' => 2786, 
			'name' => 'Agudos do Sul',
			'state' => 18,
		]);
		DB::table('cities')->insert([
			'id' => 2787, 
			'name' => 'Almirante Tamandaré',
			'state' => 18,
		]);
		DB::table('cities')->insert([
			'id' => 2788, 
			'name' => 'Altamira do Paraná',
			'state' => 18,
		]);
		DB::table('cities')->insert([
			'id' => 2789, 
			'name' => 'Alto Paraíso',
			'state' => 18,
		]);
		DB::table('cities')->insert([
			'id' => 2790, 
			'name' => 'Alto Paraná',
			'state' => 18,
		]);
		DB::table('cities')->insert([
			'id' => 2791, 
			'name' => 'Alto Piquiri',
			'state' => 18,
		]);
		DB::table('cities')->insert([
			'id' => 2792, 
			'name' => 'Altônia',
			'state' => 18,
		]);
		DB::table('cities')->insert([
			'id' => 2793, 
			'name' => 'Alvorada do Sul',
			'state' => 18,
		]);
		DB::table('cities')->insert([
			'id' => 2794, 
			'name' => 'Amaporã',
			'state' => 18,
		]);
		DB::table('cities')->insert([
			'id' => 2795, 
			'name' => 'Ampére',
			'state' => 18,
		]);
		DB::table('cities')->insert([
			'id' => 2796, 
			'name' => 'Anahy',
			'state' => 18,
		]);
		DB::table('cities')->insert([
			'id' => 2797, 
			'name' => 'Andirá',
			'state' => 18,
		]);
		DB::table('cities')->insert([
			'id' => 2798, 
			'name' => 'Ângulo',
			'state' => 18,
		]);
		DB::table('cities')->insert([
			'id' => 2799, 
			'name' => 'Antonina',
			'state' => 18,
		]);
		DB::table('cities')->insert([
			'id' => 2800, 
			'name' => 'Antônio Olinto',
			'state' => 18,
		]);
		DB::table('cities')->insert([
			'id' => 2801, 
			'name' => 'Apucarana',
			'state' => 18,
		]);
		DB::table('cities')->insert([
			'id' => 2802, 
			'name' => 'Arapongas',
			'state' => 18,
		]);
		DB::table('cities')->insert([
			'id' => 2803, 
			'name' => 'Arapoti',
			'state' => 18,
		]);
		DB::table('cities')->insert([
			'id' => 2804, 
			'name' => 'Arapuã',
			'state' => 18,
		]);
		DB::table('cities')->insert([
			'id' => 2805, 
			'name' => 'Araruna',
			'state' => 18,
		]);
		DB::table('cities')->insert([
			'id' => 2806, 
			'name' => 'Araucária',
			'state' => 18,
		]);
		DB::table('cities')->insert([
			'id' => 2807, 
			'name' => 'Ariranha do Ivaí',
			'state' => 18,
		]);
		DB::table('cities')->insert([
			'id' => 2808, 
			'name' => 'Assaí',
			'state' => 18,
		]);
		DB::table('cities')->insert([
			'id' => 2809, 
			'name' => 'Assis Chateaubriand',
			'state' => 18,
		]);
		DB::table('cities')->insert([
			'id' => 2810, 
			'name' => 'Astorga',
			'state' => 18,
		]);
		DB::table('cities')->insert([
			'id' => 2811, 
			'name' => 'Atalaia',
			'state' => 18,
		]);
		DB::table('cities')->insert([
			'id' => 2812, 
			'name' => 'Balsa Nova',
			'state' => 18,
		]);
		DB::table('cities')->insert([
			'id' => 2813, 
			'name' => 'Bandeirantes',
			'state' => 18,
		]);
		DB::table('cities')->insert([
			'id' => 2814, 
			'name' => 'Barbosa Ferraz',
			'state' => 18,
		]);
		DB::table('cities')->insert([
			'id' => 2815, 
			'name' => 'Barra do Jacaré',
			'state' => 18,
		]);
		DB::table('cities')->insert([
			'id' => 2816, 
			'name' => 'Barracão',
			'state' => 18,
		]);
		DB::table('cities')->insert([
			'id' => 2817, 
			'name' => 'Bela Vista da Caroba',
			'state' => 18,
		]);
		DB::table('cities')->insert([
			'id' => 2818, 
			'name' => 'Bela Vista do Paraíso',
			'state' => 18,
		]);
		DB::table('cities')->insert([
			'id' => 2819, 
			'name' => 'Bituruna',
			'state' => 18,
		]);
		DB::table('cities')->insert([
			'id' => 2820, 
			'name' => 'Boa Esperança',
			'state' => 18,
		]);
		DB::table('cities')->insert([
			'id' => 2821, 
			'name' => 'Boa Esperança do Iguaçu',
			'state' => 18,
		]);
		DB::table('cities')->insert([
			'id' => 2822, 
			'name' => 'Boa Ventura de São Roque',
			'state' => 18,
		]);
		DB::table('cities')->insert([
			'id' => 2823, 
			'name' => 'Boa Vista da Aparecida',
			'state' => 18,
		]);
		DB::table('cities')->insert([
			'id' => 2824, 
			'name' => 'Bocaiúva do Sul',
			'state' => 18,
		]);
		DB::table('cities')->insert([
			'id' => 2825, 
			'name' => 'Bom Jesus do Sul',
			'state' => 18,
		]);
		DB::table('cities')->insert([
			'id' => 2826, 
			'name' => 'Bom Sucesso',
			'state' => 18,
		]);
		DB::table('cities')->insert([
			'id' => 2827, 
			'name' => 'Bom Sucesso do Sul',
			'state' => 18,
		]);
		DB::table('cities')->insert([
			'id' => 2828, 
			'name' => 'Borrazópolis',
			'state' => 18,
		]);
		DB::table('cities')->insert([
			'id' => 2829, 
			'name' => 'Braganey',
			'state' => 18,
		]);
		DB::table('cities')->insert([
			'id' => 2830, 
			'name' => 'Brasilândia do Sul',
			'state' => 18,
		]);
		DB::table('cities')->insert([
			'id' => 2831, 
			'name' => 'Cafeara',
			'state' => 18,
		]);
		DB::table('cities')->insert([
			'id' => 2832, 
			'name' => 'Cafelândia',
			'state' => 18,
		]);
		DB::table('cities')->insert([
			'id' => 2833, 
			'name' => 'Cafezal do Sul',
			'state' => 18,
		]);
		DB::table('cities')->insert([
			'id' => 2834, 
			'name' => 'Califórnia',
			'state' => 18,
		]);
		DB::table('cities')->insert([
			'id' => 2835, 
			'name' => 'Cambará',
			'state' => 18,
		]);
		DB::table('cities')->insert([
			'id' => 2836, 
			'name' => 'Cambé',
			'state' => 18,
		]);
		DB::table('cities')->insert([
			'id' => 2837, 
			'name' => 'Cambira',
			'state' => 18,
		]);
		DB::table('cities')->insert([
			'id' => 2838, 
			'name' => 'Campina da Lagoa',
			'state' => 18,
		]);
		DB::table('cities')->insert([
			'id' => 2839, 
			'name' => 'Campina do Simão',
			'state' => 18,
		]);
		DB::table('cities')->insert([
			'id' => 2840, 
			'name' => 'Campina Grande do Sul',
			'state' => 18,
		]);
		DB::table('cities')->insert([
			'id' => 2841, 
			'name' => 'Campo Bonito',
			'state' => 18,
		]);
		DB::table('cities')->insert([
			'id' => 2842, 
			'name' => 'Campo do Tenente',
			'state' => 18,
		]);
		DB::table('cities')->insert([
			'id' => 2843, 
			'name' => 'Campo Largo',
			'state' => 18,
		]);
		DB::table('cities')->insert([
			'id' => 2844, 
			'name' => 'Campo Magro',
			'state' => 18,
		]);
		DB::table('cities')->insert([
			'id' => 2845, 
			'name' => 'Campo Mourão',
			'state' => 18,
		]);
		DB::table('cities')->insert([
			'id' => 2846, 
			'name' => 'Cândido de Abreu',
			'state' => 18,
		]);
		DB::table('cities')->insert([
			'id' => 2847, 
			'name' => 'Candói',
			'state' => 18,
		]);
		DB::table('cities')->insert([
			'id' => 2848, 
			'name' => 'Cantagalo',
			'state' => 18,
		]);
		DB::table('cities')->insert([
			'id' => 2849, 
			'name' => 'Capanema',
			'state' => 18,
		]);
		DB::table('cities')->insert([
			'id' => 2850, 
			'name' => 'Capitão Leônidas Marques',
			'state' => 18,
		]);
		DB::table('cities')->insert([
			'id' => 2851, 
			'name' => 'Carambeí',
			'state' => 18,
		]);
		DB::table('cities')->insert([
			'id' => 2852, 
			'name' => 'Carlópolis',
			'state' => 18,
		]);
		DB::table('cities')->insert([
			'id' => 2853, 
			'name' => 'Cascavel',
			'state' => 18,
		]);
		DB::table('cities')->insert([
			'id' => 2854, 
			'name' => 'Castro',
			'state' => 18,
		]);
		DB::table('cities')->insert([
			'id' => 2855, 
			'name' => 'Catanduvas',
			'state' => 18,
		]);
		DB::table('cities')->insert([
			'id' => 2856, 
			'name' => 'Centenário do Sul',
			'state' => 18,
		]);
		DB::table('cities')->insert([
			'id' => 2857, 
			'name' => 'Cerro Azul',
			'state' => 18,
		]);
		DB::table('cities')->insert([
			'id' => 2858, 
			'name' => 'Céu Azul',
			'state' => 18,
		]);
		DB::table('cities')->insert([
			'id' => 2859, 
			'name' => 'Chopinzinho',
			'state' => 18,
		]);
		DB::table('cities')->insert([
			'id' => 2860, 
			'name' => 'Cianorte',
			'state' => 18,
		]);
		DB::table('cities')->insert([
			'id' => 2861, 
			'name' => 'Cidade Gaúcha',
			'state' => 18,
		]);
		DB::table('cities')->insert([
			'id' => 2862, 
			'name' => 'Clevelândia',
			'state' => 18,
		]);
		DB::table('cities')->insert([
			'id' => 2863, 
			'name' => 'Colombo',
			'state' => 18,
		]);
		DB::table('cities')->insert([
			'id' => 2864, 
			'name' => 'Colorado',
			'state' => 18,
		]);
		DB::table('cities')->insert([
			'id' => 2865, 
			'name' => 'Congonhinhas',
			'state' => 18,
		]);
		DB::table('cities')->insert([
			'id' => 2866, 
			'name' => 'Conselheiro Mairinck',
			'state' => 18,
		]);
		DB::table('cities')->insert([
			'id' => 2867, 
			'name' => 'Contenda',
			'state' => 18,
		]);
		DB::table('cities')->insert([
			'id' => 2868, 
			'name' => 'Corbélia',
			'state' => 18,
		]);
		DB::table('cities')->insert([
			'id' => 2869, 
			'name' => 'Cornélio Procópio',
			'state' => 18,
		]);
		DB::table('cities')->insert([
			'id' => 2870, 
			'name' => 'Coronel Domingos Soares',
			'state' => 18,
		]);
		DB::table('cities')->insert([
			'id' => 2871, 
			'name' => 'Coronel Vivida',
			'state' => 18,
		]);
		DB::table('cities')->insert([
			'id' => 2872, 
			'name' => 'Corumbataí do Sul',
			'state' => 18,
		]);
		DB::table('cities')->insert([
			'id' => 2873, 
			'name' => 'Cruz Machado',
			'state' => 18,
		]);
		DB::table('cities')->insert([
			'id' => 2874, 
			'name' => 'Cruzeiro do Iguaçu',
			'state' => 18,
		]);
		DB::table('cities')->insert([
			'id' => 2875, 
			'name' => 'Cruzeiro do Oeste',
			'state' => 18,
		]);
		DB::table('cities')->insert([
			'id' => 2876, 
			'name' => 'Cruzeiro do Sul',
			'state' => 18,
		]);
		DB::table('cities')->insert([
			'id' => 2877, 
			'name' => 'Cruzmaltina',
			'state' => 18,
		]);
		DB::table('cities')->insert([
			'id' => 2878, 
			'name' => 'Curitiba',
			'state' => 18,
		]);
		DB::table('cities')->insert([
			'id' => 2879, 
			'name' => 'Curiúva',
			'state' => 18,
		]);
		DB::table('cities')->insert([
			'id' => 2880, 
			'name' => 'Diamante d`Oeste',
			'state' => 18,
		]);
		DB::table('cities')->insert([
			'id' => 2881, 
			'name' => 'Diamante do Norte',
			'state' => 18,
		]);
		DB::table('cities')->insert([
			'id' => 2882, 
			'name' => 'Diamante do Sul',
			'state' => 18,
		]);
		DB::table('cities')->insert([
			'id' => 2883, 
			'name' => 'Dois Vizinhos',
			'state' => 18,
		]);
		DB::table('cities')->insert([
			'id' => 2884, 
			'name' => 'Douradina',
			'state' => 18,
		]);
		DB::table('cities')->insert([
			'id' => 2885, 
			'name' => 'Doutor Camargo',
			'state' => 18,
		]);
		DB::table('cities')->insert([
			'id' => 2886, 
			'name' => 'Doutor Ulysses',
			'state' => 18,
		]);
		DB::table('cities')->insert([
			'id' => 2887, 
			'name' => 'Enéas Marques',
			'state' => 18,
		]);
		DB::table('cities')->insert([
			'id' => 2888, 
			'name' => 'Engenheiro Beltrão',
			'state' => 18,
		]);
		DB::table('cities')->insert([
			'id' => 2889, 
			'name' => 'Entre Rios do Oeste',
			'state' => 18,
		]);
		DB::table('cities')->insert([
			'id' => 2890, 
			'name' => 'Esperança Nova',
			'state' => 18,
		]);
		DB::table('cities')->insert([
			'id' => 2891, 
			'name' => 'Espigão Alto do Iguaçu',
			'state' => 18,
		]);
		DB::table('cities')->insert([
			'id' => 2892, 
			'name' => 'Farol',
			'state' => 18,
		]);
		DB::table('cities')->insert([
			'id' => 2893, 
			'name' => 'Faxinal',
			'state' => 18,
		]);
		DB::table('cities')->insert([
			'id' => 2894, 
			'name' => 'Fazenda Rio Grande',
			'state' => 18,
		]);
		DB::table('cities')->insert([
			'id' => 2895, 
			'name' => 'Fênix',
			'state' => 18,
		]);
		DB::table('cities')->insert([
			'id' => 2896, 
			'name' => 'Fernandes Pinheiro',
			'state' => 18,
		]);
		DB::table('cities')->insert([
			'id' => 2897, 
			'name' => 'Figueira',
			'state' => 18,
		]);
		DB::table('cities')->insert([
			'id' => 2898, 
			'name' => 'Flor da Serra do Sul',
			'state' => 18,
		]);
		DB::table('cities')->insert([
			'id' => 2899, 
			'name' => 'Floraí',
			'state' => 18,
		]);
		DB::table('cities')->insert([
			'id' => 2900, 
			'name' => 'Floresta',
			'state' => 18,
		]);
		DB::table('cities')->insert([
			'id' => 2901, 
			'name' => 'Florestópolis',
			'state' => 18,
		]);
		DB::table('cities')->insert([
			'id' => 2902, 
			'name' => 'Flórida',
			'state' => 18,
		]);
		DB::table('cities')->insert([
			'id' => 2903, 
			'name' => 'Formosa do Oeste',
			'state' => 18,
		]);
		DB::table('cities')->insert([
			'id' => 2904, 
			'name' => 'Foz do Iguaçu',
			'state' => 18,
		]);
		DB::table('cities')->insert([
			'id' => 2905, 
			'name' => 'Foz do Jordão',
			'state' => 18,
		]);
		DB::table('cities')->insert([
			'id' => 2906, 
			'name' => 'Francisco Alves',
			'state' => 18,
		]);
		DB::table('cities')->insert([
			'id' => 2907, 
			'name' => 'Francisco Beltrão',
			'state' => 18,
		]);
		DB::table('cities')->insert([
			'id' => 2908, 
			'name' => 'General Carneiro',
			'state' => 18,
		]);
		DB::table('cities')->insert([
			'id' => 2909, 
			'name' => 'Godoy Moreira',
			'state' => 18,
		]);
		DB::table('cities')->insert([
			'id' => 2910, 
			'name' => 'Goioerê',
			'state' => 18,
		]);
		DB::table('cities')->insert([
			'id' => 2911, 
			'name' => 'Goioxim',
			'state' => 18,
		]);
		DB::table('cities')->insert([
			'id' => 2912, 
			'name' => 'Grandes Rios',
			'state' => 18,
		]);
		DB::table('cities')->insert([
			'id' => 2913, 
			'name' => 'Guaíra',
			'state' => 18,
		]);
		DB::table('cities')->insert([
			'id' => 2914, 
			'name' => 'Guairaçá',
			'state' => 18,
		]);
		DB::table('cities')->insert([
			'id' => 2915, 
			'name' => 'Guamiranga',
			'state' => 18,
		]);
		DB::table('cities')->insert([
			'id' => 2916, 
			'name' => 'Guapirama',
			'state' => 18,
		]);
		DB::table('cities')->insert([
			'id' => 2917, 
			'name' => 'Guaporema',
			'state' => 18,
		]);
		DB::table('cities')->insert([
			'id' => 2918, 
			'name' => 'Guaraci',
			'state' => 18,
		]);
		DB::table('cities')->insert([
			'id' => 2919, 
			'name' => 'Guaraniaçu',
			'state' => 18,
		]);
		DB::table('cities')->insert([
			'id' => 2920, 
			'name' => 'Guarapuava',
			'state' => 18,
		]);
		DB::table('cities')->insert([
			'id' => 2921, 
			'name' => 'Guaraqueçaba',
			'state' => 18,
		]);
		DB::table('cities')->insert([
			'id' => 2922, 
			'name' => 'Guaratuba',
			'state' => 18,
		]);
		DB::table('cities')->insert([
			'id' => 2923, 
			'name' => 'Honório Serpa',
			'state' => 18,
		]);
		DB::table('cities')->insert([
			'id' => 2924, 
			'name' => 'Ibaiti',
			'state' => 18,
		]);
		DB::table('cities')->insert([
			'id' => 2925, 
			'name' => 'Ibema',
			'state' => 18,
		]);
		DB::table('cities')->insert([
			'id' => 2926, 
			'name' => 'Ibiporã',
			'state' => 18,
		]);
		DB::table('cities')->insert([
			'id' => 2927, 
			'name' => 'Icaraíma',
			'state' => 18,
		]);
		DB::table('cities')->insert([
			'id' => 2928, 
			'name' => 'Iguaraçu',
			'state' => 18,
		]);
		DB::table('cities')->insert([
			'id' => 2929, 
			'name' => 'Iguatu',
			'state' => 18,
		]);
		DB::table('cities')->insert([
			'id' => 2930, 
			'name' => 'Imbaú',
			'state' => 18,
		]);
		DB::table('cities')->insert([
			'id' => 2931, 
			'name' => 'Imbituva',
			'state' => 18,
		]);
		DB::table('cities')->insert([
			'id' => 2932, 
			'name' => 'Inácio Martins',
			'state' => 18,
		]);
		DB::table('cities')->insert([
			'id' => 2933, 
			'name' => 'Inajá',
			'state' => 18,
		]);
		DB::table('cities')->insert([
			'id' => 2934, 
			'name' => 'Indianópolis',
			'state' => 18,
		]);
		DB::table('cities')->insert([
			'id' => 2935, 
			'name' => 'Ipiranga',
			'state' => 18,
		]);
		DB::table('cities')->insert([
			'id' => 2936, 
			'name' => 'Iporã',
			'state' => 18,
		]);
		DB::table('cities')->insert([
			'id' => 2937, 
			'name' => 'Iracema do Oeste',
			'state' => 18,
		]);
		DB::table('cities')->insert([
			'id' => 2938, 
			'name' => 'Irati',
			'state' => 18,
		]);
		DB::table('cities')->insert([
			'id' => 2939, 
			'name' => 'Iretama',
			'state' => 18,
		]);
		DB::table('cities')->insert([
			'id' => 2940, 
			'name' => 'Itaguajé',
			'state' => 18,
		]);
		DB::table('cities')->insert([
			'id' => 2941, 
			'name' => 'Itaipulândia',
			'state' => 18,
		]);
		DB::table('cities')->insert([
			'id' => 2942, 
			'name' => 'Itambaracá',
			'state' => 18,
		]);
		DB::table('cities')->insert([
			'id' => 2943, 
			'name' => 'Itambé',
			'state' => 18,
		]);
		DB::table('cities')->insert([
			'id' => 2944, 
			'name' => 'Itapejara d`Oeste',
			'state' => 18,
		]);
		DB::table('cities')->insert([
			'id' => 2945, 
			'name' => 'Itaperuçu',
			'state' => 18,
		]);
		DB::table('cities')->insert([
			'id' => 2946, 
			'name' => 'Itaúna do Sul',
			'state' => 18,
		]);
		DB::table('cities')->insert([
			'id' => 2947, 
			'name' => 'Ivaí',
			'state' => 18,
		]);
		DB::table('cities')->insert([
			'id' => 2948, 
			'name' => 'Ivaiporã',
			'state' => 18,
		]);
		DB::table('cities')->insert([
			'id' => 2949, 
			'name' => 'Ivaté',
			'state' => 18,
		]);
		DB::table('cities')->insert([
			'id' => 2950, 
			'name' => 'Ivatuba',
			'state' => 18,
		]);
		DB::table('cities')->insert([
			'id' => 2951, 
			'name' => 'Jaboti',
			'state' => 18,
		]);
		DB::table('cities')->insert([
			'id' => 2952, 
			'name' => 'Jacarezinho',
			'state' => 18,
		]);
		DB::table('cities')->insert([
			'id' => 2953, 
			'name' => 'Jaguapitã',
			'state' => 18,
		]);
		DB::table('cities')->insert([
			'id' => 2954, 
			'name' => 'Jaguariaíva',
			'state' => 18,
		]);
		DB::table('cities')->insert([
			'id' => 2955, 
			'name' => 'Jandaia do Sul',
			'state' => 18,
		]);
		DB::table('cities')->insert([
			'id' => 2956, 
			'name' => 'Janiópolis',
			'state' => 18,
		]);
		DB::table('cities')->insert([
			'id' => 2957, 
			'name' => 'Japira',
			'state' => 18,
		]);
		DB::table('cities')->insert([
			'id' => 2958, 
			'name' => 'Japurá',
			'state' => 18,
		]);
		DB::table('cities')->insert([
			'id' => 2959, 
			'name' => 'Jardim Alegre',
			'state' => 18,
		]);
		DB::table('cities')->insert([
			'id' => 2960, 
			'name' => 'Jardim Olinda',
			'state' => 18,
		]);
		DB::table('cities')->insert([
			'id' => 2961, 
			'name' => 'Jataizinho',
			'state' => 18,
		]);
		DB::table('cities')->insert([
			'id' => 2962, 
			'name' => 'Jesuítas',
			'state' => 18,
		]);
		DB::table('cities')->insert([
			'id' => 2963, 
			'name' => 'Joaquim Távora',
			'state' => 18,
		]);
		DB::table('cities')->insert([
			'id' => 2964, 
			'name' => 'Jundiaí do Sul',
			'state' => 18,
		]);
		DB::table('cities')->insert([
			'id' => 2965, 
			'name' => 'Juranda',
			'state' => 18,
		]);
		DB::table('cities')->insert([
			'id' => 2966, 
			'name' => 'Jussara',
			'state' => 18,
		]);
		DB::table('cities')->insert([
			'id' => 2967, 
			'name' => 'Kaloré',
			'state' => 18,
		]);
		DB::table('cities')->insert([
			'id' => 2968, 
			'name' => 'Lapa',
			'state' => 18,
		]);
		DB::table('cities')->insert([
			'id' => 2969, 
			'name' => 'Laranjal',
			'state' => 18,
		]);
		DB::table('cities')->insert([
			'id' => 2970, 
			'name' => 'Laranjeiras do Sul',
			'state' => 18,
		]);
		DB::table('cities')->insert([
			'id' => 2971, 
			'name' => 'Leópolis',
			'state' => 18,
		]);
		DB::table('cities')->insert([
			'id' => 2972, 
			'name' => 'Lidianópolis',
			'state' => 18,
		]);
		DB::table('cities')->insert([
			'id' => 2973, 
			'name' => 'Lindoeste',
			'state' => 18,
		]);
		DB::table('cities')->insert([
			'id' => 2974, 
			'name' => 'Loanda',
			'state' => 18,
		]);
		DB::table('cities')->insert([
			'id' => 2975, 
			'name' => 'Lobato',
			'state' => 18,
		]);
		DB::table('cities')->insert([
			'id' => 2976, 
			'name' => 'Londrina',
			'state' => 18,
		]);
		DB::table('cities')->insert([
			'id' => 2977, 
			'name' => 'Luiziana',
			'state' => 18,
		]);
		DB::table('cities')->insert([
			'id' => 2978, 
			'name' => 'Lunardelli',
			'state' => 18,
		]);
		DB::table('cities')->insert([
			'id' => 2979, 
			'name' => 'Lupionópolis',
			'state' => 18,
		]);
		DB::table('cities')->insert([
			'id' => 2980, 
			'name' => 'Mallet',
			'state' => 18,
		]);
		DB::table('cities')->insert([
			'id' => 2981, 
			'name' => 'Mamborê',
			'state' => 18,
		]);
		DB::table('cities')->insert([
			'id' => 2982, 
			'name' => 'Mandaguaçu',
			'state' => 18,
		]);
		DB::table('cities')->insert([
			'id' => 2983, 
			'name' => 'Mandaguari',
			'state' => 18,
		]);
		DB::table('cities')->insert([
			'id' => 2984, 
			'name' => 'Mandirituba',
			'state' => 18,
		]);
		DB::table('cities')->insert([
			'id' => 2985, 
			'name' => 'Manfrinópolis',
			'state' => 18,
		]);
		DB::table('cities')->insert([
			'id' => 2986, 
			'name' => 'Mangueirinha',
			'state' => 18,
		]);
		DB::table('cities')->insert([
			'id' => 2987, 
			'name' => 'Manoel Ribas',
			'state' => 18,
		]);
		DB::table('cities')->insert([
			'id' => 2988, 
			'name' => 'Marechal Cândido Rondon',
			'state' => 18,
		]);
		DB::table('cities')->insert([
			'id' => 2989, 
			'name' => 'Maria Helena',
			'state' => 18,
		]);
		DB::table('cities')->insert([
			'id' => 2990, 
			'name' => 'Marialva',
			'state' => 18,
		]);
		DB::table('cities')->insert([
			'id' => 2991, 
			'name' => 'Marilândia do Sul',
			'state' => 18,
		]);
		DB::table('cities')->insert([
			'id' => 2992, 
			'name' => 'Marilena',
			'state' => 18,
		]);
		DB::table('cities')->insert([
			'id' => 2993, 
			'name' => 'Mariluz',
			'state' => 18,
		]);
		DB::table('cities')->insert([
			'id' => 2994, 
			'name' => 'Maringá',
			'state' => 18,
		]);
		DB::table('cities')->insert([
			'id' => 2995, 
			'name' => 'Mariópolis',
			'state' => 18,
		]);
		DB::table('cities')->insert([
			'id' => 2996, 
			'name' => 'Maripá',
			'state' => 18,
		]);
		DB::table('cities')->insert([
			'id' => 2997, 
			'name' => 'Marmeleiro',
			'state' => 18,
		]);
		DB::table('cities')->insert([
			'id' => 2998, 
			'name' => 'Marquinho',
			'state' => 18,
		]);
		DB::table('cities')->insert([
			'id' => 2999, 
			'name' => 'Marumbi',
			'state' => 18,
		]);
		DB::table('cities')->insert([
			'id' => 3000, 
			'name' => 'Matelândia',
			'state' => 18,
		]);
		DB::table('cities')->insert([
			'id' => 3001, 
			'name' => 'Matinhos',
			'state' => 18,
		]);
		DB::table('cities')->insert([
			'id' => 3002, 
			'name' => 'Mato Rico',
			'state' => 18,
		]);
		DB::table('cities')->insert([
			'id' => 3003, 
			'name' => 'Mauá da Serra',
			'state' => 18,
		]);
		DB::table('cities')->insert([
			'id' => 3004, 
			'name' => 'Medianeira',
			'state' => 18,
		]);
		DB::table('cities')->insert([
			'id' => 3005, 
			'name' => 'Mercedes',
			'state' => 18,
		]);
		DB::table('cities')->insert([
			'id' => 3006, 
			'name' => 'Mirador',
			'state' => 18,
		]);
		DB::table('cities')->insert([
			'id' => 3007, 
			'name' => 'Miraselva',
			'state' => 18,
		]);
		DB::table('cities')->insert([
			'id' => 3008, 
			'name' => 'Missal',
			'state' => 18,
		]);
		DB::table('cities')->insert([
			'id' => 3009, 
			'name' => 'Moreira Sales',
			'state' => 18,
		]);
		DB::table('cities')->insert([
			'id' => 3010, 
			'name' => 'Morretes',
			'state' => 18,
		]);
		DB::table('cities')->insert([
			'id' => 3011, 
			'name' => 'Munhoz de Melo',
			'state' => 18,
		]);
		DB::table('cities')->insert([
			'id' => 3012, 
			'name' => 'Nossa Senhora das Graças',
			'state' => 18,
		]);
		DB::table('cities')->insert([
			'id' => 3013, 
			'name' => 'Nova Aliança do Ivaí',
			'state' => 18,
		]);
		DB::table('cities')->insert([
			'id' => 3014, 
			'name' => 'Nova América da Colina',
			'state' => 18,
		]);
		DB::table('cities')->insert([
			'id' => 3015, 
			'name' => 'Nova Aurora',
			'state' => 18,
		]);
		DB::table('cities')->insert([
			'id' => 3016, 
			'name' => 'Nova Cantu',
			'state' => 18,
		]);
		DB::table('cities')->insert([
			'id' => 3017, 
			'name' => 'Nova Esperança',
			'state' => 18,
		]);
		DB::table('cities')->insert([
			'id' => 3018, 
			'name' => 'Nova Esperança do Sudoeste',
			'state' => 18,
		]);
		DB::table('cities')->insert([
			'id' => 3019, 
			'name' => 'Nova Fátima',
			'state' => 18,
		]);
		DB::table('cities')->insert([
			'id' => 3020, 
			'name' => 'Nova Laranjeiras',
			'state' => 18,
		]);
		DB::table('cities')->insert([
			'id' => 3021, 
			'name' => 'Nova Londrina',
			'state' => 18,
		]);
		DB::table('cities')->insert([
			'id' => 3022, 
			'name' => 'Nova Olímpia',
			'state' => 18,
		]);
		DB::table('cities')->insert([
			'id' => 3023, 
			'name' => 'Nova Prata do Iguaçu',
			'state' => 18,
		]);
		DB::table('cities')->insert([
			'id' => 3024, 
			'name' => 'Nova Santa Bárbara',
			'state' => 18,
		]);
		DB::table('cities')->insert([
			'id' => 3025, 
			'name' => 'Nova Santa Rosa',
			'state' => 18,
		]);
		DB::table('cities')->insert([
			'id' => 3026, 
			'name' => 'Nova Tebas',
			'state' => 18,
		]);
		DB::table('cities')->insert([
			'id' => 3027, 
			'name' => 'Novo Itacolomi',
			'state' => 18,
		]);
		DB::table('cities')->insert([
			'id' => 3028, 
			'name' => 'Ortigueira',
			'state' => 18,
		]);
		DB::table('cities')->insert([
			'id' => 3029, 
			'name' => 'Ourizona',
			'state' => 18,
		]);
		DB::table('cities')->insert([
			'id' => 3030, 
			'name' => 'Ouro Verde do Oeste',
			'state' => 18,
		]);
		DB::table('cities')->insert([
			'id' => 3031, 
			'name' => 'Paiçandu',
			'state' => 18,
		]);
		DB::table('cities')->insert([
			'id' => 3032, 
			'name' => 'Palmas',
			'state' => 18,
		]);
		DB::table('cities')->insert([
			'id' => 3033, 
			'name' => 'Palmeira',
			'state' => 18,
		]);
		DB::table('cities')->insert([
			'id' => 3034, 
			'name' => 'Palmital',
			'state' => 18,
		]);
		DB::table('cities')->insert([
			'id' => 3035, 
			'name' => 'Palotina',
			'state' => 18,
		]);
		DB::table('cities')->insert([
			'id' => 3036, 
			'name' => 'Paraíso do Norte',
			'state' => 18,
		]);
		DB::table('cities')->insert([
			'id' => 3037, 
			'name' => 'Paranacities',
			'state' => 18,
		]);
		DB::table('cities')->insert([
			'id' => 3038, 
			'name' => 'Paranaguá',
			'state' => 18,
		]);
		DB::table('cities')->insert([
			'id' => 3039, 
			'name' => 'Paranapoema',
			'state' => 18,
		]);
		DB::table('cities')->insert([
			'id' => 3040, 
			'name' => 'Paranavaí',
			'state' => 18,
		]);
		DB::table('cities')->insert([
			'id' => 3041, 
			'name' => 'Pato Bragado',
			'state' => 18,
		]);
		DB::table('cities')->insert([
			'id' => 3042, 
			'name' => 'Pato Branco',
			'state' => 18,
		]);
		DB::table('cities')->insert([
			'id' => 3043, 
			'name' => 'Paula Freitas',
			'state' => 18,
		]);
		DB::table('cities')->insert([
			'id' => 3044, 
			'name' => 'Paulo Frontin',
			'state' => 18,
		]);
		DB::table('cities')->insert([
			'id' => 3045, 
			'name' => 'Peabiru',
			'state' => 18,
		]);
		DB::table('cities')->insert([
			'id' => 3046, 
			'name' => 'Perobal',
			'state' => 18,
		]);
		DB::table('cities')->insert([
			'id' => 3047, 
			'name' => 'Pérola',
			'state' => 18,
		]);
		DB::table('cities')->insert([
			'id' => 3048, 
			'name' => 'Pérola d`Oeste',
			'state' => 18,
		]);
		DB::table('cities')->insert([
			'id' => 3049, 
			'name' => 'Piên',
			'state' => 18,
		]);
		DB::table('cities')->insert([
			'id' => 3050, 
			'name' => 'Pinhais',
			'state' => 18,
		]);
		DB::table('cities')->insert([
			'id' => 3051, 
			'name' => 'Pinhal de São Bento',
			'state' => 18,
		]);
		DB::table('cities')->insert([
			'id' => 3052, 
			'name' => 'Pinhalão',
			'state' => 18,
		]);
		DB::table('cities')->insert([
			'id' => 3053, 
			'name' => 'Pinhão',
			'state' => 18,
		]);
		DB::table('cities')->insert([
			'id' => 3054, 
			'name' => 'Piraí do Sul',
			'state' => 18,
		]);
		DB::table('cities')->insert([
			'id' => 3055, 
			'name' => 'Piraquara',
			'state' => 18,
		]);
		DB::table('cities')->insert([
			'id' => 3056, 
			'name' => 'Pitanga',
			'state' => 18,
		]);
		DB::table('cities')->insert([
			'id' => 3057, 
			'name' => 'Pitangueiras',
			'state' => 18,
		]);
		DB::table('cities')->insert([
			'id' => 3058, 
			'name' => 'Planaltina do Paraná',
			'state' => 18,
		]);
		DB::table('cities')->insert([
			'id' => 3059, 
			'name' => 'Planalto',
			'state' => 18,
		]);
		DB::table('cities')->insert([
			'id' => 3060, 
			'name' => 'Ponta Grossa',
			'state' => 18,
		]);
		DB::table('cities')->insert([
			'id' => 3061, 
			'name' => 'Pontal do Paraná',
			'state' => 18,
		]);
		DB::table('cities')->insert([
			'id' => 3062, 
			'name' => 'Porecatu',
			'state' => 18,
		]);
		DB::table('cities')->insert([
			'id' => 3063, 
			'name' => 'Porto Amazonas',
			'state' => 18,
		]);
		DB::table('cities')->insert([
			'id' => 3064, 
			'name' => 'Porto Barreiro',
			'state' => 18,
		]);
		DB::table('cities')->insert([
			'id' => 3065, 
			'name' => 'Porto Rico',
			'state' => 18,
		]);
		DB::table('cities')->insert([
			'id' => 3066, 
			'name' => 'Porto Vitória',
			'state' => 18,
		]);
		DB::table('cities')->insert([
			'id' => 3067, 
			'name' => 'Prado Ferreira',
			'state' => 18,
		]);
		DB::table('cities')->insert([
			'id' => 3068, 
			'name' => 'Pranchita',
			'state' => 18,
		]);
		DB::table('cities')->insert([
			'id' => 3069, 
			'name' => 'Presidente Castelo Branco',
			'state' => 18,
		]);
		DB::table('cities')->insert([
			'id' => 3070, 
			'name' => 'Primeiro de Maio',
			'state' => 18,
		]);
		DB::table('cities')->insert([
			'id' => 3071, 
			'name' => 'Prudentópolis',
			'state' => 18,
		]);
		DB::table('cities')->insert([
			'id' => 3072, 
			'name' => 'Quarto Centenário',
			'state' => 18,
		]);
		DB::table('cities')->insert([
			'id' => 3073, 
			'name' => 'Quatiguá',
			'state' => 18,
		]);
		DB::table('cities')->insert([
			'id' => 3074, 
			'name' => 'Quatro Barras',
			'state' => 18,
		]);
		DB::table('cities')->insert([
			'id' => 3075, 
			'name' => 'Quatro Pontes',
			'state' => 18,
		]);
		DB::table('cities')->insert([
			'id' => 3076, 
			'name' => 'Quedas do Iguaçu',
			'state' => 18,
		]);
		DB::table('cities')->insert([
			'id' => 3077, 
			'name' => 'Querência do Norte',
			'state' => 18,
		]);
		DB::table('cities')->insert([
			'id' => 3078, 
			'name' => 'Quinta do Sol',
			'state' => 18,
		]);
		DB::table('cities')->insert([
			'id' => 3079, 
			'name' => 'Quitandinha',
			'state' => 18,
		]);
		DB::table('cities')->insert([
			'id' => 3080, 
			'name' => 'Ramilândia',
			'state' => 18,
		]);
		DB::table('cities')->insert([
			'id' => 3081, 
			'name' => 'Rancho Alegre',
			'state' => 18,
		]);
		DB::table('cities')->insert([
			'id' => 3082, 
			'name' => 'Rancho Alegre d`Oeste',
			'state' => 18,
		]);
		DB::table('cities')->insert([
			'id' => 3083, 
			'name' => 'Realeza',
			'state' => 18,
		]);
		DB::table('cities')->insert([
			'id' => 3084, 
			'name' => 'Rebouças',
			'state' => 18,
		]);
		DB::table('cities')->insert([
			'id' => 3085, 
			'name' => 'Renascença',
			'state' => 18,
		]);
		DB::table('cities')->insert([
			'id' => 3086, 
			'name' => 'Reserva',
			'state' => 18,
		]);
		DB::table('cities')->insert([
			'id' => 3087, 
			'name' => 'Reserva do Iguaçu',
			'state' => 18,
		]);
		DB::table('cities')->insert([
			'id' => 3088, 
			'name' => 'Ribeirão Claro',
			'state' => 18,
		]);
		DB::table('cities')->insert([
			'id' => 3089, 
			'name' => 'Ribeirão do Pinhal',
			'state' => 18,
		]);
		DB::table('cities')->insert([
			'id' => 3090, 
			'name' => 'Rio Azul',
			'state' => 18,
		]);
		DB::table('cities')->insert([
			'id' => 3091, 
			'name' => 'Rio Bom',
			'state' => 18,
		]);
		DB::table('cities')->insert([
			'id' => 3092, 
			'name' => 'Rio Bonito do Iguaçu',
			'state' => 18,
		]);
		DB::table('cities')->insert([
			'id' => 3093, 
			'name' => 'Rio Branco do Ivaí',
			'state' => 18,
		]);
		DB::table('cities')->insert([
			'id' => 3094, 
			'name' => 'Rio Branco do Sul',
			'state' => 18,
		]);
		DB::table('cities')->insert([
			'id' => 3095, 
			'name' => 'Rio Negro',
			'state' => 18,
		]);
		DB::table('cities')->insert([
			'id' => 3096, 
			'name' => 'Rolândia',
			'state' => 18,
		]);
		DB::table('cities')->insert([
			'id' => 3097, 
			'name' => 'Roncador',
			'state' => 18,
		]);
		DB::table('cities')->insert([
			'id' => 3098, 
			'name' => 'Rondon',
			'state' => 18,
		]);
		DB::table('cities')->insert([
			'id' => 3099, 
			'name' => 'Rosário do Ivaí',
			'state' => 18,
		]);
		DB::table('cities')->insert([
			'id' => 3100, 
			'name' => 'Sabáudia',
			'state' => 18,
		]);
		DB::table('cities')->insert([
			'id' => 3101, 
			'name' => 'Salgado Filho',
			'state' => 18,
		]);
		DB::table('cities')->insert([
			'id' => 3102, 
			'name' => 'Salto do Itararé',
			'state' => 18,
		]);
		DB::table('cities')->insert([
			'id' => 3103, 
			'name' => 'Salto do Lontra',
			'state' => 18,
		]);
		DB::table('cities')->insert([
			'id' => 3104, 
			'name' => 'Santa Amélia',
			'state' => 18,
		]);
		DB::table('cities')->insert([
			'id' => 3105, 
			'name' => 'Santa Cecília do Pavão',
			'state' => 18,
		]);
		DB::table('cities')->insert([
			'id' => 3106, 
			'name' => 'Santa Cruz de Monte Castelo',
			'state' => 18,
		]);
		DB::table('cities')->insert([
			'id' => 3107, 
			'name' => 'Santa Fé',
			'state' => 18,
		]);
		DB::table('cities')->insert([
			'id' => 3108, 
			'name' => 'Santa Helena',
			'state' => 18,
		]);
		DB::table('cities')->insert([
			'id' => 3109, 
			'name' => 'Santa Inês',
			'state' => 18,
		]);
		DB::table('cities')->insert([
			'id' => 3110, 
			'name' => 'Santa Isabel do Ivaí',
			'state' => 18,
		]);
		DB::table('cities')->insert([
			'id' => 3111, 
			'name' => 'Santa Izabel do Oeste',
			'state' => 18,
		]);
		DB::table('cities')->insert([
			'id' => 3112, 
			'name' => 'Santa Lúcia',
			'state' => 18,
		]);
		DB::table('cities')->insert([
			'id' => 3113, 
			'name' => 'Santa Maria do Oeste',
			'state' => 18,
		]);
		DB::table('cities')->insert([
			'id' => 3114, 
			'name' => 'Santa Mariana',
			'state' => 18,
		]);
		DB::table('cities')->insert([
			'id' => 3115, 
			'name' => 'Santa Mônica',
			'state' => 18,
		]);
		DB::table('cities')->insert([
			'id' => 3116, 
			'name' => 'Santa Tereza do Oeste',
			'state' => 18,
		]);
		DB::table('cities')->insert([
			'id' => 3117, 
			'name' => 'Santa Terezinha de Itaipu',
			'state' => 18,
		]);
		DB::table('cities')->insert([
			'id' => 3118, 
			'name' => 'Santana do Itararé',
			'state' => 18,
		]);
		DB::table('cities')->insert([
			'id' => 3119, 
			'name' => 'Santo Antônio da Platina',
			'state' => 18,
		]);
		DB::table('cities')->insert([
			'id' => 3120, 
			'name' => 'Santo Antônio do Caiuá',
			'state' => 18,
		]);
		DB::table('cities')->insert([
			'id' => 3121, 
			'name' => 'Santo Antônio do Paraíso',
			'state' => 18,
		]);
		DB::table('cities')->insert([
			'id' => 3122, 
			'name' => 'Santo Antônio do Sudoeste',
			'state' => 18,
		]);
		DB::table('cities')->insert([
			'id' => 3123, 
			'name' => 'Santo Inácio',
			'state' => 18,
		]);
		DB::table('cities')->insert([
			'id' => 3124, 
			'name' => 'São Carlos do Ivaí',
			'state' => 18,
		]);
		DB::table('cities')->insert([
			'id' => 3125, 
			'name' => 'São Jerônimo da Serra',
			'state' => 18,
		]);
		DB::table('cities')->insert([
			'id' => 3126, 
			'name' => 'São João',
			'state' => 18,
		]);
		DB::table('cities')->insert([
			'id' => 3127, 
			'name' => 'São João do Caiuá',
			'state' => 18,
		]);
		DB::table('cities')->insert([
			'id' => 3128, 
			'name' => 'São João do Ivaí',
			'state' => 18,
		]);
		DB::table('cities')->insert([
			'id' => 3129, 
			'name' => 'São João do Triunfo',
			'state' => 18,
		]);
		DB::table('cities')->insert([
			'id' => 3130, 
			'name' => 'São Jorge d`Oeste',
			'state' => 18,
		]);
		DB::table('cities')->insert([
			'id' => 3131, 
			'name' => 'São Jorge do Ivaí',
			'state' => 18,
		]);
		DB::table('cities')->insert([
			'id' => 3132, 
			'name' => 'São Jorge do Patrocínio',
			'state' => 18,
		]);
		DB::table('cities')->insert([
			'id' => 3133, 
			'name' => 'São José da Boa Vista',
			'state' => 18,
		]);
		DB::table('cities')->insert([
			'id' => 3134, 
			'name' => 'São José das Palmeiras',
			'state' => 18,
		]);
		DB::table('cities')->insert([
			'id' => 3135, 
			'name' => 'São José dos Pinhais',
			'state' => 18,
		]);
		DB::table('cities')->insert([
			'id' => 3136, 
			'name' => 'São Manoel do Paraná',
			'state' => 18,
		]);
		DB::table('cities')->insert([
			'id' => 3137, 
			'name' => 'São Mateus do Sul',
			'state' => 18,
		]);
		DB::table('cities')->insert([
			'id' => 3138, 
			'name' => 'São Miguel do Iguaçu',
			'state' => 18,
		]);
		DB::table('cities')->insert([
			'id' => 3139, 
			'name' => 'São Pedro do Iguaçu',
			'state' => 18,
		]);
		DB::table('cities')->insert([
			'id' => 3140, 
			'name' => 'São Pedro do Ivaí',
			'state' => 18,
		]);
		DB::table('cities')->insert([
			'id' => 3141, 
			'name' => 'São Pedro do Paraná',
			'state' => 18,
		]);
		DB::table('cities')->insert([
			'id' => 3142, 
			'name' => 'São Sebastião da Amoreira',
			'state' => 18,
		]);
		DB::table('cities')->insert([
			'id' => 3143, 
			'name' => 'São Tomé',
			'state' => 18,
		]);
		DB::table('cities')->insert([
			'id' => 3144, 
			'name' => 'Sapopema',
			'state' => 18,
		]);
		DB::table('cities')->insert([
			'id' => 3145, 
			'name' => 'Sarandi',
			'state' => 18,
		]);
		DB::table('cities')->insert([
			'id' => 3146, 
			'name' => 'Saudade do Iguaçu',
			'state' => 18,
		]);
		DB::table('cities')->insert([
			'id' => 3147, 
			'name' => 'Sengés',
			'state' => 18,
		]);
		DB::table('cities')->insert([
			'id' => 3148, 
			'name' => 'Serranópolis do Iguaçu',
			'state' => 18,
		]);
		DB::table('cities')->insert([
			'id' => 3149, 
			'name' => 'Sertaneja',
			'state' => 18,
		]);
		DB::table('cities')->insert([
			'id' => 3150, 
			'name' => 'Sertanópolis',
			'state' => 18,
		]);
		DB::table('cities')->insert([
			'id' => 3151, 
			'name' => 'Siqueira Campos',
			'state' => 18,
		]);
		DB::table('cities')->insert([
			'id' => 3152, 
			'name' => 'Sulina',
			'state' => 18,
		]);
		DB::table('cities')->insert([
			'id' => 3153, 
			'name' => 'Tamarana',
			'state' => 18,
		]);
		DB::table('cities')->insert([
			'id' => 3154, 
			'name' => 'Tamboara',
			'state' => 18,
		]);
		DB::table('cities')->insert([
			'id' => 3155, 
			'name' => 'Tapejara',
			'state' => 18,
		]);
		DB::table('cities')->insert([
			'id' => 3156, 
			'name' => 'Tapira',
			'state' => 18,
		]);
		DB::table('cities')->insert([
			'id' => 3157, 
			'name' => 'Teixeira Soares',
			'state' => 18,
		]);
		DB::table('cities')->insert([
			'id' => 3158, 
			'name' => 'Telêmaco Borba',
			'state' => 18,
		]);
		DB::table('cities')->insert([
			'id' => 3159, 
			'name' => 'Terra Boa',
			'state' => 18,
		]);
		DB::table('cities')->insert([
			'id' => 3160, 
			'name' => 'Terra Rica',
			'state' => 18,
		]);
		DB::table('cities')->insert([
			'id' => 3161, 
			'name' => 'Terra Roxa',
			'state' => 18,
		]);
		DB::table('cities')->insert([
			'id' => 3162, 
			'name' => 'Tibagi',
			'state' => 18,
		]);
		DB::table('cities')->insert([
			'id' => 3163, 
			'name' => 'Tijucas do Sul',
			'state' => 18,
		]);
		DB::table('cities')->insert([
			'id' => 3164, 
			'name' => 'Toledo',
			'state' => 18,
		]);
		DB::table('cities')->insert([
			'id' => 3165, 
			'name' => 'Tomazina',
			'state' => 18,
		]);
		DB::table('cities')->insert([
			'id' => 3166, 
			'name' => 'Três Barras do Paraná',
			'state' => 18,
		]);
		DB::table('cities')->insert([
			'id' => 3167, 
			'name' => 'Tunas do Paraná',
			'state' => 18,
		]);
		DB::table('cities')->insert([
			'id' => 3168, 
			'name' => 'Tuneiras do Oeste',
			'state' => 18,
		]);
		DB::table('cities')->insert([
			'id' => 3169, 
			'name' => 'Tupãssi',
			'state' => 18,
		]);
		DB::table('cities')->insert([
			'id' => 3170, 
			'name' => 'Turvo',
			'state' => 18,
		]);
		DB::table('cities')->insert([
			'id' => 3171, 
			'name' => 'Ubiratã',
			'state' => 18,
		]);
		DB::table('cities')->insert([
			'id' => 3172, 
			'name' => 'Umuarama',
			'state' => 18,
		]);
		DB::table('cities')->insert([
			'id' => 3173, 
			'name' => 'União da Vitória',
			'state' => 18,
		]);
		DB::table('cities')->insert([
			'id' => 3174, 
			'name' => 'Uniflor',
			'state' => 18,
		]);
		DB::table('cities')->insert([
			'id' => 3175, 
			'name' => 'Uraí',
			'state' => 18,
		]);
		DB::table('cities')->insert([
			'id' => 3176, 
			'name' => 'Ventania',
			'state' => 18,
		]);
		DB::table('cities')->insert([
			'id' => 3177, 
			'name' => 'Vera Cruz do Oeste',
			'state' => 18,
		]);
		DB::table('cities')->insert([
			'id' => 3178, 
			'name' => 'Verê',
			'state' => 18,
		]);
		DB::table('cities')->insert([
			'id' => 3179, 
			'name' => 'Virmond',
			'state' => 18,
		]);
		DB::table('cities')->insert([
			'id' => 3180, 
			'name' => 'Vitorino',
			'state' => 18,
		]);
		DB::table('cities')->insert([
			'id' => 3181, 
			'name' => 'Wenceslau Braz',
			'state' => 18,
		]);
		DB::table('cities')->insert([
			'id' => 3182, 
			'name' => 'Xambrê',
			'state' => 18,
		]);
		DB::table('cities')->insert([
			'id' => 3183, 
			'name' => 'Abreu e Lima',
			'state' => 16,
		]);
		DB::table('cities')->insert([
			'id' => 3184, 
			'name' => 'Afogados da Ingazeira',
			'state' => 16,
		]);
		DB::table('cities')->insert([
			'id' => 3185, 
			'name' => 'Afrânio',
			'state' => 16,
		]);
		DB::table('cities')->insert([
			'id' => 3186, 
			'name' => 'Agrestina',
			'state' => 16,
		]);
		DB::table('cities')->insert([
			'id' => 3187, 
			'name' => 'Água Preta',
			'state' => 16,
		]);
		DB::table('cities')->insert([
			'id' => 3188, 
			'name' => 'Águas Belas',
			'state' => 16,
		]);
		DB::table('cities')->insert([
			'id' => 3189, 
			'name' => 'Alagoinha',
			'state' => 16,
		]);
		DB::table('cities')->insert([
			'id' => 3190, 
			'name' => 'Aliança',
			'state' => 16,
		]);
		DB::table('cities')->insert([
			'id' => 3191, 
			'name' => 'Altinho',
			'state' => 16,
		]);
		DB::table('cities')->insert([
			'id' => 3192, 
			'name' => 'Amaraji',
			'state' => 16,
		]);
		DB::table('cities')->insert([
			'id' => 3193, 
			'name' => 'Angelim',
			'state' => 16,
		]);
		DB::table('cities')->insert([
			'id' => 3194, 
			'name' => 'Araçoiaba',
			'state' => 16,
		]);
		DB::table('cities')->insert([
			'id' => 3195, 
			'name' => 'Araripina',
			'state' => 16,
		]);
		DB::table('cities')->insert([
			'id' => 3196, 
			'name' => 'Arcoverde',
			'state' => 16,
		]);
		DB::table('cities')->insert([
			'id' => 3197, 
			'name' => 'Barra de Guabiraba',
			'state' => 16,
		]);
		DB::table('cities')->insert([
			'id' => 3198, 
			'name' => 'Barreiros',
			'state' => 16,
		]);
		DB::table('cities')->insert([
			'id' => 3199, 
			'name' => 'Belém de Maria',
			'state' => 16,
		]);
		DB::table('cities')->insert([
			'id' => 3200, 
			'name' => 'Belém de São Francisco',
			'state' => 16,
		]);
		DB::table('cities')->insert([
			'id' => 3201, 
			'name' => 'Belo Jardim',
			'state' => 16,
		]);
		DB::table('cities')->insert([
			'id' => 3202, 
			'name' => 'Betânia',
			'state' => 16,
		]);
		DB::table('cities')->insert([
			'id' => 3203, 
			'name' => 'Bezerros',
			'state' => 16,
		]);
		DB::table('cities')->insert([
			'id' => 3204, 
			'name' => 'Bodocó',
			'state' => 16,
		]);
		DB::table('cities')->insert([
			'id' => 3205, 
			'name' => 'Bom Conselho',
			'state' => 16,
		]);
		DB::table('cities')->insert([
			'id' => 3206, 
			'name' => 'Bom Jardim',
			'state' => 16,
		]);
		DB::table('cities')->insert([
			'id' => 3207, 
			'name' => 'Bonito',
			'state' => 16,
		]);
		DB::table('cities')->insert([
			'id' => 3208, 
			'name' => 'Brejão',
			'state' => 16,
		]);
		DB::table('cities')->insert([
			'id' => 3209, 
			'name' => 'Brejinho',
			'state' => 16,
		]);
		DB::table('cities')->insert([
			'id' => 3210, 
			'name' => 'Brejo da Madre de Deus',
			'state' => 16,
		]);
		DB::table('cities')->insert([
			'id' => 3211, 
			'name' => 'Buenos Aires',
			'state' => 16,
		]);
		DB::table('cities')->insert([
			'id' => 3212, 
			'name' => 'Buíque',
			'state' => 16,
		]);
		DB::table('cities')->insert([
			'id' => 3213, 
			'name' => 'Cabo de Santo Agostinho',
			'state' => 16,
		]);
		DB::table('cities')->insert([
			'id' => 3214, 
			'name' => 'Cabrobó',
			'state' => 16,
		]);
		DB::table('cities')->insert([
			'id' => 3215, 
			'name' => 'Cachoeirinha',
			'state' => 16,
		]);
		DB::table('cities')->insert([
			'id' => 3216, 
			'name' => 'Caetés',
			'state' => 16,
		]);
		DB::table('cities')->insert([
			'id' => 3217, 
			'name' => 'Calçado',
			'state' => 16,
		]);
		DB::table('cities')->insert([
			'id' => 3218, 
			'name' => 'Calumbi',
			'state' => 16,
		]);
		DB::table('cities')->insert([
			'id' => 3219, 
			'name' => 'Camaragibe',
			'state' => 16,
		]);
		DB::table('cities')->insert([
			'id' => 3220, 
			'name' => 'Camocim de São Félix',
			'state' => 16,
		]);
		DB::table('cities')->insert([
			'id' => 3221, 
			'name' => 'Camutanga',
			'state' => 16,
		]);
		DB::table('cities')->insert([
			'id' => 3222, 
			'name' => 'Canhotinho',
			'state' => 16,
		]);
		DB::table('cities')->insert([
			'id' => 3223, 
			'name' => 'Capoeiras',
			'state' => 16,
		]);
		DB::table('cities')->insert([
			'id' => 3224, 
			'name' => 'Carnaíba',
			'state' => 16,
		]);
		DB::table('cities')->insert([
			'id' => 3225, 
			'name' => 'Carnaubeira da Penha',
			'state' => 16,
		]);
		DB::table('cities')->insert([
			'id' => 3226, 
			'name' => 'Carpina',
			'state' => 16,
		]);
		DB::table('cities')->insert([
			'id' => 3227, 
			'name' => 'Caruaru',
			'state' => 16,
		]);
		DB::table('cities')->insert([
			'id' => 3228, 
			'name' => 'Casinhas',
			'state' => 16,
		]);
		DB::table('cities')->insert([
			'id' => 3229, 
			'name' => 'Catende',
			'state' => 16,
		]);
		DB::table('cities')->insert([
			'id' => 3230, 
			'name' => 'Cedro',
			'state' => 16,
		]);
		DB::table('cities')->insert([
			'id' => 3231, 
			'name' => 'Chã de Alegria',
			'state' => 16,
		]);
		DB::table('cities')->insert([
			'id' => 3232, 
			'name' => 'Chã Grande',
			'state' => 16,
		]);
		DB::table('cities')->insert([
			'id' => 3233, 
			'name' => 'Condado',
			'state' => 16,
		]);
		DB::table('cities')->insert([
			'id' => 3234, 
			'name' => 'Correntes',
			'state' => 16,
		]);
		DB::table('cities')->insert([
			'id' => 3235, 
			'name' => 'Cortês',
			'state' => 16,
		]);
		DB::table('cities')->insert([
			'id' => 3236, 
			'name' => 'Cumaru',
			'state' => 16,
		]);
		DB::table('cities')->insert([
			'id' => 3237, 
			'name' => 'Cupira',
			'state' => 16,
		]);
		DB::table('cities')->insert([
			'id' => 3238, 
			'name' => 'Custódia',
			'state' => 16,
		]);
		DB::table('cities')->insert([
			'id' => 3239, 
			'name' => 'Dormentes',
			'state' => 16,
		]);
		DB::table('cities')->insert([
			'id' => 3240, 
			'name' => 'Escada',
			'state' => 16,
		]);
		DB::table('cities')->insert([
			'id' => 3241, 
			'name' => 'Exu',
			'state' => 16,
		]);
		DB::table('cities')->insert([
			'id' => 3242, 
			'name' => 'Feira Nova',
			'state' => 16,
		]);
		DB::table('cities')->insert([
			'id' => 3243, 
			'name' => 'Fernando de Noronha',
			'state' => 16,
		]);
		DB::table('cities')->insert([
			'id' => 3244, 
			'name' => 'Ferreiros',
			'state' => 16,
		]);
		DB::table('cities')->insert([
			'id' => 3245, 
			'name' => 'Flores',
			'state' => 16,
		]);
		DB::table('cities')->insert([
			'id' => 3246, 
			'name' => 'Floresta',
			'state' => 16,
		]);
		DB::table('cities')->insert([
			'id' => 3247, 
			'name' => 'Frei Miguelinho',
			'state' => 16,
		]);
		DB::table('cities')->insert([
			'id' => 3248, 
			'name' => 'Gameleira',
			'state' => 16,
		]);
		DB::table('cities')->insert([
			'id' => 3249, 
			'name' => 'Garanhuns',
			'state' => 16,
		]);
		DB::table('cities')->insert([
			'id' => 3250, 
			'name' => 'Glória do Goitá',
			'state' => 16,
		]);
		DB::table('cities')->insert([
			'id' => 3251, 
			'name' => 'Goiana',
			'state' => 16,
		]);
		DB::table('cities')->insert([
			'id' => 3252, 
			'name' => 'Granito',
			'state' => 16,
		]);
		DB::table('cities')->insert([
			'id' => 3253, 
			'name' => 'Gravatá',
			'state' => 16,
		]);
		DB::table('cities')->insert([
			'id' => 3254, 
			'name' => 'Iati',
			'state' => 16,
		]);
		DB::table('cities')->insert([
			'id' => 3255, 
			'name' => 'Ibimirim',
			'state' => 16,
		]);
		DB::table('cities')->insert([
			'id' => 3256, 
			'name' => 'Ibirajuba',
			'state' => 16,
		]);
		DB::table('cities')->insert([
			'id' => 3257, 
			'name' => 'Igarassu',
			'state' => 16,
		]);
		DB::table('cities')->insert([
			'id' => 3258, 
			'name' => 'Iguaraci',
			'state' => 16,
		]);
		DB::table('cities')->insert([
			'id' => 3259, 
			'name' => 'Ilha de Itamaracá',
			'state' => 16,
		]);
		DB::table('cities')->insert([
			'id' => 3260, 
			'name' => 'Inajá',
			'state' => 16,
		]);
		DB::table('cities')->insert([
			'id' => 3261, 
			'name' => 'Ingazeira',
			'state' => 16,
		]);
		DB::table('cities')->insert([
			'id' => 3262, 
			'name' => 'Ipojuca',
			'state' => 16,
		]);
		DB::table('cities')->insert([
			'id' => 3263, 
			'name' => 'Ipubi',
			'state' => 16,
		]);
		DB::table('cities')->insert([
			'id' => 3264, 
			'name' => 'Itacuruba',
			'state' => 16,
		]);
		DB::table('cities')->insert([
			'id' => 3265, 
			'name' => 'Itaíba',
			'state' => 16,
		]);
		DB::table('cities')->insert([
			'id' => 3266, 
			'name' => 'Itambé',
			'state' => 16,
		]);
		DB::table('cities')->insert([
			'id' => 3267, 
			'name' => 'Itapetim',
			'state' => 16,
		]);
		DB::table('cities')->insert([
			'id' => 3268, 
			'name' => 'Itapissuma',
			'state' => 16,
		]);
		DB::table('cities')->insert([
			'id' => 3269, 
			'name' => 'Itaquitinga',
			'state' => 16,
		]);
		DB::table('cities')->insert([
			'id' => 3270, 
			'name' => 'Jaboatão dos Guararapes',
			'state' => 16,
		]);
		DB::table('cities')->insert([
			'id' => 3271, 
			'name' => 'Jaqueira',
			'state' => 16,
		]);
		DB::table('cities')->insert([
			'id' => 3272, 
			'name' => 'Jataúba',
			'state' => 16,
		]);
		DB::table('cities')->insert([
			'id' => 3273, 
			'name' => 'Jatobá',
			'state' => 16,
		]);
		DB::table('cities')->insert([
			'id' => 3274, 
			'name' => 'João Alfredo',
			'state' => 16,
		]);
		DB::table('cities')->insert([
			'id' => 3275, 
			'name' => 'Joaquim Nabuco',
			'state' => 16,
		]);
		DB::table('cities')->insert([
			'id' => 3276, 
			'name' => 'Jucati',
			'state' => 16,
		]);
		DB::table('cities')->insert([
			'id' => 3277, 
			'name' => 'Jupi',
			'state' => 16,
		]);
		DB::table('cities')->insert([
			'id' => 3278, 
			'name' => 'Jurema',
			'state' => 16,
		]);
		DB::table('cities')->insert([
			'id' => 3279, 
			'name' => 'Lagoa do Carro',
			'state' => 16,
		]);
		DB::table('cities')->insert([
			'id' => 3280, 
			'name' => 'Lagoa do Itaenga',
			'state' => 16,
		]);
		DB::table('cities')->insert([
			'id' => 3281, 
			'name' => 'Lagoa do Ouro',
			'state' => 16,
		]);
		DB::table('cities')->insert([
			'id' => 3282, 
			'name' => 'Lagoa dos Gatos',
			'state' => 16,
		]);
		DB::table('cities')->insert([
			'id' => 3283, 
			'name' => 'Lagoa Grande',
			'state' => 16,
		]);
		DB::table('cities')->insert([
			'id' => 3284, 
			'name' => 'Lajedo',
			'state' => 16,
		]);
		DB::table('cities')->insert([
			'id' => 3285, 
			'name' => 'Limoeiro',
			'state' => 16,
		]);
		DB::table('cities')->insert([
			'id' => 3286, 
			'name' => 'Macaparana',
			'state' => 16,
		]);
		DB::table('cities')->insert([
			'id' => 3287, 
			'name' => 'Machados',
			'state' => 16,
		]);
		DB::table('cities')->insert([
			'id' => 3288, 
			'name' => 'Manari',
			'state' => 16,
		]);
		DB::table('cities')->insert([
			'id' => 3289, 
			'name' => 'Maraial',
			'state' => 16,
		]);
		DB::table('cities')->insert([
			'id' => 3290, 
			'name' => 'Mirandiba',
			'state' => 16,
		]);
		DB::table('cities')->insert([
			'id' => 3291, 
			'name' => 'Moreilândia',
			'state' => 16,
		]);
		DB::table('cities')->insert([
			'id' => 3292, 
			'name' => 'Moreno',
			'state' => 16,
		]);
		DB::table('cities')->insert([
			'id' => 3293, 
			'name' => 'Nazaré da Mata',
			'state' => 16,
		]);
		DB::table('cities')->insert([
			'id' => 3294, 
			'name' => 'Olinda',
			'state' => 16,
		]);
		DB::table('cities')->insert([
			'id' => 3295, 
			'name' => 'Orobó',
			'state' => 16,
		]);
		DB::table('cities')->insert([
			'id' => 3296, 
			'name' => 'Orocó',
			'state' => 16,
		]);
		DB::table('cities')->insert([
			'id' => 3297, 
			'name' => 'Ouricuri',
			'state' => 16,
		]);
		DB::table('cities')->insert([
			'id' => 3298, 
			'name' => 'Palmares',
			'state' => 16,
		]);
		DB::table('cities')->insert([
			'id' => 3299, 
			'name' => 'Palmeirina',
			'state' => 16,
		]);
		DB::table('cities')->insert([
			'id' => 3300, 
			'name' => 'Panelas',
			'state' => 16,
		]);
		DB::table('cities')->insert([
			'id' => 3301, 
			'name' => 'Paranatama',
			'state' => 16,
		]);
		DB::table('cities')->insert([
			'id' => 3302, 
			'name' => 'Parnamirim',
			'state' => 16,
		]);
		DB::table('cities')->insert([
			'id' => 3303, 
			'name' => 'Passira',
			'state' => 16,
		]);
		DB::table('cities')->insert([
			'id' => 3304, 
			'name' => 'Paudalho',
			'state' => 16,
		]);
		DB::table('cities')->insert([
			'id' => 3305, 
			'name' => 'Paulista',
			'state' => 16,
		]);
		DB::table('cities')->insert([
			'id' => 3306, 
			'name' => 'Pedra',
			'state' => 16,
		]);
		DB::table('cities')->insert([
			'id' => 3307, 
			'name' => 'Pesqueira',
			'state' => 16,
		]);
		DB::table('cities')->insert([
			'id' => 3308, 
			'name' => 'Petrolândia',
			'state' => 16,
		]);
		DB::table('cities')->insert([
			'id' => 3309, 
			'name' => 'Petrolina',
			'state' => 16,
		]);
		DB::table('cities')->insert([
			'id' => 3310, 
			'name' => 'Poção',
			'state' => 16,
		]);
		DB::table('cities')->insert([
			'id' => 3311, 
			'name' => 'Pombos',
			'state' => 16,
		]);
		DB::table('cities')->insert([
			'id' => 3312, 
			'name' => 'Primavera',
			'state' => 16,
		]);
		DB::table('cities')->insert([
			'id' => 3313, 
			'name' => 'Quipapá',
			'state' => 16,
		]);
		DB::table('cities')->insert([
			'id' => 3314, 
			'name' => 'Quixaba',
			'state' => 16,
		]);
		DB::table('cities')->insert([
			'id' => 3315, 
			'name' => 'Recife',
			'state' => 16,
		]);
		DB::table('cities')->insert([
			'id' => 3316, 
			'name' => 'Riacho das Almas',
			'state' => 16,
		]);
		DB::table('cities')->insert([
			'id' => 3317, 
			'name' => 'Ribeirão',
			'state' => 16,
		]);
		DB::table('cities')->insert([
			'id' => 3318, 
			'name' => 'Rio Formoso',
			'state' => 16,
		]);
		DB::table('cities')->insert([
			'id' => 3319, 
			'name' => 'Sairé',
			'state' => 16,
		]);
		DB::table('cities')->insert([
			'id' => 3320, 
			'name' => 'Salgadinho',
			'state' => 16,
		]);
		DB::table('cities')->insert([
			'id' => 3321, 
			'name' => 'Salgueiro',
			'state' => 16,
		]);
		DB::table('cities')->insert([
			'id' => 3322, 
			'name' => 'Saloá',
			'state' => 16,
		]);
		DB::table('cities')->insert([
			'id' => 3323, 
			'name' => 'Sanharó',
			'state' => 16,
		]);
		DB::table('cities')->insert([
			'id' => 3324, 
			'name' => 'Santa Cruz',
			'state' => 16,
		]);
		DB::table('cities')->insert([
			'id' => 3325, 
			'name' => 'Santa Cruz da Baixa Verde',
			'state' => 16,
		]);
		DB::table('cities')->insert([
			'id' => 3326, 
			'name' => 'Santa Cruz do Capibaribe',
			'state' => 16,
		]);
		DB::table('cities')->insert([
			'id' => 3327, 
			'name' => 'Santa Filomena',
			'state' => 16,
		]);
		DB::table('cities')->insert([
			'id' => 3328, 
			'name' => 'Santa Maria da Boa Vista',
			'state' => 16,
		]);
		DB::table('cities')->insert([
			'id' => 3329, 
			'name' => 'Santa Maria do Cambucá',
			'state' => 16,
		]);
		DB::table('cities')->insert([
			'id' => 3330, 
			'name' => 'Santa Terezinha',
			'state' => 16,
		]);
		DB::table('cities')->insert([
			'id' => 3331, 
			'name' => 'São Benedito do Sul',
			'state' => 16,
		]);
		DB::table('cities')->insert([
			'id' => 3332, 
			'name' => 'São Bento do Una',
			'state' => 16,
		]);
		DB::table('cities')->insert([
			'id' => 3333, 
			'name' => 'São Caitano',
			'state' => 16,
		]);
		DB::table('cities')->insert([
			'id' => 3334, 
			'name' => 'São João',
			'state' => 16,
		]);
		DB::table('cities')->insert([
			'id' => 3335, 
			'name' => 'São Joaquim do Monte',
			'state' => 16,
		]);
		DB::table('cities')->insert([
			'id' => 3336, 
			'name' => 'São José da Coroa Grande',
			'state' => 16,
		]);
		DB::table('cities')->insert([
			'id' => 3337, 
			'name' => 'São José do Belmonte',
			'state' => 16,
		]);
		DB::table('cities')->insert([
			'id' => 3338, 
			'name' => 'São José do Egito',
			'state' => 16,
		]);
		DB::table('cities')->insert([
			'id' => 3339, 
			'name' => 'São Lourenço da Mata',
			'state' => 16,
		]);
		DB::table('cities')->insert([
			'id' => 3340, 
			'name' => 'São Vicente Ferrer',
			'state' => 16,
		]);
		DB::table('cities')->insert([
			'id' => 3341, 
			'name' => 'Serra Talhada',
			'state' => 16,
		]);
		DB::table('cities')->insert([
			'id' => 3342, 
			'name' => 'Serrita',
			'state' => 16,
		]);
		DB::table('cities')->insert([
			'id' => 3343, 
			'name' => 'Sertânia',
			'state' => 16,
		]);
		DB::table('cities')->insert([
			'id' => 3344, 
			'name' => 'Sirinhaém',
			'state' => 16,
		]);
		DB::table('cities')->insert([
			'id' => 3345, 
			'name' => 'Solidão',
			'state' => 16,
		]);
		DB::table('cities')->insert([
			'id' => 3346, 
			'name' => 'Surubim',
			'state' => 16,
		]);
		DB::table('cities')->insert([
			'id' => 3347, 
			'name' => 'Tabira',
			'state' => 16,
		]);
		DB::table('cities')->insert([
			'id' => 3348, 
			'name' => 'Tacaimbó',
			'state' => 16,
		]);
		DB::table('cities')->insert([
			'id' => 3349, 
			'name' => 'Tacaratu',
			'state' => 16,
		]);
		DB::table('cities')->insert([
			'id' => 3350, 
			'name' => 'Tamandaré',
			'state' => 16,
		]);
		DB::table('cities')->insert([
			'id' => 3351, 
			'name' => 'Taquaritinga do Norte',
			'state' => 16,
		]);
		DB::table('cities')->insert([
			'id' => 3352, 
			'name' => 'Terezinha',
			'state' => 16,
		]);
		DB::table('cities')->insert([
			'id' => 3353, 
			'name' => 'Terra Nova',
			'state' => 16,
		]);
		DB::table('cities')->insert([
			'id' => 3354, 
			'name' => 'Timbaúba',
			'state' => 16,
		]);
		DB::table('cities')->insert([
			'id' => 3355, 
			'name' => 'Toritama',
			'state' => 16,
		]);
		DB::table('cities')->insert([
			'id' => 3356, 
			'name' => 'Tracunhaém',
			'state' => 16,
		]);
		DB::table('cities')->insert([
			'id' => 3357, 
			'name' => 'Trindade',
			'state' => 16,
		]);
		DB::table('cities')->insert([
			'id' => 3358, 
			'name' => 'Triunfo',
			'state' => 16,
		]);
		DB::table('cities')->insert([
			'id' => 3359, 
			'name' => 'Tupanatinga',
			'state' => 16,
		]);
		DB::table('cities')->insert([
			'id' => 3360, 
			'name' => 'Tuparetama',
			'state' => 16,
		]);
		DB::table('cities')->insert([
			'id' => 3361, 
			'name' => 'Venturosa',
			'state' => 16,
		]);
		DB::table('cities')->insert([
			'id' => 3362, 
			'name' => 'Verdejante',
			'state' => 16,
		]);
		DB::table('cities')->insert([
			'id' => 3363, 
			'name' => 'Vertente do Lério',
			'state' => 16,
		]);
		DB::table('cities')->insert([
			'id' => 3364, 
			'name' => 'Vertentes',
			'state' => 16,
		]);
		DB::table('cities')->insert([
			'id' => 3365, 
			'name' => 'Vicência',
			'state' => 16,
		]);
		DB::table('cities')->insert([
			'id' => 3366, 
			'name' => 'Vitória de Santo Antão',
			'state' => 16,
		]);
		DB::table('cities')->insert([
			'id' => 3367, 
			'name' => 'Xexéu',
			'state' => 16,
		]);
		DB::table('cities')->insert([
			'id' => 3368, 
			'name' => 'Acauã',
			'state' => 17,
		]);
		DB::table('cities')->insert([
			'id' => 3369, 
			'name' => 'Agricolândia',
			'state' => 17,
		]);
		DB::table('cities')->insert([
			'id' => 3370, 
			'name' => 'Água Branca',
			'state' => 17,
		]);
		DB::table('cities')->insert([
			'id' => 3371, 
			'name' => 'Alagoinha do Piauí',
			'state' => 17,
		]);
		DB::table('cities')->insert([
			'id' => 3372, 
			'name' => 'Alegrete do Piauí',
			'state' => 17,
		]);
		DB::table('cities')->insert([
			'id' => 3373, 
			'name' => 'Alto Longá',
			'state' => 17,
		]);
		DB::table('cities')->insert([
			'id' => 3374, 
			'name' => 'Altos',
			'state' => 17,
		]);
		DB::table('cities')->insert([
			'id' => 3375, 
			'name' => 'Alvorada do Gurguéia',
			'state' => 17,
		]);
		DB::table('cities')->insert([
			'id' => 3376, 
			'name' => 'Amarante',
			'state' => 17,
		]);
		DB::table('cities')->insert([
			'id' => 3377, 
			'name' => 'Angical do Piauí',
			'state' => 17,
		]);
		DB::table('cities')->insert([
			'id' => 3378, 
			'name' => 'Anísio de Abreu',
			'state' => 17,
		]);
		DB::table('cities')->insert([
			'id' => 3379, 
			'name' => 'Antônio Almeida',
			'state' => 17,
		]);
		DB::table('cities')->insert([
			'id' => 3380, 
			'name' => 'Aroazes',
			'state' => 17,
		]);
		DB::table('cities')->insert([
			'id' => 3381, 
			'name' => 'Aroeiras do Itaim',
			'state' => 17,
		]);
		DB::table('cities')->insert([
			'id' => 3382, 
			'name' => 'Arraial',
			'state' => 17,
		]);
		DB::table('cities')->insert([
			'id' => 3383, 
			'name' => 'Assunção do Piauí',
			'state' => 17,
		]);
		DB::table('cities')->insert([
			'id' => 3384, 
			'name' => 'Avelino Lopes',
			'state' => 17,
		]);
		DB::table('cities')->insert([
			'id' => 3385, 
			'name' => 'Baixa Grande do Ribeiro',
			'state' => 17,
		]);
		DB::table('cities')->insert([
			'id' => 3386, 
			'name' => 'Barra d`Alcântara',
			'state' => 17,
		]);
		DB::table('cities')->insert([
			'id' => 3387, 
			'name' => 'Barras',
			'state' => 17,
		]);
		DB::table('cities')->insert([
			'id' => 3388, 
			'name' => 'Barreiras do Piauí',
			'state' => 17,
		]);
		DB::table('cities')->insert([
			'id' => 3389, 
			'name' => 'Barro Duro',
			'state' => 17,
		]);
		DB::table('cities')->insert([
			'id' => 3390, 
			'name' => 'Batalha',
			'state' => 17,
		]);
		DB::table('cities')->insert([
			'id' => 3391, 
			'name' => 'Bela Vista do Piauí',
			'state' => 17,
		]);
		DB::table('cities')->insert([
			'id' => 3392, 
			'name' => 'Belém do Piauí',
			'state' => 17,
		]);
		DB::table('cities')->insert([
			'id' => 3393, 
			'name' => 'Beneditinos',
			'state' => 17,
		]);
		DB::table('cities')->insert([
			'id' => 3394, 
			'name' => 'Bertolínia',
			'state' => 17,
		]);
		DB::table('cities')->insert([
			'id' => 3395, 
			'name' => 'Betânia do Piauí',
			'state' => 17,
		]);
		DB::table('cities')->insert([
			'id' => 3396, 
			'name' => 'Boa Hora',
			'state' => 17,
		]);
		DB::table('cities')->insert([
			'id' => 3397, 
			'name' => 'Bocaina',
			'state' => 17,
		]);
		DB::table('cities')->insert([
			'id' => 3398, 
			'name' => 'Bom Jesus',
			'state' => 17,
		]);
		DB::table('cities')->insert([
			'id' => 3399, 
			'name' => 'Bom Princípio do Piauí',
			'state' => 17,
		]);
		DB::table('cities')->insert([
			'id' => 3400, 
			'name' => 'Bonfim do Piauí',
			'state' => 17,
		]);
		DB::table('cities')->insert([
			'id' => 3401, 
			'name' => 'Boqueirão do Piauí',
			'state' => 17,
		]);
		DB::table('cities')->insert([
			'id' => 3402, 
			'name' => 'Brasileira',
			'state' => 17,
		]);
		DB::table('cities')->insert([
			'id' => 3403, 
			'name' => 'Brejo do Piauí',
			'state' => 17,
		]);
		DB::table('cities')->insert([
			'id' => 3404, 
			'name' => 'Buriti dos Lopes',
			'state' => 17,
		]);
		DB::table('cities')->insert([
			'id' => 3405, 
			'name' => 'Buriti dos Montes',
			'state' => 17,
		]);
		DB::table('cities')->insert([
			'id' => 3406, 
			'name' => 'Cabeceiras do Piauí',
			'state' => 17,
		]);
		DB::table('cities')->insert([
			'id' => 3407, 
			'name' => 'Cajazeiras do Piauí',
			'state' => 17,
		]);
		DB::table('cities')->insert([
			'id' => 3408, 
			'name' => 'Cajueiro da Praia',
			'state' => 17,
		]);
		DB::table('cities')->insert([
			'id' => 3409, 
			'name' => 'Caldeirão Grande do Piauí',
			'state' => 17,
		]);
		DB::table('cities')->insert([
			'id' => 3410, 
			'name' => 'Campinas do Piauí',
			'state' => 17,
		]);
		DB::table('cities')->insert([
			'id' => 3411, 
			'name' => 'Campo Alegre do Fidalgo',
			'state' => 17,
		]);
		DB::table('cities')->insert([
			'id' => 3412, 
			'name' => 'Campo Grande do Piauí',
			'state' => 17,
		]);
		DB::table('cities')->insert([
			'id' => 3413, 
			'name' => 'Campo Largo do Piauí',
			'state' => 17,
		]);
		DB::table('cities')->insert([
			'id' => 3414, 
			'name' => 'Campo Maior',
			'state' => 17,
		]);
		DB::table('cities')->insert([
			'id' => 3415, 
			'name' => 'Canavieira',
			'state' => 17,
		]);
		DB::table('cities')->insert([
			'id' => 3416, 
			'name' => 'Canto do Buriti',
			'state' => 17,
		]);
		DB::table('cities')->insert([
			'id' => 3417, 
			'name' => 'Capitão de Campos',
			'state' => 17,
		]);
		DB::table('cities')->insert([
			'id' => 3418, 
			'name' => 'Capitão Gervásio Oliveira',
			'state' => 17,
		]);
		DB::table('cities')->insert([
			'id' => 3419, 
			'name' => 'Caracol',
			'state' => 17,
		]);
		DB::table('cities')->insert([
			'id' => 3420, 
			'name' => 'Caraúbas do Piauí',
			'state' => 17,
		]);
		DB::table('cities')->insert([
			'id' => 3421, 
			'name' => 'Caridade do Piauí',
			'state' => 17,
		]);
		DB::table('cities')->insert([
			'id' => 3422, 
			'name' => 'Castelo do Piauí',
			'state' => 17,
		]);
		DB::table('cities')->insert([
			'id' => 3423, 
			'name' => 'Caxingó',
			'state' => 17,
		]);
		DB::table('cities')->insert([
			'id' => 3424, 
			'name' => 'Cocal',
			'state' => 17,
		]);
		DB::table('cities')->insert([
			'id' => 3425, 
			'name' => 'Cocal de Telha',
			'state' => 17,
		]);
		DB::table('cities')->insert([
			'id' => 3426, 
			'name' => 'Cocal dos Alves',
			'state' => 17,
		]);
		DB::table('cities')->insert([
			'id' => 3427, 
			'name' => 'Coivaras',
			'state' => 17,
		]);
		DB::table('cities')->insert([
			'id' => 3428, 
			'name' => 'Colônia do Gurguéia',
			'state' => 17,
		]);
		DB::table('cities')->insert([
			'id' => 3429, 
			'name' => 'Colônia do Piauí',
			'state' => 17,
		]);
		DB::table('cities')->insert([
			'id' => 3430, 
			'name' => 'Conceição do Canindé',
			'state' => 17,
		]);
		DB::table('cities')->insert([
			'id' => 3431, 
			'name' => 'Coronel José Dias',
			'state' => 17,
		]);
		DB::table('cities')->insert([
			'id' => 3432, 
			'name' => 'Corrente',
			'state' => 17,
		]);
		DB::table('cities')->insert([
			'id' => 3433, 
			'name' => 'Cristalândia do Piauí',
			'state' => 17,
		]);
		DB::table('cities')->insert([
			'id' => 3434, 
			'name' => 'Cristino Castro',
			'state' => 17,
		]);
		DB::table('cities')->insert([
			'id' => 3435, 
			'name' => 'Curimatá',
			'state' => 17,
		]);
		DB::table('cities')->insert([
			'id' => 3436, 
			'name' => 'Currais',
			'state' => 17,
		]);
		DB::table('cities')->insert([
			'id' => 3437, 
			'name' => 'Curral Novo do Piauí',
			'state' => 17,
		]);
		DB::table('cities')->insert([
			'id' => 3438, 
			'name' => 'Curralinhos',
			'state' => 17,
		]);
		DB::table('cities')->insert([
			'id' => 3439, 
			'name' => 'Demerval Lobão',
			'state' => 17,
		]);
		DB::table('cities')->insert([
			'id' => 3440, 
			'name' => 'Dirceu Arcoverde',
			'state' => 17,
		]);
		DB::table('cities')->insert([
			'id' => 3441, 
			'name' => 'Dom Expedito Lopes',
			'state' => 17,
		]);
		DB::table('cities')->insert([
			'id' => 3442, 
			'name' => 'Dom Inocêncio',
			'state' => 17,
		]);
		DB::table('cities')->insert([
			'id' => 3443, 
			'name' => 'Domingos Mourão',
			'state' => 17,
		]);
		DB::table('cities')->insert([
			'id' => 3444, 
			'name' => 'Elesbão Veloso',
			'state' => 17,
		]);
		DB::table('cities')->insert([
			'id' => 3445, 
			'name' => 'Eliseu Martins',
			'state' => 17,
		]);
		DB::table('cities')->insert([
			'id' => 3446, 
			'name' => 'Esperantina',
			'state' => 17,
		]);
		DB::table('cities')->insert([
			'id' => 3447, 
			'name' => 'Fartura do Piauí',
			'state' => 17,
		]);
		DB::table('cities')->insert([
			'id' => 3448, 
			'name' => 'Flores do Piauí',
			'state' => 17,
		]);
		DB::table('cities')->insert([
			'id' => 3449, 
			'name' => 'Floresta do Piauí',
			'state' => 17,
		]);
		DB::table('cities')->insert([
			'id' => 3450, 
			'name' => 'Floriano',
			'state' => 17,
		]);
		DB::table('cities')->insert([
			'id' => 3451, 
			'name' => 'Francinópolis',
			'state' => 17,
		]);
		DB::table('cities')->insert([
			'id' => 3452, 
			'name' => 'Francisco Ayres',
			'state' => 17,
		]);
		DB::table('cities')->insert([
			'id' => 3453, 
			'name' => 'Francisco Macedo',
			'state' => 17,
		]);
		DB::table('cities')->insert([
			'id' => 3454, 
			'name' => 'Francisco Santos',
			'state' => 17,
		]);
		DB::table('cities')->insert([
			'id' => 3455, 
			'name' => 'Fronteiras',
			'state' => 17,
		]);
		DB::table('cities')->insert([
			'id' => 3456, 
			'name' => 'Geminiano',
			'state' => 17,
		]);
		DB::table('cities')->insert([
			'id' => 3457, 
			'name' => 'Gilbués',
			'state' => 17,
		]);
		DB::table('cities')->insert([
			'id' => 3458, 
			'name' => 'Guadalupe',
			'state' => 17,
		]);
		DB::table('cities')->insert([
			'id' => 3459, 
			'name' => 'Guaribas',
			'state' => 17,
		]);
		DB::table('cities')->insert([
			'id' => 3460, 
			'name' => 'Hugo Napoleão',
			'state' => 17,
		]);
		DB::table('cities')->insert([
			'id' => 3461, 
			'name' => 'Ilha Grande',
			'state' => 17,
		]);
		DB::table('cities')->insert([
			'id' => 3462, 
			'name' => 'Inhuma',
			'state' => 17,
		]);
		DB::table('cities')->insert([
			'id' => 3463, 
			'name' => 'Ipiranga do Piauí',
			'state' => 17,
		]);
		DB::table('cities')->insert([
			'id' => 3464, 
			'name' => 'Isaías Coelho',
			'state' => 17,
		]);
		DB::table('cities')->insert([
			'id' => 3465, 
			'name' => 'Itainópolis',
			'state' => 17,
		]);
		DB::table('cities')->insert([
			'id' => 3466, 
			'name' => 'Itaueira',
			'state' => 17,
		]);
		DB::table('cities')->insert([
			'id' => 3467, 
			'name' => 'Jacobina do Piauí',
			'state' => 17,
		]);
		DB::table('cities')->insert([
			'id' => 3468, 
			'name' => 'Jaicós',
			'state' => 17,
		]);
		DB::table('cities')->insert([
			'id' => 3469, 
			'name' => 'Jardim do Mulato',
			'state' => 17,
		]);
		DB::table('cities')->insert([
			'id' => 3470, 
			'name' => 'Jatobá do Piauí',
			'state' => 17,
		]);
		DB::table('cities')->insert([
			'id' => 3471, 
			'name' => 'Jerumenha',
			'state' => 17,
		]);
		DB::table('cities')->insert([
			'id' => 3472, 
			'name' => 'João Costa',
			'state' => 17,
		]);
		DB::table('cities')->insert([
			'id' => 3473, 
			'name' => 'Joaquim Pires',
			'state' => 17,
		]);
		DB::table('cities')->insert([
			'id' => 3474, 
			'name' => 'Joca Marques',
			'state' => 17,
		]);
		DB::table('cities')->insert([
			'id' => 3475, 
			'name' => 'José de Freitas',
			'state' => 17,
		]);
		DB::table('cities')->insert([
			'id' => 3476, 
			'name' => 'Juazeiro do Piauí',
			'state' => 17,
		]);
		DB::table('cities')->insert([
			'id' => 3477, 
			'name' => 'Júlio Borges',
			'state' => 17,
		]);
		DB::table('cities')->insert([
			'id' => 3478, 
			'name' => 'Jurema',
			'state' => 17,
		]);
		DB::table('cities')->insert([
			'id' => 3479, 
			'name' => 'Lagoa Alegre',
			'state' => 17,
		]);
		DB::table('cities')->insert([
			'id' => 3480, 
			'name' => 'Lagoa de São Francisco',
			'state' => 17,
		]);
		DB::table('cities')->insert([
			'id' => 3481, 
			'name' => 'Lagoa do Barro do Piauí',
			'state' => 17,
		]);
		DB::table('cities')->insert([
			'id' => 3482, 
			'name' => 'Lagoa do Piauí',
			'state' => 17,
		]);
		DB::table('cities')->insert([
			'id' => 3483, 
			'name' => 'Lagoa do Sítio',
			'state' => 17,
		]);
		DB::table('cities')->insert([
			'id' => 3484, 
			'name' => 'Lagoinha do Piauí',
			'state' => 17,
		]);
		DB::table('cities')->insert([
			'id' => 3485, 
			'name' => 'Landri Sales',
			'state' => 17,
		]);
		DB::table('cities')->insert([
			'id' => 3486, 
			'name' => 'Luís Correia',
			'state' => 17,
		]);
		DB::table('cities')->insert([
			'id' => 3487, 
			'name' => 'Luzilândia',
			'state' => 17,
		]);
		DB::table('cities')->insert([
			'id' => 3488, 
			'name' => 'Madeiro',
			'state' => 17,
		]);
		DB::table('cities')->insert([
			'id' => 3489, 
			'name' => 'Manoel Emídio',
			'state' => 17,
		]);
		DB::table('cities')->insert([
			'id' => 3490, 
			'name' => 'Marcolândia',
			'state' => 17,
		]);
		DB::table('cities')->insert([
			'id' => 3491, 
			'name' => 'Marcos Parente',
			'state' => 17,
		]);
		DB::table('cities')->insert([
			'id' => 3492, 
			'name' => 'Massapê do Piauí',
			'state' => 17,
		]);
		DB::table('cities')->insert([
			'id' => 3493, 
			'name' => 'Matias Olímpio',
			'state' => 17,
		]);
		DB::table('cities')->insert([
			'id' => 3494, 
			'name' => 'Miguel Alves',
			'state' => 17,
		]);
		DB::table('cities')->insert([
			'id' => 3495, 
			'name' => 'Miguel Leão',
			'state' => 17,
		]);
		DB::table('cities')->insert([
			'id' => 3496, 
			'name' => 'Milton Brandão',
			'state' => 17,
		]);
		DB::table('cities')->insert([
			'id' => 3497, 
			'name' => 'Monsenhor Gil',
			'state' => 17,
		]);
		DB::table('cities')->insert([
			'id' => 3498, 
			'name' => 'Monsenhor Hipólito',
			'state' => 17,
		]);
		DB::table('cities')->insert([
			'id' => 3499, 
			'name' => 'Monte Alegre do Piauí',
			'state' => 17,
		]);
		DB::table('cities')->insert([
			'id' => 3500, 
			'name' => 'Morro Cabeça no Tempo',
			'state' => 17,
		]);
		DB::table('cities')->insert([
			'id' => 3501, 
			'name' => 'Morro do Chapéu do Piauí',
			'state' => 17,
		]);
		DB::table('cities')->insert([
			'id' => 3502, 
			'name' => 'Murici dos Portelas',
			'state' => 17,
		]);
		DB::table('cities')->insert([
			'id' => 3503, 
			'name' => 'Nazaré do Piauí',
			'state' => 17,
		]);
		DB::table('cities')->insert([
			'id' => 3504, 
			'name' => 'Nossa Senhora de Nazaré',
			'state' => 17,
		]);
		DB::table('cities')->insert([
			'id' => 3505, 
			'name' => 'Nossa Senhora dos Remédios',
			'state' => 17,
		]);
		DB::table('cities')->insert([
			'id' => 3506, 
			'name' => 'Nova Santa Rita',
			'state' => 17,
		]);
		DB::table('cities')->insert([
			'id' => 3507, 
			'name' => 'Novo Oriente do Piauí',
			'state' => 17,
		]);
		DB::table('cities')->insert([
			'id' => 3508, 
			'name' => 'Novo Santo Antônio',
			'state' => 17,
		]);
		DB::table('cities')->insert([
			'id' => 3509, 
			'name' => 'Oeiras',
			'state' => 17,
		]);
		DB::table('cities')->insert([
			'id' => 3510, 
			'name' => 'Olho d`Água do Piauí',
			'state' => 17,
		]);
		DB::table('cities')->insert([
			'id' => 3511, 
			'name' => 'Padre Marcos',
			'state' => 17,
		]);
		DB::table('cities')->insert([
			'id' => 3512, 
			'name' => 'Paes Landim',
			'state' => 17,
		]);
		DB::table('cities')->insert([
			'id' => 3513, 
			'name' => 'Pajeú do Piauí',
			'state' => 17,
		]);
		DB::table('cities')->insert([
			'id' => 3514, 
			'name' => 'Palmeira do Piauí',
			'state' => 17,
		]);
		DB::table('cities')->insert([
			'id' => 3515, 
			'name' => 'Palmeirais',
			'state' => 17,
		]);
		DB::table('cities')->insert([
			'id' => 3516, 
			'name' => 'Paquetá',
			'state' => 17,
		]);
		DB::table('cities')->insert([
			'id' => 3517, 
			'name' => 'Parnaguá',
			'state' => 17,
		]);
		DB::table('cities')->insert([
			'id' => 3518, 
			'name' => 'Parnaíba',
			'state' => 17,
		]);
		DB::table('cities')->insert([
			'id' => 3519, 
			'name' => 'Passagem Franca do Piauí',
			'state' => 17,
		]);
		DB::table('cities')->insert([
			'id' => 3520, 
			'name' => 'Patos do Piauí',
			'state' => 17,
		]);
		DB::table('cities')->insert([
			'id' => 3521, 
			'name' => 'Pau d`Arco do Piauí',
			'state' => 17,
		]);
		DB::table('cities')->insert([
			'id' => 3522, 
			'name' => 'Paulistana',
			'state' => 17,
		]);
		DB::table('cities')->insert([
			'id' => 3523, 
			'name' => 'Pavussu',
			'state' => 17,
		]);
		DB::table('cities')->insert([
			'id' => 3524, 
			'name' => 'Pedro II',
			'state' => 17,
		]);
		DB::table('cities')->insert([
			'id' => 3525, 
			'name' => 'Pedro Laurentino',
			'state' => 17,
		]);
		DB::table('cities')->insert([
			'id' => 3526, 
			'name' => 'Picos',
			'state' => 17,
		]);
		DB::table('cities')->insert([
			'id' => 3527, 
			'name' => 'Pimenteiras',
			'state' => 17,
		]);
		DB::table('cities')->insert([
			'id' => 3528, 
			'name' => 'Pio IX',
			'state' => 17,
		]);
		DB::table('cities')->insert([
			'id' => 3529, 
			'name' => 'Piracuruca',
			'state' => 17,
		]);
		DB::table('cities')->insert([
			'id' => 3530, 
			'name' => 'Piripiri',
			'state' => 17,
		]);
		DB::table('cities')->insert([
			'id' => 3531, 
			'name' => 'Porto',
			'state' => 17,
		]);
		DB::table('cities')->insert([
			'id' => 3532, 
			'name' => 'Porto Alegre do Piauí',
			'state' => 17,
		]);
		DB::table('cities')->insert([
			'id' => 3533, 
			'name' => 'Prata do Piauí',
			'state' => 17,
		]);
		DB::table('cities')->insert([
			'id' => 3534, 
			'name' => 'Queimada Nova',
			'state' => 17,
		]);
		DB::table('cities')->insert([
			'id' => 3535, 
			'name' => 'Redenção do Gurguéia',
			'state' => 17,
		]);
		DB::table('cities')->insert([
			'id' => 3536, 
			'name' => 'Regeneração',
			'state' => 17,
		]);
		DB::table('cities')->insert([
			'id' => 3537, 
			'name' => 'Riacho Frio',
			'state' => 17,
		]);
		DB::table('cities')->insert([
			'id' => 3538, 
			'name' => 'Ribeira do Piauí',
			'state' => 17,
		]);
		DB::table('cities')->insert([
			'id' => 3539, 
			'name' => 'Ribeiro Gonçalves',
			'state' => 17,
		]);
		DB::table('cities')->insert([
			'id' => 3540, 
			'name' => 'Rio Grande do Piauí',
			'state' => 17,
		]);
		DB::table('cities')->insert([
			'id' => 3541, 
			'name' => 'Santa Cruz do Piauí',
			'state' => 17,
		]);
		DB::table('cities')->insert([
			'id' => 3542, 
			'name' => 'Santa Cruz dos Milagres',
			'state' => 17,
		]);
		DB::table('cities')->insert([
			'id' => 3543, 
			'name' => 'Santa Filomena',
			'state' => 17,
		]);
		DB::table('cities')->insert([
			'id' => 3544, 
			'name' => 'Santa Luz',
			'state' => 17,
		]);
		DB::table('cities')->insert([
			'id' => 3545, 
			'name' => 'Santa Rosa do Piauí',
			'state' => 17,
		]);
		DB::table('cities')->insert([
			'id' => 3546, 
			'name' => 'Santana do Piauí',
			'state' => 17,
		]);
		DB::table('cities')->insert([
			'id' => 3547, 
			'name' => 'Santo Antônio de Lisboa',
			'state' => 17,
		]);
		DB::table('cities')->insert([
			'id' => 3548, 
			'name' => 'Santo Antônio dos Milagres',
			'state' => 17,
		]);
		DB::table('cities')->insert([
			'id' => 3549, 
			'name' => 'Santo Inácio do Piauí',
			'state' => 17,
		]);
		DB::table('cities')->insert([
			'id' => 3550, 
			'name' => 'São Braz do Piauí',
			'state' => 17,
		]);
		DB::table('cities')->insert([
			'id' => 3551, 
			'name' => 'São Félix do Piauí',
			'state' => 17,
		]);
		DB::table('cities')->insert([
			'id' => 3552, 
			'name' => 'São Francisco de Assis do Piauí',
			'state' => 17,
		]);
		DB::table('cities')->insert([
			'id' => 3553, 
			'name' => 'São Francisco do Piauí',
			'state' => 17,
		]);
		DB::table('cities')->insert([
			'id' => 3554, 
			'name' => 'São Gonçalo do Gurguéia',
			'state' => 17,
		]);
		DB::table('cities')->insert([
			'id' => 3555, 
			'name' => 'São Gonçalo do Piauí',
			'state' => 17,
		]);
		DB::table('cities')->insert([
			'id' => 3556, 
			'name' => 'São João da Canabrava',
			'state' => 17,
		]);
		DB::table('cities')->insert([
			'id' => 3557, 
			'name' => 'São João da Fronteira',
			'state' => 17,
		]);
		DB::table('cities')->insert([
			'id' => 3558, 
			'name' => 'São João da Serra',
			'state' => 17,
		]);
		DB::table('cities')->insert([
			'id' => 3559, 
			'name' => 'São João da Varjota',
			'state' => 17,
		]);
		DB::table('cities')->insert([
			'id' => 3560, 
			'name' => 'São João do Arraial',
			'state' => 17,
		]);
		DB::table('cities')->insert([
			'id' => 3561, 
			'name' => 'São João do Piauí',
			'state' => 17,
		]);
		DB::table('cities')->insert([
			'id' => 3562, 
			'name' => 'São José do Divino',
			'state' => 17,
		]);
		DB::table('cities')->insert([
			'id' => 3563, 
			'name' => 'São José do Peixe',
			'state' => 17,
		]);
		DB::table('cities')->insert([
			'id' => 3564, 
			'name' => 'São José do Piauí',
			'state' => 17,
		]);
		DB::table('cities')->insert([
			'id' => 3565, 
			'name' => 'São Julião',
			'state' => 17,
		]);
		DB::table('cities')->insert([
			'id' => 3566, 
			'name' => 'São Lourenço do Piauí',
			'state' => 17,
		]);
		DB::table('cities')->insert([
			'id' => 3567, 
			'name' => 'São Luis do Piauí',
			'state' => 17,
		]);
		DB::table('cities')->insert([
			'id' => 3568, 
			'name' => 'São Miguel da Baixa Grande',
			'state' => 17,
		]);
		DB::table('cities')->insert([
			'id' => 3569, 
			'name' => 'São Miguel do Fidalgo',
			'state' => 17,
		]);
		DB::table('cities')->insert([
			'id' => 3570, 
			'name' => 'São Miguel do Tapuio',
			'state' => 17,
		]);
		DB::table('cities')->insert([
			'id' => 3571, 
			'name' => 'São Pedro do Piauí',
			'state' => 17,
		]);
		DB::table('cities')->insert([
			'id' => 3572, 
			'name' => 'São Raimundo Nonato',
			'state' => 17,
		]);
		DB::table('cities')->insert([
			'id' => 3573, 
			'name' => 'Sebastião Barros',
			'state' => 17,
		]);
		DB::table('cities')->insert([
			'id' => 3574, 
			'name' => 'Sebastião Leal',
			'state' => 17,
		]);
		DB::table('cities')->insert([
			'id' => 3575, 
			'name' => 'Sigefredo Pacheco',
			'state' => 17,
		]);
		DB::table('cities')->insert([
			'id' => 3576, 
			'name' => 'Simões',
			'state' => 17,
		]);
		DB::table('cities')->insert([
			'id' => 3577, 
			'name' => 'Simplício Mendes',
			'state' => 17,
		]);
		DB::table('cities')->insert([
			'id' => 3578, 
			'name' => 'Socorro do Piauí',
			'state' => 17,
		]);
		DB::table('cities')->insert([
			'id' => 3579, 
			'name' => 'Sussuapara',
			'state' => 17,
		]);
		DB::table('cities')->insert([
			'id' => 3580, 
			'name' => 'Tamboril do Piauí',
			'state' => 17,
		]);
		DB::table('cities')->insert([
			'id' => 3581, 
			'name' => 'Tanque do Piauí',
			'state' => 17,
		]);
		DB::table('cities')->insert([
			'id' => 3582, 
			'name' => 'Teresina',
			'state' => 17,
		]);
		DB::table('cities')->insert([
			'id' => 3583, 
			'name' => 'União',
			'state' => 17,
		]);
		DB::table('cities')->insert([
			'id' => 3584, 
			'name' => 'Uruçuí',
			'state' => 17,
		]);
		DB::table('cities')->insert([
			'id' => 3585, 
			'name' => 'Valença do Piauí',
			'state' => 17,
		]);
		DB::table('cities')->insert([
			'id' => 3586, 
			'name' => 'Várzea Branca',
			'state' => 17,
		]);
		DB::table('cities')->insert([
			'id' => 3587, 
			'name' => 'Várzea Grande',
			'state' => 17,
		]);
		DB::table('cities')->insert([
			'id' => 3588, 
			'name' => 'Vera Mendes',
			'state' => 17,
		]);
		DB::table('cities')->insert([
			'id' => 3589, 
			'name' => 'Vila Nova do Piauí',
			'state' => 17,
		]);
		DB::table('cities')->insert([
			'id' => 3590, 
			'name' => 'Wall Ferraz',
			'state' => 17,
		]);
		DB::table('cities')->insert([
			'id' => 3591, 
			'name' => 'Angra dos Reis',
			'state' => 19,
		]);
		DB::table('cities')->insert([
			'id' => 3592, 
			'name' => 'Aperibé',
			'state' => 19,
		]);
		DB::table('cities')->insert([
			'id' => 3593, 
			'name' => 'Araruama',
			'state' => 19,
		]);
		DB::table('cities')->insert([
			'id' => 3594, 
			'name' => 'Areal',
			'state' => 19,
		]);
		DB::table('cities')->insert([
			'id' => 3595, 
			'name' => 'Armação dos Búzios',
			'state' => 19,
		]);
		DB::table('cities')->insert([
			'id' => 3596, 
			'name' => 'Arraial do Cabo',
			'state' => 19,
		]);
		DB::table('cities')->insert([
			'id' => 3597, 
			'name' => 'Barra do Piraí',
			'state' => 19,
		]);
		DB::table('cities')->insert([
			'id' => 3598, 
			'name' => 'Barra Mansa',
			'state' => 19,
		]);
		DB::table('cities')->insert([
			'id' => 3599, 
			'name' => 'Belford Roxo',
			'state' => 19,
		]);
		DB::table('cities')->insert([
			'id' => 3600, 
			'name' => 'Bom Jardim',
			'state' => 19,
		]);
		DB::table('cities')->insert([
			'id' => 3601, 
			'name' => 'Bom Jesus do Itabapoana',
			'state' => 19,
		]);
		DB::table('cities')->insert([
			'id' => 3602, 
			'name' => 'Cabo Frio',
			'state' => 19,
		]);
		DB::table('cities')->insert([
			'id' => 3603, 
			'name' => 'Cachoeiras de Macacu',
			'state' => 19,
		]);
		DB::table('cities')->insert([
			'id' => 3604, 
			'name' => 'Cambuci',
			'state' => 19,
		]);
		DB::table('cities')->insert([
			'id' => 3605, 
			'name' => 'Campos dos Goytacazes',
			'state' => 19,
		]);
		DB::table('cities')->insert([
			'id' => 3606, 
			'name' => 'Cantagalo',
			'state' => 19,
		]);
		DB::table('cities')->insert([
			'id' => 3607, 
			'name' => 'Carapebus',
			'state' => 19,
		]);
		DB::table('cities')->insert([
			'id' => 3608, 
			'name' => 'Cardoso Moreira',
			'state' => 19,
		]);
		DB::table('cities')->insert([
			'id' => 3609, 
			'name' => 'Carmo',
			'state' => 19,
		]);
		DB::table('cities')->insert([
			'id' => 3610, 
			'name' => 'Casimiro de Abreu',
			'state' => 19,
		]);
		DB::table('cities')->insert([
			'id' => 3611, 
			'name' => 'Comendador Levy Gasparian',
			'state' => 19,
		]);
		DB::table('cities')->insert([
			'id' => 3612, 
			'name' => 'Conceição de Macabu',
			'state' => 19,
		]);
		DB::table('cities')->insert([
			'id' => 3613, 
			'name' => 'Cordeiro',
			'state' => 19,
		]);
		DB::table('cities')->insert([
			'id' => 3614, 
			'name' => 'Duas Barras',
			'state' => 19,
		]);
		DB::table('cities')->insert([
			'id' => 3615, 
			'name' => 'Duque de Caxias',
			'state' => 19,
		]);
		DB::table('cities')->insert([
			'id' => 3616, 
			'name' => 'Engenheiro Paulo de Frontin',
			'state' => 19,
		]);
		DB::table('cities')->insert([
			'id' => 3617, 
			'name' => 'Guapimirim',
			'state' => 19,
		]);
		DB::table('cities')->insert([
			'id' => 3618, 
			'name' => 'Iguaba Grande',
			'state' => 19,
		]);
		DB::table('cities')->insert([
			'id' => 3619, 
			'name' => 'Itaboraí',
			'state' => 19,
		]);
		DB::table('cities')->insert([
			'id' => 3620, 
			'name' => 'Itaguaí',
			'state' => 19,
		]);
		DB::table('cities')->insert([
			'id' => 3621, 
			'name' => 'Italva',
			'state' => 19,
		]);
		DB::table('cities')->insert([
			'id' => 3622, 
			'name' => 'Itaocara',
			'state' => 19,
		]);
		DB::table('cities')->insert([
			'id' => 3623, 
			'name' => 'Itaperuna',
			'state' => 19,
		]);
		DB::table('cities')->insert([
			'id' => 3624, 
			'name' => 'Itatiaia',
			'state' => 19,
		]);
		DB::table('cities')->insert([
			'id' => 3625, 
			'name' => 'Japeri',
			'state' => 19,
		]);
		DB::table('cities')->insert([
			'id' => 3626, 
			'name' => 'Laje do Muriaé',
			'state' => 19,
		]);
		DB::table('cities')->insert([
			'id' => 3627, 
			'name' => 'Macaé',
			'state' => 19,
		]);
		DB::table('cities')->insert([
			'id' => 3628, 
			'name' => 'Macuco',
			'state' => 19,
		]);
		DB::table('cities')->insert([
			'id' => 3629, 
			'name' => 'Magé',
			'state' => 19,
		]);
		DB::table('cities')->insert([
			'id' => 3630, 
			'name' => 'Mangaratiba',
			'state' => 19,
		]);
		DB::table('cities')->insert([
			'id' => 3631, 
			'name' => 'Maricá',
			'state' => 19,
		]);
		DB::table('cities')->insert([
			'id' => 3632, 
			'name' => 'Mendes',
			'state' => 19,
		]);
		DB::table('cities')->insert([
			'id' => 3633, 
			'name' => 'Mesquita',
			'state' => 19,
		]);
		DB::table('cities')->insert([
			'id' => 3634, 
			'name' => 'Miguel Pereira',
			'state' => 19,
		]);
		DB::table('cities')->insert([
			'id' => 3635, 
			'name' => 'Miracema',
			'state' => 19,
		]);
		DB::table('cities')->insert([
			'id' => 3636, 
			'name' => 'Natividade',
			'state' => 19,
		]);
		DB::table('cities')->insert([
			'id' => 3637, 
			'name' => 'Nilópolis',
			'state' => 19,
		]);
		DB::table('cities')->insert([
			'id' => 3638, 
			'name' => 'Niterói',
			'state' => 19,
		]);
		DB::table('cities')->insert([
			'id' => 3639, 
			'name' => 'Nova Friburgo',
			'state' => 19,
		]);
		DB::table('cities')->insert([
			'id' => 3640, 
			'name' => 'Nova Iguaçu',
			'state' => 19,
		]);
		DB::table('cities')->insert([
			'id' => 3641, 
			'name' => 'Paracambi',
			'state' => 19,
		]);
		DB::table('cities')->insert([
			'id' => 3642, 
			'name' => 'Paraíba do Sul',
			'state' => 19,
		]);
		DB::table('cities')->insert([
			'id' => 3643, 
			'name' => 'Parati',
			'state' => 19,
		]);
		DB::table('cities')->insert([
			'id' => 3644, 
			'name' => 'Paty do Alferes',
			'state' => 19,
		]);
		DB::table('cities')->insert([
			'id' => 3645, 
			'name' => 'Petrópolis',
			'state' => 19,
		]);
		DB::table('cities')->insert([
			'id' => 3646, 
			'name' => 'Pinheiral',
			'state' => 19,
		]);
		DB::table('cities')->insert([
			'id' => 3647, 
			'name' => 'Piraí',
			'state' => 19,
		]);
		DB::table('cities')->insert([
			'id' => 3648, 
			'name' => 'Porciúncula',
			'state' => 19,
		]);
		DB::table('cities')->insert([
			'id' => 3649, 
			'name' => 'Porto Real',
			'state' => 19,
		]);
		DB::table('cities')->insert([
			'id' => 3650, 
			'name' => 'Quatis',
			'state' => 19,
		]);
		DB::table('cities')->insert([
			'id' => 3651, 
			'name' => 'Queimados',
			'state' => 19,
		]);
		DB::table('cities')->insert([
			'id' => 3652, 
			'name' => 'Quissamã',
			'state' => 19,
		]);
		DB::table('cities')->insert([
			'id' => 3653, 
			'name' => 'Resende',
			'state' => 19,
		]);
		DB::table('cities')->insert([
			'id' => 3654, 
			'name' => 'Rio Bonito',
			'state' => 19,
		]);
		DB::table('cities')->insert([
			'id' => 3655, 
			'name' => 'Rio Claro',
			'state' => 19,
		]);
		DB::table('cities')->insert([
			'id' => 3656, 
			'name' => 'Rio das Flores',
			'state' => 19,
		]);
		DB::table('cities')->insert([
			'id' => 3657, 
			'name' => 'Rio das Ostras',
			'state' => 19,
		]);
		DB::table('cities')->insert([
			'id' => 3658, 
			'name' => 'Rio de Janeiro',
			'state' => 19,
		]);
		DB::table('cities')->insert([
			'id' => 3659, 
			'name' => 'Santa Maria Madalena',
			'state' => 19,
		]);
		DB::table('cities')->insert([
			'id' => 3660, 
			'name' => 'Santo Antônio de Pádua',
			'state' => 19,
		]);
		DB::table('cities')->insert([
			'id' => 3661, 
			'name' => 'São Fidélis',
			'state' => 19,
		]);
		DB::table('cities')->insert([
			'id' => 3662, 
			'name' => 'São Francisco de Itabapoana',
			'state' => 19,
		]);
		DB::table('cities')->insert([
			'id' => 3663, 
			'name' => 'São Gonçalo',
			'state' => 19,
		]);
		DB::table('cities')->insert([
			'id' => 3664, 
			'name' => 'São João da Barra',
			'state' => 19,
		]);
		DB::table('cities')->insert([
			'id' => 3665, 
			'name' => 'São João de Meriti',
			'state' => 19,
		]);
		DB::table('cities')->insert([
			'id' => 3666, 
			'name' => 'São José de Ubá',
			'state' => 19,
		]);
		DB::table('cities')->insert([
			'id' => 3667, 
			'name' => 'São José do Vale do Rio Pret',
			'state' => 19,
		]);
		DB::table('cities')->insert([
			'id' => 3668, 
			'name' => 'São Pedro da Aldeia',
			'state' => 19,
		]);
		DB::table('cities')->insert([
			'id' => 3669, 
			'name' => 'São Sebastião do Alto',
			'state' => 19,
		]);
		DB::table('cities')->insert([
			'id' => 3670, 
			'name' => 'Sapucaia',
			'state' => 19,
		]);
		DB::table('cities')->insert([
			'id' => 3671, 
			'name' => 'Saquarema',
			'state' => 19,
		]);
		DB::table('cities')->insert([
			'id' => 3672, 
			'name' => 'Seropédica',
			'state' => 19,
		]);
		DB::table('cities')->insert([
			'id' => 3673, 
			'name' => 'Silva Jardim',
			'state' => 19,
		]);
		DB::table('cities')->insert([
			'id' => 3674, 
			'name' => 'Sumidouro',
			'state' => 19,
		]);
		DB::table('cities')->insert([
			'id' => 3675, 
			'name' => 'Tanguá',
			'state' => 19,
		]);
		DB::table('cities')->insert([
			'id' => 3676, 
			'name' => 'Teresópolis',
			'state' => 19,
		]);
		DB::table('cities')->insert([
			'id' => 3677, 
			'name' => 'Trajano de Morais',
			'state' => 19,
		]);
		DB::table('cities')->insert([
			'id' => 3678, 
			'name' => 'Três Rios',
			'state' => 19,
		]);
		DB::table('cities')->insert([
			'id' => 3679, 
			'name' => 'Valença',
			'state' => 19,
		]);
		DB::table('cities')->insert([
			'id' => 3680, 
			'name' => 'Varre-Sai',
			'state' => 19,
		]);
		DB::table('cities')->insert([
			'id' => 3681, 
			'name' => 'Vassouras',
			'state' => 19,
		]);
		DB::table('cities')->insert([
			'id' => 3682, 
			'name' => 'Volta Redonda',
			'state' => 19,
		]);
		DB::table('cities')->insert([
			'id' => 3683, 
			'name' => 'Acari',
			'state' => 20,
		]);
		DB::table('cities')->insert([
			'id' => 3684, 
			'name' => 'Açu',
			'state' => 20,
		]);
		DB::table('cities')->insert([
			'id' => 3685, 
			'name' => 'Afonso Bezerra',
			'state' => 20,
		]);
		DB::table('cities')->insert([
			'id' => 3686, 
			'name' => 'Água Nova',
			'state' => 20,
		]);
		DB::table('cities')->insert([
			'id' => 3687, 
			'name' => 'Alexandria',
			'state' => 20,
		]);
		DB::table('cities')->insert([
			'id' => 3688, 
			'name' => 'Almino Afonso',
			'state' => 20,
		]);
		DB::table('cities')->insert([
			'id' => 3689, 
			'name' => 'Alto do Rodrigues',
			'state' => 20,
		]);
		DB::table('cities')->insert([
			'id' => 3690, 
			'name' => 'Angicos',
			'state' => 20,
		]);
		DB::table('cities')->insert([
			'id' => 3691, 
			'name' => 'Antônio Martins',
			'state' => 20,
		]);
		DB::table('cities')->insert([
			'id' => 3692, 
			'name' => 'Apodi',
			'state' => 20,
		]);
		DB::table('cities')->insert([
			'id' => 3693, 
			'name' => 'Areia Branca',
			'state' => 20,
		]);
		DB::table('cities')->insert([
			'id' => 3694, 
			'name' => 'Arês',
			'state' => 20,
		]);
		DB::table('cities')->insert([
			'id' => 3695, 
			'name' => 'Augusto Severo',
			'state' => 20,
		]);
		DB::table('cities')->insert([
			'id' => 3696, 
			'name' => 'Baía Formosa',
			'state' => 20,
		]);
		DB::table('cities')->insert([
			'id' => 3697, 
			'name' => 'Baraúna',
			'state' => 20,
		]);
		DB::table('cities')->insert([
			'id' => 3698, 
			'name' => 'Barcelona',
			'state' => 20,
		]);
		DB::table('cities')->insert([
			'id' => 3699, 
			'name' => 'Bento Fernandes',
			'state' => 20,
		]);
		DB::table('cities')->insert([
			'id' => 3700, 
			'name' => 'Bodó',
			'state' => 20,
		]);
		DB::table('cities')->insert([
			'id' => 3701, 
			'name' => 'Bom Jesus',
			'state' => 20,
		]);
		DB::table('cities')->insert([
			'id' => 3702, 
			'name' => 'Brejinho',
			'state' => 20,
		]);
		DB::table('cities')->insert([
			'id' => 3703, 
			'name' => 'Caiçara do Norte',
			'state' => 20,
		]);
		DB::table('cities')->insert([
			'id' => 3704, 
			'name' => 'Caiçara do Rio do Vento',
			'state' => 20,
		]);
		DB::table('cities')->insert([
			'id' => 3705, 
			'name' => 'Caicó',
			'state' => 20,
		]);
		DB::table('cities')->insert([
			'id' => 3706, 
			'name' => 'Campo Redondo',
			'state' => 20,
		]);
		DB::table('cities')->insert([
			'id' => 3707, 
			'name' => 'Canguaretama',
			'state' => 20,
		]);
		DB::table('cities')->insert([
			'id' => 3708, 
			'name' => 'Caraúbas',
			'state' => 20,
		]);
		DB::table('cities')->insert([
			'id' => 3709, 
			'name' => 'Carnaúba dos Dantas',
			'state' => 20,
		]);
		DB::table('cities')->insert([
			'id' => 3710, 
			'name' => 'Carnaubais',
			'state' => 20,
		]);
		DB::table('cities')->insert([
			'id' => 3711, 
			'name' => 'Ceará-Mirim',
			'state' => 20,
		]);
		DB::table('cities')->insert([
			'id' => 3712, 
			'name' => 'Cerro Corá',
			'state' => 20,
		]);
		DB::table('cities')->insert([
			'id' => 3713, 
			'name' => 'Coronel Ezequiel',
			'state' => 20,
		]);
		DB::table('cities')->insert([
			'id' => 3714, 
			'name' => 'Coronel João Pessoa',
			'state' => 20,
		]);
		DB::table('cities')->insert([
			'id' => 3715, 
			'name' => 'Cruzeta',
			'state' => 20,
		]);
		DB::table('cities')->insert([
			'id' => 3716, 
			'name' => 'Currais Novos',
			'state' => 20,
		]);
		DB::table('cities')->insert([
			'id' => 3717, 
			'name' => 'Doutor Severiano',
			'state' => 20,
		]);
		DB::table('cities')->insert([
			'id' => 3718, 
			'name' => 'Encanto',
			'state' => 20,
		]);
		DB::table('cities')->insert([
			'id' => 3719, 
			'name' => 'Equador',
			'state' => 20,
		]);
		DB::table('cities')->insert([
			'id' => 3720, 
			'name' => 'Espírito Santo',
			'state' => 20,
		]);
		DB::table('cities')->insert([
			'id' => 3721, 
			'name' => 'Extremoz',
			'state' => 20,
		]);
		DB::table('cities')->insert([
			'id' => 3722, 
			'name' => 'Felipe Guerra',
			'state' => 20,
		]);
		DB::table('cities')->insert([
			'id' => 3723, 
			'name' => 'Fernando Pedroza',
			'state' => 20,
		]);
		DB::table('cities')->insert([
			'id' => 3724, 
			'name' => 'Florânia',
			'state' => 20,
		]);
		DB::table('cities')->insert([
			'id' => 3725, 
			'name' => 'Francisco Dantas',
			'state' => 20,
		]);
		DB::table('cities')->insert([
			'id' => 3726, 
			'name' => 'Frutuoso Gomes',
			'state' => 20,
		]);
		DB::table('cities')->insert([
			'id' => 3727, 
			'name' => 'Galinhos',
			'state' => 20,
		]);
		DB::table('cities')->insert([
			'id' => 3728, 
			'name' => 'Goianinha',
			'state' => 20,
		]);
		DB::table('cities')->insert([
			'id' => 3729, 
			'name' => 'Governador Dix-Sept Rosado',
			'state' => 20,
		]);
		DB::table('cities')->insert([
			'id' => 3730, 
			'name' => 'Grossos',
			'state' => 20,
		]);
		DB::table('cities')->insert([
			'id' => 3731, 
			'name' => 'Guamaré',
			'state' => 20,
		]);
		DB::table('cities')->insert([
			'id' => 3732, 
			'name' => 'Ielmo Marinho',
			'state' => 20,
		]);
		DB::table('cities')->insert([
			'id' => 3733, 
			'name' => 'Ipanguaçu',
			'state' => 20,
		]);
		DB::table('cities')->insert([
			'id' => 3734, 
			'name' => 'Ipueira',
			'state' => 20,
		]);
		DB::table('cities')->insert([
			'id' => 3735, 
			'name' => 'Itajá',
			'state' => 20,
		]);
		DB::table('cities')->insert([
			'id' => 3736, 
			'name' => 'Itaú',
			'state' => 20,
		]);
		DB::table('cities')->insert([
			'id' => 3737, 
			'name' => 'Jaçanã',
			'state' => 20,
		]);
		DB::table('cities')->insert([
			'id' => 3738, 
			'name' => 'Jandaíra',
			'state' => 20,
		]);
		DB::table('cities')->insert([
			'id' => 3739, 
			'name' => 'Janduís',
			'state' => 20,
		]);
		DB::table('cities')->insert([
			'id' => 3740, 
			'name' => 'Januário Cicco',
			'state' => 20,
		]);
		DB::table('cities')->insert([
			'id' => 3741, 
			'name' => 'Japi',
			'state' => 20,
		]);
		DB::table('cities')->insert([
			'id' => 3742, 
			'name' => 'Jardim de Angicos',
			'state' => 20,
		]);
		DB::table('cities')->insert([
			'id' => 3743, 
			'name' => 'Jardim de Piranhas',
			'state' => 20,
		]);
		DB::table('cities')->insert([
			'id' => 3744, 
			'name' => 'Jardim do Seridó',
			'state' => 20,
		]);
		DB::table('cities')->insert([
			'id' => 3745, 
			'name' => 'João Câmara',
			'state' => 20,
		]);
		DB::table('cities')->insert([
			'id' => 3746, 
			'name' => 'João Dias',
			'state' => 20,
		]);
		DB::table('cities')->insert([
			'id' => 3747, 
			'name' => 'José da Penha',
			'state' => 20,
		]);
		DB::table('cities')->insert([
			'id' => 3748, 
			'name' => 'Jucurutu',
			'state' => 20,
		]);
		DB::table('cities')->insert([
			'id' => 3749, 
			'name' => 'Jundiá',
			'state' => 20,
		]);
		DB::table('cities')->insert([
			'id' => 3750, 
			'name' => 'Lagoa d`Anta',
			'state' => 20,
		]);
		DB::table('cities')->insert([
			'id' => 3751, 
			'name' => 'Lagoa de Pedras',
			'state' => 20,
		]);
		DB::table('cities')->insert([
			'id' => 3752, 
			'name' => 'Lagoa de Velhos',
			'state' => 20,
		]);
		DB::table('cities')->insert([
			'id' => 3753, 
			'name' => 'Lagoa Nova',
			'state' => 20,
		]);
		DB::table('cities')->insert([
			'id' => 3754, 
			'name' => 'Lagoa Salgada',
			'state' => 20,
		]);
		DB::table('cities')->insert([
			'id' => 3755, 
			'name' => 'Lajes',
			'state' => 20,
		]);
		DB::table('cities')->insert([
			'id' => 3756, 
			'name' => 'Lajes Pintadas',
			'state' => 20,
		]);
		DB::table('cities')->insert([
			'id' => 3757, 
			'name' => 'Lucrécia',
			'state' => 20,
		]);
		DB::table('cities')->insert([
			'id' => 3758, 
			'name' => 'Luís Gomes',
			'state' => 20,
		]);
		DB::table('cities')->insert([
			'id' => 3759, 
			'name' => 'Macaíba',
			'state' => 20,
		]);
		DB::table('cities')->insert([
			'id' => 3760, 
			'name' => 'Macau',
			'state' => 20,
		]);
		DB::table('cities')->insert([
			'id' => 3761, 
			'name' => 'Major Sales',
			'state' => 20,
		]);
		DB::table('cities')->insert([
			'id' => 3762, 
			'name' => 'Marcelino Vieira',
			'state' => 20,
		]);
		DB::table('cities')->insert([
			'id' => 3763, 
			'name' => 'Martins',
			'state' => 20,
		]);
		DB::table('cities')->insert([
			'id' => 3764, 
			'name' => 'Maxaranguape',
			'state' => 20,
		]);
		DB::table('cities')->insert([
			'id' => 3765, 
			'name' => 'Messias Targino',
			'state' => 20,
		]);
		DB::table('cities')->insert([
			'id' => 3766, 
			'name' => 'Montanhas',
			'state' => 20,
		]);
		DB::table('cities')->insert([
			'id' => 3767, 
			'name' => 'Monte Alegre',
			'state' => 20,
		]);
		DB::table('cities')->insert([
			'id' => 3768, 
			'name' => 'Monte das Gameleiras',
			'state' => 20,
		]);
		DB::table('cities')->insert([
			'id' => 3769, 
			'name' => 'Mossoró',
			'state' => 20,
		]);
		DB::table('cities')->insert([
			'id' => 3770, 
			'name' => 'Natal',
			'state' => 20,
		]);
		DB::table('cities')->insert([
			'id' => 3771, 
			'name' => 'Nísia Floresta',
			'state' => 20,
		]);
		DB::table('cities')->insert([
			'id' => 3772, 
			'name' => 'Nova Cruz',
			'state' => 20,
		]);
		DB::table('cities')->insert([
			'id' => 3773, 
			'name' => 'Olho-d`Água do Borges',
			'state' => 20,
		]);
		DB::table('cities')->insert([
			'id' => 3774, 
			'name' => 'Ouro Branco',
			'state' => 20,
		]);
		DB::table('cities')->insert([
			'id' => 3775, 
			'name' => 'Paraná',
			'state' => 20,
		]);
		DB::table('cities')->insert([
			'id' => 3776, 
			'name' => 'Paraú',
			'state' => 20,
		]);
		DB::table('cities')->insert([
			'id' => 3777, 
			'name' => 'Parazinho',
			'state' => 20,
		]);
		DB::table('cities')->insert([
			'id' => 3778, 
			'name' => 'Parelhas',
			'state' => 20,
		]);
		DB::table('cities')->insert([
			'id' => 3779, 
			'name' => 'Parnamirim',
			'state' => 20,
		]);
		DB::table('cities')->insert([
			'id' => 3780, 
			'name' => 'Passa e Fica',
			'state' => 20,
		]);
		DB::table('cities')->insert([
			'id' => 3781, 
			'name' => 'Passagem',
			'state' => 20,
		]);
		DB::table('cities')->insert([
			'id' => 3782, 
			'name' => 'Patu',
			'state' => 20,
		]);
		DB::table('cities')->insert([
			'id' => 3783, 
			'name' => 'Pau dos Ferros',
			'state' => 20,
		]);
		DB::table('cities')->insert([
			'id' => 3784, 
			'name' => 'Pedra Grande',
			'state' => 20,
		]);
		DB::table('cities')->insert([
			'id' => 3785, 
			'name' => 'Pedra Preta',
			'state' => 20,
		]);
		DB::table('cities')->insert([
			'id' => 3786, 
			'name' => 'Pedro Avelino',
			'state' => 20,
		]);
		DB::table('cities')->insert([
			'id' => 3787, 
			'name' => 'Pedro Velho',
			'state' => 20,
		]);
		DB::table('cities')->insert([
			'id' => 3788, 
			'name' => 'Pendências',
			'state' => 20,
		]);
		DB::table('cities')->insert([
			'id' => 3789, 
			'name' => 'Pilões',
			'state' => 20,
		]);
		DB::table('cities')->insert([
			'id' => 3790, 
			'name' => 'Poço Branco',
			'state' => 20,
		]);
		DB::table('cities')->insert([
			'id' => 3791, 
			'name' => 'Portalegre',
			'state' => 20,
		]);
		DB::table('cities')->insert([
			'id' => 3792, 
			'name' => 'Porto do Mangue',
			'state' => 20,
		]);
		DB::table('cities')->insert([
			'id' => 3793, 
			'name' => 'Presidente Juscelino',
			'state' => 20,
		]);
		DB::table('cities')->insert([
			'id' => 3794, 
			'name' => 'Pureza',
			'state' => 20,
		]);
		DB::table('cities')->insert([
			'id' => 3795, 
			'name' => 'Rafael Fernandes',
			'state' => 20,
		]);
		DB::table('cities')->insert([
			'id' => 3796, 
			'name' => 'Rafael Godeiro',
			'state' => 20,
		]);
		DB::table('cities')->insert([
			'id' => 3797, 
			'name' => 'Riacho da Cruz',
			'state' => 20,
		]);
		DB::table('cities')->insert([
			'id' => 3798, 
			'name' => 'Riacho de Santana',
			'state' => 20,
		]);
		DB::table('cities')->insert([
			'id' => 3799, 
			'name' => 'Riachuelo',
			'state' => 20,
		]);
		DB::table('cities')->insert([
			'id' => 3800, 
			'name' => 'Rio do Fogo',
			'state' => 20,
		]);
		DB::table('cities')->insert([
			'id' => 3801, 
			'name' => 'Rodolfo Fernandes',
			'state' => 20,
		]);
		DB::table('cities')->insert([
			'id' => 3802, 
			'name' => 'Ruy Barbosa',
			'state' => 20,
		]);
		DB::table('cities')->insert([
			'id' => 3803, 
			'name' => 'Santa Cruz',
			'state' => 20,
		]);
		DB::table('cities')->insert([
			'id' => 3804, 
			'name' => 'Santa Maria',
			'state' => 20,
		]);
		DB::table('cities')->insert([
			'id' => 3805, 
			'name' => 'Santana do Matos',
			'state' => 20,
		]);
		DB::table('cities')->insert([
			'id' => 3806, 
			'name' => 'Santana do Seridó',
			'state' => 20,
		]);
		DB::table('cities')->insert([
			'id' => 3807, 
			'name' => 'Santo Antônio',
			'state' => 20,
		]);
		DB::table('cities')->insert([
			'id' => 3808, 
			'name' => 'São Bento do Norte',
			'state' => 20,
		]);
		DB::table('cities')->insert([
			'id' => 3809, 
			'name' => 'São Bento do Trairí',
			'state' => 20,
		]);
		DB::table('cities')->insert([
			'id' => 3810, 
			'name' => 'São Fernando',
			'state' => 20,
		]);
		DB::table('cities')->insert([
			'id' => 3811, 
			'name' => 'São Francisco do Oeste',
			'state' => 20,
		]);
		DB::table('cities')->insert([
			'id' => 3812, 
			'name' => 'São Gonçalo do Amarante',
			'state' => 20,
		]);
		DB::table('cities')->insert([
			'id' => 3813, 
			'name' => 'São João do Sabugi',
			'state' => 20,
		]);
		DB::table('cities')->insert([
			'id' => 3814, 
			'name' => 'São José de Mipibu',
			'state' => 20,
		]);
		DB::table('cities')->insert([
			'id' => 3815, 
			'name' => 'São José do Campestre',
			'state' => 20,
		]);
		DB::table('cities')->insert([
			'id' => 3816, 
			'name' => 'São José do Seridó',
			'state' => 20,
		]);
		DB::table('cities')->insert([
			'id' => 3817, 
			'name' => 'São Miguel',
			'state' => 20,
		]);
		DB::table('cities')->insert([
			'id' => 3818, 
			'name' => 'São Miguel do Gostoso',
			'state' => 20,
		]);
		DB::table('cities')->insert([
			'id' => 3819, 
			'name' => 'São Paulo do Potengi',
			'state' => 20,
		]);
		DB::table('cities')->insert([
			'id' => 3820, 
			'name' => 'São Pedro',
			'state' => 20,
		]);
		DB::table('cities')->insert([
			'id' => 3821, 
			'name' => 'São Rafael',
			'state' => 20,
		]);
		DB::table('cities')->insert([
			'id' => 3822, 
			'name' => 'São Tomé',
			'state' => 20,
		]);
		DB::table('cities')->insert([
			'id' => 3823, 
			'name' => 'São Vicente',
			'state' => 20,
		]);
		DB::table('cities')->insert([
			'id' => 3824, 
			'name' => 'Senador Elói de Souza',
			'state' => 20,
		]);
		DB::table('cities')->insert([
			'id' => 3825, 
			'name' => 'Senador Georgino Avelino',
			'state' => 20,
		]);
		DB::table('cities')->insert([
			'id' => 3826, 
			'name' => 'Serra de São Bento',
			'state' => 20,
		]);
		DB::table('cities')->insert([
			'id' => 3827, 
			'name' => 'Serra do Mel',
			'state' => 20,
		]);
		DB::table('cities')->insert([
			'id' => 3828, 
			'name' => 'Serra Negra do Norte',
			'state' => 20,
		]);
		DB::table('cities')->insert([
			'id' => 3829, 
			'name' => 'Serrinha',
			'state' => 20,
		]);
		DB::table('cities')->insert([
			'id' => 3830, 
			'name' => 'Serrinha dos Pintos',
			'state' => 20,
		]);
		DB::table('cities')->insert([
			'id' => 3831, 
			'name' => 'Severiano Melo',
			'state' => 20,
		]);
		DB::table('cities')->insert([
			'id' => 3832, 
			'name' => 'Sítio Novo',
			'state' => 20,
		]);
		DB::table('cities')->insert([
			'id' => 3833, 
			'name' => 'Taboleiro Grande',
			'state' => 20,
		]);
		DB::table('cities')->insert([
			'id' => 3834, 
			'name' => 'Taipu',
			'state' => 20,
		]);
		DB::table('cities')->insert([
			'id' => 3835, 
			'name' => 'Tangará',
			'state' => 20,
		]);
		DB::table('cities')->insert([
			'id' => 3836, 
			'name' => 'Tenente Ananias',
			'state' => 20,
		]);
		DB::table('cities')->insert([
			'id' => 3837, 
			'name' => 'Tenente Laurentino Cruz',
			'state' => 20,
		]);
		DB::table('cities')->insert([
			'id' => 3838, 
			'name' => 'Tibau',
			'state' => 20,
		]);
		DB::table('cities')->insert([
			'id' => 3839, 
			'name' => 'Tibau do Sul',
			'state' => 20,
		]);
		DB::table('cities')->insert([
			'id' => 3840, 
			'name' => 'Timbaúba dos Batistas',
			'state' => 20,
		]);
		DB::table('cities')->insert([
			'id' => 3841, 
			'name' => 'Touros',
			'state' => 20,
		]);
		DB::table('cities')->insert([
			'id' => 3842, 
			'name' => 'Triunfo Potiguar',
			'state' => 20,
		]);
		DB::table('cities')->insert([
			'id' => 3843, 
			'name' => 'Umarizal',
			'state' => 20,
		]);
		DB::table('cities')->insert([
			'id' => 3844, 
			'name' => 'Upanema',
			'state' => 20,
		]);
		DB::table('cities')->insert([
			'id' => 3845, 
			'name' => 'Várzea',
			'state' => 20,
		]);
		DB::table('cities')->insert([
			'id' => 3846, 
			'name' => 'Venha-Ver',
			'state' => 20,
		]);
		DB::table('cities')->insert([
			'id' => 3847, 
			'name' => 'Vera Cruz',
			'state' => 20,
		]);
		DB::table('cities')->insert([
			'id' => 3848, 
			'name' => 'Viçosa',
			'state' => 20,
		]);
		DB::table('cities')->insert([
			'id' => 3849, 
			'name' => 'Vila Flor',
			'state' => 20,
		]);
		DB::table('cities')->insert([
			'id' => 3850, 
			'name' => 'Aceguá',
			'state' => 23,
		]);
		DB::table('cities')->insert([
			'id' => 3851, 
			'name' => 'Água Santa',
			'state' => 23,
		]);
		DB::table('cities')->insert([
			'id' => 3852, 
			'name' => 'Agudo',
			'state' => 23,
		]);
		DB::table('cities')->insert([
			'id' => 3853, 
			'name' => 'Ajuricaba',
			'state' => 23,
		]);
		DB::table('cities')->insert([
			'id' => 3854, 
			'name' => 'Alecrim',
			'state' => 23,
		]);
		DB::table('cities')->insert([
			'id' => 3855, 
			'name' => 'Alegrete',
			'state' => 23,
		]);
		DB::table('cities')->insert([
			'id' => 3856, 
			'name' => 'Alegria',
			'state' => 23,
		]);
		DB::table('cities')->insert([
			'id' => 3857, 
			'name' => 'Almirante Tamandaré do Sul',
			'state' => 23,
		]);
		DB::table('cities')->insert([
			'id' => 3858, 
			'name' => 'Alpestre',
			'state' => 23,
		]);
		DB::table('cities')->insert([
			'id' => 3859, 
			'name' => 'Alto Alegre',
			'state' => 23,
		]);
		DB::table('cities')->insert([
			'id' => 3860, 
			'name' => 'Alto Feliz',
			'state' => 23,
		]);
		DB::table('cities')->insert([
			'id' => 3861, 
			'name' => 'Alvorada',
			'state' => 23,
		]);
		DB::table('cities')->insert([
			'id' => 3862, 
			'name' => 'Amaral Ferrador',
			'state' => 23,
		]);
		DB::table('cities')->insert([
			'id' => 3863, 
			'name' => 'Ametista do Sul',
			'state' => 23,
		]);
		DB::table('cities')->insert([
			'id' => 3864, 
			'name' => 'André da Rocha',
			'state' => 23,
		]);
		DB::table('cities')->insert([
			'id' => 3865, 
			'name' => 'Anta Gorda',
			'state' => 23,
		]);
		DB::table('cities')->insert([
			'id' => 3866, 
			'name' => 'Antônio Prado',
			'state' => 23,
		]);
		DB::table('cities')->insert([
			'id' => 3867, 
			'name' => 'Arambaré',
			'state' => 23,
		]);
		DB::table('cities')->insert([
			'id' => 3868, 
			'name' => 'Araricá',
			'state' => 23,
		]);
		DB::table('cities')->insert([
			'id' => 3869, 
			'name' => 'Aratiba',
			'state' => 23,
		]);
		DB::table('cities')->insert([
			'id' => 3870, 
			'name' => 'Arroio do Meio',
			'state' => 23,
		]);
		DB::table('cities')->insert([
			'id' => 3871, 
			'name' => 'Arroio do Padre',
			'state' => 23,
		]);
		DB::table('cities')->insert([
			'id' => 3872, 
			'name' => 'Arroio do Sal',
			'state' => 23,
		]);
		DB::table('cities')->insert([
			'id' => 3873, 
			'name' => 'Arroio do Tigre',
			'state' => 23,
		]);
		DB::table('cities')->insert([
			'id' => 3874, 
			'name' => 'Arroio dos Ratos',
			'state' => 23,
		]);
		DB::table('cities')->insert([
			'id' => 3875, 
			'name' => 'Arroio Grande',
			'state' => 23,
		]);
		DB::table('cities')->insert([
			'id' => 3876, 
			'name' => 'Arvorezinha',
			'state' => 23,
		]);
		DB::table('cities')->insert([
			'id' => 3877, 
			'name' => 'Augusto Pestana',
			'state' => 23,
		]);
		DB::table('cities')->insert([
			'id' => 3878, 
			'name' => 'Áurea',
			'state' => 23,
		]);
		DB::table('cities')->insert([
			'id' => 3879, 
			'name' => 'Bagé',
			'state' => 23,
		]);
		DB::table('cities')->insert([
			'id' => 3880, 
			'name' => 'Balneário Pinhal',
			'state' => 23,
		]);
		DB::table('cities')->insert([
			'id' => 3881, 
			'name' => 'Barão',
			'state' => 23,
		]);
		DB::table('cities')->insert([
			'id' => 3882, 
			'name' => 'Barão de Cotegipe',
			'state' => 23,
		]);
		DB::table('cities')->insert([
			'id' => 3883, 
			'name' => 'Barão do Triunfo',
			'state' => 23,
		]);
		DB::table('cities')->insert([
			'id' => 3884, 
			'name' => 'Barra do Guarita',
			'state' => 23,
		]);
		DB::table('cities')->insert([
			'id' => 3885, 
			'name' => 'Barra do Quaraí',
			'state' => 23,
		]);
		DB::table('cities')->insert([
			'id' => 3886, 
			'name' => 'Barra do Ribeiro',
			'state' => 23,
		]);
		DB::table('cities')->insert([
			'id' => 3887, 
			'name' => 'Barra do Rio Azul',
			'state' => 23,
		]);
		DB::table('cities')->insert([
			'id' => 3888, 
			'name' => 'Barra Funda',
			'state' => 23,
		]);
		DB::table('cities')->insert([
			'id' => 3889, 
			'name' => 'Barracão',
			'state' => 23,
		]);
		DB::table('cities')->insert([
			'id' => 3890, 
			'name' => 'Barros Cassal',
			'state' => 23,
		]);
		DB::table('cities')->insert([
			'id' => 3891, 
			'name' => 'Benjamin Constant do Sul',
			'state' => 23,
		]);
		DB::table('cities')->insert([
			'id' => 3892, 
			'name' => 'Bento Gonçalves',
			'state' => 23,
		]);
		DB::table('cities')->insert([
			'id' => 3893, 
			'name' => 'Boa Vista das Missões',
			'state' => 23,
		]);
		DB::table('cities')->insert([
			'id' => 3894, 
			'name' => 'Boa Vista do Buricá',
			'state' => 23,
		]);
		DB::table('cities')->insert([
			'id' => 3895, 
			'name' => 'Boa Vista do Cadeado',
			'state' => 23,
		]);
		DB::table('cities')->insert([
			'id' => 3896, 
			'name' => 'Boa Vista do Incra',
			'state' => 23,
		]);
		DB::table('cities')->insert([
			'id' => 3897, 
			'name' => 'Boa Vista do Sul',
			'state' => 23,
		]);
		DB::table('cities')->insert([
			'id' => 3898, 
			'name' => 'Bom Jesus',
			'state' => 23,
		]);
		DB::table('cities')->insert([
			'id' => 3899, 
			'name' => 'Bom Princípio',
			'state' => 23,
		]);
		DB::table('cities')->insert([
			'id' => 3900, 
			'name' => 'Bom Progresso',
			'state' => 23,
		]);
		DB::table('cities')->insert([
			'id' => 3901, 
			'name' => 'Bom Retiro do Sul',
			'state' => 23,
		]);
		DB::table('cities')->insert([
			'id' => 3902, 
			'name' => 'Boqueirão do Leão',
			'state' => 23,
		]);
		DB::table('cities')->insert([
			'id' => 3903, 
			'name' => 'Bossoroca',
			'state' => 23,
		]);
		DB::table('cities')->insert([
			'id' => 3904, 
			'name' => 'Bozano',
			'state' => 23,
		]);
		DB::table('cities')->insert([
			'id' => 3905, 
			'name' => 'Braga',
			'state' => 23,
		]);
		DB::table('cities')->insert([
			'id' => 3906, 
			'name' => 'Brochier',
			'state' => 23,
		]);
		DB::table('cities')->insert([
			'id' => 3907, 
			'name' => 'Butiá',
			'state' => 23,
		]);
		DB::table('cities')->insert([
			'id' => 3908, 
			'name' => 'Caçapava do Sul',
			'state' => 23,
		]);
		DB::table('cities')->insert([
			'id' => 3909, 
			'name' => 'Cacequi',
			'state' => 23,
		]);
		DB::table('cities')->insert([
			'id' => 3910, 
			'name' => 'Cachoeira do Sul',
			'state' => 23,
		]);
		DB::table('cities')->insert([
			'id' => 3911, 
			'name' => 'Cachoeirinha',
			'state' => 23,
		]);
		DB::table('cities')->insert([
			'id' => 3912, 
			'name' => 'Cacique Doble',
			'state' => 23,
		]);
		DB::table('cities')->insert([
			'id' => 3913, 
			'name' => 'Caibaté',
			'state' => 23,
		]);
		DB::table('cities')->insert([
			'id' => 3914, 
			'name' => 'Caiçara',
			'state' => 23,
		]);
		DB::table('cities')->insert([
			'id' => 3915, 
			'name' => 'Camaquã',
			'state' => 23,
		]);
		DB::table('cities')->insert([
			'id' => 3916, 
			'name' => 'Camargo',
			'state' => 23,
		]);
		DB::table('cities')->insert([
			'id' => 3917, 
			'name' => 'Cambará do Sul',
			'state' => 23,
		]);
		DB::table('cities')->insert([
			'id' => 3918, 
			'name' => 'Campestre da Serra',
			'state' => 23,
		]);
		DB::table('cities')->insert([
			'id' => 3919, 
			'name' => 'Campina das Missões',
			'state' => 23,
		]);
		DB::table('cities')->insert([
			'id' => 3920, 
			'name' => 'Campinas do Sul',
			'state' => 23,
		]);
		DB::table('cities')->insert([
			'id' => 3921, 
			'name' => 'Campo Bom',
			'state' => 23,
		]);
		DB::table('cities')->insert([
			'id' => 3922, 
			'name' => 'Campo Novo',
			'state' => 23,
		]);
		DB::table('cities')->insert([
			'id' => 3923, 
			'name' => 'Campos Borges',
			'state' => 23,
		]);
		DB::table('cities')->insert([
			'id' => 3924, 
			'name' => 'Candelária',
			'state' => 23,
		]);
		DB::table('cities')->insert([
			'id' => 3925, 
			'name' => 'Cândido Godói',
			'state' => 23,
		]);
		DB::table('cities')->insert([
			'id' => 3926, 
			'name' => 'Candiota',
			'state' => 23,
		]);
		DB::table('cities')->insert([
			'id' => 3927, 
			'name' => 'Canela',
			'state' => 23,
		]);
		DB::table('cities')->insert([
			'id' => 3928, 
			'name' => 'Canguçu',
			'state' => 23,
		]);
		DB::table('cities')->insert([
			'id' => 3929, 
			'name' => 'Canoas',
			'state' => 23,
		]);
		DB::table('cities')->insert([
			'id' => 3930, 
			'name' => 'Canudos do Vale',
			'state' => 23,
		]);
		DB::table('cities')->insert([
			'id' => 3931, 
			'name' => 'Capão Bonito do Sul',
			'state' => 23,
		]);
		DB::table('cities')->insert([
			'id' => 3932, 
			'name' => 'Capão da Canoa',
			'state' => 23,
		]);
		DB::table('cities')->insert([
			'id' => 3933, 
			'name' => 'Capão do Cipó',
			'state' => 23,
		]);
		DB::table('cities')->insert([
			'id' => 3934, 
			'name' => 'Capão do Leão',
			'state' => 23,
		]);
		DB::table('cities')->insert([
			'id' => 3935, 
			'name' => 'Capela de Santana',
			'state' => 23,
		]);
		DB::table('cities')->insert([
			'id' => 3936, 
			'name' => 'Capitão',
			'state' => 23,
		]);
		DB::table('cities')->insert([
			'id' => 3937, 
			'name' => 'Capivari do Sul',
			'state' => 23,
		]);
		DB::table('cities')->insert([
			'id' => 3938, 
			'name' => 'Caraá',
			'state' => 23,
		]);
		DB::table('cities')->insert([
			'id' => 3939, 
			'name' => 'Carazinho',
			'state' => 23,
		]);
		DB::table('cities')->insert([
			'id' => 3940, 
			'name' => 'Carlos Barbosa',
			'state' => 23,
		]);
		DB::table('cities')->insert([
			'id' => 3941, 
			'name' => 'Carlos Gomes',
			'state' => 23,
		]);
		DB::table('cities')->insert([
			'id' => 3942, 
			'name' => 'Casca',
			'state' => 23,
		]);
		DB::table('cities')->insert([
			'id' => 3943, 
			'name' => 'Caseiros',
			'state' => 23,
		]);
		DB::table('cities')->insert([
			'id' => 3944, 
			'name' => 'Catuípe',
			'state' => 23,
		]);
		DB::table('cities')->insert([
			'id' => 3945, 
			'name' => 'Caxias do Sul',
			'state' => 23,
		]);
		DB::table('cities')->insert([
			'id' => 3946, 
			'name' => 'Centenário',
			'state' => 23,
		]);
		DB::table('cities')->insert([
			'id' => 3947, 
			'name' => 'Cerrito',
			'state' => 23,
		]);
		DB::table('cities')->insert([
			'id' => 3948, 
			'name' => 'Cerro Branco',
			'state' => 23,
		]);
		DB::table('cities')->insert([
			'id' => 3949, 
			'name' => 'Cerro Grande',
			'state' => 23,
		]);
		DB::table('cities')->insert([
			'id' => 3950, 
			'name' => 'Cerro Grande do Sul',
			'state' => 23,
		]);
		DB::table('cities')->insert([
			'id' => 3951, 
			'name' => 'Cerro Largo',
			'state' => 23,
		]);
		DB::table('cities')->insert([
			'id' => 3952, 
			'name' => 'Chapada',
			'state' => 23,
		]);
		DB::table('cities')->insert([
			'id' => 3953, 
			'name' => 'Charqueadas',
			'state' => 23,
		]);
		DB::table('cities')->insert([
			'id' => 3954, 
			'name' => 'Charrua',
			'state' => 23,
		]);
		DB::table('cities')->insert([
			'id' => 3955, 
			'name' => 'Chiapeta',
			'state' => 23,
		]);
		DB::table('cities')->insert([
			'id' => 3956, 
			'name' => 'Chuí',
			'state' => 23,
		]);
		DB::table('cities')->insert([
			'id' => 3957, 
			'name' => 'Chuvisca',
			'state' => 23,
		]);
		DB::table('cities')->insert([
			'id' => 3958, 
			'name' => 'Cidreira',
			'state' => 23,
		]);
		DB::table('cities')->insert([
			'id' => 3959, 
			'name' => 'Ciríaco',
			'state' => 23,
		]);
		DB::table('cities')->insert([
			'id' => 3960, 
			'name' => 'Colinas',
			'state' => 23,
		]);
		DB::table('cities')->insert([
			'id' => 3961, 
			'name' => 'Colorado',
			'state' => 23,
		]);
		DB::table('cities')->insert([
			'id' => 3962, 
			'name' => 'Condor',
			'state' => 23,
		]);
		DB::table('cities')->insert([
			'id' => 3963, 
			'name' => 'Constantina',
			'state' => 23,
		]);
		DB::table('cities')->insert([
			'id' => 3964, 
			'name' => 'Coqueiro Baixo',
			'state' => 23,
		]);
		DB::table('cities')->insert([
			'id' => 3965, 
			'name' => 'Coqueiros do Sul',
			'state' => 23,
		]);
		DB::table('cities')->insert([
			'id' => 3966, 
			'name' => 'Coronel Barros',
			'state' => 23,
		]);
		DB::table('cities')->insert([
			'id' => 3967, 
			'name' => 'Coronel Bicaco',
			'state' => 23,
		]);
		DB::table('cities')->insert([
			'id' => 3968, 
			'name' => 'Coronel Pilar',
			'state' => 23,
		]);
		DB::table('cities')->insert([
			'id' => 3969, 
			'name' => 'Cotiporã',
			'state' => 23,
		]);
		DB::table('cities')->insert([
			'id' => 3970, 
			'name' => 'Coxilha',
			'state' => 23,
		]);
		DB::table('cities')->insert([
			'id' => 3971, 
			'name' => 'Crissiumal',
			'state' => 23,
		]);
		DB::table('cities')->insert([
			'id' => 3972, 
			'name' => 'Cristal',
			'state' => 23,
		]);
		DB::table('cities')->insert([
			'id' => 3973, 
			'name' => 'Cristal do Sul',
			'state' => 23,
		]);
		DB::table('cities')->insert([
			'id' => 3974, 
			'name' => 'Cruz Alta',
			'state' => 23,
		]);
		DB::table('cities')->insert([
			'id' => 3975, 
			'name' => 'Cruzaltense',
			'state' => 23,
		]);
		DB::table('cities')->insert([
			'id' => 3976, 
			'name' => 'Cruzeiro do Sul',
			'state' => 23,
		]);
		DB::table('cities')->insert([
			'id' => 3977, 
			'name' => 'David Canabarro',
			'state' => 23,
		]);
		DB::table('cities')->insert([
			'id' => 3978, 
			'name' => 'Derrubadas',
			'state' => 23,
		]);
		DB::table('cities')->insert([
			'id' => 3979, 
			'name' => 'Dezesseis de Novembro',
			'state' => 23,
		]);
		DB::table('cities')->insert([
			'id' => 3980, 
			'name' => 'Dilermando de Aguiar',
			'state' => 23,
		]);
		DB::table('cities')->insert([
			'id' => 3981, 
			'name' => 'Dois Irmãos',
			'state' => 23,
		]);
		DB::table('cities')->insert([
			'id' => 3982, 
			'name' => 'Dois Irmãos das Missões',
			'state' => 23,
		]);
		DB::table('cities')->insert([
			'id' => 3983, 
			'name' => 'Dois Lajeados',
			'state' => 23,
		]);
		DB::table('cities')->insert([
			'id' => 3984, 
			'name' => 'Dom Feliciano',
			'state' => 23,
		]);
		DB::table('cities')->insert([
			'id' => 3985, 
			'name' => 'Dom Pedrito',
			'state' => 23,
		]);
		DB::table('cities')->insert([
			'id' => 3986, 
			'name' => 'Dom Pedro de Alcântara',
			'state' => 23,
		]);
		DB::table('cities')->insert([
			'id' => 3987, 
			'name' => 'Dona Francisca',
			'state' => 23,
		]);
		DB::table('cities')->insert([
			'id' => 3988, 
			'name' => 'Doutor Maurício Cardoso',
			'state' => 23,
		]);
		DB::table('cities')->insert([
			'id' => 3989, 
			'name' => 'Doutor Ricardo',
			'state' => 23,
		]);
		DB::table('cities')->insert([
			'id' => 3990, 
			'name' => 'Eldorado do Sul',
			'state' => 23,
		]);
		DB::table('cities')->insert([
			'id' => 3991, 
			'name' => 'Encantado',
			'state' => 23,
		]);
		DB::table('cities')->insert([
			'id' => 3992, 
			'name' => 'Encruzilhada do Sul',
			'state' => 23,
		]);
		DB::table('cities')->insert([
			'id' => 3993, 
			'name' => 'Engenho Velho',
			'state' => 23,
		]);
		DB::table('cities')->insert([
			'id' => 3994, 
			'name' => 'Entre Rios do Sul',
			'state' => 23,
		]);
		DB::table('cities')->insert([
			'id' => 3995, 
			'name' => 'Entre-Ijuís',
			'state' => 23,
		]);
		DB::table('cities')->insert([
			'id' => 3996, 
			'name' => 'Erebango',
			'state' => 23,
		]);
		DB::table('cities')->insert([
			'id' => 3997, 
			'name' => 'Erechim',
			'state' => 23,
		]);
		DB::table('cities')->insert([
			'id' => 3998, 
			'name' => 'Ernestina',
			'state' => 23,
		]);
		DB::table('cities')->insert([
			'id' => 3999, 
			'name' => 'Erval Grande',
			'state' => 23,
		]);
		DB::table('cities')->insert([
			'id' => 4000, 
			'name' => 'Erval Seco',
			'state' => 23,
		]);
		DB::table('cities')->insert([
			'id' => 4001, 
			'name' => 'Esmeralda',
			'state' => 23,
		]);
		DB::table('cities')->insert([
			'id' => 4002, 
			'name' => 'Esperança do Sul',
			'state' => 23,
		]);
		DB::table('cities')->insert([
			'id' => 4003, 
			'name' => 'Espumoso',
			'state' => 23,
		]);
		DB::table('cities')->insert([
			'id' => 4004, 
			'name' => 'Estação',
			'state' => 23,
		]);
		DB::table('cities')->insert([
			'id' => 4005, 
			'name' => 'Estância Velha',
			'state' => 23,
		]);
		DB::table('cities')->insert([
			'id' => 4006, 
			'name' => 'Esteio',
			'state' => 23,
		]);
		DB::table('cities')->insert([
			'id' => 4007, 
			'name' => 'Estrela',
			'state' => 23,
		]);
		DB::table('cities')->insert([
			'id' => 4008, 
			'name' => 'Estrela Velha',
			'state' => 23,
		]);
		DB::table('cities')->insert([
			'id' => 4009, 
			'name' => 'Eugênio de Castro',
			'state' => 23,
		]);
		DB::table('cities')->insert([
			'id' => 4010, 
			'name' => 'Fagundes Varela',
			'state' => 23,
		]);
		DB::table('cities')->insert([
			'id' => 4011, 
			'name' => 'Farroupilha',
			'state' => 23,
		]);
		DB::table('cities')->insert([
			'id' => 4012, 
			'name' => 'Faxinal do Soturno',
			'state' => 23,
		]);
		DB::table('cities')->insert([
			'id' => 4013, 
			'name' => 'Faxinalzinho',
			'state' => 23,
		]);
		DB::table('cities')->insert([
			'id' => 4014, 
			'name' => 'Fazenda Vilanova',
			'state' => 23,
		]);
		DB::table('cities')->insert([
			'id' => 4015, 
			'name' => 'Feliz',
			'state' => 23,
		]);
		DB::table('cities')->insert([
			'id' => 4016, 
			'name' => 'Flores da Cunha',
			'state' => 23,
		]);
		DB::table('cities')->insert([
			'id' => 4017, 
			'name' => 'Floriano Peixoto',
			'state' => 23,
		]);
		DB::table('cities')->insert([
			'id' => 4018, 
			'name' => 'Fontoura Xavier',
			'state' => 23,
		]);
		DB::table('cities')->insert([
			'id' => 4019, 
			'name' => 'Formigueiro',
			'state' => 23,
		]);
		DB::table('cities')->insert([
			'id' => 4020, 
			'name' => 'Forquetinha',
			'state' => 23,
		]);
		DB::table('cities')->insert([
			'id' => 4021, 
			'name' => 'Fortaleza dos Valos',
			'state' => 23,
		]);
		DB::table('cities')->insert([
			'id' => 4022, 
			'name' => 'Frederico Westphalen',
			'state' => 23,
		]);
		DB::table('cities')->insert([
			'id' => 4023, 
			'name' => 'Garibaldi',
			'state' => 23,
		]);
		DB::table('cities')->insert([
			'id' => 4024, 
			'name' => 'Garruchos',
			'state' => 23,
		]);
		DB::table('cities')->insert([
			'id' => 4025, 
			'name' => 'Gaurama',
			'state' => 23,
		]);
		DB::table('cities')->insert([
			'id' => 4026, 
			'name' => 'General Câmara',
			'state' => 23,
		]);
		DB::table('cities')->insert([
			'id' => 4027, 
			'name' => 'Gentil',
			'state' => 23,
		]);
		DB::table('cities')->insert([
			'id' => 4028, 
			'name' => 'Getúlio Vargas',
			'state' => 23,
		]);
		DB::table('cities')->insert([
			'id' => 4029, 
			'name' => 'Giruá',
			'state' => 23,
		]);
		DB::table('cities')->insert([
			'id' => 4030, 
			'name' => 'Glorinha',
			'state' => 23,
		]);
		DB::table('cities')->insert([
			'id' => 4031, 
			'name' => 'Gramado',
			'state' => 23,
		]);
		DB::table('cities')->insert([
			'id' => 4032, 
			'name' => 'Gramado dos Loureiros',
			'state' => 23,
		]);
		DB::table('cities')->insert([
			'id' => 4033, 
			'name' => 'Gramado Xavier',
			'state' => 23,
		]);
		DB::table('cities')->insert([
			'id' => 4034, 
			'name' => 'Gravataí',
			'state' => 23,
		]);
		DB::table('cities')->insert([
			'id' => 4035, 
			'name' => 'Guabiju',
			'state' => 23,
		]);
		DB::table('cities')->insert([
			'id' => 4036, 
			'name' => 'Guaíba',
			'state' => 23,
		]);
		DB::table('cities')->insert([
			'id' => 4037, 
			'name' => 'Guaporé',
			'state' => 23,
		]);
		DB::table('cities')->insert([
			'id' => 4038, 
			'name' => 'Guarani das Missões',
			'state' => 23,
		]);
		DB::table('cities')->insert([
			'id' => 4039, 
			'name' => 'Harmonia',
			'state' => 23,
		]);
		DB::table('cities')->insert([
			'id' => 4040, 
			'name' => 'Herval',
			'state' => 23,
		]);
		DB::table('cities')->insert([
			'id' => 4041, 
			'name' => 'Herveiras',
			'state' => 23,
		]);
		DB::table('cities')->insert([
			'id' => 4042, 
			'name' => 'Horizontina',
			'state' => 23,
		]);
		DB::table('cities')->insert([
			'id' => 4043, 
			'name' => 'Hulha Negra',
			'state' => 23,
		]);
		DB::table('cities')->insert([
			'id' => 4044, 
			'name' => 'Humaitá',
			'state' => 23,
		]);
		DB::table('cities')->insert([
			'id' => 4045, 
			'name' => 'Ibarama',
			'state' => 23,
		]);
		DB::table('cities')->insert([
			'id' => 4046, 
			'name' => 'Ibiaçá',
			'state' => 23,
		]);
		DB::table('cities')->insert([
			'id' => 4047, 
			'name' => 'Ibiraiaras',
			'state' => 23,
		]);
		DB::table('cities')->insert([
			'id' => 4048, 
			'name' => 'Ibirapuitã',
			'state' => 23,
		]);
		DB::table('cities')->insert([
			'id' => 4049, 
			'name' => 'Ibirubá',
			'state' => 23,
		]);
		DB::table('cities')->insert([
			'id' => 4050, 
			'name' => 'Igrejinha',
			'state' => 23,
		]);
		DB::table('cities')->insert([
			'id' => 4051, 
			'name' => 'Ijuí',
			'state' => 23,
		]);
		DB::table('cities')->insert([
			'id' => 4052, 
			'name' => 'Ilópolis',
			'state' => 23,
		]);
		DB::table('cities')->insert([
			'id' => 4053, 
			'name' => 'Imbé',
			'state' => 23,
		]);
		DB::table('cities')->insert([
			'id' => 4054, 
			'name' => 'Imigrante',
			'state' => 23,
		]);
		DB::table('cities')->insert([
			'id' => 4055, 
			'name' => 'Independência',
			'state' => 23,
		]);
		DB::table('cities')->insert([
			'id' => 4056, 
			'name' => 'Inhacorá',
			'state' => 23,
		]);
		DB::table('cities')->insert([
			'id' => 4057, 
			'name' => 'Ipê',
			'state' => 23,
		]);
		DB::table('cities')->insert([
			'id' => 4058, 
			'name' => 'Ipiranga do Sul',
			'state' => 23,
		]);
		DB::table('cities')->insert([
			'id' => 4059, 
			'name' => 'Iraí',
			'state' => 23,
		]);
		DB::table('cities')->insert([
			'id' => 4060, 
			'name' => 'Itaara',
			'state' => 23,
		]);
		DB::table('cities')->insert([
			'id' => 4061, 
			'name' => 'Itacurubi',
			'state' => 23,
		]);
		DB::table('cities')->insert([
			'id' => 4062, 
			'name' => 'Itapuca',
			'state' => 23,
		]);
		DB::table('cities')->insert([
			'id' => 4063, 
			'name' => 'Itaqui',
			'state' => 23,
		]);
		DB::table('cities')->insert([
			'id' => 4064, 
			'name' => 'Itati',
			'state' => 23,
		]);
		DB::table('cities')->insert([
			'id' => 4065, 
			'name' => 'Itatiba do Sul',
			'state' => 23,
		]);
		DB::table('cities')->insert([
			'id' => 4066, 
			'name' => 'Ivorá',
			'state' => 23,
		]);
		DB::table('cities')->insert([
			'id' => 4067, 
			'name' => 'Ivoti',
			'state' => 23,
		]);
		DB::table('cities')->insert([
			'id' => 4068, 
			'name' => 'Jaboticaba',
			'state' => 23,
		]);
		DB::table('cities')->insert([
			'id' => 4069, 
			'name' => 'Jacuizinho',
			'state' => 23,
		]);
		DB::table('cities')->insert([
			'id' => 4070, 
			'name' => 'Jacutinga',
			'state' => 23,
		]);
		DB::table('cities')->insert([
			'id' => 4071, 
			'name' => 'Jaguarão',
			'state' => 23,
		]);
		DB::table('cities')->insert([
			'id' => 4072, 
			'name' => 'Jaguari',
			'state' => 23,
		]);
		DB::table('cities')->insert([
			'id' => 4073, 
			'name' => 'Jaquirana',
			'state' => 23,
		]);
		DB::table('cities')->insert([
			'id' => 4074, 
			'name' => 'Jari',
			'state' => 23,
		]);
		DB::table('cities')->insert([
			'id' => 4075, 
			'name' => 'Jóia',
			'state' => 23,
		]);
		DB::table('cities')->insert([
			'id' => 4076, 
			'name' => 'Júlio de Castilhos',
			'state' => 23,
		]);
		DB::table('cities')->insert([
			'id' => 4077, 
			'name' => 'Lagoa Bonita do Sul',
			'state' => 23,
		]);
		DB::table('cities')->insert([
			'id' => 4078, 
			'name' => 'Lagoa dos Três Cantos',
			'state' => 23,
		]);
		DB::table('cities')->insert([
			'id' => 4079, 
			'name' => 'Lagoa Vermelha',
			'state' => 23,
		]);
		DB::table('cities')->insert([
			'id' => 4080, 
			'name' => 'Lagoão',
			'state' => 23,
		]);
		DB::table('cities')->insert([
			'id' => 4081, 
			'name' => 'Lajeado',
			'state' => 23,
		]);
		DB::table('cities')->insert([
			'id' => 4082, 
			'name' => 'Lajeado do Bugre',
			'state' => 23,
		]);
		DB::table('cities')->insert([
			'id' => 4083, 
			'name' => 'Lavras do Sul',
			'state' => 23,
		]);
		DB::table('cities')->insert([
			'id' => 4084, 
			'name' => 'Liberato Salzano',
			'state' => 23,
		]);
		DB::table('cities')->insert([
			'id' => 4085, 
			'name' => 'Lindolfo Collor',
			'state' => 23,
		]);
		DB::table('cities')->insert([
			'id' => 4086, 
			'name' => 'Linha Nova',
			'state' => 23,
		]);
		DB::table('cities')->insert([
			'id' => 4087, 
			'name' => 'Maçambara',
			'state' => 23,
		]);
		DB::table('cities')->insert([
			'id' => 4088, 
			'name' => 'Machadinho',
			'state' => 23,
		]);
		DB::table('cities')->insert([
			'id' => 4089, 
			'name' => 'Mampituba',
			'state' => 23,
		]);
		DB::table('cities')->insert([
			'id' => 4090, 
			'name' => 'Manoel Viana',
			'state' => 23,
		]);
		DB::table('cities')->insert([
			'id' => 4091, 
			'name' => 'Maquiné',
			'state' => 23,
		]);
		DB::table('cities')->insert([
			'id' => 4092, 
			'name' => 'Maratá',
			'state' => 23,
		]);
		DB::table('cities')->insert([
			'id' => 4093, 
			'name' => 'Marau',
			'state' => 23,
		]);
		DB::table('cities')->insert([
			'id' => 4094, 
			'name' => 'Marcelino Ramos',
			'state' => 23,
		]);
		DB::table('cities')->insert([
			'id' => 4095, 
			'name' => 'Mariana Pimentel',
			'state' => 23,
		]);
		DB::table('cities')->insert([
			'id' => 4096, 
			'name' => 'Mariano Moro',
			'state' => 23,
		]);
		DB::table('cities')->insert([
			'id' => 4097, 
			'name' => 'Marques de Souza',
			'state' => 23,
		]);
		DB::table('cities')->insert([
			'id' => 4098, 
			'name' => 'Mata',
			'state' => 23,
		]);
		DB::table('cities')->insert([
			'id' => 4099, 
			'name' => 'Mato Castelhano',
			'state' => 23,
		]);
		DB::table('cities')->insert([
			'id' => 4100, 
			'name' => 'Mato Leitão',
			'state' => 23,
		]);
		DB::table('cities')->insert([
			'id' => 4101, 
			'name' => 'Mato Queimado',
			'state' => 23,
		]);
		DB::table('cities')->insert([
			'id' => 4102, 
			'name' => 'Maximiliano de Almeida',
			'state' => 23,
		]);
		DB::table('cities')->insert([
			'id' => 4103, 
			'name' => 'Minas do Leão',
			'state' => 23,
		]);
		DB::table('cities')->insert([
			'id' => 4104, 
			'name' => 'Miraguaí',
			'state' => 23,
		]);
		DB::table('cities')->insert([
			'id' => 4105, 
			'name' => 'Montauri',
			'state' => 23,
		]);
		DB::table('cities')->insert([
			'id' => 4106, 
			'name' => 'Monte Alegre dos Campos',
			'state' => 23,
		]);
		DB::table('cities')->insert([
			'id' => 4107, 
			'name' => 'Monte Belo do Sul',
			'state' => 23,
		]);
		DB::table('cities')->insert([
			'id' => 4108, 
			'name' => 'Montenegro',
			'state' => 23,
		]);
		DB::table('cities')->insert([
			'id' => 4109, 
			'name' => 'Mormaço',
			'state' => 23,
		]);
		DB::table('cities')->insert([
			'id' => 4110, 
			'name' => 'Morrinhos do Sul',
			'state' => 23,
		]);
		DB::table('cities')->insert([
			'id' => 4111, 
			'name' => 'Morro Redondo',
			'state' => 23,
		]);
		DB::table('cities')->insert([
			'id' => 4112, 
			'name' => 'Morro Reuter',
			'state' => 23,
		]);
		DB::table('cities')->insert([
			'id' => 4113, 
			'name' => 'Mostardas',
			'state' => 23,
		]);
		DB::table('cities')->insert([
			'id' => 4114, 
			'name' => 'Muçum',
			'state' => 23,
		]);
		DB::table('cities')->insert([
			'id' => 4115, 
			'name' => 'Muitos Capões',
			'state' => 23,
		]);
		DB::table('cities')->insert([
			'id' => 4116, 
			'name' => 'Muliterno',
			'state' => 23,
		]);
		DB::table('cities')->insert([
			'id' => 4117, 
			'name' => 'Não-Me-Toque',
			'state' => 23,
		]);
		DB::table('cities')->insert([
			'id' => 4118, 
			'name' => 'Nicolau Vergueiro',
			'state' => 23,
		]);
		DB::table('cities')->insert([
			'id' => 4119, 
			'name' => 'Nonoai',
			'state' => 23,
		]);
		DB::table('cities')->insert([
			'id' => 4120, 
			'name' => 'Nova Alvorada',
			'state' => 23,
		]);
		DB::table('cities')->insert([
			'id' => 4121, 
			'name' => 'Nova Araçá',
			'state' => 23,
		]);
		DB::table('cities')->insert([
			'id' => 4122, 
			'name' => 'Nova Bassano',
			'state' => 23,
		]);
		DB::table('cities')->insert([
			'id' => 4123, 
			'name' => 'Nova Boa Vista',
			'state' => 23,
		]);
		DB::table('cities')->insert([
			'id' => 4124, 
			'name' => 'Nova Bréscia',
			'state' => 23,
		]);
		DB::table('cities')->insert([
			'id' => 4125, 
			'name' => 'Nova Candelária',
			'state' => 23,
		]);
		DB::table('cities')->insert([
			'id' => 4126, 
			'name' => 'Nova Esperança do Sul',
			'state' => 23,
		]);
		DB::table('cities')->insert([
			'id' => 4127, 
			'name' => 'Nova Hartz',
			'state' => 23,
		]);
		DB::table('cities')->insert([
			'id' => 4128, 
			'name' => 'Nova Pádua',
			'state' => 23,
		]);
		DB::table('cities')->insert([
			'id' => 4129, 
			'name' => 'Nova Palma',
			'state' => 23,
		]);
		DB::table('cities')->insert([
			'id' => 4130, 
			'name' => 'Nova Petrópolis',
			'state' => 23,
		]);
		DB::table('cities')->insert([
			'id' => 4131, 
			'name' => 'Nova Prata',
			'state' => 23,
		]);
		DB::table('cities')->insert([
			'id' => 4132, 
			'name' => 'Nova Ramada',
			'state' => 23,
		]);
		DB::table('cities')->insert([
			'id' => 4133, 
			'name' => 'Nova Roma do Sul',
			'state' => 23,
		]);
		DB::table('cities')->insert([
			'id' => 4134, 
			'name' => 'Nova Santa Rita',
			'state' => 23,
		]);
		DB::table('cities')->insert([
			'id' => 4135, 
			'name' => 'Novo Barreiro',
			'state' => 23,
		]);
		DB::table('cities')->insert([
			'id' => 4136, 
			'name' => 'Novo Cabrais',
			'state' => 23,
		]);
		DB::table('cities')->insert([
			'id' => 4137, 
			'name' => 'Novo Hamburgo',
			'state' => 23,
		]);
		DB::table('cities')->insert([
			'id' => 4138, 
			'name' => 'Novo Machado',
			'state' => 23,
		]);
		DB::table('cities')->insert([
			'id' => 4139, 
			'name' => 'Novo Tiradentes',
			'state' => 23,
		]);
		DB::table('cities')->insert([
			'id' => 4140, 
			'name' => 'Novo Xingu',
			'state' => 23,
		]);
		DB::table('cities')->insert([
			'id' => 4141, 
			'name' => 'Osório',
			'state' => 23,
		]);
		DB::table('cities')->insert([
			'id' => 4142, 
			'name' => 'Paim Filho',
			'state' => 23,
		]);
		DB::table('cities')->insert([
			'id' => 4143, 
			'name' => 'Palmares do Sul',
			'state' => 23,
		]);
		DB::table('cities')->insert([
			'id' => 4144, 
			'name' => 'Palmeira das Missões',
			'state' => 23,
		]);
		DB::table('cities')->insert([
			'id' => 4145, 
			'name' => 'Palmitinho',
			'state' => 23,
		]);
		DB::table('cities')->insert([
			'id' => 4146, 
			'name' => 'Panambi',
			'state' => 23,
		]);
		DB::table('cities')->insert([
			'id' => 4147, 
			'name' => 'Pantano Grande',
			'state' => 23,
		]);
		DB::table('cities')->insert([
			'id' => 4148, 
			'name' => 'Paraí',
			'state' => 23,
		]);
		DB::table('cities')->insert([
			'id' => 4149, 
			'name' => 'Paraíso do Sul',
			'state' => 23,
		]);
		DB::table('cities')->insert([
			'id' => 4150, 
			'name' => 'Pareci Novo',
			'state' => 23,
		]);
		DB::table('cities')->insert([
			'id' => 4151, 
			'name' => 'Parobé',
			'state' => 23,
		]);
		DB::table('cities')->insert([
			'id' => 4152, 
			'name' => 'Passa Sete',
			'state' => 23,
		]);
		DB::table('cities')->insert([
			'id' => 4153, 
			'name' => 'Passo do Sobrado',
			'state' => 23,
		]);
		DB::table('cities')->insert([
			'id' => 4154, 
			'name' => 'Passo Fundo',
			'state' => 23,
		]);
		DB::table('cities')->insert([
			'id' => 4155, 
			'name' => 'Paulo Bento',
			'state' => 23,
		]);
		DB::table('cities')->insert([
			'id' => 4156, 
			'name' => 'Paverama',
			'state' => 23,
		]);
		DB::table('cities')->insert([
			'id' => 4157, 
			'name' => 'Pedras Altas',
			'state' => 23,
		]);
		DB::table('cities')->insert([
			'id' => 4158, 
			'name' => 'Pedro Osório',
			'state' => 23,
		]);
		DB::table('cities')->insert([
			'id' => 4159, 
			'name' => 'Pejuçara',
			'state' => 23,
		]);
		DB::table('cities')->insert([
			'id' => 4160, 
			'name' => 'Pelotas',
			'state' => 23,
		]);
		DB::table('cities')->insert([
			'id' => 4161, 
			'name' => 'Picada Café',
			'state' => 23,
		]);
		DB::table('cities')->insert([
			'id' => 4162, 
			'name' => 'Pinhal',
			'state' => 23,
		]);
		DB::table('cities')->insert([
			'id' => 4163, 
			'name' => 'Pinhal da Serra',
			'state' => 23,
		]);
		DB::table('cities')->insert([
			'id' => 4164, 
			'name' => 'Pinhal Grande',
			'state' => 23,
		]);
		DB::table('cities')->insert([
			'id' => 4165, 
			'name' => 'Pinheirinho do Vale',
			'state' => 23,
		]);
		DB::table('cities')->insert([
			'id' => 4166, 
			'name' => 'Pinheiro Machado',
			'state' => 23,
		]);
		DB::table('cities')->insert([
			'id' => 4167, 
			'name' => 'Pirapó',
			'state' => 23,
		]);
		DB::table('cities')->insert([
			'id' => 4168, 
			'name' => 'Piratini',
			'state' => 23,
		]);
		DB::table('cities')->insert([
			'id' => 4169, 
			'name' => 'Planalto',
			'state' => 23,
		]);
		DB::table('cities')->insert([
			'id' => 4170, 
			'name' => 'Poço das Antas',
			'state' => 23,
		]);
		DB::table('cities')->insert([
			'id' => 4171, 
			'name' => 'Pontão',
			'state' => 23,
		]);
		DB::table('cities')->insert([
			'id' => 4172, 
			'name' => 'Ponte Preta',
			'state' => 23,
		]);
		DB::table('cities')->insert([
			'id' => 4173, 
			'name' => 'Portão',
			'state' => 23,
		]);
		DB::table('cities')->insert([
			'id' => 4174, 
			'name' => 'Porto Alegre',
			'state' => 23,
		]);
		DB::table('cities')->insert([
			'id' => 4175, 
			'name' => 'Porto Lucena',
			'state' => 23,
		]);
		DB::table('cities')->insert([
			'id' => 4176, 
			'name' => 'Porto Mauá',
			'state' => 23,
		]);
		DB::table('cities')->insert([
			'id' => 4177, 
			'name' => 'Porto Vera Cruz',
			'state' => 23,
		]);
		DB::table('cities')->insert([
			'id' => 4178, 
			'name' => 'Porto Xavier',
			'state' => 23,
		]);
		DB::table('cities')->insert([
			'id' => 4179, 
			'name' => 'Pouso Novo',
			'state' => 23,
		]);
		DB::table('cities')->insert([
			'id' => 4180, 
			'name' => 'Presidente Lucena',
			'state' => 23,
		]);
		DB::table('cities')->insert([
			'id' => 4181, 
			'name' => 'Progresso',
			'state' => 23,
		]);
		DB::table('cities')->insert([
			'id' => 4182, 
			'name' => 'Protásio Alves',
			'state' => 23,
		]);
		DB::table('cities')->insert([
			'id' => 4183, 
			'name' => 'Putinga',
			'state' => 23,
		]);
		DB::table('cities')->insert([
			'id' => 4184, 
			'name' => 'Quaraí',
			'state' => 23,
		]);
		DB::table('cities')->insert([
			'id' => 4185, 
			'name' => 'Quatro Irmãos',
			'state' => 23,
		]);
		DB::table('cities')->insert([
			'id' => 4186, 
			'name' => 'Quevedos',
			'state' => 23,
		]);
		DB::table('cities')->insert([
			'id' => 4187, 
			'name' => 'Quinze de Novembro',
			'state' => 23,
		]);
		DB::table('cities')->insert([
			'id' => 4188, 
			'name' => 'Redentora',
			'state' => 23,
		]);
		DB::table('cities')->insert([
			'id' => 4189, 
			'name' => 'Relvado',
			'state' => 23,
		]);
		DB::table('cities')->insert([
			'id' => 4190, 
			'name' => 'Restinga Seca',
			'state' => 23,
		]);
		DB::table('cities')->insert([
			'id' => 4191, 
			'name' => 'Rio dos Índios',
			'state' => 23,
		]);
		DB::table('cities')->insert([
			'id' => 4192, 
			'name' => 'Rio Grande',
			'state' => 23,
		]);
		DB::table('cities')->insert([
			'id' => 4193, 
			'name' => 'Rio Pardo',
			'state' => 23,
		]);
		DB::table('cities')->insert([
			'id' => 4194, 
			'name' => 'Riozinho',
			'state' => 23,
		]);
		DB::table('cities')->insert([
			'id' => 4195, 
			'name' => 'Roca Sales',
			'state' => 23,
		]);
		DB::table('cities')->insert([
			'id' => 4196, 
			'name' => 'Rodeio Bonito',
			'state' => 23,
		]);
		DB::table('cities')->insert([
			'id' => 4197, 
			'name' => 'Rolador',
			'state' => 23,
		]);
		DB::table('cities')->insert([
			'id' => 4198, 
			'name' => 'Rolante',
			'state' => 23,
		]);
		DB::table('cities')->insert([
			'id' => 4199, 
			'name' => 'Ronda Alta',
			'state' => 23,
		]);
		DB::table('cities')->insert([
			'id' => 4200, 
			'name' => 'Rondinha',
			'state' => 23,
		]);
		DB::table('cities')->insert([
			'id' => 4201, 
			'name' => 'Roque Gonzales',
			'state' => 23,
		]);
		DB::table('cities')->insert([
			'id' => 4202, 
			'name' => 'Rosário do Sul',
			'state' => 23,
		]);
		DB::table('cities')->insert([
			'id' => 4203, 
			'name' => 'Sagrada Família',
			'state' => 23,
		]);
		DB::table('cities')->insert([
			'id' => 4204, 
			'name' => 'Saldanha Marinho',
			'state' => 23,
		]);
		DB::table('cities')->insert([
			'id' => 4205, 
			'name' => 'Salto do Jacuí',
			'state' => 23,
		]);
		DB::table('cities')->insert([
			'id' => 4206, 
			'name' => 'Salvador das Missões',
			'state' => 23,
		]);
		DB::table('cities')->insert([
			'id' => 4207, 
			'name' => 'Salvador do Sul',
			'state' => 23,
		]);
		DB::table('cities')->insert([
			'id' => 4208, 
			'name' => 'Sananduva',
			'state' => 23,
		]);
		DB::table('cities')->insert([
			'id' => 4209, 
			'name' => 'Santa Bárbara do Sul',
			'state' => 23,
		]);
		DB::table('cities')->insert([
			'id' => 4210, 
			'name' => 'Santa Cecília do Sul',
			'state' => 23,
		]);
		DB::table('cities')->insert([
			'id' => 4211, 
			'name' => 'Santa Clara do Sul',
			'state' => 23,
		]);
		DB::table('cities')->insert([
			'id' => 4212, 
			'name' => 'Santa Cruz do Sul',
			'state' => 23,
		]);
		DB::table('cities')->insert([
			'id' => 4213, 
			'name' => 'Santa Margarida do Sul',
			'state' => 23,
		]);
		DB::table('cities')->insert([
			'id' => 4214, 
			'name' => 'Santa Maria',
			'state' => 23,
		]);
		DB::table('cities')->insert([
			'id' => 4215, 
			'name' => 'Santa Maria do Herval',
			'state' => 23,
		]);
		DB::table('cities')->insert([
			'id' => 4216, 
			'name' => 'Santa Rosa',
			'state' => 23,
		]);
		DB::table('cities')->insert([
			'id' => 4217, 
			'name' => 'Santa Tereza',
			'state' => 23,
		]);
		DB::table('cities')->insert([
			'id' => 4218, 
			'name' => 'Santa Vitória do Palmar',
			'state' => 23,
		]);
		DB::table('cities')->insert([
			'id' => 4219, 
			'name' => 'Santana da Boa Vista',
			'state' => 23,
		]);
		DB::table('cities')->insert([
			'id' => 4220, 
			'name' => 'Santana do Livramento',
			'state' => 23,
		]);
		DB::table('cities')->insert([
			'id' => 4221, 
			'name' => 'Santiago',
			'state' => 23,
		]);
		DB::table('cities')->insert([
			'id' => 4222, 
			'name' => 'Santo Ângelo',
			'state' => 23,
		]);
		DB::table('cities')->insert([
			'id' => 4223, 
			'name' => 'Santo Antônio da Patrulha',
			'state' => 23,
		]);
		DB::table('cities')->insert([
			'id' => 4224, 
			'name' => 'Santo Antônio das Missões',
			'state' => 23,
		]);
		DB::table('cities')->insert([
			'id' => 4225, 
			'name' => 'Santo Antônio do Palma',
			'state' => 23,
		]);
		DB::table('cities')->insert([
			'id' => 4226, 
			'name' => 'Santo Antônio do Planalto',
			'state' => 23,
		]);
		DB::table('cities')->insert([
			'id' => 4227, 
			'name' => 'Santo Augusto',
			'state' => 23,
		]);
		DB::table('cities')->insert([
			'id' => 4228, 
			'name' => 'Santo Cristo',
			'state' => 23,
		]);
		DB::table('cities')->insert([
			'id' => 4229, 
			'name' => 'Santo Expedito do Sul',
			'state' => 23,
		]);
		DB::table('cities')->insert([
			'id' => 4230, 
			'name' => 'São Borja',
			'state' => 23,
		]);
		DB::table('cities')->insert([
			'id' => 4231, 
			'name' => 'São Domingos do Sul',
			'state' => 23,
		]);
		DB::table('cities')->insert([
			'id' => 4232, 
			'name' => 'São Francisco de Assis',
			'state' => 23,
		]);
		DB::table('cities')->insert([
			'id' => 4233, 
			'name' => 'São Francisco de Paula',
			'state' => 23,
		]);
		DB::table('cities')->insert([
			'id' => 4234, 
			'name' => 'São Gabriel',
			'state' => 23,
		]);
		DB::table('cities')->insert([
			'id' => 4235, 
			'name' => 'São Jerônimo',
			'state' => 23,
		]);
		DB::table('cities')->insert([
			'id' => 4236, 
			'name' => 'São João da Urtiga',
			'state' => 23,
		]);
		DB::table('cities')->insert([
			'id' => 4237, 
			'name' => 'São João do Polêsine',
			'state' => 23,
		]);
		DB::table('cities')->insert([
			'id' => 4238, 
			'name' => 'São Jorge',
			'state' => 23,
		]);
		DB::table('cities')->insert([
			'id' => 4239, 
			'name' => 'São José das Missões',
			'state' => 23,
		]);
		DB::table('cities')->insert([
			'id' => 4240, 
			'name' => 'São José do Herval',
			'state' => 23,
		]);
		DB::table('cities')->insert([
			'id' => 4241, 
			'name' => 'São José do Hortêncio',
			'state' => 23,
		]);
		DB::table('cities')->insert([
			'id' => 4242, 
			'name' => 'São José do Inhacorá',
			'state' => 23,
		]);
		DB::table('cities')->insert([
			'id' => 4243, 
			'name' => 'São José do Norte',
			'state' => 23,
		]);
		DB::table('cities')->insert([
			'id' => 4244, 
			'name' => 'São José do Ouro',
			'state' => 23,
		]);
		DB::table('cities')->insert([
			'id' => 4245, 
			'name' => 'São José do Sul',
			'state' => 23,
		]);
		DB::table('cities')->insert([
			'id' => 4246, 
			'name' => 'São José dos Ausentes',
			'state' => 23,
		]);
		DB::table('cities')->insert([
			'id' => 4247, 
			'name' => 'São Leopoldo',
			'state' => 23,
		]);
		DB::table('cities')->insert([
			'id' => 4248, 
			'name' => 'São Lourenço do Sul',
			'state' => 23,
		]);
		DB::table('cities')->insert([
			'id' => 4249, 
			'name' => 'São Luiz Gonzaga',
			'state' => 23,
		]);
		DB::table('cities')->insert([
			'id' => 4250, 
			'name' => 'São Marcos',
			'state' => 23,
		]);
		DB::table('cities')->insert([
			'id' => 4251, 
			'name' => 'São Martinho',
			'state' => 23,
		]);
		DB::table('cities')->insert([
			'id' => 4252, 
			'name' => 'São Martinho da Serra',
			'state' => 23,
		]);
		DB::table('cities')->insert([
			'id' => 4253, 
			'name' => 'São Miguel das Missões',
			'state' => 23,
		]);
		DB::table('cities')->insert([
			'id' => 4254, 
			'name' => 'São Nicolau',
			'state' => 23,
		]);
		DB::table('cities')->insert([
			'id' => 4255, 
			'name' => 'São Paulo das Missões',
			'state' => 23,
		]);
		DB::table('cities')->insert([
			'id' => 4256, 
			'name' => 'São Pedro da Serra',
			'state' => 23,
		]);
		DB::table('cities')->insert([
			'id' => 4257, 
			'name' => 'São Pedro das Missões',
			'state' => 23,
		]);
		DB::table('cities')->insert([
			'id' => 4258, 
			'name' => 'São Pedro do Butiá',
			'state' => 23,
		]);
		DB::table('cities')->insert([
			'id' => 4259, 
			'name' => 'São Pedro do Sul',
			'state' => 23,
		]);
		DB::table('cities')->insert([
			'id' => 4260, 
			'name' => 'São Sebastião do Caí',
			'state' => 23,
		]);
		DB::table('cities')->insert([
			'id' => 4261, 
			'name' => 'São Sepé',
			'state' => 23,
		]);
		DB::table('cities')->insert([
			'id' => 4262, 
			'name' => 'São Valentim',
			'state' => 23,
		]);
		DB::table('cities')->insert([
			'id' => 4263, 
			'name' => 'São Valentim do Sul',
			'state' => 23,
		]);
		DB::table('cities')->insert([
			'id' => 4264, 
			'name' => 'São Valério do Sul',
			'state' => 23,
		]);
		DB::table('cities')->insert([
			'id' => 4265, 
			'name' => 'São Vendelino',
			'state' => 23,
		]);
		DB::table('cities')->insert([
			'id' => 4266, 
			'name' => 'São Vicente do Sul',
			'state' => 23,
		]);
		DB::table('cities')->insert([
			'id' => 4267, 
			'name' => 'Sapiranga',
			'state' => 23,
		]);
		DB::table('cities')->insert([
			'id' => 4268, 
			'name' => 'Sapucaia do Sul',
			'state' => 23,
		]);
		DB::table('cities')->insert([
			'id' => 4269, 
			'name' => 'Sarandi',
			'state' => 23,
		]);
		DB::table('cities')->insert([
			'id' => 4270, 
			'name' => 'Seberi',
			'state' => 23,
		]);
		DB::table('cities')->insert([
			'id' => 4271, 
			'name' => 'Sede Nova',
			'state' => 23,
		]);
		DB::table('cities')->insert([
			'id' => 4272, 
			'name' => 'Segredo',
			'state' => 23,
		]);
		DB::table('cities')->insert([
			'id' => 4273, 
			'name' => 'Selbach',
			'state' => 23,
		]);
		DB::table('cities')->insert([
			'id' => 4274, 
			'name' => 'Senador Salgado Filho',
			'state' => 23,
		]);
		DB::table('cities')->insert([
			'id' => 4275, 
			'name' => 'Sentinela do Sul',
			'state' => 23,
		]);
		DB::table('cities')->insert([
			'id' => 4276, 
			'name' => 'Serafina Corrêa',
			'state' => 23,
		]);
		DB::table('cities')->insert([
			'id' => 4277, 
			'name' => 'Sério',
			'state' => 23,
		]);
		DB::table('cities')->insert([
			'id' => 4278, 
			'name' => 'Sertão',
			'state' => 23,
		]);
		DB::table('cities')->insert([
			'id' => 4279, 
			'name' => 'Sertão Santana',
			'state' => 23,
		]);
		DB::table('cities')->insert([
			'id' => 4280, 
			'name' => 'Sete de Setembro',
			'state' => 23,
		]);
		DB::table('cities')->insert([
			'id' => 4281, 
			'name' => 'Severiano de Almeida',
			'state' => 23,
		]);
		DB::table('cities')->insert([
			'id' => 4282, 
			'name' => 'Silveira Martins',
			'state' => 23,
		]);
		DB::table('cities')->insert([
			'id' => 4283, 
			'name' => 'Sinimbu',
			'state' => 23,
		]);
		DB::table('cities')->insert([
			'id' => 4284, 
			'name' => 'Sobradinho',
			'state' => 23,
		]);
		DB::table('cities')->insert([
			'id' => 4285, 
			'name' => 'Soledade',
			'state' => 23,
		]);
		DB::table('cities')->insert([
			'id' => 4286, 
			'name' => 'Tabaí',
			'state' => 23,
		]);
		DB::table('cities')->insert([
			'id' => 4287, 
			'name' => 'Tapejara',
			'state' => 23,
		]);
		DB::table('cities')->insert([
			'id' => 4288, 
			'name' => 'Tapera',
			'state' => 23,
		]);
		DB::table('cities')->insert([
			'id' => 4289, 
			'name' => 'Tapes',
			'state' => 23,
		]);
		DB::table('cities')->insert([
			'id' => 4290, 
			'name' => 'Taquara',
			'state' => 23,
		]);
		DB::table('cities')->insert([
			'id' => 4291, 
			'name' => 'Taquari',
			'state' => 23,
		]);
		DB::table('cities')->insert([
			'id' => 4292, 
			'name' => 'Taquaruçu do Sul',
			'state' => 23,
		]);
		DB::table('cities')->insert([
			'id' => 4293, 
			'name' => 'Tavares',
			'state' => 23,
		]);
		DB::table('cities')->insert([
			'id' => 4294, 
			'name' => 'Tenente Portela',
			'state' => 23,
		]);
		DB::table('cities')->insert([
			'id' => 4295, 
			'name' => 'Terra de Areia',
			'state' => 23,
		]);
		DB::table('cities')->insert([
			'id' => 4296, 
			'name' => 'Teutônia',
			'state' => 23,
		]);
		DB::table('cities')->insert([
			'id' => 4297, 
			'name' => 'Tio Hugo',
			'state' => 23,
		]);
		DB::table('cities')->insert([
			'id' => 4298, 
			'name' => 'Tiradentes do Sul',
			'state' => 23,
		]);
		DB::table('cities')->insert([
			'id' => 4299, 
			'name' => 'Toropi',
			'state' => 23,
		]);
		DB::table('cities')->insert([
			'id' => 4300, 
			'name' => 'Torres',
			'state' => 23,
		]);
		DB::table('cities')->insert([
			'id' => 4301, 
			'name' => 'Tramandaí',
			'state' => 23,
		]);
		DB::table('cities')->insert([
			'id' => 4302, 
			'name' => 'Travesseiro',
			'state' => 23,
		]);
		DB::table('cities')->insert([
			'id' => 4303, 
			'name' => 'Três Arroios',
			'state' => 23,
		]);
		DB::table('cities')->insert([
			'id' => 4304, 
			'name' => 'Três Cachoeiras',
			'state' => 23,
		]);
		DB::table('cities')->insert([
			'id' => 4305, 
			'name' => 'Três Coroas',
			'state' => 23,
		]);
		DB::table('cities')->insert([
			'id' => 4306, 
			'name' => 'Três de Maio',
			'state' => 23,
		]);
		DB::table('cities')->insert([
			'id' => 4307, 
			'name' => 'Três Forquilhas',
			'state' => 23,
		]);
		DB::table('cities')->insert([
			'id' => 4308, 
			'name' => 'Três Palmeiras',
			'state' => 23,
		]);
		DB::table('cities')->insert([
			'id' => 4309, 
			'name' => 'Três Passos',
			'state' => 23,
		]);
		DB::table('cities')->insert([
			'id' => 4310, 
			'name' => 'Trindade do Sul',
			'state' => 23,
		]);
		DB::table('cities')->insert([
			'id' => 4311, 
			'name' => 'Triunfo',
			'state' => 23,
		]);
		DB::table('cities')->insert([
			'id' => 4312, 
			'name' => 'Tucunduva',
			'state' => 23,
		]);
		DB::table('cities')->insert([
			'id' => 4313, 
			'name' => 'Tunas',
			'state' => 23,
		]);
		DB::table('cities')->insert([
			'id' => 4314, 
			'name' => 'Tupanci do Sul',
			'state' => 23,
		]);
		DB::table('cities')->insert([
			'id' => 4315, 
			'name' => 'Tupanciretã',
			'state' => 23,
		]);
		DB::table('cities')->insert([
			'id' => 4316, 
			'name' => 'Tupandi',
			'state' => 23,
		]);
		DB::table('cities')->insert([
			'id' => 4317, 
			'name' => 'Tuparendi',
			'state' => 23,
		]);
		DB::table('cities')->insert([
			'id' => 4318, 
			'name' => 'Turuçu',
			'state' => 23,
		]);
		DB::table('cities')->insert([
			'id' => 4319, 
			'name' => 'Ubiretama',
			'state' => 23,
		]);
		DB::table('cities')->insert([
			'id' => 4320, 
			'name' => 'União da Serra',
			'state' => 23,
		]);
		DB::table('cities')->insert([
			'id' => 4321, 
			'name' => 'Unistalda',
			'state' => 23,
		]);
		DB::table('cities')->insert([
			'id' => 4322, 
			'name' => 'Uruguaiana',
			'state' => 23,
		]);
		DB::table('cities')->insert([
			'id' => 4323, 
			'name' => 'Vacaria',
			'state' => 23,
		]);
		DB::table('cities')->insert([
			'id' => 4324, 
			'name' => 'Vale do Sol',
			'state' => 23,
		]);
		DB::table('cities')->insert([
			'id' => 4325, 
			'name' => 'Vale Real',
			'state' => 23,
		]);
		DB::table('cities')->insert([
			'id' => 4326, 
			'name' => 'Vale Verde',
			'state' => 23,
		]);
		DB::table('cities')->insert([
			'id' => 4327, 
			'name' => 'Vanini',
			'state' => 23,
		]);
		DB::table('cities')->insert([
			'id' => 4328, 
			'name' => 'Venâncio Aires',
			'state' => 23,
		]);
		DB::table('cities')->insert([
			'id' => 4329, 
			'name' => 'Vera Cruz',
			'state' => 23,
		]);
		DB::table('cities')->insert([
			'id' => 4330, 
			'name' => 'Veranópolis',
			'state' => 23,
		]);
		DB::table('cities')->insert([
			'id' => 4331, 
			'name' => 'Vespasiano Correa',
			'state' => 23,
		]);
		DB::table('cities')->insert([
			'id' => 4332, 
			'name' => 'Viadutos',
			'state' => 23,
		]);
		DB::table('cities')->insert([
			'id' => 4333, 
			'name' => 'Viamão',
			'state' => 23,
		]);
		DB::table('cities')->insert([
			'id' => 4334, 
			'name' => 'Vicente Dutra',
			'state' => 23,
		]);
		DB::table('cities')->insert([
			'id' => 4335, 
			'name' => 'Victor Graeff',
			'state' => 23,
		]);
		DB::table('cities')->insert([
			'id' => 4336, 
			'name' => 'Vila Flores',
			'state' => 23,
		]);
		DB::table('cities')->insert([
			'id' => 4337, 
			'name' => 'Vila Lângaro',
			'state' => 23,
		]);
		DB::table('cities')->insert([
			'id' => 4338, 
			'name' => 'Vila Maria',
			'state' => 23,
		]);
		DB::table('cities')->insert([
			'id' => 4339, 
			'name' => 'Vila Nova do Sul',
			'state' => 23,
		]);
		DB::table('cities')->insert([
			'id' => 4340, 
			'name' => 'Vista Alegre',
			'state' => 23,
		]);
		DB::table('cities')->insert([
			'id' => 4341, 
			'name' => 'Vista Alegre do Prata',
			'state' => 23,
		]);
		DB::table('cities')->insert([
			'id' => 4342, 
			'name' => 'Vista Gaúcha',
			'state' => 23,
		]);
		DB::table('cities')->insert([
			'id' => 4343, 
			'name' => 'Vitória das Missões',
			'state' => 23,
		]);
		DB::table('cities')->insert([
			'id' => 4344, 
			'name' => 'Westfália',
			'state' => 23,
		]);
		DB::table('cities')->insert([
			'id' => 4345, 
			'name' => 'Xangri-lá',
			'state' => 23,
		]);
		DB::table('cities')->insert([
			'id' => 4346, 
			'name' => 'Alta Floresta d`Oeste',
			'state' => 21,
		]);
		DB::table('cities')->insert([
			'id' => 4347, 
			'name' => 'Alto Alegre dos Parecis',
			'state' => 21,
		]);
		DB::table('cities')->insert([
			'id' => 4348, 
			'name' => 'Alto Paraíso',
			'state' => 21,
		]);
		DB::table('cities')->insert([
			'id' => 4349, 
			'name' => 'Alvorada d`Oeste',
			'state' => 21,
		]);
		DB::table('cities')->insert([
			'id' => 4350, 
			'name' => 'Ariquemes',
			'state' => 21,
		]);
		DB::table('cities')->insert([
			'id' => 4351, 
			'name' => 'Buritis',
			'state' => 21,
		]);
		DB::table('cities')->insert([
			'id' => 4352, 
			'name' => 'Cabixi',
			'state' => 21,
		]);
		DB::table('cities')->insert([
			'id' => 4353, 
			'name' => 'Cacaulândia',
			'state' => 21,
		]);
		DB::table('cities')->insert([
			'id' => 4354, 
			'name' => 'Cacoal',
			'state' => 21,
		]);
		DB::table('cities')->insert([
			'id' => 4355, 
			'name' => 'Campo Novo de Rondônia',
			'state' => 21,
		]);
		DB::table('cities')->insert([
			'id' => 4356, 
			'name' => 'Candeias do Jamari',
			'state' => 21,
		]);
		DB::table('cities')->insert([
			'id' => 4357, 
			'name' => 'Castanheiras',
			'state' => 21,
		]);
		DB::table('cities')->insert([
			'id' => 4358, 
			'name' => 'Cerejeiras',
			'state' => 21,
		]);
		DB::table('cities')->insert([
			'id' => 4359, 
			'name' => 'Chupinguaia',
			'state' => 21,
		]);
		DB::table('cities')->insert([
			'id' => 4360, 
			'name' => 'Colorado do Oeste',
			'state' => 21,
		]);
		DB::table('cities')->insert([
			'id' => 4361, 
			'name' => 'Corumbiara',
			'state' => 21,
		]);
		DB::table('cities')->insert([
			'id' => 4362, 
			'name' => 'Costa Marques',
			'state' => 21,
		]);
		DB::table('cities')->insert([
			'id' => 4363, 
			'name' => 'Cujubim',
			'state' => 21,
		]);
		DB::table('cities')->insert([
			'id' => 4364, 
			'name' => 'Espigão d`Oeste',
			'state' => 21,
		]);
		DB::table('cities')->insert([
			'id' => 4365, 
			'name' => 'Governador Jorge Teixeira',
			'state' => 21,
		]);
		DB::table('cities')->insert([
			'id' => 4366, 
			'name' => 'Guajará-Mirim',
			'state' => 21,
		]);
		DB::table('cities')->insert([
			'id' => 4367, 
			'name' => 'Itapuã do Oeste',
			'state' => 21,
		]);
		DB::table('cities')->insert([
			'id' => 4368, 
			'name' => 'Jaru',
			'state' => 21,
		]);
		DB::table('cities')->insert([
			'id' => 4369, 
			'name' => 'Ji-Paraná',
			'state' => 21,
		]);
		DB::table('cities')->insert([
			'id' => 4370, 
			'name' => 'Machadinho d`Oeste',
			'state' => 21,
		]);
		DB::table('cities')->insert([
			'id' => 4371, 
			'name' => 'Ministro Andreazza',
			'state' => 21,
		]);
		DB::table('cities')->insert([
			'id' => 4372, 
			'name' => 'Mirante da Serra',
			'state' => 21,
		]);
		DB::table('cities')->insert([
			'id' => 4373, 
			'name' => 'Monte Negro',
			'state' => 21,
		]);
		DB::table('cities')->insert([
			'id' => 4374, 
			'name' => 'Nova Brasilândia d`Oeste',
			'state' => 21,
		]);
		DB::table('cities')->insert([
			'id' => 4375, 
			'name' => 'Nova Mamoré',
			'state' => 21,
		]);
		DB::table('cities')->insert([
			'id' => 4376, 
			'name' => 'Nova União',
			'state' => 21,
		]);
		DB::table('cities')->insert([
			'id' => 4377, 
			'name' => 'Novo Horizonte do Oeste',
			'state' => 21,
		]);
		DB::table('cities')->insert([
			'id' => 4378, 
			'name' => 'Ouro Preto do Oeste',
			'state' => 21,
		]);
		DB::table('cities')->insert([
			'id' => 4379, 
			'name' => 'Parecis',
			'state' => 21,
		]);
		DB::table('cities')->insert([
			'id' => 4380, 
			'name' => 'Pimenta Bueno',
			'state' => 21,
		]);
		DB::table('cities')->insert([
			'id' => 4381, 
			'name' => 'Pimenteiras do Oeste',
			'state' => 21,
		]);
		DB::table('cities')->insert([
			'id' => 4382, 
			'name' => 'Porto Velho',
			'state' => 21,
		]);
		DB::table('cities')->insert([
			'id' => 4383, 
			'name' => 'Presidente Médici',
			'state' => 21,
		]);
		DB::table('cities')->insert([
			'id' => 4384, 
			'name' => 'Primavera de Rondônia',
			'state' => 21,
		]);
		DB::table('cities')->insert([
			'id' => 4385, 
			'name' => 'Rio Crespo',
			'state' => 21,
		]);
		DB::table('cities')->insert([
			'id' => 4386, 
			'name' => 'Rolim de Moura',
			'state' => 21,
		]);
		DB::table('cities')->insert([
			'id' => 4387, 
			'name' => 'Santa Luzia d`Oeste',
			'state' => 21,
		]);
		DB::table('cities')->insert([
			'id' => 4388, 
			'name' => 'São Felipe d`Oeste',
			'state' => 21,
		]);
		DB::table('cities')->insert([
			'id' => 4389, 
			'name' => 'São Francisco do Guaporé',
			'state' => 21,
		]);
		DB::table('cities')->insert([
			'id' => 4390, 
			'name' => 'São Miguel do Guaporé',
			'state' => 21,
		]);
		DB::table('cities')->insert([
			'id' => 4391, 
			'name' => 'Seringueiras',
			'state' => 21,
		]);
		DB::table('cities')->insert([
			'id' => 4392, 
			'name' => 'Teixeirópolis',
			'state' => 21,
		]);
		DB::table('cities')->insert([
			'id' => 4393, 
			'name' => 'Theobroma',
			'state' => 21,
		]);
		DB::table('cities')->insert([
			'id' => 4394, 
			'name' => 'Urupá',
			'state' => 21,
		]);
		DB::table('cities')->insert([
			'id' => 4395, 
			'name' => 'Vale do Anari',
			'state' => 21,
		]);
		DB::table('cities')->insert([
			'id' => 4396, 
			'name' => 'Vale do Paraíso',
			'state' => 21,
		]);
		DB::table('cities')->insert([
			'id' => 4397, 
			'name' => 'Vilhena',
			'state' => 21,
		]);
		DB::table('cities')->insert([
			'id' => 4398, 
			'name' => 'Alto Alegre',
			'state' => 22,
		]);
		DB::table('cities')->insert([
			'id' => 4399, 
			'name' => 'Amajari',
			'state' => 22,
		]);
		DB::table('cities')->insert([
			'id' => 4400, 
			'name' => 'Boa Vista',
			'state' => 22,
		]);
		DB::table('cities')->insert([
			'id' => 4401, 
			'name' => 'Bonfim',
			'state' => 22,
		]);
		DB::table('cities')->insert([
			'id' => 4402, 
			'name' => 'Cantá',
			'state' => 22,
		]);
		DB::table('cities')->insert([
			'id' => 4403, 
			'name' => 'Caracaraí',
			'state' => 22,
		]);
		DB::table('cities')->insert([
			'id' => 4404, 
			'name' => 'Caroebe',
			'state' => 22,
		]);
		DB::table('cities')->insert([
			'id' => 4405, 
			'name' => 'Iracema',
			'state' => 22,
		]);
		DB::table('cities')->insert([
			'id' => 4406, 
			'name' => 'Mucajaí',
			'state' => 22,
		]);
		DB::table('cities')->insert([
			'id' => 4407, 
			'name' => 'Normandia',
			'state' => 22,
		]);
		DB::table('cities')->insert([
			'id' => 4408, 
			'name' => 'Pacaraima',
			'state' => 22,
		]);
		DB::table('cities')->insert([
			'id' => 4409, 
			'name' => 'Rorainópolis',
			'state' => 22,
		]);
		DB::table('cities')->insert([
			'id' => 4410, 
			'name' => 'São João da Baliza',
			'state' => 22,
		]);
		DB::table('cities')->insert([
			'id' => 4411, 
			'name' => 'São Luiz',
			'state' => 22,
		]);
		DB::table('cities')->insert([
			'id' => 4412, 
			'name' => 'Uiramutã',
			'state' => 22,
		]);
		DB::table('cities')->insert([
			'id' => 4413, 
			'name' => 'Abdon Batista',
			'state' => 24,
		]);
		DB::table('cities')->insert([
			'id' => 4414, 
			'name' => 'Abelardo Luz',
			'state' => 24,
		]);
		DB::table('cities')->insert([
			'id' => 4415, 
			'name' => 'Agrolândia',
			'state' => 24,
		]);
		DB::table('cities')->insert([
			'id' => 4416, 
			'name' => 'Agronômica',
			'state' => 24,
		]);
		DB::table('cities')->insert([
			'id' => 4417, 
			'name' => 'Água Doce',
			'state' => 24,
		]);
		DB::table('cities')->insert([
			'id' => 4418, 
			'name' => 'Águas de Chapecó',
			'state' => 24,
		]);
		DB::table('cities')->insert([
			'id' => 4419, 
			'name' => 'Águas Frias',
			'state' => 24,
		]);
		DB::table('cities')->insert([
			'id' => 4420, 
			'name' => 'Águas Mornas',
			'state' => 24,
		]);
		DB::table('cities')->insert([
			'id' => 4421, 
			'name' => 'Alfredo Wagner',
			'state' => 24,
		]);
		DB::table('cities')->insert([
			'id' => 4422, 
			'name' => 'Alto Bela Vista',
			'state' => 24,
		]);
		DB::table('cities')->insert([
			'id' => 4423, 
			'name' => 'Anchieta',
			'state' => 24,
		]);
		DB::table('cities')->insert([
			'id' => 4424, 
			'name' => 'Angelina',
			'state' => 24,
		]);
		DB::table('cities')->insert([
			'id' => 4425, 
			'name' => 'Anita Garibaldi',
			'state' => 24,
		]);
		DB::table('cities')->insert([
			'id' => 4426, 
			'name' => 'Anitápolis',
			'state' => 24,
		]);
		DB::table('cities')->insert([
			'id' => 4427, 
			'name' => 'Antônio Carlos',
			'state' => 24,
		]);
		DB::table('cities')->insert([
			'id' => 4428, 
			'name' => 'Apiúna',
			'state' => 24,
		]);
		DB::table('cities')->insert([
			'id' => 4429, 
			'name' => 'Arabutã',
			'state' => 24,
		]);
		DB::table('cities')->insert([
			'id' => 4430, 
			'name' => 'Araquari',
			'state' => 24,
		]);
		DB::table('cities')->insert([
			'id' => 4431, 
			'name' => 'Araranguá',
			'state' => 24,
		]);
		DB::table('cities')->insert([
			'id' => 4432, 
			'name' => 'Armazém',
			'state' => 24,
		]);
		DB::table('cities')->insert([
			'id' => 4433, 
			'name' => 'Arroio Trinta',
			'state' => 24,
		]);
		DB::table('cities')->insert([
			'id' => 4434, 
			'name' => 'Arvoredo',
			'state' => 24,
		]);
		DB::table('cities')->insert([
			'id' => 4435, 
			'name' => 'Ascurra',
			'state' => 24,
		]);
		DB::table('cities')->insert([
			'id' => 4436, 
			'name' => 'Atalanta',
			'state' => 24,
		]);
		DB::table('cities')->insert([
			'id' => 4437, 
			'name' => 'Aurora',
			'state' => 24,
		]);
		DB::table('cities')->insert([
			'id' => 4438, 
			'name' => 'Balneário Arroio do Silva',
			'state' => 24,
		]);
		DB::table('cities')->insert([
			'id' => 4439, 
			'name' => 'Balneário Barra do Sul',
			'state' => 24,
		]);
		DB::table('cities')->insert([
			'id' => 4440, 
			'name' => 'Balneário Camboriú',
			'state' => 24,
		]);
		DB::table('cities')->insert([
			'id' => 4441, 
			'name' => 'Balneário Gaivota',
			'state' => 24,
		]);
		DB::table('cities')->insert([
			'id' => 4442, 
			'name' => 'Bandeirante',
			'state' => 24,
		]);
		DB::table('cities')->insert([
			'id' => 4443, 
			'name' => 'Barra Bonita',
			'state' => 24,
		]);
		DB::table('cities')->insert([
			'id' => 4444, 
			'name' => 'Barra Velha',
			'state' => 24,
		]);
		DB::table('cities')->insert([
			'id' => 4445, 
			'name' => 'Bela Vista do Toldo',
			'state' => 24,
		]);
		DB::table('cities')->insert([
			'id' => 4446, 
			'name' => 'Belmonte',
			'state' => 24,
		]);
		DB::table('cities')->insert([
			'id' => 4447, 
			'name' => 'Benedito Novo',
			'state' => 24,
		]);
		DB::table('cities')->insert([
			'id' => 4448, 
			'name' => 'Biguaçu',
			'state' => 24,
		]);
		DB::table('cities')->insert([
			'id' => 4449, 
			'name' => 'Blumenau',
			'state' => 24,
		]);
		DB::table('cities')->insert([
			'id' => 4450, 
			'name' => 'Bocaina do Sul',
			'state' => 24,
		]);
		DB::table('cities')->insert([
			'id' => 4451, 
			'name' => 'Bom Jardim da Serra',
			'state' => 24,
		]);
		DB::table('cities')->insert([
			'id' => 4452, 
			'name' => 'Bom Jesus',
			'state' => 24,
		]);
		DB::table('cities')->insert([
			'id' => 4453, 
			'name' => 'Bom Jesus do Oeste',
			'state' => 24,
		]);
		DB::table('cities')->insert([
			'id' => 4454, 
			'name' => 'Bom Retiro',
			'state' => 24,
		]);
		DB::table('cities')->insert([
			'id' => 4455, 
			'name' => 'Bombinhas',
			'state' => 24,
		]);
		DB::table('cities')->insert([
			'id' => 4456, 
			'name' => 'Botuverá',
			'state' => 24,
		]);
		DB::table('cities')->insert([
			'id' => 4457, 
			'name' => 'Braço do Norte',
			'state' => 24,
		]);
		DB::table('cities')->insert([
			'id' => 4458, 
			'name' => 'Braço do Trombudo',
			'state' => 24,
		]);
		DB::table('cities')->insert([
			'id' => 4459, 
			'name' => 'Brunópolis',
			'state' => 24,
		]);
		DB::table('cities')->insert([
			'id' => 4460, 
			'name' => 'Brusque',
			'state' => 24,
		]);
		DB::table('cities')->insert([
			'id' => 4461, 
			'name' => 'Caçador',
			'state' => 24,
		]);
		DB::table('cities')->insert([
			'id' => 4462, 
			'name' => 'Caibi',
			'state' => 24,
		]);
		DB::table('cities')->insert([
			'id' => 4463, 
			'name' => 'Calmon',
			'state' => 24,
		]);
		DB::table('cities')->insert([
			'id' => 4464, 
			'name' => 'Camboriú',
			'state' => 24,
		]);
		DB::table('cities')->insert([
			'id' => 4465, 
			'name' => 'Campo Alegre',
			'state' => 24,
		]);
		DB::table('cities')->insert([
			'id' => 4466, 
			'name' => 'Campo Belo do Sul',
			'state' => 24,
		]);
		DB::table('cities')->insert([
			'id' => 4467, 
			'name' => 'Campo Erê',
			'state' => 24,
		]);
		DB::table('cities')->insert([
			'id' => 4468, 
			'name' => 'Campos Novos',
			'state' => 24,
		]);
		DB::table('cities')->insert([
			'id' => 4469, 
			'name' => 'Canelinha',
			'state' => 24,
		]);
		DB::table('cities')->insert([
			'id' => 4470, 
			'name' => 'Canoinhas',
			'state' => 24,
		]);
		DB::table('cities')->insert([
			'id' => 4471, 
			'name' => 'Capão Alto',
			'state' => 24,
		]);
		DB::table('cities')->insert([
			'id' => 4472, 
			'name' => 'Capinzal',
			'state' => 24,
		]);
		DB::table('cities')->insert([
			'id' => 4473, 
			'name' => 'Capivari de Baixo',
			'state' => 24,
		]);
		DB::table('cities')->insert([
			'id' => 4474, 
			'name' => 'Catanduvas',
			'state' => 24,
		]);
		DB::table('cities')->insert([
			'id' => 4475, 
			'name' => 'Caxambu do Sul',
			'state' => 24,
		]);
		DB::table('cities')->insert([
			'id' => 4476, 
			'name' => 'Celso Ramos',
			'state' => 24,
		]);
		DB::table('cities')->insert([
			'id' => 4477, 
			'name' => 'Cerro Negro',
			'state' => 24,
		]);
		DB::table('cities')->insert([
			'id' => 4478, 
			'name' => 'Chapadão do Lageado',
			'state' => 24,
		]);
		DB::table('cities')->insert([
			'id' => 4479, 
			'name' => 'Chapecó',
			'state' => 24,
		]);
		DB::table('cities')->insert([
			'id' => 4480, 
			'name' => 'Cocal do Sul',
			'state' => 24,
		]);
		DB::table('cities')->insert([
			'id' => 4481, 
			'name' => 'Concórdia',
			'state' => 24,
		]);
		DB::table('cities')->insert([
			'id' => 4482, 
			'name' => 'Cordilheira Alta',
			'state' => 24,
		]);
		DB::table('cities')->insert([
			'id' => 4483, 
			'name' => 'Coronel Freitas',
			'state' => 24,
		]);
		DB::table('cities')->insert([
			'id' => 4484, 
			'name' => 'Coronel Martins',
			'state' => 24,
		]);
		DB::table('cities')->insert([
			'id' => 4485, 
			'name' => 'Correia Pinto',
			'state' => 24,
		]);
		DB::table('cities')->insert([
			'id' => 4486, 
			'name' => 'Corupá',
			'state' => 24,
		]);
		DB::table('cities')->insert([
			'id' => 4487, 
			'name' => 'Criciúma',
			'state' => 24,
		]);
		DB::table('cities')->insert([
			'id' => 4488, 
			'name' => 'Cunha Porã',
			'state' => 24,
		]);
		DB::table('cities')->insert([
			'id' => 4489, 
			'name' => 'Cunhataí',
			'state' => 24,
		]);
		DB::table('cities')->insert([
			'id' => 4490, 
			'name' => 'Curitibanos',
			'state' => 24,
		]);
		DB::table('cities')->insert([
			'id' => 4491, 
			'name' => 'Descanso',
			'state' => 24,
		]);
		DB::table('cities')->insert([
			'id' => 4492, 
			'name' => 'Dionísio Cerqueira',
			'state' => 24,
		]);
		DB::table('cities')->insert([
			'id' => 4493, 
			'name' => 'Dona Emma',
			'state' => 24,
		]);
		DB::table('cities')->insert([
			'id' => 4494, 
			'name' => 'Doutor Pedrinho',
			'state' => 24,
		]);
		DB::table('cities')->insert([
			'id' => 4495, 
			'name' => 'Entre Rios',
			'state' => 24,
		]);
		DB::table('cities')->insert([
			'id' => 4496, 
			'name' => 'Ermo',
			'state' => 24,
		]);
		DB::table('cities')->insert([
			'id' => 4497, 
			'name' => 'Erval Velho',
			'state' => 24,
		]);
		DB::table('cities')->insert([
			'id' => 4498, 
			'name' => 'Faxinal dos Guedes',
			'state' => 24,
		]);
		DB::table('cities')->insert([
			'id' => 4499, 
			'name' => 'Flor do Sertão',
			'state' => 24,
		]);
		DB::table('cities')->insert([
			'id' => 4500, 
			'name' => 'Florianópolis',
			'state' => 24,
		]);
		DB::table('cities')->insert([
			'id' => 4501, 
			'name' => 'Formosa do Sul',
			'state' => 24,
		]);
		DB::table('cities')->insert([
			'id' => 4502, 
			'name' => 'Forquilhinha',
			'state' => 24,
		]);
		DB::table('cities')->insert([
			'id' => 4503, 
			'name' => 'Fraiburgo',
			'state' => 24,
		]);
		DB::table('cities')->insert([
			'id' => 4504, 
			'name' => 'Frei Rogério',
			'state' => 24,
		]);
		DB::table('cities')->insert([
			'id' => 4505, 
			'name' => 'Galvão',
			'state' => 24,
		]);
		DB::table('cities')->insert([
			'id' => 4506, 
			'name' => 'Garopaba',
			'state' => 24,
		]);
		DB::table('cities')->insert([
			'id' => 4507, 
			'name' => 'Garuva',
			'state' => 24,
		]);
		DB::table('cities')->insert([
			'id' => 4508, 
			'name' => 'Gaspar',
			'state' => 24,
		]);
		DB::table('cities')->insert([
			'id' => 4509, 
			'name' => 'Governador Celso Ramos',
			'state' => 24,
		]);
		DB::table('cities')->insert([
			'id' => 4510, 
			'name' => 'Grão Pará',
			'state' => 24,
		]);
		DB::table('cities')->insert([
			'id' => 4511, 
			'name' => 'Gravatal',
			'state' => 24,
		]);
		DB::table('cities')->insert([
			'id' => 4512, 
			'name' => 'Guabiruba',
			'state' => 24,
		]);
		DB::table('cities')->insert([
			'id' => 4513, 
			'name' => 'Guaraciaba',
			'state' => 24,
		]);
		DB::table('cities')->insert([
			'id' => 4514, 
			'name' => 'Guaramirim',
			'state' => 24,
		]);
		DB::table('cities')->insert([
			'id' => 4515, 
			'name' => 'Guarujá do Sul',
			'state' => 24,
		]);
		DB::table('cities')->insert([
			'id' => 4516, 
			'name' => 'Guatambú',
			'state' => 24,
		]);
		DB::table('cities')->insert([
			'id' => 4517, 
			'name' => 'Herval d`Oeste',
			'state' => 24,
		]);
		DB::table('cities')->insert([
			'id' => 4518, 
			'name' => 'Ibiam',
			'state' => 24,
		]);
		DB::table('cities')->insert([
			'id' => 4519, 
			'name' => 'Ibicaré',
			'state' => 24,
		]);
		DB::table('cities')->insert([
			'id' => 4520, 
			'name' => 'Ibirama',
			'state' => 24,
		]);
		DB::table('cities')->insert([
			'id' => 4521, 
			'name' => 'Içara',
			'state' => 24,
		]);
		DB::table('cities')->insert([
			'id' => 4522, 
			'name' => 'Ilhota',
			'state' => 24,
		]);
		DB::table('cities')->insert([
			'id' => 4523, 
			'name' => 'Imaruí',
			'state' => 24,
		]);
		DB::table('cities')->insert([
			'id' => 4524, 
			'name' => 'Imbituba',
			'state' => 24,
		]);
		DB::table('cities')->insert([
			'id' => 4525, 
			'name' => 'Imbuia',
			'state' => 24,
		]);
		DB::table('cities')->insert([
			'id' => 4526, 
			'name' => 'Indaial',
			'state' => 24,
		]);
		DB::table('cities')->insert([
			'id' => 4527, 
			'name' => 'Iomerê',
			'state' => 24,
		]);
		DB::table('cities')->insert([
			'id' => 4528, 
			'name' => 'Ipira',
			'state' => 24,
		]);
		DB::table('cities')->insert([
			'id' => 4529, 
			'name' => 'Iporã do Oeste',
			'state' => 24,
		]);
		DB::table('cities')->insert([
			'id' => 4530, 
			'name' => 'Ipuaçu',
			'state' => 24,
		]);
		DB::table('cities')->insert([
			'id' => 4531, 
			'name' => 'Ipumirim',
			'state' => 24,
		]);
		DB::table('cities')->insert([
			'id' => 4532, 
			'name' => 'Iraceminha',
			'state' => 24,
		]);
		DB::table('cities')->insert([
			'id' => 4533, 
			'name' => 'Irani',
			'state' => 24,
		]);
		DB::table('cities')->insert([
			'id' => 4534, 
			'name' => 'Irati',
			'state' => 24,
		]);
		DB::table('cities')->insert([
			'id' => 4535, 
			'name' => 'Irineópolis',
			'state' => 24,
		]);
		DB::table('cities')->insert([
			'id' => 4536, 
			'name' => 'Itá',
			'state' => 24,
		]);
		DB::table('cities')->insert([
			'id' => 4537, 
			'name' => 'Itaiópolis',
			'state' => 24,
		]);
		DB::table('cities')->insert([
			'id' => 4538, 
			'name' => 'Itajaí',
			'state' => 24,
		]);
		DB::table('cities')->insert([
			'id' => 4539, 
			'name' => 'Itapema',
			'state' => 24,
		]);
		DB::table('cities')->insert([
			'id' => 4540, 
			'name' => 'Itapiranga',
			'state' => 24,
		]);
		DB::table('cities')->insert([
			'id' => 4541, 
			'name' => 'Itapoá',
			'state' => 24,
		]);
		DB::table('cities')->insert([
			'id' => 4542, 
			'name' => 'Ituporanga',
			'state' => 24,
		]);
		DB::table('cities')->insert([
			'id' => 4543, 
			'name' => 'Jaborá',
			'state' => 24,
		]);
		DB::table('cities')->insert([
			'id' => 4544, 
			'name' => 'Jacinto Machado',
			'state' => 24,
		]);
		DB::table('cities')->insert([
			'id' => 4545, 
			'name' => 'Jaguaruna',
			'state' => 24,
		]);
		DB::table('cities')->insert([
			'id' => 4546, 
			'name' => 'Jaraguá do Sul',
			'state' => 24,
		]);
		DB::table('cities')->insert([
			'id' => 4547, 
			'name' => 'Jardinópolis',
			'state' => 24,
		]);
		DB::table('cities')->insert([
			'id' => 4548, 
			'name' => 'Joaçaba',
			'state' => 24,
		]);
		DB::table('cities')->insert([
			'id' => 4549, 
			'name' => 'Joinville',
			'state' => 24,
		]);
		DB::table('cities')->insert([
			'id' => 4550, 
			'name' => 'José Boiteux',
			'state' => 24,
		]);
		DB::table('cities')->insert([
			'id' => 4551, 
			'name' => 'Jupiá',
			'state' => 24,
		]);
		DB::table('cities')->insert([
			'id' => 4552, 
			'name' => 'Lacerdópolis',
			'state' => 24,
		]);
		DB::table('cities')->insert([
			'id' => 4553, 
			'name' => 'Lages',
			'state' => 24,
		]);
		DB::table('cities')->insert([
			'id' => 4554, 
			'name' => 'Laguna',
			'state' => 24,
		]);
		DB::table('cities')->insert([
			'id' => 4555, 
			'name' => 'Lajeado Grande',
			'state' => 24,
		]);
		DB::table('cities')->insert([
			'id' => 4556, 
			'name' => 'Laurentino',
			'state' => 24,
		]);
		DB::table('cities')->insert([
			'id' => 4557, 
			'name' => 'Lauro Muller',
			'state' => 24,
		]);
		DB::table('cities')->insert([
			'id' => 4558, 
			'name' => 'Lebon Régis',
			'state' => 24,
		]);
		DB::table('cities')->insert([
			'id' => 4559, 
			'name' => 'Leoberto Leal',
			'state' => 24,
		]);
		DB::table('cities')->insert([
			'id' => 4560, 
			'name' => 'Lindóia do Sul',
			'state' => 24,
		]);
		DB::table('cities')->insert([
			'id' => 4561, 
			'name' => 'Lontras',
			'state' => 24,
		]);
		DB::table('cities')->insert([
			'id' => 4562, 
			'name' => 'Luiz Alves',
			'state' => 24,
		]);
		DB::table('cities')->insert([
			'id' => 4563, 
			'name' => 'Luzerna',
			'state' => 24,
		]);
		DB::table('cities')->insert([
			'id' => 4564, 
			'name' => 'Macieira',
			'state' => 24,
		]);
		DB::table('cities')->insert([
			'id' => 4565, 
			'name' => 'Mafra',
			'state' => 24,
		]);
		DB::table('cities')->insert([
			'id' => 4566, 
			'name' => 'Major Gercino',
			'state' => 24,
		]);
		DB::table('cities')->insert([
			'id' => 4567, 
			'name' => 'Major Vieira',
			'state' => 24,
		]);
		DB::table('cities')->insert([
			'id' => 4568, 
			'name' => 'Maracajá',
			'state' => 24,
		]);
		DB::table('cities')->insert([
			'id' => 4569, 
			'name' => 'Maravilha',
			'state' => 24,
		]);
		DB::table('cities')->insert([
			'id' => 4570, 
			'name' => 'Marema',
			'state' => 24,
		]);
		DB::table('cities')->insert([
			'id' => 4571, 
			'name' => 'Massaranduba',
			'state' => 24,
		]);
		DB::table('cities')->insert([
			'id' => 4572, 
			'name' => 'Matos Costa',
			'state' => 24,
		]);
		DB::table('cities')->insert([
			'id' => 4573, 
			'name' => 'Meleiro',
			'state' => 24,
		]);
		DB::table('cities')->insert([
			'id' => 4574, 
			'name' => 'Mirim Doce',
			'state' => 24,
		]);
		DB::table('cities')->insert([
			'id' => 4575, 
			'name' => 'Modelo',
			'state' => 24,
		]);
		DB::table('cities')->insert([
			'id' => 4576, 
			'name' => 'Mondaí',
			'state' => 24,
		]);
		DB::table('cities')->insert([
			'id' => 4577, 
			'name' => 'Monte Carlo',
			'state' => 24,
		]);
		DB::table('cities')->insert([
			'id' => 4578, 
			'name' => 'Monte Castelo',
			'state' => 24,
		]);
		DB::table('cities')->insert([
			'id' => 4579, 
			'name' => 'Morro da Fumaça',
			'state' => 24,
		]);
		DB::table('cities')->insert([
			'id' => 4580, 
			'name' => 'Morro Grande',
			'state' => 24,
		]);
		DB::table('cities')->insert([
			'id' => 4581, 
			'name' => 'Navegantes',
			'state' => 24,
		]);
		DB::table('cities')->insert([
			'id' => 4582, 
			'name' => 'Nova Erechim',
			'state' => 24,
		]);
		DB::table('cities')->insert([
			'id' => 4583, 
			'name' => 'Nova Itaberaba',
			'state' => 24,
		]);
		DB::table('cities')->insert([
			'id' => 4584, 
			'name' => 'Nova Trento',
			'state' => 24,
		]);
		DB::table('cities')->insert([
			'id' => 4585, 
			'name' => 'Nova Veneza',
			'state' => 24,
		]);
		DB::table('cities')->insert([
			'id' => 4586, 
			'name' => 'Novo Horizonte',
			'state' => 24,
		]);
		DB::table('cities')->insert([
			'id' => 4587, 
			'name' => 'Orleans',
			'state' => 24,
		]);
		DB::table('cities')->insert([
			'id' => 4588, 
			'name' => 'Otacílio Costa',
			'state' => 24,
		]);
		DB::table('cities')->insert([
			'id' => 4589, 
			'name' => 'Ouro',
			'state' => 24,
		]);
		DB::table('cities')->insert([
			'id' => 4590, 
			'name' => 'Ouro Verde',
			'state' => 24,
		]);
		DB::table('cities')->insert([
			'id' => 4591, 
			'name' => 'Paial',
			'state' => 24,
		]);
		DB::table('cities')->insert([
			'id' => 4592, 
			'name' => 'Painel',
			'state' => 24,
		]);
		DB::table('cities')->insert([
			'id' => 4593, 
			'name' => 'Palhoça',
			'state' => 24,
		]);
		DB::table('cities')->insert([
			'id' => 4594, 
			'name' => 'Palma Sola',
			'state' => 24,
		]);
		DB::table('cities')->insert([
			'id' => 4595, 
			'name' => 'Palmeira',
			'state' => 24,
		]);
		DB::table('cities')->insert([
			'id' => 4596, 
			'name' => 'Palmitos',
			'state' => 24,
		]);
		DB::table('cities')->insert([
			'id' => 4597, 
			'name' => 'Papanduva',
			'state' => 24,
		]);
		DB::table('cities')->insert([
			'id' => 4598, 
			'name' => 'Paraíso',
			'state' => 24,
		]);
		DB::table('cities')->insert([
			'id' => 4599, 
			'name' => 'Passo de Torres',
			'state' => 24,
		]);
		DB::table('cities')->insert([
			'id' => 4600, 
			'name' => 'Passos Maia',
			'state' => 24,
		]);
		DB::table('cities')->insert([
			'id' => 4601, 
			'name' => 'Paulo Lopes',
			'state' => 24,
		]);
		DB::table('cities')->insert([
			'id' => 4602, 
			'name' => 'Pedras Grandes',
			'state' => 24,
		]);
		DB::table('cities')->insert([
			'id' => 4603, 
			'name' => 'Penha',
			'state' => 24,
		]);
		DB::table('cities')->insert([
			'id' => 4604, 
			'name' => 'Peritiba',
			'state' => 24,
		]);
		DB::table('cities')->insert([
			'id' => 4605, 
			'name' => 'Petrolândia',
			'state' => 24,
		]);
		DB::table('cities')->insert([
			'id' => 4606, 
			'name' => 'Piçarras',
			'state' => 24,
		]);
		DB::table('cities')->insert([
			'id' => 4607, 
			'name' => 'Pinhalzinho',
			'state' => 24,
		]);
		DB::table('cities')->insert([
			'id' => 4608, 
			'name' => 'Pinheiro Preto',
			'state' => 24,
		]);
		DB::table('cities')->insert([
			'id' => 4609, 
			'name' => 'Piratuba',
			'state' => 24,
		]);
		DB::table('cities')->insert([
			'id' => 4610, 
			'name' => 'Planalto Alegre',
			'state' => 24,
		]);
		DB::table('cities')->insert([
			'id' => 4611, 
			'name' => 'Pomerode',
			'state' => 24,
		]);
		DB::table('cities')->insert([
			'id' => 4612, 
			'name' => 'Ponte Alta',
			'state' => 24,
		]);
		DB::table('cities')->insert([
			'id' => 4613, 
			'name' => 'Ponte Alta do Norte',
			'state' => 24,
		]);
		DB::table('cities')->insert([
			'id' => 4614, 
			'name' => 'Ponte Serrada',
			'state' => 24,
		]);
		DB::table('cities')->insert([
			'id' => 4615, 
			'name' => 'Porto Belo',
			'state' => 24,
		]);
		DB::table('cities')->insert([
			'id' => 4616, 
			'name' => 'Porto União',
			'state' => 24,
		]);
		DB::table('cities')->insert([
			'id' => 4617, 
			'name' => 'Pouso Redondo',
			'state' => 24,
		]);
		DB::table('cities')->insert([
			'id' => 4618, 
			'name' => 'Praia Grande',
			'state' => 24,
		]);
		DB::table('cities')->insert([
			'id' => 4619, 
			'name' => 'Presidente Castelo Branco',
			'state' => 24,
		]);
		DB::table('cities')->insert([
			'id' => 4620, 
			'name' => 'Presidente Getúlio',
			'state' => 24,
		]);
		DB::table('cities')->insert([
			'id' => 4621, 
			'name' => 'Presidente Nereu',
			'state' => 24,
		]);
		DB::table('cities')->insert([
			'id' => 4622, 
			'name' => 'Princesa',
			'state' => 24,
		]);
		DB::table('cities')->insert([
			'id' => 4623, 
			'name' => 'Quilombo',
			'state' => 24,
		]);
		DB::table('cities')->insert([
			'id' => 4624, 
			'name' => 'Rancho Queimado',
			'state' => 24,
		]);
		DB::table('cities')->insert([
			'id' => 4625, 
			'name' => 'Rio das Antas',
			'state' => 24,
		]);
		DB::table('cities')->insert([
			'id' => 4626, 
			'name' => 'Rio do Campo',
			'state' => 24,
		]);
		DB::table('cities')->insert([
			'id' => 4627, 
			'name' => 'Rio do Oeste',
			'state' => 24,
		]);
		DB::table('cities')->insert([
			'id' => 4628, 
			'name' => 'Rio do Sul',
			'state' => 24,
		]);
		DB::table('cities')->insert([
			'id' => 4629, 
			'name' => 'Rio dos Cedros',
			'state' => 24,
		]);
		DB::table('cities')->insert([
			'id' => 4630, 
			'name' => 'Rio Fortuna',
			'state' => 24,
		]);
		DB::table('cities')->insert([
			'id' => 4631, 
			'name' => 'Rio Negrinho',
			'state' => 24,
		]);
		DB::table('cities')->insert([
			'id' => 4632, 
			'name' => 'Rio Rufino',
			'state' => 24,
		]);
		DB::table('cities')->insert([
			'id' => 4633, 
			'name' => 'Riqueza',
			'state' => 24,
		]);
		DB::table('cities')->insert([
			'id' => 4634, 
			'name' => 'Rodeio',
			'state' => 24,
		]);
		DB::table('cities')->insert([
			'id' => 4635, 
			'name' => 'Romelândia',
			'state' => 24,
		]);
		DB::table('cities')->insert([
			'id' => 4636, 
			'name' => 'Salete',
			'state' => 24,
		]);
		DB::table('cities')->insert([
			'id' => 4637, 
			'name' => 'Saltinho',
			'state' => 24,
		]);
		DB::table('cities')->insert([
			'id' => 4638, 
			'name' => 'Salto Veloso',
			'state' => 24,
		]);
		DB::table('cities')->insert([
			'id' => 4639, 
			'name' => 'Sangão',
			'state' => 24,
		]);
		DB::table('cities')->insert([
			'id' => 4640, 
			'name' => 'Santa Cecília',
			'state' => 24,
		]);
		DB::table('cities')->insert([
			'id' => 4641, 
			'name' => 'Santa Helena',
			'state' => 24,
		]);
		DB::table('cities')->insert([
			'id' => 4642, 
			'name' => 'Santa Rosa de Lima',
			'state' => 24,
		]);
		DB::table('cities')->insert([
			'id' => 4643, 
			'name' => 'Santa Rosa do Sul',
			'state' => 24,
		]);
		DB::table('cities')->insert([
			'id' => 4644, 
			'name' => 'Santa Terezinha',
			'state' => 24,
		]);
		DB::table('cities')->insert([
			'id' => 4645, 
			'name' => 'Santa Terezinha do Progresso',
			'state' => 24,
		]);
		DB::table('cities')->insert([
			'id' => 4646, 
			'name' => 'Santiago do Sul',
			'state' => 24,
		]);
		DB::table('cities')->insert([
			'id' => 4647, 
			'name' => 'Santo Amaro da Imperatriz',
			'state' => 24,
		]);
		DB::table('cities')->insert([
			'id' => 4648, 
			'name' => 'São Bento do Sul',
			'state' => 24,
		]);
		DB::table('cities')->insert([
			'id' => 4649, 
			'name' => 'São Bernardino',
			'state' => 24,
		]);
		DB::table('cities')->insert([
			'id' => 4650, 
			'name' => 'São Bonifácio',
			'state' => 24,
		]);
		DB::table('cities')->insert([
			'id' => 4651, 
			'name' => 'São Carlos',
			'state' => 24,
		]);
		DB::table('cities')->insert([
			'id' => 4652, 
			'name' => 'São Cristovão do Sul',
			'state' => 24,
		]);
		DB::table('cities')->insert([
			'id' => 4653, 
			'name' => 'São Domingos',
			'state' => 24,
		]);
		DB::table('cities')->insert([
			'id' => 4654, 
			'name' => 'São Francisco do Sul',
			'state' => 24,
		]);
		DB::table('cities')->insert([
			'id' => 4655, 
			'name' => 'São João Batista',
			'state' => 24,
		]);
		DB::table('cities')->insert([
			'id' => 4656, 
			'name' => 'São João do Itaperiú',
			'state' => 24,
		]);
		DB::table('cities')->insert([
			'id' => 4657, 
			'name' => 'São João do Oeste',
			'state' => 24,
		]);
		DB::table('cities')->insert([
			'id' => 4658, 
			'name' => 'São João do Sul',
			'state' => 24,
		]);
		DB::table('cities')->insert([
			'id' => 4659, 
			'name' => 'São Joaquim',
			'state' => 24,
		]);
		DB::table('cities')->insert([
			'id' => 4660, 
			'name' => 'São José',
			'state' => 24,
		]);
		DB::table('cities')->insert([
			'id' => 4661, 
			'name' => 'São José do Cedro',
			'state' => 24,
		]);
		DB::table('cities')->insert([
			'id' => 4662, 
			'name' => 'São José do Cerrito',
			'state' => 24,
		]);
		DB::table('cities')->insert([
			'id' => 4663, 
			'name' => 'São Lourenço do Oeste',
			'state' => 24,
		]);
		DB::table('cities')->insert([
			'id' => 4664, 
			'name' => 'São Ludgero',
			'state' => 24,
		]);
		DB::table('cities')->insert([
			'id' => 4665, 
			'name' => 'São Martinho',
			'state' => 24,
		]);
		DB::table('cities')->insert([
			'id' => 4666, 
			'name' => 'São Miguel da Boa Vista',
			'state' => 24,
		]);
		DB::table('cities')->insert([
			'id' => 4667, 
			'name' => 'São Miguel do Oeste',
			'state' => 24,
		]);
		DB::table('cities')->insert([
			'id' => 4668, 
			'name' => 'São Pedro de Alcântara',
			'state' => 24,
		]);
		DB::table('cities')->insert([
			'id' => 4669, 
			'name' => 'Saudades',
			'state' => 24,
		]);
		DB::table('cities')->insert([
			'id' => 4670, 
			'name' => 'Schroeder',
			'state' => 24,
		]);
		DB::table('cities')->insert([
			'id' => 4671, 
			'name' => 'Seara',
			'state' => 24,
		]);
		DB::table('cities')->insert([
			'id' => 4672, 
			'name' => 'Serra Alta',
			'state' => 24,
		]);
		DB::table('cities')->insert([
			'id' => 4673, 
			'name' => 'Siderópolis',
			'state' => 24,
		]);
		DB::table('cities')->insert([
			'id' => 4674, 
			'name' => 'Sombrio',
			'state' => 24,
		]);
		DB::table('cities')->insert([
			'id' => 4675, 
			'name' => 'Sul Brasil',
			'state' => 24,
		]);
		DB::table('cities')->insert([
			'id' => 4676, 
			'name' => 'Taió',
			'state' => 24,
		]);
		DB::table('cities')->insert([
			'id' => 4677, 
			'name' => 'Tangará',
			'state' => 24,
		]);
		DB::table('cities')->insert([
			'id' => 4678, 
			'name' => 'Tigrinhos',
			'state' => 24,
		]);
		DB::table('cities')->insert([
			'id' => 4679, 
			'name' => 'Tijucas',
			'state' => 24,
		]);
		DB::table('cities')->insert([
			'id' => 4680, 
			'name' => 'Timbé do Sul',
			'state' => 24,
		]);
		DB::table('cities')->insert([
			'id' => 4681, 
			'name' => 'Timbó',
			'state' => 24,
		]);
		DB::table('cities')->insert([
			'id' => 4682, 
			'name' => 'Timbó Grande',
			'state' => 24,
		]);
		DB::table('cities')->insert([
			'id' => 4683, 
			'name' => 'Três Barras',
			'state' => 24,
		]);
		DB::table('cities')->insert([
			'id' => 4684, 
			'name' => 'Treviso',
			'state' => 24,
		]);
		DB::table('cities')->insert([
			'id' => 4685, 
			'name' => 'Treze de Maio',
			'state' => 24,
		]);
		DB::table('cities')->insert([
			'id' => 4686, 
			'name' => 'Treze Tílias',
			'state' => 24,
		]);
		DB::table('cities')->insert([
			'id' => 4687, 
			'name' => 'Trombudo Central',
			'state' => 24,
		]);
		DB::table('cities')->insert([
			'id' => 4688, 
			'name' => 'Tubarão',
			'state' => 24,
		]);
		DB::table('cities')->insert([
			'id' => 4689, 
			'name' => 'Tunápolis',
			'state' => 24,
		]);
		DB::table('cities')->insert([
			'id' => 4690, 
			'name' => 'Turvo',
			'state' => 24,
		]);
		DB::table('cities')->insert([
			'id' => 4691, 
			'name' => 'União do Oeste',
			'state' => 24,
		]);
		DB::table('cities')->insert([
			'id' => 4692, 
			'name' => 'Urubici',
			'state' => 24,
		]);
		DB::table('cities')->insert([
			'id' => 4693, 
			'name' => 'Urupema',
			'state' => 24,
		]);
		DB::table('cities')->insert([
			'id' => 4694, 
			'name' => 'Urussanga',
			'state' => 24,
		]);
		DB::table('cities')->insert([
			'id' => 4695, 
			'name' => 'Vargeão',
			'state' => 24,
		]);
		DB::table('cities')->insert([
			'id' => 4696, 
			'name' => 'Vargem',
			'state' => 24,
		]);
		DB::table('cities')->insert([
			'id' => 4697, 
			'name' => 'Vargem Bonita',
			'state' => 24,
		]);
		DB::table('cities')->insert([
			'id' => 4698, 
			'name' => 'Vidal Ramos',
			'state' => 24,
		]);
		DB::table('cities')->insert([
			'id' => 4699, 
			'name' => 'Videira',
			'state' => 24,
		]);
		DB::table('cities')->insert([
			'id' => 4700, 
			'name' => 'Vitor Meireles',
			'state' => 24,
		]);
		DB::table('cities')->insert([
			'id' => 4701, 
			'name' => 'Witmarsum',
			'state' => 24,
		]);
		DB::table('cities')->insert([
			'id' => 4702, 
			'name' => 'Xanxerê',
			'state' => 24,
		]);
		DB::table('cities')->insert([
			'id' => 4703, 
			'name' => 'Xavantina',
			'state' => 24,
		]);
		DB::table('cities')->insert([
			'id' => 4704, 
			'name' => 'Xaxim',
			'state' => 24,
		]);
		DB::table('cities')->insert([
			'id' => 4705, 
			'name' => 'Zortéa',
			'state' => 24,
		]);
		DB::table('cities')->insert([
			'id' => 4706, 
			'name' => 'Adamantina',
			'state' => 26,
		]);
		DB::table('cities')->insert([
			'id' => 4707, 
			'name' => 'Adolfo',
			'state' => 26,
		]);
		DB::table('cities')->insert([
			'id' => 4708, 
			'name' => 'Aguaí',
			'state' => 26,
		]);
		DB::table('cities')->insert([
			'id' => 4709, 
			'name' => 'Águas da Prata',
			'state' => 26,
		]);
		DB::table('cities')->insert([
			'id' => 4710, 
			'name' => 'Águas de Lindóia',
			'state' => 26,
		]);
		DB::table('cities')->insert([
			'id' => 4711, 
			'name' => 'Águas de Santa Bárbara',
			'state' => 26,
		]);
		DB::table('cities')->insert([
			'id' => 4712, 
			'name' => 'Águas de São Pedro',
			'state' => 26,
		]);
		DB::table('cities')->insert([
			'id' => 4713, 
			'name' => 'Agudos',
			'state' => 26,
		]);
		DB::table('cities')->insert([
			'id' => 4714, 
			'name' => 'Alambari',
			'state' => 26,
		]);
		DB::table('cities')->insert([
			'id' => 4715, 
			'name' => 'Alfredo Marcondes',
			'state' => 26,
		]);
		DB::table('cities')->insert([
			'id' => 4716, 
			'name' => 'Altair',
			'state' => 26,
		]);
		DB::table('cities')->insert([
			'id' => 4717, 
			'name' => 'Altinópolis',
			'state' => 26,
		]);
		DB::table('cities')->insert([
			'id' => 4718, 
			'name' => 'Alto Alegre',
			'state' => 26,
		]);
		DB::table('cities')->insert([
			'id' => 4719, 
			'name' => 'Alumínio',
			'state' => 26,
		]);
		DB::table('cities')->insert([
			'id' => 4720, 
			'name' => 'Álvares Florence',
			'state' => 26,
		]);
		DB::table('cities')->insert([
			'id' => 4721, 
			'name' => 'Álvares Machado',
			'state' => 26,
		]);
		DB::table('cities')->insert([
			'id' => 4722, 
			'name' => 'Álvaro de Carvalho',
			'state' => 26,
		]);
		DB::table('cities')->insert([
			'id' => 4723, 
			'name' => 'Alvinlândia',
			'state' => 26,
		]);
		DB::table('cities')->insert([
			'id' => 4724, 
			'name' => 'Americana',
			'state' => 26,
		]);
		DB::table('cities')->insert([
			'id' => 4725, 
			'name' => 'Américo Brasiliense',
			'state' => 26,
		]);
		DB::table('cities')->insert([
			'id' => 4726, 
			'name' => 'Américo de Campos',
			'state' => 26,
		]);
		DB::table('cities')->insert([
			'id' => 4727, 
			'name' => 'Amparo',
			'state' => 26,
		]);
		DB::table('cities')->insert([
			'id' => 4728, 
			'name' => 'Analândia',
			'state' => 26,
		]);
		DB::table('cities')->insert([
			'id' => 4729, 
			'name' => 'Andradina',
			'state' => 26,
		]);
		DB::table('cities')->insert([
			'id' => 4730, 
			'name' => 'Angatuba',
			'state' => 26,
		]);
		DB::table('cities')->insert([
			'id' => 4731, 
			'name' => 'Anhembi',
			'state' => 26,
		]);
		DB::table('cities')->insert([
			'id' => 4732, 
			'name' => 'Anhumas',
			'state' => 26,
		]);
		DB::table('cities')->insert([
			'id' => 4733, 
			'name' => 'Aparecida',
			'state' => 26,
		]);
		DB::table('cities')->insert([
			'id' => 4734, 
			'name' => 'Aparecida d`Oeste',
			'state' => 26,
		]);
		DB::table('cities')->insert([
			'id' => 4735, 
			'name' => 'Apiaí',
			'state' => 26,
		]);
		DB::table('cities')->insert([
			'id' => 4736, 
			'name' => 'Araçariguama',
			'state' => 26,
		]);
		DB::table('cities')->insert([
			'id' => 4737, 
			'name' => 'Araçatuba',
			'state' => 26,
		]);
		DB::table('cities')->insert([
			'id' => 4738, 
			'name' => 'Araçoiaba da Serra',
			'state' => 26,
		]);
		DB::table('cities')->insert([
			'id' => 4739, 
			'name' => 'Aramina',
			'state' => 26,
		]);
		DB::table('cities')->insert([
			'id' => 4740, 
			'name' => 'Arandu',
			'state' => 26,
		]);
		DB::table('cities')->insert([
			'id' => 4741, 
			'name' => 'Arapeí',
			'state' => 26,
		]);
		DB::table('cities')->insert([
			'id' => 4742, 
			'name' => 'Araraquara',
			'state' => 26,
		]);
		DB::table('cities')->insert([
			'id' => 4743, 
			'name' => 'Araras',
			'state' => 26,
		]);
		DB::table('cities')->insert([
			'id' => 4744, 
			'name' => 'Arco-Íris',
			'state' => 26,
		]);
		DB::table('cities')->insert([
			'id' => 4745, 
			'name' => 'Arealva',
			'state' => 26,
		]);
		DB::table('cities')->insert([
			'id' => 4746, 
			'name' => 'Areias',
			'state' => 26,
		]);
		DB::table('cities')->insert([
			'id' => 4747, 
			'name' => 'Areiópolis',
			'state' => 26,
		]);
		DB::table('cities')->insert([
			'id' => 4748, 
			'name' => 'Ariranha',
			'state' => 26,
		]);
		DB::table('cities')->insert([
			'id' => 4749, 
			'name' => 'Artur Nogueira',
			'state' => 26,
		]);
		DB::table('cities')->insert([
			'id' => 4750, 
			'name' => 'Arujá',
			'state' => 26,
		]);
		DB::table('cities')->insert([
			'id' => 4751, 
			'name' => 'Aspásia',
			'state' => 26,
		]);
		DB::table('cities')->insert([
			'id' => 4752, 
			'name' => 'Assis',
			'state' => 26,
		]);
		DB::table('cities')->insert([
			'id' => 4753, 
			'name' => 'Atibaia',
			'state' => 26,
		]);
		DB::table('cities')->insert([
			'id' => 4754, 
			'name' => 'Auriflama',
			'state' => 26,
		]);
		DB::table('cities')->insert([
			'id' => 4755, 
			'name' => 'Avaí',
			'state' => 26,
		]);
		DB::table('cities')->insert([
			'id' => 4756, 
			'name' => 'Avanhandava',
			'state' => 26,
		]);
		DB::table('cities')->insert([
			'id' => 4757, 
			'name' => 'Avaré',
			'state' => 26,
		]);
		DB::table('cities')->insert([
			'id' => 4758, 
			'name' => 'Bady Bassitt',
			'state' => 26,
		]);
		DB::table('cities')->insert([
			'id' => 4759, 
			'name' => 'Balbinos',
			'state' => 26,
		]);
		DB::table('cities')->insert([
			'id' => 4760, 
			'name' => 'Bálsamo',
			'state' => 26,
		]);
		DB::table('cities')->insert([
			'id' => 4761, 
			'name' => 'Bananal',
			'state' => 26,
		]);
		DB::table('cities')->insert([
			'id' => 4762, 
			'name' => 'Barão de Antonina',
			'state' => 26,
		]);
		DB::table('cities')->insert([
			'id' => 4763, 
			'name' => 'Barbosa',
			'state' => 26,
		]);
		DB::table('cities')->insert([
			'id' => 4764, 
			'name' => 'Bariri',
			'state' => 26,
		]);
		DB::table('cities')->insert([
			'id' => 4765, 
			'name' => 'Barra Bonita',
			'state' => 26,
		]);
		DB::table('cities')->insert([
			'id' => 4766, 
			'name' => 'Barra do Chapéu',
			'state' => 26,
		]);
		DB::table('cities')->insert([
			'id' => 4767, 
			'name' => 'Barra do Turvo',
			'state' => 26,
		]);
		DB::table('cities')->insert([
			'id' => 4768, 
			'name' => 'Barretos',
			'state' => 26,
		]);
		DB::table('cities')->insert([
			'id' => 4769, 
			'name' => 'Barrinha',
			'state' => 26,
		]);
		DB::table('cities')->insert([
			'id' => 4770, 
			'name' => 'Barueri',
			'state' => 26,
		]);
		DB::table('cities')->insert([
			'id' => 4771, 
			'name' => 'Bastos',
			'state' => 26,
		]);
		DB::table('cities')->insert([
			'id' => 4772, 
			'name' => 'Batatais',
			'state' => 26,
		]);
		DB::table('cities')->insert([
			'id' => 4773, 
			'name' => 'Bauru',
			'state' => 26,
		]);
		DB::table('cities')->insert([
			'id' => 4774, 
			'name' => 'Bebedouro',
			'state' => 26,
		]);
		DB::table('cities')->insert([
			'id' => 4775, 
			'name' => 'Bento de Abreu',
			'state' => 26,
		]);
		DB::table('cities')->insert([
			'id' => 4776, 
			'name' => 'Bernardino de Campos',
			'state' => 26,
		]);
		DB::table('cities')->insert([
			'id' => 4777, 
			'name' => 'Bertioga',
			'state' => 26,
		]);
		DB::table('cities')->insert([
			'id' => 4778, 
			'name' => 'Bilac',
			'state' => 26,
		]);
		DB::table('cities')->insert([
			'id' => 4779, 
			'name' => 'Birigui',
			'state' => 26,
		]);
		DB::table('cities')->insert([
			'id' => 4780, 
			'name' => 'Biritiba-Mirim',
			'state' => 26,
		]);
		DB::table('cities')->insert([
			'id' => 4781, 
			'name' => 'Boa Esperança do Sul',
			'state' => 26,
		]);
		DB::table('cities')->insert([
			'id' => 4782, 
			'name' => 'Bocaina',
			'state' => 26,
		]);
		DB::table('cities')->insert([
			'id' => 4783, 
			'name' => 'Bofete',
			'state' => 26,
		]);
		DB::table('cities')->insert([
			'id' => 4784, 
			'name' => 'Boituva',
			'state' => 26,
		]);
		DB::table('cities')->insert([
			'id' => 4785, 
			'name' => 'Bom Jesus dos Perdões',
			'state' => 26,
		]);
		DB::table('cities')->insert([
			'id' => 4786, 
			'name' => 'Bom Sucesso de Itararé',
			'state' => 26,
		]);
		DB::table('cities')->insert([
			'id' => 4787, 
			'name' => 'Borá',
			'state' => 26,
		]);
		DB::table('cities')->insert([
			'id' => 4788, 
			'name' => 'Boracéia',
			'state' => 26,
		]);
		DB::table('cities')->insert([
			'id' => 4789, 
			'name' => 'Borborema',
			'state' => 26,
		]);
		DB::table('cities')->insert([
			'id' => 4790, 
			'name' => 'Borebi',
			'state' => 26,
		]);
		DB::table('cities')->insert([
			'id' => 4791, 
			'name' => 'Botucatu',
			'state' => 26,
		]);
		DB::table('cities')->insert([
			'id' => 4792, 
			'name' => 'Bragança Paulista',
			'state' => 26,
		]);
		DB::table('cities')->insert([
			'id' => 4793, 
			'name' => 'Braúna',
			'state' => 26,
		]);
		DB::table('cities')->insert([
			'id' => 4794, 
			'name' => 'Brejo Alegre',
			'state' => 26,
		]);
		DB::table('cities')->insert([
			'id' => 4795, 
			'name' => 'Brodowski',
			'state' => 26,
		]);
		DB::table('cities')->insert([
			'id' => 4796, 
			'name' => 'Brotas',
			'state' => 26,
		]);
		DB::table('cities')->insert([
			'id' => 4797, 
			'name' => 'Buri',
			'state' => 26,
		]);
		DB::table('cities')->insert([
			'id' => 4798, 
			'name' => 'Buritama',
			'state' => 26,
		]);
		DB::table('cities')->insert([
			'id' => 4799, 
			'name' => 'Buritizal',
			'state' => 26,
		]);
		DB::table('cities')->insert([
			'id' => 4800, 
			'name' => 'Cabrália Paulista',
			'state' => 26,
		]);
		DB::table('cities')->insert([
			'id' => 4801, 
			'name' => 'Cabreúva',
			'state' => 26,
		]);
		DB::table('cities')->insert([
			'id' => 4802, 
			'name' => 'Caçapava',
			'state' => 26,
		]);
		DB::table('cities')->insert([
			'id' => 4803, 
			'name' => 'Cachoeira Paulista',
			'state' => 26,
		]);
		DB::table('cities')->insert([
			'id' => 4804, 
			'name' => 'Caconde',
			'state' => 26,
		]);
		DB::table('cities')->insert([
			'id' => 4805, 
			'name' => 'Cafelândia',
			'state' => 26,
		]);
		DB::table('cities')->insert([
			'id' => 4806, 
			'name' => 'Caiabu',
			'state' => 26,
		]);
		DB::table('cities')->insert([
			'id' => 4807, 
			'name' => 'Caieiras',
			'state' => 26,
		]);
		DB::table('cities')->insert([
			'id' => 4808, 
			'name' => 'Caiuá',
			'state' => 26,
		]);
		DB::table('cities')->insert([
			'id' => 4809, 
			'name' => 'Cajamar',
			'state' => 26,
		]);
		DB::table('cities')->insert([
			'id' => 4810, 
			'name' => 'Cajati',
			'state' => 26,
		]);
		DB::table('cities')->insert([
			'id' => 4811, 
			'name' => 'Cajobi',
			'state' => 26,
		]);
		DB::table('cities')->insert([
			'id' => 4812, 
			'name' => 'Cajuru',
			'state' => 26,
		]);
		DB::table('cities')->insert([
			'id' => 4813, 
			'name' => 'Campina do Monte Alegre',
			'state' => 26,
		]);
		DB::table('cities')->insert([
			'id' => 4814, 
			'name' => 'Campinas',
			'state' => 26,
		]);
		DB::table('cities')->insert([
			'id' => 4815, 
			'name' => 'Campo Limpo Paulista',
			'state' => 26,
		]);
		DB::table('cities')->insert([
			'id' => 4816, 
			'name' => 'Campos do Jordão',
			'state' => 26,
		]);
		DB::table('cities')->insert([
			'id' => 4817, 
			'name' => 'Campos Novos Paulista',
			'state' => 26,
		]);
		DB::table('cities')->insert([
			'id' => 4818, 
			'name' => 'Cananéia',
			'state' => 26,
		]);
		DB::table('cities')->insert([
			'id' => 4819, 
			'name' => 'Canas',
			'state' => 26,
		]);
		DB::table('cities')->insert([
			'id' => 4820, 
			'name' => 'Cândido Mota',
			'state' => 26,
		]);
		DB::table('cities')->insert([
			'id' => 4821, 
			'name' => 'Cândido Rodrigues',
			'state' => 26,
		]);
		DB::table('cities')->insert([
			'id' => 4822, 
			'name' => 'Canitar',
			'state' => 26,
		]);
		DB::table('cities')->insert([
			'id' => 4823, 
			'name' => 'Capão Bonito',
			'state' => 26,
		]);
		DB::table('cities')->insert([
			'id' => 4824, 
			'name' => 'Capela do Alto',
			'state' => 26,
		]);
		DB::table('cities')->insert([
			'id' => 4825, 
			'name' => 'Capivari',
			'state' => 26,
		]);
		DB::table('cities')->insert([
			'id' => 4826, 
			'name' => 'Caraguatatuba',
			'state' => 26,
		]);
		DB::table('cities')->insert([
			'id' => 4827, 
			'name' => 'Carapicuíba',
			'state' => 26,
		]);
		DB::table('cities')->insert([
			'id' => 4828, 
			'name' => 'Cardoso',
			'state' => 26,
		]);
		DB::table('cities')->insert([
			'id' => 4829, 
			'name' => 'Casa Branca',
			'state' => 26,
		]);
		DB::table('cities')->insert([
			'id' => 4830, 
			'name' => 'Cássia dos Coqueiros',
			'state' => 26,
		]);
		DB::table('cities')->insert([
			'id' => 4831, 
			'name' => 'Castilho',
			'state' => 26,
		]);
		DB::table('cities')->insert([
			'id' => 4832, 
			'name' => 'Catanduva',
			'state' => 26,
		]);
		DB::table('cities')->insert([
			'id' => 4833, 
			'name' => 'Catiguá',
			'state' => 26,
		]);
		DB::table('cities')->insert([
			'id' => 4834, 
			'name' => 'Cedral',
			'state' => 26,
		]);
		DB::table('cities')->insert([
			'id' => 4835, 
			'name' => 'Cerqueira César',
			'state' => 26,
		]);
		DB::table('cities')->insert([
			'id' => 4836, 
			'name' => 'Cerquilho',
			'state' => 26,
		]);
		DB::table('cities')->insert([
			'id' => 4837, 
			'name' => 'Cesário Lange',
			'state' => 26,
		]);
		DB::table('cities')->insert([
			'id' => 4838, 
			'name' => 'Charqueada',
			'state' => 26,
		]);
		DB::table('cities')->insert([
			'id' => 4839, 
			'name' => 'Chavantes',
			'state' => 26,
		]);
		DB::table('cities')->insert([
			'id' => 4840, 
			'name' => 'Clementina',
			'state' => 26,
		]);
		DB::table('cities')->insert([
			'id' => 4841, 
			'name' => 'Colina',
			'state' => 26,
		]);
		DB::table('cities')->insert([
			'id' => 4842, 
			'name' => 'Colômbia',
			'state' => 26,
		]);
		DB::table('cities')->insert([
			'id' => 4843, 
			'name' => 'Conchal',
			'state' => 26,
		]);
		DB::table('cities')->insert([
			'id' => 4844, 
			'name' => 'Conchas',
			'state' => 26,
		]);
		DB::table('cities')->insert([
			'id' => 4845, 
			'name' => 'Cordeirópolis',
			'state' => 26,
		]);
		DB::table('cities')->insert([
			'id' => 4846, 
			'name' => 'Coroados',
			'state' => 26,
		]);
		DB::table('cities')->insert([
			'id' => 4847, 
			'name' => 'Coronel Macedo',
			'state' => 26,
		]);
		DB::table('cities')->insert([
			'id' => 4848, 
			'name' => 'Corumbataí',
			'state' => 26,
		]);
		DB::table('cities')->insert([
			'id' => 4849, 
			'name' => 'Cosmópolis',
			'state' => 26,
		]);
		DB::table('cities')->insert([
			'id' => 4850, 
			'name' => 'Cosmorama',
			'state' => 26,
		]);
		DB::table('cities')->insert([
			'id' => 4851, 
			'name' => 'Cotia',
			'state' => 26,
		]);
		DB::table('cities')->insert([
			'id' => 4852, 
			'name' => 'Cravinhos',
			'state' => 26,
		]);
		DB::table('cities')->insert([
			'id' => 4853, 
			'name' => 'Cristais Paulista',
			'state' => 26,
		]);
		DB::table('cities')->insert([
			'id' => 4854, 
			'name' => 'Cruzália',
			'state' => 26,
		]);
		DB::table('cities')->insert([
			'id' => 4855, 
			'name' => 'Cruzeiro',
			'state' => 26,
		]);
		DB::table('cities')->insert([
			'id' => 4856, 
			'name' => 'Cubatão',
			'state' => 26,
		]);
		DB::table('cities')->insert([
			'id' => 4857, 
			'name' => 'Cunha',
			'state' => 26,
		]);
		DB::table('cities')->insert([
			'id' => 4858, 
			'name' => 'Descalvado',
			'state' => 26,
		]);
		DB::table('cities')->insert([
			'id' => 4859, 
			'name' => 'Diadema',
			'state' => 26,
		]);
		DB::table('cities')->insert([
			'id' => 4860, 
			'name' => 'Dirce Reis',
			'state' => 26,
		]);
		DB::table('cities')->insert([
			'id' => 4861, 
			'name' => 'Divinolândia',
			'state' => 26,
		]);
		DB::table('cities')->insert([
			'id' => 4862, 
			'name' => 'Dobrada',
			'state' => 26,
		]);
		DB::table('cities')->insert([
			'id' => 4863, 
			'name' => 'Dois Córregos',
			'state' => 26,
		]);
		DB::table('cities')->insert([
			'id' => 4864, 
			'name' => 'Dolcinópolis',
			'state' => 26,
		]);
		DB::table('cities')->insert([
			'id' => 4865, 
			'name' => 'Dourado',
			'state' => 26,
		]);
		DB::table('cities')->insert([
			'id' => 4866, 
			'name' => 'Dracena',
			'state' => 26,
		]);
		DB::table('cities')->insert([
			'id' => 4867, 
			'name' => 'Duartina',
			'state' => 26,
		]);
		DB::table('cities')->insert([
			'id' => 4868, 
			'name' => 'Dumont',
			'state' => 26,
		]);
		DB::table('cities')->insert([
			'id' => 4869, 
			'name' => 'Echaporã',
			'state' => 26,
		]);
		DB::table('cities')->insert([
			'id' => 4870, 
			'name' => 'Eldorado',
			'state' => 26,
		]);
		DB::table('cities')->insert([
			'id' => 4871, 
			'name' => 'Elias Fausto',
			'state' => 26,
		]);
		DB::table('cities')->insert([
			'id' => 4872, 
			'name' => 'Elisiário',
			'state' => 26,
		]);
		DB::table('cities')->insert([
			'id' => 4873, 
			'name' => 'Embaúba',
			'state' => 26,
		]);
		DB::table('cities')->insert([
			'id' => 4874, 
			'name' => 'Embu',
			'state' => 26,
		]);
		DB::table('cities')->insert([
			'id' => 4875, 
			'name' => 'Embu-Guaçu',
			'state' => 26,
		]);
		DB::table('cities')->insert([
			'id' => 4876, 
			'name' => 'Emilianópolis',
			'state' => 26,
		]);
		DB::table('cities')->insert([
			'id' => 4877, 
			'name' => 'Engenheiro Coelho',
			'state' => 26,
		]);
		DB::table('cities')->insert([
			'id' => 4878, 
			'name' => 'Espírito Santo do Pinhal',
			'state' => 26,
		]);
		DB::table('cities')->insert([
			'id' => 4879, 
			'name' => 'Espírito Santo do Turvo',
			'state' => 26,
		]);
		DB::table('cities')->insert([
			'id' => 4880, 
			'name' => 'Estiva Gerbi',
			'state' => 26,
		]);
		DB::table('cities')->insert([
			'id' => 4881, 
			'name' => 'Estrela d`Oeste',
			'state' => 26,
		]);
		DB::table('cities')->insert([
			'id' => 4882, 
			'name' => 'Estrela do Norte',
			'state' => 26,
		]);
		DB::table('cities')->insert([
			'id' => 4883, 
			'name' => 'Euclides da Cunha Paulista',
			'state' => 26,
		]);
		DB::table('cities')->insert([
			'id' => 4884, 
			'name' => 'Fartura',
			'state' => 26,
		]);
		DB::table('cities')->insert([
			'id' => 4885, 
			'name' => 'Fernando Prestes',
			'state' => 26,
		]);
		DB::table('cities')->insert([
			'id' => 4886, 
			'name' => 'Fernandópolis',
			'state' => 26,
		]);
		DB::table('cities')->insert([
			'id' => 4887, 
			'name' => 'Fernão',
			'state' => 26,
		]);
		DB::table('cities')->insert([
			'id' => 4888, 
			'name' => 'Ferraz de Vasconcelos',
			'state' => 26,
		]);
		DB::table('cities')->insert([
			'id' => 4889, 
			'name' => 'Flora Rica',
			'state' => 26,
		]);
		DB::table('cities')->insert([
			'id' => 4890, 
			'name' => 'Floreal',
			'state' => 26,
		]);
		DB::table('cities')->insert([
			'id' => 4891, 
			'name' => 'Flórida Paulista',
			'state' => 26,
		]);
		DB::table('cities')->insert([
			'id' => 4892, 
			'name' => 'Florínia',
			'state' => 26,
		]);
		DB::table('cities')->insert([
			'id' => 4893, 
			'name' => 'Franca',
			'state' => 26,
		]);
		DB::table('cities')->insert([
			'id' => 4894, 
			'name' => 'Francisco Morato',
			'state' => 26,
		]);
		DB::table('cities')->insert([
			'id' => 4895, 
			'name' => 'Franco da Rocha',
			'state' => 26,
		]);
		DB::table('cities')->insert([
			'id' => 4896, 
			'name' => 'Gabriel Monteiro',
			'state' => 26,
		]);
		DB::table('cities')->insert([
			'id' => 4897, 
			'name' => 'Gália',
			'state' => 26,
		]);
		DB::table('cities')->insert([
			'id' => 4898, 
			'name' => 'Garça',
			'state' => 26,
		]);
		DB::table('cities')->insert([
			'id' => 4899, 
			'name' => 'Gastão Vidigal',
			'state' => 26,
		]);
		DB::table('cities')->insert([
			'id' => 4900, 
			'name' => 'Gavião Peixoto',
			'state' => 26,
		]);
		DB::table('cities')->insert([
			'id' => 4901, 
			'name' => 'General Salgado',
			'state' => 26,
		]);
		DB::table('cities')->insert([
			'id' => 4902, 
			'name' => 'Getulina',
			'state' => 26,
		]);
		DB::table('cities')->insert([
			'id' => 4903, 
			'name' => 'Glicério',
			'state' => 26,
		]);
		DB::table('cities')->insert([
			'id' => 4904, 
			'name' => 'Guaiçara',
			'state' => 26,
		]);
		DB::table('cities')->insert([
			'id' => 4905, 
			'name' => 'Guaimbê',
			'state' => 26,
		]);
		DB::table('cities')->insert([
			'id' => 4906, 
			'name' => 'Guaíra',
			'state' => 26,
		]);
		DB::table('cities')->insert([
			'id' => 4907, 
			'name' => 'Guapiaçu',
			'state' => 26,
		]);
		DB::table('cities')->insert([
			'id' => 4908, 
			'name' => 'Guapiara',
			'state' => 26,
		]);
		DB::table('cities')->insert([
			'id' => 4909, 
			'name' => 'Guará',
			'state' => 26,
		]);
		DB::table('cities')->insert([
			'id' => 4910, 
			'name' => 'Guaraçaí',
			'state' => 26,
		]);
		DB::table('cities')->insert([
			'id' => 4911, 
			'name' => 'Guaraci',
			'state' => 26,
		]);
		DB::table('cities')->insert([
			'id' => 4912, 
			'name' => 'Guarani d`Oeste',
			'state' => 26,
		]);
		DB::table('cities')->insert([
			'id' => 4913, 
			'name' => 'Guarantã',
			'state' => 26,
		]);
		DB::table('cities')->insert([
			'id' => 4914, 
			'name' => 'Guararapes',
			'state' => 26,
		]);
		DB::table('cities')->insert([
			'id' => 4915, 
			'name' => 'Guararema',
			'state' => 26,
		]);
		DB::table('cities')->insert([
			'id' => 4916, 
			'name' => 'Guaratinguetá',
			'state' => 26,
		]);
		DB::table('cities')->insert([
			'id' => 4917, 
			'name' => 'Guareí',
			'state' => 26,
		]);
		DB::table('cities')->insert([
			'id' => 4918, 
			'name' => 'Guariba',
			'state' => 26,
		]);
		DB::table('cities')->insert([
			'id' => 4919, 
			'name' => 'Guarujá',
			'state' => 26,
		]);
		DB::table('cities')->insert([
			'id' => 4920, 
			'name' => 'Guarulhos',
			'state' => 26,
		]);
		DB::table('cities')->insert([
			'id' => 4921, 
			'name' => 'Guatapará',
			'state' => 26,
		]);
		DB::table('cities')->insert([
			'id' => 4922, 
			'name' => 'Guzolândia',
			'state' => 26,
		]);
		DB::table('cities')->insert([
			'id' => 4923, 
			'name' => 'Herculândia',
			'state' => 26,
		]);
		DB::table('cities')->insert([
			'id' => 4924, 
			'name' => 'Holambra',
			'state' => 26,
		]);
		DB::table('cities')->insert([
			'id' => 4925, 
			'name' => 'Hortolândia',
			'state' => 26,
		]);
		DB::table('cities')->insert([
			'id' => 4926, 
			'name' => 'Iacanga',
			'state' => 26,
		]);
		DB::table('cities')->insert([
			'id' => 4927, 
			'name' => 'Iacri',
			'state' => 26,
		]);
		DB::table('cities')->insert([
			'id' => 4928, 
			'name' => 'Iaras',
			'state' => 26,
		]);
		DB::table('cities')->insert([
			'id' => 4929, 
			'name' => 'Ibaté',
			'state' => 26,
		]);
		DB::table('cities')->insert([
			'id' => 4930, 
			'name' => 'Ibirá',
			'state' => 26,
		]);
		DB::table('cities')->insert([
			'id' => 4931, 
			'name' => 'Ibirarema',
			'state' => 26,
		]);
		DB::table('cities')->insert([
			'id' => 4932, 
			'name' => 'Ibitinga',
			'state' => 26,
		]);
		DB::table('cities')->insert([
			'id' => 4933, 
			'name' => 'Ibiúna',
			'state' => 26,
		]);
		DB::table('cities')->insert([
			'id' => 4934, 
			'name' => 'Icém',
			'state' => 26,
		]);
		DB::table('cities')->insert([
			'id' => 4935, 
			'name' => 'Iepê',
			'state' => 26,
		]);
		DB::table('cities')->insert([
			'id' => 4936, 
			'name' => 'Igaraçu do Tietê',
			'state' => 26,
		]);
		DB::table('cities')->insert([
			'id' => 4937, 
			'name' => 'Igarapava',
			'state' => 26,
		]);
		DB::table('cities')->insert([
			'id' => 4938, 
			'name' => 'Igaratá',
			'state' => 26,
		]);
		DB::table('cities')->insert([
			'id' => 4939, 
			'name' => 'Iguape',
			'state' => 26,
		]);
		DB::table('cities')->insert([
			'id' => 4940, 
			'name' => 'Ilha Comprida',
			'state' => 26,
		]);
		DB::table('cities')->insert([
			'id' => 4941, 
			'name' => 'Ilha Solteira',
			'state' => 26,
		]);
		DB::table('cities')->insert([
			'id' => 4942, 
			'name' => 'Ilhabela',
			'state' => 26,
		]);
		DB::table('cities')->insert([
			'id' => 4943, 
			'name' => 'Indaiatuba',
			'state' => 26,
		]);
		DB::table('cities')->insert([
			'id' => 4944, 
			'name' => 'Indiana',
			'state' => 26,
		]);
		DB::table('cities')->insert([
			'id' => 4945, 
			'name' => 'Indiaporã',
			'state' => 26,
		]);
		DB::table('cities')->insert([
			'id' => 4946, 
			'name' => 'Inúbia Paulista',
			'state' => 26,
		]);
		DB::table('cities')->insert([
			'id' => 4947, 
			'name' => 'Ipaussu',
			'state' => 26,
		]);
		DB::table('cities')->insert([
			'id' => 4948, 
			'name' => 'Iperó',
			'state' => 26,
		]);
		DB::table('cities')->insert([
			'id' => 4949, 
			'name' => 'Ipeúna',
			'state' => 26,
		]);
		DB::table('cities')->insert([
			'id' => 4950, 
			'name' => 'Ipiguá',
			'state' => 26,
		]);
		DB::table('cities')->insert([
			'id' => 4951, 
			'name' => 'Iporanga',
			'state' => 26,
		]);
		DB::table('cities')->insert([
			'id' => 4952, 
			'name' => 'Ipuã',
			'state' => 26,
		]);
		DB::table('cities')->insert([
			'id' => 4953, 
			'name' => 'Iracemápolis',
			'state' => 26,
		]);
		DB::table('cities')->insert([
			'id' => 4954, 
			'name' => 'Irapuã',
			'state' => 26,
		]);
		DB::table('cities')->insert([
			'id' => 4955, 
			'name' => 'Irapuru',
			'state' => 26,
		]);
		DB::table('cities')->insert([
			'id' => 4956, 
			'name' => 'Itaberá',
			'state' => 26,
		]);
		DB::table('cities')->insert([
			'id' => 4957, 
			'name' => 'Itaí',
			'state' => 26,
		]);
		DB::table('cities')->insert([
			'id' => 4958, 
			'name' => 'Itajobi',
			'state' => 26,
		]);
		DB::table('cities')->insert([
			'id' => 4959, 
			'name' => 'Itaju',
			'state' => 26,
		]);
		DB::table('cities')->insert([
			'id' => 4960, 
			'name' => 'Itanhaém',
			'state' => 26,
		]);
		DB::table('cities')->insert([
			'id' => 4961, 
			'name' => 'Itaóca',
			'state' => 26,
		]);
		DB::table('cities')->insert([
			'id' => 4962, 
			'name' => 'Itapecerica da Serra',
			'state' => 26,
		]);
		DB::table('cities')->insert([
			'id' => 4963, 
			'name' => 'Itapetininga',
			'state' => 26,
		]);
		DB::table('cities')->insert([
			'id' => 4964, 
			'name' => 'Itapeva',
			'state' => 26,
		]);
		DB::table('cities')->insert([
			'id' => 4965, 
			'name' => 'Itapevi',
			'state' => 26,
		]);
		DB::table('cities')->insert([
			'id' => 4966, 
			'name' => 'Itapira',
			'state' => 26,
		]);
		DB::table('cities')->insert([
			'id' => 4967, 
			'name' => 'Itapirapuã Paulista',
			'state' => 26,
		]);
		DB::table('cities')->insert([
			'id' => 4968, 
			'name' => 'Itápolis',
			'state' => 26,
		]);
		DB::table('cities')->insert([
			'id' => 4969, 
			'name' => 'Itaporanga',
			'state' => 26,
		]);
		DB::table('cities')->insert([
			'id' => 4970, 
			'name' => 'Itapuí',
			'state' => 26,
		]);
		DB::table('cities')->insert([
			'id' => 4971, 
			'name' => 'Itapura',
			'state' => 26,
		]);
		DB::table('cities')->insert([
			'id' => 4972, 
			'name' => 'Itaquaquecetuba',
			'state' => 26,
		]);
		DB::table('cities')->insert([
			'id' => 4973, 
			'name' => 'Itararé',
			'state' => 26,
		]);
		DB::table('cities')->insert([
			'id' => 4974, 
			'name' => 'Itariri',
			'state' => 26,
		]);
		DB::table('cities')->insert([
			'id' => 4975, 
			'name' => 'Itatiba',
			'state' => 26,
		]);
		DB::table('cities')->insert([
			'id' => 4976, 
			'name' => 'Itatinga',
			'state' => 26,
		]);
		DB::table('cities')->insert([
			'id' => 4977, 
			'name' => 'Itirapina',
			'state' => 26,
		]);
		DB::table('cities')->insert([
			'id' => 4978, 
			'name' => 'Itirapuã',
			'state' => 26,
		]);
		DB::table('cities')->insert([
			'id' => 4979, 
			'name' => 'Itobi',
			'state' => 26,
		]);
		DB::table('cities')->insert([
			'id' => 4980, 
			'name' => 'Itu',
			'state' => 26,
		]);
		DB::table('cities')->insert([
			'id' => 4981, 
			'name' => 'Itupeva',
			'state' => 26,
		]);
		DB::table('cities')->insert([
			'id' => 4982, 
			'name' => 'Ituverava',
			'state' => 26,
		]);
		DB::table('cities')->insert([
			'id' => 4983, 
			'name' => 'Jaborandi',
			'state' => 26,
		]);
		DB::table('cities')->insert([
			'id' => 4984, 
			'name' => 'Jaboticabal',
			'state' => 26,
		]);
		DB::table('cities')->insert([
			'id' => 4985, 
			'name' => 'Jacareí',
			'state' => 26,
		]);
		DB::table('cities')->insert([
			'id' => 4986, 
			'name' => 'Jaci',
			'state' => 26,
		]);
		DB::table('cities')->insert([
			'id' => 4987, 
			'name' => 'Jacupiranga',
			'state' => 26,
		]);
		DB::table('cities')->insert([
			'id' => 4988, 
			'name' => 'Jaguariúna',
			'state' => 26,
		]);
		DB::table('cities')->insert([
			'id' => 4989, 
			'name' => 'Jales',
			'state' => 26,
		]);
		DB::table('cities')->insert([
			'id' => 4990, 
			'name' => 'Jambeiro',
			'state' => 26,
		]);
		DB::table('cities')->insert([
			'id' => 4991, 
			'name' => 'Jandira',
			'state' => 26,
		]);
		DB::table('cities')->insert([
			'id' => 4992, 
			'name' => 'Jardinópolis',
			'state' => 26,
		]);
		DB::table('cities')->insert([
			'id' => 4993, 
			'name' => 'Jarinu',
			'state' => 26,
		]);
		DB::table('cities')->insert([
			'id' => 4994, 
			'name' => 'Jaú',
			'state' => 26,
		]);
		DB::table('cities')->insert([
			'id' => 4995, 
			'name' => 'Jeriquara',
			'state' => 26,
		]);
		DB::table('cities')->insert([
			'id' => 4996, 
			'name' => 'Joanópolis',
			'state' => 26,
		]);
		DB::table('cities')->insert([
			'id' => 4997, 
			'name' => 'João Ramalho',
			'state' => 26,
		]);
		DB::table('cities')->insert([
			'id' => 4998, 
			'name' => 'José Bonifácio',
			'state' => 26,
		]);
		DB::table('cities')->insert([
			'id' => 4999, 
			'name' => 'Júlio Mesquita',
			'state' => 26,
		]);
		DB::table('cities')->insert([
			'id' => 5000, 
			'name' => 'Jumirim',
			'state' => 26,
		]);
		DB::table('cities')->insert([
			'id' => 5001, 
			'name' => 'Jundiaí',
			'state' => 26,
		]);
		DB::table('cities')->insert([
			'id' => 5002, 
			'name' => 'Junqueirópolis',
			'state' => 26,
		]);
		DB::table('cities')->insert([
			'id' => 5003, 
			'name' => 'Juquiá',
			'state' => 26,
		]);
		DB::table('cities')->insert([
			'id' => 5004, 
			'name' => 'Juquitiba',
			'state' => 26,
		]);
		DB::table('cities')->insert([
			'id' => 5005, 
			'name' => 'Lagoinha',
			'state' => 26,
		]);
		DB::table('cities')->insert([
			'id' => 5006, 
			'name' => 'Laranjal Paulista',
			'state' => 26,
		]);
		DB::table('cities')->insert([
			'id' => 5007, 
			'name' => 'Lavínia',
			'state' => 26,
		]);
		DB::table('cities')->insert([
			'id' => 5008, 
			'name' => 'Lavrinhas',
			'state' => 26,
		]);
		DB::table('cities')->insert([
			'id' => 5009, 
			'name' => 'Leme',
			'state' => 26,
		]);
		DB::table('cities')->insert([
			'id' => 5010, 
			'name' => 'Lençóis Paulista',
			'state' => 26,
		]);
		DB::table('cities')->insert([
			'id' => 5011, 
			'name' => 'Limeira',
			'state' => 26,
		]);
		DB::table('cities')->insert([
			'id' => 5012, 
			'name' => 'Lindóia',
			'state' => 26,
		]);
		DB::table('cities')->insert([
			'id' => 5013, 
			'name' => 'Lins',
			'state' => 26,
		]);
		DB::table('cities')->insert([
			'id' => 5014, 
			'name' => 'Lorena',
			'state' => 26,
		]);
		DB::table('cities')->insert([
			'id' => 5015, 
			'name' => 'Lourdes',
			'state' => 26,
		]);
		DB::table('cities')->insert([
			'id' => 5016, 
			'name' => 'Louveira',
			'state' => 26,
		]);
		DB::table('cities')->insert([
			'id' => 5017, 
			'name' => 'Lucélia',
			'state' => 26,
		]);
		DB::table('cities')->insert([
			'id' => 5018, 
			'name' => 'Lucianópolis',
			'state' => 26,
		]);
		DB::table('cities')->insert([
			'id' => 5019, 
			'name' => 'Luís Antônio',
			'state' => 26,
		]);
		DB::table('cities')->insert([
			'id' => 5020, 
			'name' => 'Luiziânia',
			'state' => 26,
		]);
		DB::table('cities')->insert([
			'id' => 5021, 
			'name' => 'Lupércio',
			'state' => 26,
		]);
		DB::table('cities')->insert([
			'id' => 5022, 
			'name' => 'Lutécia',
			'state' => 26,
		]);
		DB::table('cities')->insert([
			'id' => 5023, 
			'name' => 'Macatuba',
			'state' => 26,
		]);
		DB::table('cities')->insert([
			'id' => 5024, 
			'name' => 'Macaubal',
			'state' => 26,
		]);
		DB::table('cities')->insert([
			'id' => 5025, 
			'name' => 'Macedônia',
			'state' => 26,
		]);
		DB::table('cities')->insert([
			'id' => 5026, 
			'name' => 'Magda',
			'state' => 26,
		]);
		DB::table('cities')->insert([
			'id' => 5027, 
			'name' => 'Mairinque',
			'state' => 26,
		]);
		DB::table('cities')->insert([
			'id' => 5028, 
			'name' => 'Mairiporã',
			'state' => 26,
		]);
		DB::table('cities')->insert([
			'id' => 5029, 
			'name' => 'Manduri',
			'state' => 26,
		]);
		DB::table('cities')->insert([
			'id' => 5030, 
			'name' => 'Marabá Paulista',
			'state' => 26,
		]);
		DB::table('cities')->insert([
			'id' => 5031, 
			'name' => 'Maracaí',
			'state' => 26,
		]);
		DB::table('cities')->insert([
			'id' => 5032, 
			'name' => 'Marapoama',
			'state' => 26,
		]);
		DB::table('cities')->insert([
			'id' => 5033, 
			'name' => 'Mariápolis',
			'state' => 26,
		]);
		DB::table('cities')->insert([
			'id' => 5034, 
			'name' => 'Marília',
			'state' => 26,
		]);
		DB::table('cities')->insert([
			'id' => 5035, 
			'name' => 'Marinópolis',
			'state' => 26,
		]);
		DB::table('cities')->insert([
			'id' => 5036, 
			'name' => 'Martinópolis',
			'state' => 26,
		]);
		DB::table('cities')->insert([
			'id' => 5037, 
			'name' => 'Matão',
			'state' => 26,
		]);
		DB::table('cities')->insert([
			'id' => 5038, 
			'name' => 'Mauá',
			'state' => 26,
		]);
		DB::table('cities')->insert([
			'id' => 5039, 
			'name' => 'Mendonça',
			'state' => 26,
		]);
		DB::table('cities')->insert([
			'id' => 5040, 
			'name' => 'Meridiano',
			'state' => 26,
		]);
		DB::table('cities')->insert([
			'id' => 5041, 
			'name' => 'Mesópolis',
			'state' => 26,
		]);
		DB::table('cities')->insert([
			'id' => 5042, 
			'name' => 'Miguelópolis',
			'state' => 26,
		]);
		DB::table('cities')->insert([
			'id' => 5043, 
			'name' => 'Mineiros do Tietê',
			'state' => 26,
		]);
		DB::table('cities')->insert([
			'id' => 5044, 
			'name' => 'Mira Estrela',
			'state' => 26,
		]);
		DB::table('cities')->insert([
			'id' => 5045, 
			'name' => 'Miracatu',
			'state' => 26,
		]);
		DB::table('cities')->insert([
			'id' => 5046, 
			'name' => 'Mirandópolis',
			'state' => 26,
		]);
		DB::table('cities')->insert([
			'id' => 5047, 
			'name' => 'Mirante do Paranapanema',
			'state' => 26,
		]);
		DB::table('cities')->insert([
			'id' => 5048, 
			'name' => 'Mirassol',
			'state' => 26,
		]);
		DB::table('cities')->insert([
			'id' => 5049, 
			'name' => 'Mirassolândia',
			'state' => 26,
		]);
		DB::table('cities')->insert([
			'id' => 5050, 
			'name' => 'Mococa',
			'state' => 26,
		]);
		DB::table('cities')->insert([
			'id' => 5051, 
			'name' => 'Mogi das Cruzes',
			'state' => 26,
		]);
		DB::table('cities')->insert([
			'id' => 5052, 
			'name' => 'Mogi Guaçu',
			'state' => 26,
		]);
		DB::table('cities')->insert([
			'id' => 5053, 
			'name' => 'Moji Mirim',
			'state' => 26,
		]);
		DB::table('cities')->insert([
			'id' => 5054, 
			'name' => 'Mombuca',
			'state' => 26,
		]);
		DB::table('cities')->insert([
			'id' => 5055, 
			'name' => 'Monções',
			'state' => 26,
		]);
		DB::table('cities')->insert([
			'id' => 5056, 
			'name' => 'Mongaguá',
			'state' => 26,
		]);
		DB::table('cities')->insert([
			'id' => 5057, 
			'name' => 'Monte Alegre do Sul',
			'state' => 26,
		]);
		DB::table('cities')->insert([
			'id' => 5058, 
			'name' => 'Monte Alto',
			'state' => 26,
		]);
		DB::table('cities')->insert([
			'id' => 5059, 
			'name' => 'Monte Aprazível',
			'state' => 26,
		]);
		DB::table('cities')->insert([
			'id' => 5060, 
			'name' => 'Monte Azul Paulista',
			'state' => 26,
		]);
		DB::table('cities')->insert([
			'id' => 5061, 
			'name' => 'Monte Castelo',
			'state' => 26,
		]);
		DB::table('cities')->insert([
			'id' => 5062, 
			'name' => 'Monte Mor',
			'state' => 26,
		]);
		DB::table('cities')->insert([
			'id' => 5063, 
			'name' => 'Monteiro Lobato',
			'state' => 26,
		]);
		DB::table('cities')->insert([
			'id' => 5064, 
			'name' => 'Morro Agudo',
			'state' => 26,
		]);
		DB::table('cities')->insert([
			'id' => 5065, 
			'name' => 'Morungaba',
			'state' => 26,
		]);
		DB::table('cities')->insert([
			'id' => 5066, 
			'name' => 'Motuca',
			'state' => 26,
		]);
		DB::table('cities')->insert([
			'id' => 5067, 
			'name' => 'Murutinga do Sul',
			'state' => 26,
		]);
		DB::table('cities')->insert([
			'id' => 5068, 
			'name' => 'Nantes',
			'state' => 26,
		]);
		DB::table('cities')->insert([
			'id' => 5069, 
			'name' => 'Narandiba',
			'state' => 26,
		]);
		DB::table('cities')->insert([
			'id' => 5070, 
			'name' => 'Natividade da Serra',
			'state' => 26,
		]);
		DB::table('cities')->insert([
			'id' => 5071, 
			'name' => 'Nazaré Paulista',
			'state' => 26,
		]);
		DB::table('cities')->insert([
			'id' => 5072, 
			'name' => 'Neves Paulista',
			'state' => 26,
		]);
		DB::table('cities')->insert([
			'id' => 5073, 
			'name' => 'Nhandeara',
			'state' => 26,
		]);
		DB::table('cities')->insert([
			'id' => 5074, 
			'name' => 'Nipoã',
			'state' => 26,
		]);
		DB::table('cities')->insert([
			'id' => 5075, 
			'name' => 'Nova Aliança',
			'state' => 26,
		]);
		DB::table('cities')->insert([
			'id' => 5076, 
			'name' => 'Nova Campina',
			'state' => 26,
		]);
		DB::table('cities')->insert([
			'id' => 5077, 
			'name' => 'Nova Canaã Paulista',
			'state' => 26,
		]);
		DB::table('cities')->insert([
			'id' => 5078, 
			'name' => 'Nova Castilho',
			'state' => 26,
		]);
		DB::table('cities')->insert([
			'id' => 5079, 
			'name' => 'Nova Europa',
			'state' => 26,
		]);
		DB::table('cities')->insert([
			'id' => 5080, 
			'name' => 'Nova Granada',
			'state' => 26,
		]);
		DB::table('cities')->insert([
			'id' => 5081, 
			'name' => 'Nova Guataporanga',
			'state' => 26,
		]);
		DB::table('cities')->insert([
			'id' => 5082, 
			'name' => 'Nova Independência',
			'state' => 26,
		]);
		DB::table('cities')->insert([
			'id' => 5083, 
			'name' => 'Nova Luzitânia',
			'state' => 26,
		]);
		DB::table('cities')->insert([
			'id' => 5084, 
			'name' => 'Nova Odessa',
			'state' => 26,
		]);
		DB::table('cities')->insert([
			'id' => 5085, 
			'name' => 'Novais',
			'state' => 26,
		]);
		DB::table('cities')->insert([
			'id' => 5086, 
			'name' => 'Novo Horizonte',
			'state' => 26,
		]);
		DB::table('cities')->insert([
			'id' => 5087, 
			'name' => 'Nuporanga',
			'state' => 26,
		]);
		DB::table('cities')->insert([
			'id' => 5088, 
			'name' => 'Ocauçu',
			'state' => 26,
		]);
		DB::table('cities')->insert([
			'id' => 5089, 
			'name' => 'Óleo',
			'state' => 26,
		]);
		DB::table('cities')->insert([
			'id' => 5090, 
			'name' => 'Olímpia',
			'state' => 26,
		]);
		DB::table('cities')->insert([
			'id' => 5091, 
			'name' => 'Onda Verde',
			'state' => 26,
		]);
		DB::table('cities')->insert([
			'id' => 5092, 
			'name' => 'Oriente',
			'state' => 26,
		]);
		DB::table('cities')->insert([
			'id' => 5093, 
			'name' => 'Orindiúva',
			'state' => 26,
		]);
		DB::table('cities')->insert([
			'id' => 5094, 
			'name' => 'Orlândia',
			'state' => 26,
		]);
		DB::table('cities')->insert([
			'id' => 5095, 
			'name' => 'Osasco',
			'state' => 26,
		]);
		DB::table('cities')->insert([
			'id' => 5096, 
			'name' => 'Oscar Bressane',
			'state' => 26,
		]);
		DB::table('cities')->insert([
			'id' => 5097, 
			'name' => 'Osvaldo Cruz',
			'state' => 26,
		]);
		DB::table('cities')->insert([
			'id' => 5098, 
			'name' => 'Ourinhos',
			'state' => 26,
		]);
		DB::table('cities')->insert([
			'id' => 5099, 
			'name' => 'Ouro Verde',
			'state' => 26,
		]);
		DB::table('cities')->insert([
			'id' => 5100, 
			'name' => 'Ouroeste',
			'state' => 26,
		]);
		DB::table('cities')->insert([
			'id' => 5101, 
			'name' => 'Pacaembu',
			'state' => 26,
		]);
		DB::table('cities')->insert([
			'id' => 5102, 
			'name' => 'Palestina',
			'state' => 26,
		]);
		DB::table('cities')->insert([
			'id' => 5103, 
			'name' => 'Palmares Paulista',
			'state' => 26,
		]);
		DB::table('cities')->insert([
			'id' => 5104, 
			'name' => 'Palmeira d`Oeste',
			'state' => 26,
		]);
		DB::table('cities')->insert([
			'id' => 5105, 
			'name' => 'Palmital',
			'state' => 26,
		]);
		DB::table('cities')->insert([
			'id' => 5106, 
			'name' => 'Panorama',
			'state' => 26,
		]);
		DB::table('cities')->insert([
			'id' => 5107, 
			'name' => 'Paraguaçu Paulista',
			'state' => 26,
		]);
		DB::table('cities')->insert([
			'id' => 5108, 
			'name' => 'Paraibuna',
			'state' => 26,
		]);
		DB::table('cities')->insert([
			'id' => 5109, 
			'name' => 'Paraíso',
			'state' => 26,
		]);
		DB::table('cities')->insert([
			'id' => 5110, 
			'name' => 'Paranapanema',
			'state' => 26,
		]);
		DB::table('cities')->insert([
			'id' => 5111, 
			'name' => 'Paranapuã',
			'state' => 26,
		]);
		DB::table('cities')->insert([
			'id' => 5112, 
			'name' => 'Parapuã',
			'state' => 26,
		]);
		DB::table('cities')->insert([
			'id' => 5113, 
			'name' => 'Pardinho',
			'state' => 26,
		]);
		DB::table('cities')->insert([
			'id' => 5114, 
			'name' => 'Pariquera-Açu',
			'state' => 26,
		]);
		DB::table('cities')->insert([
			'id' => 5115, 
			'name' => 'Parisi',
			'state' => 26,
		]);
		DB::table('cities')->insert([
			'id' => 5116, 
			'name' => 'Patrocínio Paulista',
			'state' => 26,
		]);
		DB::table('cities')->insert([
			'id' => 5117, 
			'name' => 'Paulicéia',
			'state' => 26,
		]);
		DB::table('cities')->insert([
			'id' => 5118, 
			'name' => 'Paulínia',
			'state' => 26,
		]);
		DB::table('cities')->insert([
			'id' => 5119, 
			'name' => 'Paulistânia',
			'state' => 26,
		]);
		DB::table('cities')->insert([
			'id' => 5120, 
			'name' => 'Paulo de Faria',
			'state' => 26,
		]);
		DB::table('cities')->insert([
			'id' => 5121, 
			'name' => 'Pederneiras',
			'state' => 26,
		]);
		DB::table('cities')->insert([
			'id' => 5122, 
			'name' => 'Pedra Bela',
			'state' => 26,
		]);
		DB::table('cities')->insert([
			'id' => 5123, 
			'name' => 'Pedranópolis',
			'state' => 26,
		]);
		DB::table('cities')->insert([
			'id' => 5124, 
			'name' => 'Pedregulho',
			'state' => 26,
		]);
		DB::table('cities')->insert([
			'id' => 5125, 
			'name' => 'Pedreira',
			'state' => 26,
		]);
		DB::table('cities')->insert([
			'id' => 5126, 
			'name' => 'Pedrinhas Paulista',
			'state' => 26,
		]);
		DB::table('cities')->insert([
			'id' => 5127, 
			'name' => 'Pedro de Toledo',
			'state' => 26,
		]);
		DB::table('cities')->insert([
			'id' => 5128, 
			'name' => 'Penápolis',
			'state' => 26,
		]);
		DB::table('cities')->insert([
			'id' => 5129, 
			'name' => 'Pereira Barreto',
			'state' => 26,
		]);
		DB::table('cities')->insert([
			'id' => 5130, 
			'name' => 'Pereiras',
			'state' => 26,
		]);
		DB::table('cities')->insert([
			'id' => 5131, 
			'name' => 'Peruíbe',
			'state' => 26,
		]);
		DB::table('cities')->insert([
			'id' => 5132, 
			'name' => 'Piacatu',
			'state' => 26,
		]);
		DB::table('cities')->insert([
			'id' => 5133, 
			'name' => 'Piedade',
			'state' => 26,
		]);
		DB::table('cities')->insert([
			'id' => 5134, 
			'name' => 'Pilar do Sul',
			'state' => 26,
		]);
		DB::table('cities')->insert([
			'id' => 5135, 
			'name' => 'Pindamonhangaba',
			'state' => 26,
		]);
		DB::table('cities')->insert([
			'id' => 5136, 
			'name' => 'Pindorama',
			'state' => 26,
		]);
		DB::table('cities')->insert([
			'id' => 5137, 
			'name' => 'Pinhalzinho',
			'state' => 26,
		]);
		DB::table('cities')->insert([
			'id' => 5138, 
			'name' => 'Piquerobi',
			'state' => 26,
		]);
		DB::table('cities')->insert([
			'id' => 5139, 
			'name' => 'Piquete',
			'state' => 26,
		]);
		DB::table('cities')->insert([
			'id' => 5140, 
			'name' => 'Piracaia',
			'state' => 26,
		]);
		DB::table('cities')->insert([
			'id' => 5141, 
			'name' => 'Piracicaba',
			'state' => 26,
		]);
		DB::table('cities')->insert([
			'id' => 5142, 
			'name' => 'Piraju',
			'state' => 26,
		]);
		DB::table('cities')->insert([
			'id' => 5143, 
			'name' => 'Pirajuí',
			'state' => 26,
		]);
		DB::table('cities')->insert([
			'id' => 5144, 
			'name' => 'Pirangi',
			'state' => 26,
		]);
		DB::table('cities')->insert([
			'id' => 5145, 
			'name' => 'Pirapora do Bom Jesus',
			'state' => 26,
		]);
		DB::table('cities')->insert([
			'id' => 5146, 
			'name' => 'Pirapozinho',
			'state' => 26,
		]);
		DB::table('cities')->insert([
			'id' => 5147, 
			'name' => 'Pirassununga',
			'state' => 26,
		]);
		DB::table('cities')->insert([
			'id' => 5148, 
			'name' => 'Piratininga',
			'state' => 26,
		]);
		DB::table('cities')->insert([
			'id' => 5149, 
			'name' => 'Pitangueiras',
			'state' => 26,
		]);
		DB::table('cities')->insert([
			'id' => 5150, 
			'name' => 'Planalto',
			'state' => 26,
		]);
		DB::table('cities')->insert([
			'id' => 5151, 
			'name' => 'Platina',
			'state' => 26,
		]);
		DB::table('cities')->insert([
			'id' => 5152, 
			'name' => 'Poá',
			'state' => 26,
		]);
		DB::table('cities')->insert([
			'id' => 5153, 
			'name' => 'Poloni',
			'state' => 26,
		]);
		DB::table('cities')->insert([
			'id' => 5154, 
			'name' => 'Pompéia',
			'state' => 26,
		]);
		DB::table('cities')->insert([
			'id' => 5155, 
			'name' => 'Pongaí',
			'state' => 26,
		]);
		DB::table('cities')->insert([
			'id' => 5156, 
			'name' => 'Pontal',
			'state' => 26,
		]);
		DB::table('cities')->insert([
			'id' => 5157, 
			'name' => 'Pontalinda',
			'state' => 26,
		]);
		DB::table('cities')->insert([
			'id' => 5158, 
			'name' => 'Pontes Gestal',
			'state' => 26,
		]);
		DB::table('cities')->insert([
			'id' => 5159, 
			'name' => 'Populina',
			'state' => 26,
		]);
		DB::table('cities')->insert([
			'id' => 5160, 
			'name' => 'Porangaba',
			'state' => 26,
		]);
		DB::table('cities')->insert([
			'id' => 5161, 
			'name' => 'Porto Feliz',
			'state' => 26,
		]);
		DB::table('cities')->insert([
			'id' => 5162, 
			'name' => 'Porto Ferreira',
			'state' => 26,
		]);
		DB::table('cities')->insert([
			'id' => 5163, 
			'name' => 'Potim',
			'state' => 26,
		]);
		DB::table('cities')->insert([
			'id' => 5164, 
			'name' => 'Potirendaba',
			'state' => 26,
		]);
		DB::table('cities')->insert([
			'id' => 5165, 
			'name' => 'Pracinha',
			'state' => 26,
		]);
		DB::table('cities')->insert([
			'id' => 5166, 
			'name' => 'Pradópolis',
			'state' => 26,
		]);
		DB::table('cities')->insert([
			'id' => 5167, 
			'name' => 'Praia Grande',
			'state' => 26,
		]);
		DB::table('cities')->insert([
			'id' => 5168, 
			'name' => 'Pratânia',
			'state' => 26,
		]);
		DB::table('cities')->insert([
			'id' => 5169, 
			'name' => 'Presidente Alves',
			'state' => 26,
		]);
		DB::table('cities')->insert([
			'id' => 5170, 
			'name' => 'Presidente Bernardes',
			'state' => 26,
		]);
		DB::table('cities')->insert([
			'id' => 5171, 
			'name' => 'Presidente Epitácio',
			'state' => 26,
		]);
		DB::table('cities')->insert([
			'id' => 5172, 
			'name' => 'Presidente Prudente',
			'state' => 26,
		]);
		DB::table('cities')->insert([
			'id' => 5173, 
			'name' => 'Presidente Venceslau',
			'state' => 26,
		]);
		DB::table('cities')->insert([
			'id' => 5174, 
			'name' => 'Promissão',
			'state' => 26,
		]);
		DB::table('cities')->insert([
			'id' => 5175, 
			'name' => 'Quadra',
			'state' => 26,
		]);
		DB::table('cities')->insert([
			'id' => 5176, 
			'name' => 'Quatá',
			'state' => 26,
		]);
		DB::table('cities')->insert([
			'id' => 5177, 
			'name' => 'Queiroz',
			'state' => 26,
		]);
		DB::table('cities')->insert([
			'id' => 5178, 
			'name' => 'Queluz',
			'state' => 26,
		]);
		DB::table('cities')->insert([
			'id' => 5179, 
			'name' => 'Quintana',
			'state' => 26,
		]);
		DB::table('cities')->insert([
			'id' => 5180, 
			'name' => 'Rafard',
			'state' => 26,
		]);
		DB::table('cities')->insert([
			'id' => 5181, 
			'name' => 'Rancharia',
			'state' => 26,
		]);
		DB::table('cities')->insert([
			'id' => 5182, 
			'name' => 'Redenção da Serra',
			'state' => 26,
		]);
		DB::table('cities')->insert([
			'id' => 5183, 
			'name' => 'Regente Feijó',
			'state' => 26,
		]);
		DB::table('cities')->insert([
			'id' => 5184, 
			'name' => 'Reginópolis',
			'state' => 26,
		]);
		DB::table('cities')->insert([
			'id' => 5185, 
			'name' => 'Registro',
			'state' => 26,
		]);
		DB::table('cities')->insert([
			'id' => 5186, 
			'name' => 'Restinga',
			'state' => 26,
		]);
		DB::table('cities')->insert([
			'id' => 5187, 
			'name' => 'Ribeira',
			'state' => 26,
		]);
		DB::table('cities')->insert([
			'id' => 5188, 
			'name' => 'Ribeirão Bonito',
			'state' => 26,
		]);
		DB::table('cities')->insert([
			'id' => 5189, 
			'name' => 'Ribeirão Branco',
			'state' => 26,
		]);
		DB::table('cities')->insert([
			'id' => 5190, 
			'name' => 'Ribeirão Corrente',
			'state' => 26,
		]);
		DB::table('cities')->insert([
			'id' => 5191, 
			'name' => 'Ribeirão do Sul',
			'state' => 26,
		]);
		DB::table('cities')->insert([
			'id' => 5192, 
			'name' => 'Ribeirão dos Índios',
			'state' => 26,
		]);
		DB::table('cities')->insert([
			'id' => 5193, 
			'name' => 'Ribeirão Grande',
			'state' => 26,
		]);
		DB::table('cities')->insert([
			'id' => 5194, 
			'name' => 'Ribeirão Pires',
			'state' => 26,
		]);
		DB::table('cities')->insert([
			'id' => 5195, 
			'name' => 'Ribeirão Preto',
			'state' => 26,
		]);
		DB::table('cities')->insert([
			'id' => 5196, 
			'name' => 'Rifaina',
			'state' => 26,
		]);
		DB::table('cities')->insert([
			'id' => 5197, 
			'name' => 'Rincão',
			'state' => 26,
		]);
		DB::table('cities')->insert([
			'id' => 5198, 
			'name' => 'Rinópolis',
			'state' => 26,
		]);
		DB::table('cities')->insert([
			'id' => 5199, 
			'name' => 'Rio Claro',
			'state' => 26,
		]);
		DB::table('cities')->insert([
			'id' => 5200, 
			'name' => 'Rio das Pedras',
			'state' => 26,
		]);
		DB::table('cities')->insert([
			'id' => 5201, 
			'name' => 'Rio Grande da Serra',
			'state' => 26,
		]);
		DB::table('cities')->insert([
			'id' => 5202, 
			'name' => 'Riolândia',
			'state' => 26,
		]);
		DB::table('cities')->insert([
			'id' => 5203, 
			'name' => 'Riversul',
			'state' => 26,
		]);
		DB::table('cities')->insert([
			'id' => 5204, 
			'name' => 'Rosana',
			'state' => 26,
		]);
		DB::table('cities')->insert([
			'id' => 5205, 
			'name' => 'Roseira',
			'state' => 26,
		]);
		DB::table('cities')->insert([
			'id' => 5206, 
			'name' => 'Rubiácea',
			'state' => 26,
		]);
		DB::table('cities')->insert([
			'id' => 5207, 
			'name' => 'Rubinéia',
			'state' => 26,
		]);
		DB::table('cities')->insert([
			'id' => 5208, 
			'name' => 'Sabino',
			'state' => 26,
		]);
		DB::table('cities')->insert([
			'id' => 5209, 
			'name' => 'Sagres',
			'state' => 26,
		]);
		DB::table('cities')->insert([
			'id' => 5210, 
			'name' => 'Sales',
			'state' => 26,
		]);
		DB::table('cities')->insert([
			'id' => 5211, 
			'name' => 'Sales Oliveira',
			'state' => 26,
		]);
		DB::table('cities')->insert([
			'id' => 5212, 
			'name' => 'Salesópolis',
			'state' => 26,
		]);
		DB::table('cities')->insert([
			'id' => 5213, 
			'name' => 'Salmourão',
			'state' => 26,
		]);
		DB::table('cities')->insert([
			'id' => 5214, 
			'name' => 'Saltinho',
			'state' => 26,
		]);
		DB::table('cities')->insert([
			'id' => 5215, 
			'name' => 'Salto',
			'state' => 26,
		]);
		DB::table('cities')->insert([
			'id' => 5216, 
			'name' => 'Salto de Pirapora',
			'state' => 26,
		]);
		DB::table('cities')->insert([
			'id' => 5217, 
			'name' => 'Salto Grande',
			'state' => 26,
		]);
		DB::table('cities')->insert([
			'id' => 5218, 
			'name' => 'Sandovalina',
			'state' => 26,
		]);
		DB::table('cities')->insert([
			'id' => 5219, 
			'name' => 'Santa Adélia',
			'state' => 26,
		]);
		DB::table('cities')->insert([
			'id' => 5220, 
			'name' => 'Santa Albertina',
			'state' => 26,
		]);
		DB::table('cities')->insert([
			'id' => 5221, 
			'name' => 'Santa Bárbara d`Oeste',
			'state' => 26,
		]);
		DB::table('cities')->insert([
			'id' => 5222, 
			'name' => 'Santa Branca',
			'state' => 26,
		]);
		DB::table('cities')->insert([
			'id' => 5223, 
			'name' => 'Santa Clara d`Oeste',
			'state' => 26,
		]);
		DB::table('cities')->insert([
			'id' => 5224, 
			'name' => 'Santa Cruz da Conceição',
			'state' => 26,
		]);
		DB::table('cities')->insert([
			'id' => 5225, 
			'name' => 'Santa Cruz da Esperança',
			'state' => 26,
		]);
		DB::table('cities')->insert([
			'id' => 5226, 
			'name' => 'Santa Cruz das Palmeiras',
			'state' => 26,
		]);
		DB::table('cities')->insert([
			'id' => 5227, 
			'name' => 'Santa Cruz do Rio Pardo',
			'state' => 26,
		]);
		DB::table('cities')->insert([
			'id' => 5228, 
			'name' => 'Santa Ernestina',
			'state' => 26,
		]);
		DB::table('cities')->insert([
			'id' => 5229, 
			'name' => 'Santa Fé do Sul',
			'state' => 26,
		]);
		DB::table('cities')->insert([
			'id' => 5230, 
			'name' => 'Santa Gertrudes',
			'state' => 26,
		]);
		DB::table('cities')->insert([
			'id' => 5231, 
			'name' => 'Santa Isabel',
			'state' => 26,
		]);
		DB::table('cities')->insert([
			'id' => 5232, 
			'name' => 'Santa Lúcia',
			'state' => 26,
		]);
		DB::table('cities')->insert([
			'id' => 5233, 
			'name' => 'Santa Maria da Serra',
			'state' => 26,
		]);
		DB::table('cities')->insert([
			'id' => 5234, 
			'name' => 'Santa Mercedes',
			'state' => 26,
		]);
		DB::table('cities')->insert([
			'id' => 5235, 
			'name' => 'Santa Rita d`Oeste',
			'state' => 26,
		]);
		DB::table('cities')->insert([
			'id' => 5236, 
			'name' => 'Santa Rita do Passa Quatro',
			'state' => 26,
		]);
		DB::table('cities')->insert([
			'id' => 5237, 
			'name' => 'Santa Rosa de Viterbo',
			'state' => 26,
		]);
		DB::table('cities')->insert([
			'id' => 5238, 
			'name' => 'Santa Salete',
			'state' => 26,
		]);
		DB::table('cities')->insert([
			'id' => 5239, 
			'name' => 'Santana da Ponte Pensa',
			'state' => 26,
		]);
		DB::table('cities')->insert([
			'id' => 5240, 
			'name' => 'Santana de Parnaíba',
			'state' => 26,
		]);
		DB::table('cities')->insert([
			'id' => 5241, 
			'name' => 'Santo Anastácio',
			'state' => 26,
		]);
		DB::table('cities')->insert([
			'id' => 5242, 
			'name' => 'Santo André',
			'state' => 26,
		]);
		DB::table('cities')->insert([
			'id' => 5243, 
			'name' => 'Santo Antônio da Alegria',
			'state' => 26,
		]);
		DB::table('cities')->insert([
			'id' => 5244, 
			'name' => 'Santo Antônio de Posse',
			'state' => 26,
		]);
		DB::table('cities')->insert([
			'id' => 5245, 
			'name' => 'Santo Antônio do Aracanguá',
			'state' => 26,
		]);
		DB::table('cities')->insert([
			'id' => 5246, 
			'name' => 'Santo Antônio do Jardim',
			'state' => 26,
		]);
		DB::table('cities')->insert([
			'id' => 5247, 
			'name' => 'Santo Antônio do Pinhal',
			'state' => 26,
		]);
		DB::table('cities')->insert([
			'id' => 5248, 
			'name' => 'Santo Expedito',
			'state' => 26,
		]);
		DB::table('cities')->insert([
			'id' => 5249, 
			'name' => 'Santópolis do Aguapeí',
			'state' => 26,
		]);
		DB::table('cities')->insert([
			'id' => 5250, 
			'name' => 'Santos',
			'state' => 26,
		]);
		DB::table('cities')->insert([
			'id' => 5251, 
			'name' => 'São Bento do Sapucaí',
			'state' => 26,
		]);
		DB::table('cities')->insert([
			'id' => 5252, 
			'name' => 'São Bernardo do Campo',
			'state' => 26,
		]);
		DB::table('cities')->insert([
			'id' => 5253, 
			'name' => 'São Caetano do Sul',
			'state' => 26,
		]);
		DB::table('cities')->insert([
			'id' => 5254, 
			'name' => 'São Carlos',
			'state' => 26,
		]);
		DB::table('cities')->insert([
			'id' => 5255, 
			'name' => 'São Francisco',
			'state' => 26,
		]);
		DB::table('cities')->insert([
			'id' => 5256, 
			'name' => 'São João da Boa Vista',
			'state' => 26,
		]);
		DB::table('cities')->insert([
			'id' => 5257, 
			'name' => 'São João das Duas Pontes',
			'state' => 26,
		]);
		DB::table('cities')->insert([
			'id' => 5258, 
			'name' => 'São João de Iracema',
			'state' => 26,
		]);
		DB::table('cities')->insert([
			'id' => 5259, 
			'name' => 'São João do Pau d`Alho',
			'state' => 26,
		]);
		DB::table('cities')->insert([
			'id' => 5260, 
			'name' => 'São Joaquim da Barra',
			'state' => 26,
		]);
		DB::table('cities')->insert([
			'id' => 5261, 
			'name' => 'São José da Bela Vista',
			'state' => 26,
		]);
		DB::table('cities')->insert([
			'id' => 5262, 
			'name' => 'São José do Barreiro',
			'state' => 26,
		]);
		DB::table('cities')->insert([
			'id' => 5263, 
			'name' => 'São José do Rio Pardo',
			'state' => 26,
		]);
		DB::table('cities')->insert([
			'id' => 5264, 
			'name' => 'São José do Rio Preto',
			'state' => 26,
		]);
		DB::table('cities')->insert([
			'id' => 5265, 
			'name' => 'São José dos Campos',
			'state' => 26,
		]);
		DB::table('cities')->insert([
			'id' => 5266, 
			'name' => 'São Lourenço da Serra',
			'state' => 26,
		]);
		DB::table('cities')->insert([
			'id' => 5267, 
			'name' => 'São Luís do Paraitinga',
			'state' => 26,
		]);
		DB::table('cities')->insert([
			'id' => 5268, 
			'name' => 'São Manuel',
			'state' => 26,
		]);
		DB::table('cities')->insert([
			'id' => 5269, 
			'name' => 'São Miguel Arcanjo',
			'state' => 26,
		]);
		DB::table('cities')->insert([
			'id' => 5270, 
			'name' => 'São Paulo',
			'state' => 26,
		]);
		DB::table('cities')->insert([
			'id' => 5271, 
			'name' => 'São Pedro',
			'state' => 26,
		]);
		DB::table('cities')->insert([
			'id' => 5272, 
			'name' => 'São Pedro do Turvo',
			'state' => 26,
		]);
		DB::table('cities')->insert([
			'id' => 5273, 
			'name' => 'São Roque',
			'state' => 26,
		]);
		DB::table('cities')->insert([
			'id' => 5274, 
			'name' => 'São Sebastião',
			'state' => 26,
		]);
		DB::table('cities')->insert([
			'id' => 5275, 
			'name' => 'São Sebastião da Grama',
			'state' => 26,
		]);
		DB::table('cities')->insert([
			'id' => 5276, 
			'name' => 'São Simão',
			'state' => 26,
		]);
		DB::table('cities')->insert([
			'id' => 5277, 
			'name' => 'São Vicente',
			'state' => 26,
		]);
		DB::table('cities')->insert([
			'id' => 5278, 
			'name' => 'Sarapuí',
			'state' => 26,
		]);
		DB::table('cities')->insert([
			'id' => 5279, 
			'name' => 'Sarutaiá',
			'state' => 26,
		]);
		DB::table('cities')->insert([
			'id' => 5280, 
			'name' => 'Sebastianópolis do Sul',
			'state' => 26,
		]);
		DB::table('cities')->insert([
			'id' => 5281, 
			'name' => 'Serra Azul',
			'state' => 26,
		]);
		DB::table('cities')->insert([
			'id' => 5282, 
			'name' => 'Serra Negra',
			'state' => 26,
		]);
		DB::table('cities')->insert([
			'id' => 5283, 
			'name' => 'Serrana',
			'state' => 26,
		]);
		DB::table('cities')->insert([
			'id' => 5284, 
			'name' => 'Sertãozinho',
			'state' => 26,
		]);
		DB::table('cities')->insert([
			'id' => 5285, 
			'name' => 'Sete Barras',
			'state' => 26,
		]);
		DB::table('cities')->insert([
			'id' => 5286, 
			'name' => 'Severínia',
			'state' => 26,
		]);
		DB::table('cities')->insert([
			'id' => 5287, 
			'name' => 'Silveiras',
			'state' => 26,
		]);
		DB::table('cities')->insert([
			'id' => 5288, 
			'name' => 'Socorro',
			'state' => 26,
		]);
		DB::table('cities')->insert([
			'id' => 5289, 
			'name' => 'Sorocaba',
			'state' => 26,
		]);
		DB::table('cities')->insert([
			'id' => 5290, 
			'name' => 'Sud Mennucci',
			'state' => 26,
		]);
		DB::table('cities')->insert([
			'id' => 5291, 
			'name' => 'Sumaré',
			'state' => 26,
		]);
		DB::table('cities')->insert([
			'id' => 5292, 
			'name' => 'Suzanápolis',
			'state' => 26,
		]);
		DB::table('cities')->insert([
			'id' => 5293, 
			'name' => 'Suzano',
			'state' => 26,
		]);
		DB::table('cities')->insert([
			'id' => 5294, 
			'name' => 'Tabapuã',
			'state' => 26,
		]);
		DB::table('cities')->insert([
			'id' => 5295, 
			'name' => 'Tabatinga',
			'state' => 26,
		]);
		DB::table('cities')->insert([
			'id' => 5296, 
			'name' => 'Taboão da Serra',
			'state' => 26,
		]);
		DB::table('cities')->insert([
			'id' => 5297, 
			'name' => 'Taciba',
			'state' => 26,
		]);
		DB::table('cities')->insert([
			'id' => 5298, 
			'name' => 'Taguaí',
			'state' => 26,
		]);
		DB::table('cities')->insert([
			'id' => 5299, 
			'name' => 'Taiaçu',
			'state' => 26,
		]);
		DB::table('cities')->insert([
			'id' => 5300, 
			'name' => 'Taiúva',
			'state' => 26,
		]);
		DB::table('cities')->insert([
			'id' => 5301, 
			'name' => 'Tambaú',
			'state' => 26,
		]);
		DB::table('cities')->insert([
			'id' => 5302, 
			'name' => 'Tanabi',
			'state' => 26,
		]);
		DB::table('cities')->insert([
			'id' => 5303, 
			'name' => 'Tapiraí',
			'state' => 26,
		]);
		DB::table('cities')->insert([
			'id' => 5304, 
			'name' => 'Tapiratiba',
			'state' => 26,
		]);
		DB::table('cities')->insert([
			'id' => 5305, 
			'name' => 'Taquaral',
			'state' => 26,
		]);
		DB::table('cities')->insert([
			'id' => 5306, 
			'name' => 'Taquaritinga',
			'state' => 26,
		]);
		DB::table('cities')->insert([
			'id' => 5307, 
			'name' => 'Taquarituba',
			'state' => 26,
		]);
		DB::table('cities')->insert([
			'id' => 5308, 
			'name' => 'Taquarivaí',
			'state' => 26,
		]);
		DB::table('cities')->insert([
			'id' => 5309, 
			'name' => 'Tarabai',
			'state' => 26,
		]);
		DB::table('cities')->insert([
			'id' => 5310, 
			'name' => 'Tarumã',
			'state' => 26,
		]);
		DB::table('cities')->insert([
			'id' => 5311, 
			'name' => 'Tatuí',
			'state' => 26,
		]);
		DB::table('cities')->insert([
			'id' => 5312, 
			'name' => 'Taubaté',
			'state' => 26,
		]);
		DB::table('cities')->insert([
			'id' => 5313, 
			'name' => 'Tejupá',
			'state' => 26,
		]);
		DB::table('cities')->insert([
			'id' => 5314, 
			'name' => 'Teodoro Sampaio',
			'state' => 26,
		]);
		DB::table('cities')->insert([
			'id' => 5315, 
			'name' => 'Terra Roxa',
			'state' => 26,
		]);
		DB::table('cities')->insert([
			'id' => 5316, 
			'name' => 'Tietê',
			'state' => 26,
		]);
		DB::table('cities')->insert([
			'id' => 5317, 
			'name' => 'Timburi',
			'state' => 26,
		]);
		DB::table('cities')->insert([
			'id' => 5318, 
			'name' => 'Torre de Pedra',
			'state' => 26,
		]);
		DB::table('cities')->insert([
			'id' => 5319, 
			'name' => 'Torrinha',
			'state' => 26,
		]);
		DB::table('cities')->insert([
			'id' => 5320, 
			'name' => 'Trabiju',
			'state' => 26,
		]);
		DB::table('cities')->insert([
			'id' => 5321, 
			'name' => 'Tremembé',
			'state' => 26,
		]);
		DB::table('cities')->insert([
			'id' => 5322, 
			'name' => 'Três Fronteiras',
			'state' => 26,
		]);
		DB::table('cities')->insert([
			'id' => 5323, 
			'name' => 'Tuiuti',
			'state' => 26,
		]);
		DB::table('cities')->insert([
			'id' => 5324, 
			'name' => 'Tupã',
			'state' => 26,
		]);
		DB::table('cities')->insert([
			'id' => 5325, 
			'name' => 'Tupi Paulista',
			'state' => 26,
		]);
		DB::table('cities')->insert([
			'id' => 5326, 
			'name' => 'Turiúba',
			'state' => 26,
		]);
		DB::table('cities')->insert([
			'id' => 5327, 
			'name' => 'Turmalina',
			'state' => 26,
		]);
		DB::table('cities')->insert([
			'id' => 5328, 
			'name' => 'Ubarana',
			'state' => 26,
		]);
		DB::table('cities')->insert([
			'id' => 5329, 
			'name' => 'Ubatuba',
			'state' => 26,
		]);
		DB::table('cities')->insert([
			'id' => 5330, 
			'name' => 'Ubirajara',
			'state' => 26,
		]);
		DB::table('cities')->insert([
			'id' => 5331, 
			'name' => 'Uchoa',
			'state' => 26,
		]);
		DB::table('cities')->insert([
			'id' => 5332, 
			'name' => 'União Paulista',
			'state' => 26,
		]);
		DB::table('cities')->insert([
			'id' => 5333, 
			'name' => 'Urânia',
			'state' => 26,
		]);
		DB::table('cities')->insert([
			'id' => 5334, 
			'name' => 'Uru',
			'state' => 26,
		]);
		DB::table('cities')->insert([
			'id' => 5335, 
			'name' => 'Urupês',
			'state' => 26,
		]);
		DB::table('cities')->insert([
			'id' => 5336, 
			'name' => 'Valentim Gentil',
			'state' => 26,
		]);
		DB::table('cities')->insert([
			'id' => 5337, 
			'name' => 'Valinhos',
			'state' => 26,
		]);
		DB::table('cities')->insert([
			'id' => 5338, 
			'name' => 'Valparaíso',
			'state' => 26,
		]);
		DB::table('cities')->insert([
			'id' => 5339, 
			'name' => 'Vargem',
			'state' => 26,
		]);
		DB::table('cities')->insert([
			'id' => 5340, 
			'name' => 'Vargem Grande do Sul',
			'state' => 26,
		]);
		DB::table('cities')->insert([
			'id' => 5341, 
			'name' => 'Vargem Grande Paulista',
			'state' => 26,
		]);
		DB::table('cities')->insert([
			'id' => 5342, 
			'name' => 'Várzea Paulista',
			'state' => 26,
		]);
		DB::table('cities')->insert([
			'id' => 5343, 
			'name' => 'Vera Cruz',
			'state' => 26,
		]);
		DB::table('cities')->insert([
			'id' => 5344, 
			'name' => 'Vinhedo',
			'state' => 26,
		]);
		DB::table('cities')->insert([
			'id' => 5345, 
			'name' => 'Viradouro',
			'state' => 26,
		]);
		DB::table('cities')->insert([
			'id' => 5346, 
			'name' => 'Vista Alegre do Alto',
			'state' => 26,
		]);
		DB::table('cities')->insert([
			'id' => 5347, 
			'name' => 'Vitória Brasil',
			'state' => 26,
		]);
		DB::table('cities')->insert([
			'id' => 5348, 
			'name' => 'Votorantim',
			'state' => 26,
		]);
		DB::table('cities')->insert([
			'id' => 5349, 
			'name' => 'Votuporanga',
			'state' => 26,
		]);
		DB::table('cities')->insert([
			'id' => 5350, 
			'name' => 'Zacarias',
			'state' => 26,
		]);
		DB::table('cities')->insert([
			'id' => 5351, 
			'name' => 'Amparo de São Francisco',
			'state' => 25,
		]);
		DB::table('cities')->insert([
			'id' => 5352, 
			'name' => 'Aquidabã',
			'state' => 25,
		]);
		DB::table('cities')->insert([
			'id' => 5353, 
			'name' => 'Aracaju',
			'state' => 25,
		]);
		DB::table('cities')->insert([
			'id' => 5354, 
			'name' => 'Arauá',
			'state' => 25,
		]);
		DB::table('cities')->insert([
			'id' => 5355, 
			'name' => 'Areia Branca',
			'state' => 25,
		]);
		DB::table('cities')->insert([
			'id' => 5356, 
			'name' => 'Barra dos Coqueiros',
			'state' => 25,
		]);
		DB::table('cities')->insert([
			'id' => 5357, 
			'name' => 'Boquim',
			'state' => 25,
		]);
		DB::table('cities')->insert([
			'id' => 5358, 
			'name' => 'Brejo Grande',
			'state' => 25,
		]);
		DB::table('cities')->insert([
			'id' => 5359, 
			'name' => 'Campo do Brito',
			'state' => 25,
		]);
		DB::table('cities')->insert([
			'id' => 5360, 
			'name' => 'Canhoba',
			'state' => 25,
		]);
		DB::table('cities')->insert([
			'id' => 5361, 
			'name' => 'Canindé de São Francisco',
			'state' => 25,
		]);
		DB::table('cities')->insert([
			'id' => 5362, 
			'name' => 'Capela',
			'state' => 25,
		]);
		DB::table('cities')->insert([
			'id' => 5363, 
			'name' => 'Carira',
			'state' => 25,
		]);
		DB::table('cities')->insert([
			'id' => 5364, 
			'name' => 'Carmópolis',
			'state' => 25,
		]);
		DB::table('cities')->insert([
			'id' => 5365, 
			'name' => 'Cedro de São João',
			'state' => 25,
		]);
		DB::table('cities')->insert([
			'id' => 5366, 
			'name' => 'Cristinápolis',
			'state' => 25,
		]);
		DB::table('cities')->insert([
			'id' => 5367, 
			'name' => 'Cumbe',
			'state' => 25,
		]);
		DB::table('cities')->insert([
			'id' => 5368, 
			'name' => 'Divina Pastora',
			'state' => 25,
		]);
		DB::table('cities')->insert([
			'id' => 5369, 
			'name' => 'Estância',
			'state' => 25,
		]);
		DB::table('cities')->insert([
			'id' => 5370, 
			'name' => 'Feira Nova',
			'state' => 25,
		]);
		DB::table('cities')->insert([
			'id' => 5371, 
			'name' => 'Frei Paulo',
			'state' => 25,
		]);
		DB::table('cities')->insert([
			'id' => 5372, 
			'name' => 'Gararu',
			'state' => 25,
		]);
		DB::table('cities')->insert([
			'id' => 5373, 
			'name' => 'General Maynard',
			'state' => 25,
		]);
		DB::table('cities')->insert([
			'id' => 5374, 
			'name' => 'Gracho Cardoso',
			'state' => 25,
		]);
		DB::table('cities')->insert([
			'id' => 5375, 
			'name' => 'Ilha das Flores',
			'state' => 25,
		]);
		DB::table('cities')->insert([
			'id' => 5376, 
			'name' => 'Indiaroba',
			'state' => 25,
		]);
		DB::table('cities')->insert([
			'id' => 5377, 
			'name' => 'Itabaiana',
			'state' => 25,
		]);
		DB::table('cities')->insert([
			'id' => 5378, 
			'name' => 'Itabaianinha',
			'state' => 25,
		]);
		DB::table('cities')->insert([
			'id' => 5379, 
			'name' => 'Itabi',
			'state' => 25,
		]);
		DB::table('cities')->insert([
			'id' => 5380, 
			'name' => 'Itaporanga d`Ajuda',
			'state' => 25,
		]);
		DB::table('cities')->insert([
			'id' => 5381, 
			'name' => 'Japaratuba',
			'state' => 25,
		]);
		DB::table('cities')->insert([
			'id' => 5382, 
			'name' => 'Japoatã',
			'state' => 25,
		]);
		DB::table('cities')->insert([
			'id' => 5383, 
			'name' => 'Lagarto',
			'state' => 25,
		]);
		DB::table('cities')->insert([
			'id' => 5384, 
			'name' => 'Laranjeiras',
			'state' => 25,
		]);
		DB::table('cities')->insert([
			'id' => 5385, 
			'name' => 'Macambira',
			'state' => 25,
		]);
		DB::table('cities')->insert([
			'id' => 5386, 
			'name' => 'Malhada dos Bois',
			'state' => 25,
		]);
		DB::table('cities')->insert([
			'id' => 5387, 
			'name' => 'Malhador',
			'state' => 25,
		]);
		DB::table('cities')->insert([
			'id' => 5388, 
			'name' => 'Maruim',
			'state' => 25,
		]);
		DB::table('cities')->insert([
			'id' => 5389, 
			'name' => 'Moita Bonita',
			'state' => 25,
		]);
		DB::table('cities')->insert([
			'id' => 5390, 
			'name' => 'Monte Alegre de Sergipe',
			'state' => 25,
		]);
		DB::table('cities')->insert([
			'id' => 5391, 
			'name' => 'Muribeca',
			'state' => 25,
		]);
		DB::table('cities')->insert([
			'id' => 5392, 
			'name' => 'Neópolis',
			'state' => 25,
		]);
		DB::table('cities')->insert([
			'id' => 5393, 
			'name' => 'Nossa Senhora Aparecida',
			'state' => 25,
		]);
		DB::table('cities')->insert([
			'id' => 5394, 
			'name' => 'Nossa Senhora da Glória',
			'state' => 25,
		]);
		DB::table('cities')->insert([
			'id' => 5395, 
			'name' => 'Nossa Senhora das Dores',
			'state' => 25,
		]);
		DB::table('cities')->insert([
			'id' => 5396, 
			'name' => 'Nossa Senhora de Lourdes',
			'state' => 25,
		]);
		DB::table('cities')->insert([
			'id' => 5397, 
			'name' => 'Nossa Senhora do Socorro',
			'state' => 25,
		]);
		DB::table('cities')->insert([
			'id' => 5398, 
			'name' => 'Pacatuba',
			'state' => 25,
		]);
		DB::table('cities')->insert([
			'id' => 5399, 
			'name' => 'Pedra Mole',
			'state' => 25,
		]);
		DB::table('cities')->insert([
			'id' => 5400, 
			'name' => 'Pedrinhas',
			'state' => 25,
		]);
		DB::table('cities')->insert([
			'id' => 5401, 
			'name' => 'Pinhão',
			'state' => 25,
		]);
		DB::table('cities')->insert([
			'id' => 5402, 
			'name' => 'Pirambu',
			'state' => 25,
		]);
		DB::table('cities')->insert([
			'id' => 5403, 
			'name' => 'Poço Redondo',
			'state' => 25,
		]);
		DB::table('cities')->insert([
			'id' => 5404, 
			'name' => 'Poço Verde',
			'state' => 25,
		]);
		DB::table('cities')->insert([
			'id' => 5405, 
			'name' => 'Porto da Folha',
			'state' => 25,
		]);
		DB::table('cities')->insert([
			'id' => 5406, 
			'name' => 'Propriá',
			'state' => 25,
		]);
		DB::table('cities')->insert([
			'id' => 5407, 
			'name' => 'Riachão do Dantas',
			'state' => 25,
		]);
		DB::table('cities')->insert([
			'id' => 5408, 
			'name' => 'Riachuelo',
			'state' => 25,
		]);
		DB::table('cities')->insert([
			'id' => 5409, 
			'name' => 'Ribeirópolis',
			'state' => 25,
		]);
		DB::table('cities')->insert([
			'id' => 5410, 
			'name' => 'Rosário do Catete',
			'state' => 25,
		]);
		DB::table('cities')->insert([
			'id' => 5411, 
			'name' => 'Salgado',
			'state' => 25,
		]);
		DB::table('cities')->insert([
			'id' => 5412, 
			'name' => 'Santa Luzia do Itanhy',
			'state' => 25,
		]);
		DB::table('cities')->insert([
			'id' => 5413, 
			'name' => 'Santa Rosa de Lima',
			'state' => 25,
		]);
		DB::table('cities')->insert([
			'id' => 5414, 
			'name' => 'Santana do São Francisco',
			'state' => 25,
		]);
		DB::table('cities')->insert([
			'id' => 5415, 
			'name' => 'Santo Amaro das Brotas',
			'state' => 25,
		]);
		DB::table('cities')->insert([
			'id' => 5416, 
			'name' => 'São Cristóvão',
			'state' => 25,
		]);
		DB::table('cities')->insert([
			'id' => 5417, 
			'name' => 'São Domingos',
			'state' => 25,
		]);
		DB::table('cities')->insert([
			'id' => 5418, 
			'name' => 'São Francisco',
			'state' => 25,
		]);
		DB::table('cities')->insert([
			'id' => 5419, 
			'name' => 'São Miguel do Aleixo',
			'state' => 25,
		]);
		DB::table('cities')->insert([
			'id' => 5420, 
			'name' => 'Simão Dias',
			'state' => 25,
		]);
		DB::table('cities')->insert([
			'id' => 5421, 
			'name' => 'Siriri',
			'state' => 25,
		]);
		DB::table('cities')->insert([
			'id' => 5422, 
			'name' => 'Telha',
			'state' => 25,
		]);
		DB::table('cities')->insert([
			'id' => 5423, 
			'name' => 'Tobias Barreto',
			'state' => 25,
		]);
		DB::table('cities')->insert([
			'id' => 5424, 
			'name' => 'Tomar do Geru',
			'state' => 25,
		]);
		DB::table('cities')->insert([
			'id' => 5425, 
			'name' => 'Umbaúba',
			'state' => 25,
		]);
		DB::table('cities')->insert([
			'id' => 5426, 
			'name' => 'Abreulândia',
			'state' => 27,
		]);
		DB::table('cities')->insert([
			'id' => 5427, 
			'name' => 'Aguiarnópolis',
			'state' => 27,
		]);
		DB::table('cities')->insert([
			'id' => 5428, 
			'name' => 'Aliança do Tocantins',
			'state' => 27,
		]);
		DB::table('cities')->insert([
			'id' => 5429, 
			'name' => 'Almas',
			'state' => 27,
		]);
		DB::table('cities')->insert([
			'id' => 5430, 
			'name' => 'Alvorada',
			'state' => 27,
		]);
		DB::table('cities')->insert([
			'id' => 5431, 
			'name' => 'Ananás',
			'state' => 27,
		]);
		DB::table('cities')->insert([
			'id' => 5432, 
			'name' => 'Angico',
			'state' => 27,
		]);
		DB::table('cities')->insert([
			'id' => 5433, 
			'name' => 'Aparecida do Rio Negro',
			'state' => 27,
		]);
		DB::table('cities')->insert([
			'id' => 5434, 
			'name' => 'Aragominas',
			'state' => 27,
		]);
		DB::table('cities')->insert([
			'id' => 5435, 
			'name' => 'Araguacema',
			'state' => 27,
		]);
		DB::table('cities')->insert([
			'id' => 5436, 
			'name' => 'Araguaçu',
			'state' => 27,
		]);
		DB::table('cities')->insert([
			'id' => 5437, 
			'name' => 'Araguaína',
			'state' => 27,
		]);
		DB::table('cities')->insert([
			'id' => 5438, 
			'name' => 'Araguanã',
			'state' => 27,
		]);
		DB::table('cities')->insert([
			'id' => 5439, 
			'name' => 'Araguatins',
			'state' => 27,
		]);
		DB::table('cities')->insert([
			'id' => 5440, 
			'name' => 'Arapoema',
			'state' => 27,
		]);
		DB::table('cities')->insert([
			'id' => 5441, 
			'name' => 'Arraias',
			'state' => 27,
		]);
		DB::table('cities')->insert([
			'id' => 5442, 
			'name' => 'Augustinópolis',
			'state' => 27,
		]);
		DB::table('cities')->insert([
			'id' => 5443, 
			'name' => 'Aurora do Tocantins',
			'state' => 27,
		]);
		DB::table('cities')->insert([
			'id' => 5444, 
			'name' => 'Axixá do Tocantins',
			'state' => 27,
		]);
		DB::table('cities')->insert([
			'id' => 5445, 
			'name' => 'Babaçulândia',
			'state' => 27,
		]);
		DB::table('cities')->insert([
			'id' => 5446, 
			'name' => 'Bandeirantes do Tocantins',
			'state' => 27,
		]);
		DB::table('cities')->insert([
			'id' => 5447, 
			'name' => 'Barra do Ouro',
			'state' => 27,
		]);
		DB::table('cities')->insert([
			'id' => 5448, 
			'name' => 'Barrolândia',
			'state' => 27,
		]);
		DB::table('cities')->insert([
			'id' => 5449, 
			'name' => 'Bernardo Sayão',
			'state' => 27,
		]);
		DB::table('cities')->insert([
			'id' => 5450, 
			'name' => 'Bom Jesus do Tocantins',
			'state' => 27,
		]);
		DB::table('cities')->insert([
			'id' => 5451, 
			'name' => 'Brasilândia do Tocantins',
			'state' => 27,
		]);
		DB::table('cities')->insert([
			'id' => 5452, 
			'name' => 'Brejinho de Nazaré',
			'state' => 27,
		]);
		DB::table('cities')->insert([
			'id' => 5453, 
			'name' => 'Buriti do Tocantins',
			'state' => 27,
		]);
		DB::table('cities')->insert([
			'id' => 5454, 
			'name' => 'Cachoeirinha',
			'state' => 27,
		]);
		DB::table('cities')->insert([
			'id' => 5455, 
			'name' => 'Campos Lindos',
			'state' => 27,
		]);
		DB::table('cities')->insert([
			'id' => 5456, 
			'name' => 'Cariri do Tocantins',
			'state' => 27,
		]);
		DB::table('cities')->insert([
			'id' => 5457, 
			'name' => 'Carmolândia',
			'state' => 27,
		]);
		DB::table('cities')->insert([
			'id' => 5458, 
			'name' => 'Carrasco Bonito',
			'state' => 27,
		]);
		DB::table('cities')->insert([
			'id' => 5459, 
			'name' => 'Caseara',
			'state' => 27,
		]);
		DB::table('cities')->insert([
			'id' => 5460, 
			'name' => 'Centenário',
			'state' => 27,
		]);
		DB::table('cities')->insert([
			'id' => 5461, 
			'name' => 'Chapada da Natividade',
			'state' => 27,
		]);
		DB::table('cities')->insert([
			'id' => 5462, 
			'name' => 'Chapada de Areia',
			'state' => 27,
		]);
		DB::table('cities')->insert([
			'id' => 5463, 
			'name' => 'Colinas do Tocantins',
			'state' => 27,
		]);
		DB::table('cities')->insert([
			'id' => 5464, 
			'name' => 'Colméia',
			'state' => 27,
		]);
		DB::table('cities')->insert([
			'id' => 5465, 
			'name' => 'Combinado',
			'state' => 27,
		]);
		DB::table('cities')->insert([
			'id' => 5466, 
			'name' => 'Conceição do Tocantins',
			'state' => 27,
		]);
		DB::table('cities')->insert([
			'id' => 5467, 
			'name' => 'Couto de Magalhães',
			'state' => 27,
		]);
		DB::table('cities')->insert([
			'id' => 5468, 
			'name' => 'Cristalândia',
			'state' => 27,
		]);
		DB::table('cities')->insert([
			'id' => 5469, 
			'name' => 'Crixás do Tocantins',
			'state' => 27,
		]);
		DB::table('cities')->insert([
			'id' => 5470, 
			'name' => 'Darcinópolis',
			'state' => 27,
		]);
		DB::table('cities')->insert([
			'id' => 5471, 
			'name' => 'Dianópolis',
			'state' => 27,
		]);
		DB::table('cities')->insert([
			'id' => 5472, 
			'name' => 'Divinópolis do Tocantins',
			'state' => 27,
		]);
		DB::table('cities')->insert([
			'id' => 5473, 
			'name' => 'Dois Irmãos do Tocantins',
			'state' => 27,
		]);
		DB::table('cities')->insert([
			'id' => 5474, 
			'name' => 'Dueré',
			'state' => 27,
		]);
		DB::table('cities')->insert([
			'id' => 5475, 
			'name' => 'Esperantina',
			'state' => 27,
		]);
		DB::table('cities')->insert([
			'id' => 5476, 
			'name' => 'Fátima',
			'state' => 27,
		]);
		DB::table('cities')->insert([
			'id' => 5477, 
			'name' => 'Figueirópolis',
			'state' => 27,
		]);
		DB::table('cities')->insert([
			'id' => 5478, 
			'name' => 'Filadélfia',
			'state' => 27,
		]);
		DB::table('cities')->insert([
			'id' => 5479, 
			'name' => 'Formoso do Araguaia',
			'state' => 27,
		]);
		DB::table('cities')->insert([
			'id' => 5480, 
			'name' => 'Fortaleza do Tabocão',
			'state' => 27,
		]);
		DB::table('cities')->insert([
			'id' => 5481, 
			'name' => 'Goianorte',
			'state' => 27,
		]);
		DB::table('cities')->insert([
			'id' => 5482, 
			'name' => 'Goiatins',
			'state' => 27,
		]);
		DB::table('cities')->insert([
			'id' => 5483, 
			'name' => 'Guaraí',
			'state' => 27,
		]);
		DB::table('cities')->insert([
			'id' => 5484, 
			'name' => 'Gurupi',
			'state' => 27,
		]);
		DB::table('cities')->insert([
			'id' => 5485, 
			'name' => 'Ipueiras',
			'state' => 27,
		]);
		DB::table('cities')->insert([
			'id' => 5486, 
			'name' => 'Itacajá',
			'state' => 27,
		]);
		DB::table('cities')->insert([
			'id' => 5487, 
			'name' => 'Itaguatins',
			'state' => 27,
		]);
		DB::table('cities')->insert([
			'id' => 5488, 
			'name' => 'Itapiratins',
			'state' => 27,
		]);
		DB::table('cities')->insert([
			'id' => 5489, 
			'name' => 'Itaporã do Tocantins',
			'state' => 27,
		]);
		DB::table('cities')->insert([
			'id' => 5490, 
			'name' => 'Jaú do Tocantins',
			'state' => 27,
		]);
		DB::table('cities')->insert([
			'id' => 5491, 
			'name' => 'Juarina',
			'state' => 27,
		]);
		DB::table('cities')->insert([
			'id' => 5492, 
			'name' => 'Lagoa da Confusão',
			'state' => 27,
		]);
		DB::table('cities')->insert([
			'id' => 5493, 
			'name' => 'Lagoa do Tocantins',
			'state' => 27,
		]);
		DB::table('cities')->insert([
			'id' => 5494, 
			'name' => 'Lajeado',
			'state' => 27,
		]);
		DB::table('cities')->insert([
			'id' => 5495, 
			'name' => 'Lavandeira',
			'state' => 27,
		]);
		DB::table('cities')->insert([
			'id' => 5496, 
			'name' => 'Lizarda',
			'state' => 27,
		]);
		DB::table('cities')->insert([
			'id' => 5497, 
			'name' => 'Luzinópolis',
			'state' => 27,
		]);
		DB::table('cities')->insert([
			'id' => 5498, 
			'name' => 'Marianópolis do Tocantins',
			'state' => 27,
		]);
		DB::table('cities')->insert([
			'id' => 5499, 
			'name' => 'Mateiros',
			'state' => 27,
		]);
		DB::table('cities')->insert([
			'id' => 5500, 
			'name' => 'Maurilândia do Tocantins',
			'state' => 27,
		]);
		DB::table('cities')->insert([
			'id' => 5501, 
			'name' => 'Miracema do Tocantins',
			'state' => 27,
		]);
		DB::table('cities')->insert([
			'id' => 5502, 
			'name' => 'Miranorte',
			'state' => 27,
		]);
		DB::table('cities')->insert([
			'id' => 5503, 
			'name' => 'Monte do Carmo',
			'state' => 27,
		]);
		DB::table('cities')->insert([
			'id' => 5504, 
			'name' => 'Monte Santo do Tocantins',
			'state' => 27,
		]);
		DB::table('cities')->insert([
			'id' => 5505, 
			'name' => 'Muricilândia',
			'state' => 27,
		]);
		DB::table('cities')->insert([
			'id' => 5506, 
			'name' => 'Natividade',
			'state' => 27,
		]);
		DB::table('cities')->insert([
			'id' => 5507, 
			'name' => 'Nazaré',
			'state' => 27,
		]);
		DB::table('cities')->insert([
			'id' => 5508, 
			'name' => 'Nova Olinda',
			'state' => 27,
		]);
		DB::table('cities')->insert([
			'id' => 5509, 
			'name' => 'Nova Rosalândia',
			'state' => 27,
		]);
		DB::table('cities')->insert([
			'id' => 5510, 
			'name' => 'Novo Acordo',
			'state' => 27,
		]);
		DB::table('cities')->insert([
			'id' => 5511, 
			'name' => 'Novo Alegre',
			'state' => 27,
		]);
		DB::table('cities')->insert([
			'id' => 5512, 
			'name' => 'Novo Jardim',
			'state' => 27,
		]);
		DB::table('cities')->insert([
			'id' => 5513, 
			'name' => 'Oliveira de Fátima',
			'state' => 27,
		]);
		DB::table('cities')->insert([
			'id' => 5514, 
			'name' => 'Palmas',
			'state' => 27,
		]);
		DB::table('cities')->insert([
			'id' => 5515, 
			'name' => 'Palmeirante',
			'state' => 27,
		]);
		DB::table('cities')->insert([
			'id' => 5516, 
			'name' => 'Palmeiras do Tocantins',
			'state' => 27,
		]);
		DB::table('cities')->insert([
			'id' => 5517, 
			'name' => 'Palmeirópolis',
			'state' => 27,
		]);
		DB::table('cities')->insert([
			'id' => 5518, 
			'name' => 'Paraíso do Tocantins',
			'state' => 27,
		]);
		DB::table('cities')->insert([
			'id' => 5519, 
			'name' => 'Paranã',
			'state' => 27,
		]);
		DB::table('cities')->insert([
			'id' => 5520, 
			'name' => 'Pau d`Arco',
			'state' => 27,
		]);
		DB::table('cities')->insert([
			'id' => 5521, 
			'name' => 'Pedro Afonso',
			'state' => 27,
		]);
		DB::table('cities')->insert([
			'id' => 5522, 
			'name' => 'Peixe',
			'state' => 27,
		]);
		DB::table('cities')->insert([
			'id' => 5523, 
			'name' => 'Pequizeiro',
			'state' => 27,
		]);
		DB::table('cities')->insert([
			'id' => 5524, 
			'name' => 'Pindorama do Tocantins',
			'state' => 27,
		]);
		DB::table('cities')->insert([
			'id' => 5525, 
			'name' => 'Piraquê',
			'state' => 27,
		]);
		DB::table('cities')->insert([
			'id' => 5526, 
			'name' => 'Pium',
			'state' => 27,
		]);
		DB::table('cities')->insert([
			'id' => 5527, 
			'name' => 'Ponte Alta do Bom Jesus',
			'state' => 27,
		]);
		DB::table('cities')->insert([
			'id' => 5528, 
			'name' => 'Ponte Alta do Tocantins',
			'state' => 27,
		]);
		DB::table('cities')->insert([
			'id' => 5529, 
			'name' => 'Porto Alegre do Tocantins',
			'state' => 27,
		]);
		DB::table('cities')->insert([
			'id' => 5530, 
			'name' => 'Porto Nacional',
			'state' => 27,
		]);
		DB::table('cities')->insert([
			'id' => 5531, 
			'name' => 'Praia Norte',
			'state' => 27,
		]);
		DB::table('cities')->insert([
			'id' => 5532, 
			'name' => 'Presidente Kennedy',
			'state' => 27,
		]);
		DB::table('cities')->insert([
			'id' => 5533, 
			'name' => 'Pugmil',
			'state' => 27,
		]);
		DB::table('cities')->insert([
			'id' => 5534, 
			'name' => 'Recursolândia',
			'state' => 27,
		]);
		DB::table('cities')->insert([
			'id' => 5535, 
			'name' => 'Riachinho',
			'state' => 27,
		]);
		DB::table('cities')->insert([
			'id' => 5536, 
			'name' => 'Rio da Conceição',
			'state' => 27,
		]);
		DB::table('cities')->insert([
			'id' => 5537, 
			'name' => 'Rio dos Bois',
			'state' => 27,
		]);
		DB::table('cities')->insert([
			'id' => 5538, 
			'name' => 'Rio Sono',
			'state' => 27,
		]);
		DB::table('cities')->insert([
			'id' => 5539, 
			'name' => 'Sampaio',
			'state' => 27,
		]);
		DB::table('cities')->insert([
			'id' => 5540, 
			'name' => 'Sandolândia',
			'state' => 27,
		]);
		DB::table('cities')->insert([
			'id' => 5541, 
			'name' => 'Santa Fé do Araguaia',
			'state' => 27,
		]);
		DB::table('cities')->insert([
			'id' => 5542, 
			'name' => 'Santa Maria do Tocantins',
			'state' => 27,
		]);
		DB::table('cities')->insert([
			'id' => 5543, 
			'name' => 'Santa Rita do Tocantins',
			'state' => 27,
		]);
		DB::table('cities')->insert([
			'id' => 5544, 
			'name' => 'Santa Rosa do Tocantins',
			'state' => 27,
		]);
		DB::table('cities')->insert([
			'id' => 5545, 
			'name' => 'Santa Tereza do Tocantins',
			'state' => 27,
		]);
		DB::table('cities')->insert([
			'id' => 5546, 
			'name' => 'Santa Terezinha do Tocantins',
			'state' => 27,
		]);
		DB::table('cities')->insert([
			'id' => 5547, 
			'name' => 'São Bento do Tocantins',
			'state' => 27,
		]);
		DB::table('cities')->insert([
			'id' => 5548, 
			'name' => 'São Félix do Tocantins',
			'state' => 27,
		]);
		DB::table('cities')->insert([
			'id' => 5549, 
			'name' => 'São Miguel do Tocantins',
			'state' => 27,
		]);
		DB::table('cities')->insert([
			'id' => 5550, 
			'name' => 'São Salvador do Tocantins',
			'state' => 27,
		]);
		DB::table('cities')->insert([
			'id' => 5551, 
			'name' => 'São Sebastião do Tocantins',
			'state' => 27,
		]);
		DB::table('cities')->insert([
			'id' => 5552, 
			'name' => 'São Valério da Natividade',
			'state' => 27,
		]);
		DB::table('cities')->insert([
			'id' => 5553, 
			'name' => 'Silvanópolis',
			'state' => 27,
		]);
		DB::table('cities')->insert([
			'id' => 5554, 
			'name' => 'Sítio Novo do Tocantins',
			'state' => 27,
		]);
		DB::table('cities')->insert([
			'id' => 5555, 
			'name' => 'Sucupira',
			'state' => 27,
		]);
		DB::table('cities')->insert([
			'id' => 5556, 
			'name' => 'Taguatinga',
			'state' => 27,
		]);
		DB::table('cities')->insert([
			'id' => 5557, 
			'name' => 'Taipas do Tocantins',
			'state' => 27,
		]);
		DB::table('cities')->insert([
			'id' => 5558, 
			'name' => 'Talismã',
			'state' => 27,
		]);
		DB::table('cities')->insert([
			'id' => 5559, 
			'name' => 'Tocantínia',
			'state' => 27,
		]);
		DB::table('cities')->insert([
			'id' => 5560, 
			'name' => 'Tocantinópolis',
			'state' => 27,
		]);
		DB::table('cities')->insert([
			'id' => 5561, 
			'name' => 'Tupirama',
			'state' => 27,
		]);
		DB::table('cities')->insert([
			'id' => 5562, 
			'name' => 'Tupiratins',
			'state' => 27,
		]);
		DB::table('cities')->insert([
			'id' => 5563, 
			'name' => 'Wanderlândia',
			'state' => 27,
		]);
		DB::table('cities')->insert([
			'id' => 5564, 
			'name' => 'Xambioá',
			'state' => 27,
		]);

    }
}
